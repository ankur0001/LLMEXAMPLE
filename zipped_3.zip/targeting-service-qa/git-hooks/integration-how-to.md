# Git Hooks & Spotless — Quick Setup

This setup assumes you want to use these git-hooks as we have implemented them, which includes using
Spotless for code formatting and linting. If you do not want Spotless, you will need to manually
remove it from the `pre-commit` hook and update `code-quality.gradle`.

## Setup (3 steps)

1. **Copy files to project root:**
    - `git-hooks/` folder
    - `code-quality.gradle`

2. **Add to build.gradle:**
   ```groovy
   plugins {
       id 'com.diffplug.spotless' version '8.0.0'
   }
   apply from: 'code-quality.gradle'
   ```

3. **Install hooks:**
   ```bash
   ./gradlew installGitHooks
   ```
