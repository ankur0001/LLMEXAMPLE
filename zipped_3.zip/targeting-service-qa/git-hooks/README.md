# Git Hooks

The automatic git hooks in this directory are used to enforce coding standards, improve code
quality by running checks before commits and pushes and auto-format commit messages for DORA. To
integrate these hooks with your own repository, please follow the instructions in
[integration instructions](integration-how-to.md).

## Hooks provided:

1. **prepare-commit-msg**:

- **NOTE**: Branch name must be in the format `<type>_<project>-<issue-number>` or
  `<type>_<project>-<issue-number>_<description>` for the hook to extract accurate default values.
    - Example: `fix_FCSDRMXX-1337`
    - Example w/ description: `feat_FCSDRMXX-1337_my-AMAZING-feature`
- This hook formats the commit message to fit the required convention format.
- If no type is provided in the commit message, it will default to type specified in branch name, or
  `feat` if no type was specified in the branch name.
- If no scope is provided in the commit message, it will default to `Spring`.
- To specify a type in commit message, use the shorthand format: `type_scope {commit message} `
- For example:
  ```bash
   git commit -m "fix_pipeline Example commit message"
  # would result in a commit message like:
  # fix(Pipeline): [#FCSDRMXX-1337] Example commit message

  # OR Default type and scope
   git commit -m "Example commit message"
   # would result in a commit message like:
   # feat(Spring): [#FCSDRMXX-1337] Example commit message
   ```

2. **pre-commit**:
    - Runs spotless linting and formats changed files to ensure code quality.
    - Enforces consistent branch naming conventions.

3. **pre-push**:
    - Runs gradle:test before allowing a push to the remote repository.
    - Enforces consistent branch naming conventions.

### Installation

- Install all git hooks:
  ```bash
    ./gradlew build
     OR
    ./gradlew installGitHooks
  ```
