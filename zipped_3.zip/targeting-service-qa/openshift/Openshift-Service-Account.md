### **Overview**
To automate our deployments with Jenkins we need a way for Jenkins to authenticate
itself with Openshift's API.  When a person uses the OpenShift Container
Platform CLI or web console, their API token authenticates them to the
OpenShift API. However, when a regular user’s credentials are not available, it
is common for components to make API using credentials granted to __Service Accounts__.

Service accounts provide a flexible way to control API access without sharing a
regular user’s credentials. They operate similarly to a human user with the distinction
that they don't have a password, instead they use API tokens stored in OpenShift
secrets to authenticate with the API.

**User Names and Groups**

Every service account has an associated user name that can be granted roles,
just like a regular user. The user name is derived from its project and name:

> system:serviceaccount:_project_:_name_

To create a new service account to be used by some external automation:
```bash
$ oc create sa jenkins-robot
```
As soon as a service account is created, two secrets are automatically added to it:

* an API token

* credentials for the OpenShift Container Registry

The API token can be used by external applications to authenticate with the
Openshift API and take actions as that service account. The system ensures that
service accounts always have an API token and registry credentials. The
generated API token and registry credentials do not expire, but they can be
revoked by deleting the secret. When the secret is deleted, a new one is
automatically generated to take its place.

We can then assign roles to the service account to manage what permissions it has
to act on our OpenShift cluster. The combination of a service account with
roles lets you granularly constrain the permissions granted to an external
application when interacting with OpenShift.

To give `jenkins-robot` the `edit-pods` role : (refer to [role-jenkins.yaml](./manifests/role-jenkins.yaml) and [rolebinding-jenkins.yaml](./manifests/rolebinding-jenkins.yaml) files)
```bash
$ oc create -f .\openshift\manifests\role-jenkins.yaml
$ oc create -f .\openshift\manifests\rolebinding-jenkins.yaml

```

After creating a service account and granting it the permissions we want, we can
get the token to act as the service account with the following command:

```bash
$ oc serviceaccounts get-token jenkins-robot
```

> You will need admin privileges to do this just like accessing any secret in
> OpenShift

Now that we have the service account's API token we can store that in our Jenkins
credentials to allow Jenkins to make calls to our OpenShift namespace.

1. Copy the token we just fetched from the console.
1. Navigate to your Jenkins credentials area.
1. Click "Add Credentials" and select "OpenShift Token for OpenShift Client Plugin" from the drop down.
   > This is assuming you have the OpenShift Client Jenkins Plugin installed
1. Paste the token and give it the ID of "_project-name_-_environment_-openshift-token" and click OK.

Now when we reference the ID of the token we just created we will have access
to the service account's token and be able to act as that service account.