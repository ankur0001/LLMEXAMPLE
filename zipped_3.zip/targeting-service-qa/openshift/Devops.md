# Dev Enablement Jenkins Pipeline for CaaS with Springboot,Gradle and GitHub

This Jenkins pipeline is based on the [Dev Enablement PCF pipeline](https://github.ford.com/DevEnablement/pcfdev-guides/tree/master/pipeline-jenkins)
with adjustments made for CaaS. The `Jenkinsfile` and Groovy
files in this directory are intended to be placed in a GitHub repository where
revisions can be tracked and Jenkins can always pull the most recent version
of the pipeline. `Jenkinsfile` contains the actual pipeline script that Jenkins
runs, `pipeline.configuration.groovy` holds configuration specific to your project
and will be modified by you, `pipeline.helper.groovy` has helper functions used
by the `Jenkinsfile`.

This pipeline takes care of building a new/updated release of your application
and updating your Deployment to use the newly-built image.
Similarly, any Services, Routes, ConfigMaps, Secrets etc. must be deployed and
updated manually. This pipeline will not interact with any of those resources.

The pipeline also assumes that you will be creating a Jenkins job for each deployment environment you have and using the [project-based security settings](https://www.jenkins.io/doc/book/managing/security/#authorization)
to ensure a separation of duties in who can deploy to what environment.

## Deployment Strategy
The current pipeline does not support a Blue/Green deployment with smoke tests.
It relies on you thoroughly testing in lower environments before running the
pipeline for your production environment. CaaS will do a rolling update of the
replicas in your Deployment, so if for some reason your new image
fails a liveness check, the update will stop. The pipeline is not aware of this
process and will consider the deployment successful if it gets to this point,
so you need to go to your namespace and confirm the rollout happened successfully.

## Pipeline Steps
1. Jenkins will automatically trigger a run of the pipeline everytime source code is pushed to Git.

1. The pipeline will first setup some necessary configuration to support the
   functionality of later steps.

1. The pipeline then checks out the specified Github branch specified and includes the latest  files so your project can link against them while compiling. These files will be included in your final Docker image.

1. You can configure which of the built-in quality checks you would like to run
   against your project before it is built and deployed. We currently support FOSSA, Checkmarx and SonarQube.

   If your project fails any of the quality checks the build will stop.

1. Once your project passes the quality checks the pipeline will trigger `gradle` build and compile your project.

1. This step is basically to build your image and publish it to Quay registry. When your project is successfully compiled the pipeline will create a buildconfig, making use of [buildconfig yaml](./manifests/build-config.yaml) from your source code to tag images it builds with the name of the build number the build is based on.

1. After the build is completed the pipeline will create deployment using [deployment yaml](./manifests/deployment.yaml) and set the deployment to use the image built with the buildUrl specified.

1. Incase, you have already deployed to CaaS successfully and want to update a new release, pipeline takes care of doing rolling update with the new image url.

## Jenkins Set Up
You need to install some plugins/custom tools in and add a few credentials to
your Jenkins for the pipeline to work as intended.

### Credentials
1. GitHub credentials are needed to pull the `Jenkinsfile` from your repo. You
   can find instructions for generating an SSH key and adding it to GitHub and
   Jenkins [here](https://github.ford.com/DevEnablement/caas-dev-guides/blob/master/jenkins/accurev-ant/Generating-and-using-SSH-Key.md).

1. A service account needs to be created in CaaS that Jenkins can use to interact with your namespace. Look [here](./Openshift-Service-Account.md) for instructions.

1. Since the pipeline is using BuildConfigs to build your image, you need to
   create a robot account in Quay and add it as a Secret in CaaS so it can be used by the BuildConfig to pull and push Quay images. We have instructions for this [here](https://github.ford.com/DevEnablement/caas-dev-guides/blob/master/registries/Quay/README.md#robot-creation).

### Plugins and Custom Tools

1. To run Checkmarx checks, the pipeline uses the Checkmarx plugin which you can find instructions [here](https://github.ford.com/DevEnablement/caas-dev-guides/blob/master/jenkins/accurev-ant/Jenkins-Checkmarx.md).

1. FOSSA checks use the FOSSA CLI directly, so you need to install it as a custom tool and include it in the global Jenkins PATH. We have instructions for setting up FOSSA [here](https://github.ford.com/DevEnablement/caas-dev-guides/blob/master/jenkins/accurev-ant/Fossa.md).

1. Sonarqube checks use the GradleBoost plugin, for which you can find the instructions [here](https://github.ford.com/DevEnablement/pcfdev-guides/tree/master/sonarqube).
   > Optional

1. The pipeline uses the OpenShift Client Plugin to make the CaaS steps feel more native to the pipeline. There are instructions for installing and configuring
   the plugin [here](https://github.ford.com/DevEnablement/caas-dev-guides/blob/master/jenkins/accurev-ant/Openshift-Client-Plugin.md).

1. The OpenShift Client Plugin relies on the OpenShift CLI (`oc`) being installed.
   You can learn how to install `oc` as a custom tool [here](https://github.ford.com/DevEnablement/caas-dev-guides/blob/master/jenkins/accurev-ant/OpenShift-Client-Tools.md).

## Pipeline Configuration
The pipeline has a configuration file (`pipeline.configuration.groovy`) where you
will make the necessary changes to get the pipeline to work with your project.

There are two main sections to this file: `build`, for configuring you build
process for each of your environments, and `integrations`, for configuring and
enabling tools like Checkmarx, Sonarqube and FOSSA.

###`build`
Most of the configuration in this section is designed to be specific to a given
deployment environment. You will see sections for `DEV`,`QA` and `PROD`, but you
could add additional environments or change these names if they do not match your project. When you create your pipeline in Jenkins you will have to set up an
input for environment and the value of that input must match one of these options.


  - `openshift` : Configuration for the pipeline to interact with your OpenShift
    namespace.
    - `namespace` : The namespace in OpenShift containing your application.
    - `buildConfig` : The name of the BuildConfig in this namespace that should
      be used to build your application.
    - `credential` : The name of the Jenkins credential where you stored the
      OpenShift service account token as described in the section on [credentials](#credentials).
    - `deployment` : The name of the Deployment that runs your application.
    - `container` : The name of the container within your Deployment
      that runs your application image. If you have a sidecar you might have two containers. You only need to specify the one containing your application.
      See the section on updating the Deployment from
      [this document](https://github.ford.com/DevEnablement/caas-dev-guides/blob/master/liberty-os-cli-deployments/README.md#day-2) for additional details on finding your `deployment` and `container` values.
  - `quay` : Configuration for interacting with the Quay repository where your
    your images are stored.
    - `org` : The name of the org in Quay where built image are stored.
    - `repo` : The name of the repo in Quay where built images are stored.
    - `tag` : The tag your build config will assign to the image.
      > This setting will not apply if we use `Jenkinsfile_patch_image`

### `integrations`
This section is used to enable and configure third-party integrations like Checkmarx
and FOSSA. It contains settings for Nexus and SonarQube but the pipeline does not
yet support those tools yet.

- `checkmarx`
  - `enabled` : Whether the tool will be run by the pipeline.
  - `credentialsId` : The credential in Jenkins you set up to run Checkmarx as
    described in the section on [plugins and custom tools](#plugins-and-custom-tools).
  - `serverUrl` : The URL of the Checkmarx server you are using.
  - `projectName` : The name of your project within Checkmarx.
  - `teamPath` : The team path for your project within Checkmarx.
  - `enableOSA` : Whether you want to enable open suorce analysis
- `fossa`
  - `enabled` : Whether the tool will be run by the pipeline.
  - `credentialsId` : The credential in Jenkins you set up to run Checkmarx as
    described in the section on [plugins and custom tools](#plugins-and-custom-tools).
  - `projectName` : The name of your project within FOSSA.
  - `teamname` : The name of the team within FOSSA.
  - `enableBreakBuildOnIssue` : Whether you would like a FOSSA issue to stop your
    build and consider the build failed.
- `sonarqube`
  - `enabled` : Whether the tool will be run by the pipeline.
  - `credentialsId` : The credential in Jenkins you set up to run sonarqube analysis as described in the section on [plugins and custom tools](#plugins-and-custom-tools).
  - `projectKey` : The name of your project within Sonarqube.
  - `enableBreakBuildOnIssue` : Whether you would like a SONARQUBE issue to stop your build and consider the build failed. Additional steps are required for this. Refer to [Break Jenkins Pipeline Build on Issue](https://github.ford.com/DevEnablement/pcfdev-guides/tree/master/sonarqube#Break-Jenkins-Pipeline-Build-on-Issue) section for details.


