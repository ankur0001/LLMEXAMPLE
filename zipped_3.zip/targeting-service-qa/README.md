[![Quality Gate Status](https://www.sonarqube.ford.com/api/project_badges/measure?project=com.ford.gcamp%3Agcampservicetargeting&metric=alert_status&token=sqb_6e61981a4cd51c89340ebb9763c5f1105d55ff53)](https://www.sonarqube.ford.com/dashboard?id=com.ford.gcamp%3Agcampservicetargeting)
[![FOSSA Status](https://ford.fossa.com/api/projects/custom%2B1%2Fgcamp-service-targeting.svg?type=shield&issueType=license)](https://ford.fossa.com/projects/custom%2B1%2Fgcamp-service-targeting?ref=badge_shield&issueType=license)
[![FOSSA Status](https://ford.fossa.com/api/projects/custom%2B1%2Fgcamp-service-targeting.svg?type=shield&issueType=security)](https://ford.fossa.com/projects/custom%2B1%2Fgcamp-service-targeting?ref=badge_shield&issueType=security)

# gcamp-service-targeting

**Branches:** `qa` → `prod` | **Review:** 1 developer required per PR

## 📋 Overview

Spring Boot 3.4.11 application for GCAMP targeting operations, campaign management, and data processing.

**Requirements:** JDK 21, Gradle (wrapper included), Docker, OpenShift CLI  
**Deployment:** OpenShift (pp11.edc.caas.ford.com) via EcoBoost Tekton Pipeline 4.2.0

## 🚀 Quick Start

```bash
# Build and run
./gradlew clean build
./gradlew bootRun --args='--spring.profiles.active=qa'
./gradlew installGitHooks
```

## 🌍 Environments

| Environment | Namespace | Container Image | Deployment | API Server |
|-------------|-----------|-----------------|------------|------------|
| **QA** | `seo-gcamp-qa` | `fcr.ford.com/gcamp/qa:qa` | `targeting-service-qa-dep` | `api.pp11.edc.caas.ford.com:6443` |
| **PROD** | `seo-gcamp-prod` | `fcr.ford.com/gcamp/prod:prod` | `targeting-service-prod-dep` | Production cluster |

## 🔄 CI/CD Pipeline

**EcoBoost Tekton Pipeline v4.2.0** with DORA metrics (App ID: 11577)

- `qa` branch → QA deployment
- `prod` branch → PROD deployment
- Configs: `pipeline/pipeline-configuration-{qa|prod}.json`

## 📝 Code Quality & Security

```bash
./gradlew check                    # All quality checks
./gradlew spotlessApply            # Format code
./gradlew pitest                   # Mutation tests
```

**FOSSA:** License and security scanning enabled (badges above)  
**Secrets:** OpenShift secrets `openshift-tektontoken-{qa|prod}`

## 🛠️ Development Workflow

### ⚠️ Required Formats (Enforced by Git Hooks & GitHub Actions)

**Branch:** `<type>_<PROJECT>-<issue>` (e.g., `feat_FCSDRMXX-1337`)  
**Commit:** `<type>(<scope>): [#TICKET] Description`  
**PR Title:** `<type>(<title>): [#TICKET] Description` *(only `feat`, `fix`, `perf` allowed)*

| Item | Types | Scopes | Example |
|------|-------|--------|---------|
| Branch | `feat`, `fix`, `perf`, `docs`, `style`, `refactor`, `test`, `chore` | N/A | `feat_FCSDRMXX-1337` |
| Commit | `feat`, `fix`, `perf`, `docs`, `style`, `refactor`, `test`, `chore` | `Pipeline`, `Gcp`, `Spring`, `React`, `Gradle` | `feat(Spring): [#US12345] Add feature` |
| PR Title | **`feat`, `fix`, `perf` only** | Any | `feat(Spring): [#US12345] Add feature` |

**Tip:** Use shorthand for commits: `git commit -m "fix_spring Message"` → Auto-formatted to `fix(Spring): [#TICKET] Message`

### Steps

```bash
# 1. Setup (first time)
./gradlew installGitHooks

# 2. Create feature branch
git checkout qa && git pull
git checkout -b feat_FCSDRMXX-1234

# 3. Commit changes
git add . && git commit -m "feat(Spring): [#FCSDRMXX-1234] Add validation"

# 4. Push and create PR
git push origin feat_FCSDRMXX-1234
# PR title MUST be: feat(Spring): [#FCSDRMXX-1234] Add validation

# 5. After QA approval → Merge to prod
```


## 📚 Validation & Docs

**Git Hooks** (install: `./gradlew installGitHooks`):
- `prepare-commit-msg` - Auto-formats commits
- `pre-commit` - Validates branch names, runs Spotless
- `pre-push` - Runs tests

**Docs:** [EcoBoost Tekton Pipeline](https://github.ford.com/DevEnablement/ecoboost-tekton-pipeline) | `openshift/Devops.md` | `git-hooks/README.md`

## 📞 Support

For issues or questions, contact the GCAMP development team or create an issue in the repository.

---

**Last Updated:** January 15, 2026
