package com.ford.gcamp.targeting.gridgcamp.gcamp.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.sql.Timestamp;
import java.util.List;

@Setter
@Getter
@Entity
@Table(name = "SGCPG14_PRCDST_MAP")
public class ProcessDistributionMapEntity {

    @Id
    @Column(name = "GCPG13_PROCESS_D")
    private int processId;

    @Column(name = "GCPE10_HUB_C")
    private String hub;

    @Column(name = "COUNTRY_ISO3_C")
    private String countryIso;

    @Column(name = "GCPG11_DIST_LIST_D")
    private int distributionList;

    @Column(name = "GCPG14_DEFAULT_F")
    private String defaultFlag;

    @Column(name = "GPCG14_UPDATE_ID_C")
    private String updateId;

    @Column(name = "GCPG14_UPDATE_S")
    private Timestamp updatedTimestamp;

    @OneToMany(mappedBy = "distributionMapEntity")
    private List<DistributionDetailEntity> distributionDetailEntities;

    @OneToMany(mappedBy = "priceDistributionMap")
    private List<DistributionProcessEntity> distributionProcessEntities;

}
