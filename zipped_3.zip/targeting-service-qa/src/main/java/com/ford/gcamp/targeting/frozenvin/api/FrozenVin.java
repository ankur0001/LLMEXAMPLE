package com.ford.gcamp.targeting.frozenvin.api;

import io.swagger.v3.oas.annotations.extensions.Extension;
import io.swagger.v3.oas.annotations.extensions.ExtensionProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class FrozenVin {
    @NotNull
	@Size(min = 5, max = 6)
	@Pattern(regexp = "^\\d{2}[A-Za-z\\d]{2}\\d{1}\\d*$")
	@Schema(type="string", description = "FSA number",minLength=5,maxLength = 6, extensions = @Extension(properties = @ExtensionProperty(name = "x-42c-sample", value = "15311")))
	private String fscNumber;

	@Size(min = 0, max = 2)
	@Pattern(regexp ="^[A-Za-z\\d\\s\\*]*$", message = "population Code")
	@Schema(example = "AA", description = "Population")
	private String population;


	@Size(min = 1, max = 2)
	@Pattern(regexp = "^[a-zA-Z\\*\\s]*$")
	@Schema(example = "NA", description = "Hub code")
	private String hub;


	@Size(min=0, max =1)
	@Pattern(regexp = "^[a-zA-Z]")
	@Schema(example = "G", description = "FSA Type Global or Local")
	private String optRadio;


	@Schema(example= "F" , description = "Flag")
	@Size(min = 0, max = 1)
	@Pattern(regexp ="^[A-Za-z]*$")
	private String filterBy;
	
	
}
