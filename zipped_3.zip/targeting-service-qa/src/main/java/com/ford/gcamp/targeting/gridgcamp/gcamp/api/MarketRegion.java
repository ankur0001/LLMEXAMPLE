package com.ford.gcamp.targeting.gridgcamp.gcamp.api;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Size;

import com.ford.gcamp.targeting.common.api.GenericLookup;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@JsonIgnoreProperties(ignoreUnknown = true)
public class MarketRegion {

	@Valid
	private GenericLookup region;
	@Size(min=0, max = 500)
	private List< @Valid  GenericLookup> countries;
}
