package com.ford.gcamp.targeting.fsacriteria;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.ford.gcamp.targeting.fsacriteria.entity.FSACriteriaRegionalFilterData;
import com.ford.gcamp.targeting.fsacriteria.entity.RegionalFilterId;

@Repository
public interface FSACriteriaRegionalFilterRepository
		extends JpaRepository<FSACriteriaRegionalFilterData, RegionalFilterId> {

}
