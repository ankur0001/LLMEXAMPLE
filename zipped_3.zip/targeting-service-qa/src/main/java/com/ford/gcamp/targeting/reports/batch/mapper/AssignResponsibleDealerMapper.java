package com.ford.gcamp.targeting.reports.batch.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.commons.lang3.StringUtils;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import com.ford.gcamp.targeting.reports.batch.exception.api.AssignResponsibleDealer;


@Component
public class AssignResponsibleDealerMapper implements RowMapper<AssignResponsibleDealer> {

	@Override
	public AssignResponsibleDealer mapRow(ResultSet rs, int rowNum) throws SQLException {
		return AssignResponsibleDealer.builder()
				.vin(StringUtils.trimToEmpty(rs.getString(1)))
				.reason(StringUtils.trimToEmpty(rs.getString(2)))
				.hub(StringUtils.trimToEmpty(rs.getString(3)))
				.country(StringUtils.trimToEmpty(rs.getString(4)))
				.shippingDealer(StringUtils.trimToEmpty(rs.getString(5)))
				.sellingDealer(StringUtils.trimToEmpty(rs.getString(6)))
				.orderingDealer(StringUtils.trimToEmpty(rs.getString(7)))
				.stockingDealer(StringUtils.trimToEmpty(rs.getString(8)))
				.build();
	}
}
