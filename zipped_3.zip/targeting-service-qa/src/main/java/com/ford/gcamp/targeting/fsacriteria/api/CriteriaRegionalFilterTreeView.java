package com.ford.gcamp.targeting.fsacriteria.api;

import java.util.List;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class CriteriaRegionalFilterTreeView {
	@NotNull
	@Schema(description = "globalFSANumber")
	@Min(0)
	@Max(99999999)
	private int globalFSANumber;


	@NotNull
	@Schema(description = "supplementId")
	@Size(min = 1, max = 2, message = "length 1-2")
	@Pattern(regexp ="^[A-Za-z\\d]*$", message = "Supplement Code")
	private String supplementId;

	@NotNull
	@Size(min = 1, max = 2)
	@Pattern(regexp = "^[A-Za-z\\d\\s\\*]*$")
	@Schema(example = "**", description = "Vin Group Code")
	private String vinGroupCode;

	@Size(min = 0, max = 250, message = "regionalFilters List")
	private List<@Valid RegionalFilterHubTreeView> regionalFilters;

}
