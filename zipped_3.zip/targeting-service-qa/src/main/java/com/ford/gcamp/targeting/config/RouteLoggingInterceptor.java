package com.ford.gcamp.targeting.config;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;
import org.jspecify.annotations.NonNull;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

@Component
@Slf4j
public class RouteLoggingInterceptor implements HandlerInterceptor {

    private static final String ROUTE_LOG = "[Route] {} {} {} {}";

    private static String getContextClientId() {
        String clientId = "unknown";
        var authentication = SecurityContextHolder.getContext().getAuthentication();

        if (authentication != null && authentication.getPrincipal() instanceof Jwt jwt) {
            if (jwt.getClaims().containsKey("azp")) {
                clientId = jwt.getClaimAsString("azp");
            } else if (jwt.getClaims().containsKey("appid")) {
                clientId = jwt.getClaimAsString("appid");
            }
        }

        return clientId;
    }

    @Override
    public boolean preHandle(
            HttpServletRequest request,
            @NonNull HttpServletResponse response,
            @NonNull Object handler) {
        log.debug(
                "[Route - In] Request: {} {} {}",
                request.getMethod(),
                request.getRequestURI(),
                getContextClientId());
        return true;
    }

    @Override
    public void afterCompletion(
            @NonNull HttpServletRequest request,
            @NonNull HttpServletResponse response,
            @NonNull Object handler,
            Exception ex) {
        int status = response.getStatus();
        String method = request.getMethod();
        String uri = request.getRequestURI();
        String clientId = getContextClientId();

        if (ex != null) {
            log.error(ROUTE_LOG, status, method, uri, clientId, ex);
        } else if (status >= 500) {
            log.error(ROUTE_LOG, status, method, uri, clientId);
        } else if (status >= 400) {
            log.warn(ROUTE_LOG, status, method, uri, clientId);
        } else {
            log.info(ROUTE_LOG, status, method, uri, clientId);
        }
    }
}
