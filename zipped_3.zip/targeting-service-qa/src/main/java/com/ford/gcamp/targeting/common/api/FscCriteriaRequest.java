package com.ford.gcamp.targeting.common.api;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import io.swagger.v3.oas.annotations.extensions.Extension;
import io.swagger.v3.oas.annotations.extensions.ExtensionProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder

@JsonInclude(Include.NON_NULL)
public class FscCriteriaRequest {


	@NotNull
	@Size(min = 5, max = 10)
	@Pattern(regexp = "^\\d{2}[A-Za-z\\d]{2}\\d{1}\\d*$")
	@Schema(type="string", description = "FSA number",minLength=5,maxLength = 10, extensions = @Extension(properties = @ExtensionProperty(name = "x-42c-sample", value = "15311")))
	private String fscNumber;



	@Size(min=0, max = 8)
	@Pattern(regexp ="^[A-Za-z\\d\\s\\*]*$", message = "population Code")
	@Schema(types={"string","null"},example = "Original", description = "Population", minLength = 0, maxLength = 8)
	private String population;


	@Size(min=0,max =1)
	@Pattern(regexp = "^[a-zA-Z\\s]*$")
	@Schema(types={"string","null"},example = "G", description = "FSA Type Global or Local", minLength = 0, maxLength = 1)
	private String optRadio;



	@Size(min=0, max = 8)
	@Pattern(regexp = "^[a-zA-Z\\d\\-]*$")
	@Schema(types={"string","null"},example = "SDUDIWAR", description = "CDSID",minLength = 0,maxLength = 8)
	private String cdsId;
	
}
