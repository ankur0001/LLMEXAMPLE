package com.ford.gcamp.targeting.common.api;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class FSATypes {

	@Size(min = 0, max = 2)
	@Pattern(regexp = "^[a-zA-Z\\d\\*]*$")
	@Schema(example = "SC", description = "FSA Type Codes")
	private String fsaTypeCode;


	@Size(min = 0, max = 2)
	@Pattern(regexp = "^[a-zA-Z\\d\\s\\-\\/\\(\\)]*$")
	@Schema(example = "SAFETY COMPLIANCE", description = "FSA Type Codes")
	private String fsaTypeDesc;
}
