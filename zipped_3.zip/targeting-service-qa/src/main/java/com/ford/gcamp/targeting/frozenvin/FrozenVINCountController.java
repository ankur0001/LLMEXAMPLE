package com.ford.gcamp.targeting.frozenvin;

import com.ford.cloudnative.base.api.StandardErrorResponse;
import com.ford.gcamp.targeting.common.api.CommonErrorResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.WebRequest;
import com.ford.gcamp.targeting.core.exception.GCampBatchTriggerException;
import com.ford.gcamp.targeting.frozenvin.api.FrozenVINCountRequest;
import com.ford.gcamp.targeting.frozenvin.api.FrozenVINCountResponse;
import com.ford.gcamp.targeting.frozenvin.api.FrozenVinHistResponse;
import com.ford.gcamp.targeting.frozenvin.api.FrozenVinResponseDTO;
import com.ford.gcamp.targeting.logging.LogExecutionTime;
import com.ford.gcamp.targeting.frozenvin.api.FrozenVin;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping(path = "/api/v1/targeting/frozenvincount")
@Validated
public class FrozenVINCountController {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(FrozenVINCountController.class);
	
    @Autowired
    private FrozenVINCountService frozenVINCountService;
    @Autowired
	FrozenVinResponseDTO frozenVinResponse;
    
    @PreAuthorize("@authorizeService.isAuthorized('GCAMP:frozenVinCount:FROZENGO','execute')")
	@Operation(summary = "Load Frozen Vins action", security = {
			@SecurityRequirement(name = "ADFS"),
			@SecurityRequirement(name = "AzureAD")
	})
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Load Frozen Vins Action request fetched successfully",
					content = @Content(mediaType = "application/problem+json",schema = @Schema(implementation = FrozenVinResponseDTO.class))),
			@ApiResponse(responseCode = "default", description = "All Errors", content = @Content(schema = @Schema(implementation = StandardErrorResponse.class)))
	})
	@PostMapping("/loadFrozenVins")
	public ResponseEntity<FrozenVinResponseDTO> fscCriteriaSearch(@RequestBody @Valid final FrozenVin frozenVin) {
		if (frozenVin != null) {
			frozenVinResponse = frozenVINCountService.getFrozenVinList(frozenVin);
		}
		return ResponseEntity.ok(frozenVinResponse);
	}
    
    @PreAuthorize("@authorizeService.isAuthorized('GCAMP:historyOfFrozenVinCount:HISTORYCOUNT','execute')")
	@Operation(summary = "Load Frozen Vins History action", security = {
			@SecurityRequirement(name = "ADFS"),
			@SecurityRequirement(name = "AzureAD")
	})
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Load Frozen Vins Action request fetched successfully",
					content = @Content(mediaType = "application/problem+json",schema = @Schema(implementation = FrozenVinHistResponse.class))),
			@ApiResponse(responseCode = "default", description = "All Errors", content = @Content(schema = @Schema(implementation = StandardErrorResponse.class)))
	})
	@PostMapping(value = "/loadFrozenVinHistory")
	@LogExecutionTime
	public ResponseEntity<FrozenVinHistResponse> addVinsManual(
			@RequestBody @Valid final FrozenVin fsaCriteria) {
		FrozenVinHistResponse frozenResponse = frozenVINCountService.getFrozenHistory(fsaCriteria);
		LOGGER.info("manual upload response {}", frozenResponse);
		return ResponseEntity.ok(frozenResponse);

	}
    
    @PreAuthorize("@authorizeService.isAuthorized('GCAMP:frozenVinCount:FREEZE','execute')")
	@Operation(summary = "Freeze and UnFreeze the population", security = {
			@SecurityRequirement(name = "ADFS"),
			@SecurityRequirement(name = "AzureAD")
	})
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Load Frozen Vins Action request fetched successfully",
					content = @Content(mediaType = "application/problem+json",schema = @Schema(implementation = FrozenVINCountResponse.class))),
			@ApiResponse(responseCode = "412", description = "Precondition Failed", content = @Content(schema = @Schema(implementation = CommonErrorResponse.class))),
			@ApiResponse(responseCode = "default", description = "All Errors", content = @Content(schema = @Schema(implementation = StandardErrorResponse.class)))
	})
    @PostMapping(value ="/freezeUnfreeze")
    @LogExecutionTime
	public @ResponseBody ResponseEntity<FrozenVINCountResponse> freezeUnfreeze(@RequestBody @Valid FrozenVINCountRequest frozenVINCountRequest) throws GCampBatchTriggerException {
    	FrozenVINCountResponse response =  frozenVINCountService.freezeUnfreeze(frozenVINCountRequest);
        return ResponseEntity.ok(response);
	}
    
    @ExceptionHandler({AccessDeniedException.class})
    public ResponseEntity<Object> handleAccessDeniedException(Exception ex, WebRequest request) {
        if (ex.getMessage().toLowerCase().indexOf("access is denied") > -1) {
            return new ResponseEntity<>("You are not Authorized by APS to access the Resource", new HttpHeaders(), HttpStatus.FORBIDDEN);
        }
        return new ResponseEntity<>(ex.getMessage(), new HttpHeaders(), HttpStatus.INTERNAL_SERVER_ERROR);
    }
  
}