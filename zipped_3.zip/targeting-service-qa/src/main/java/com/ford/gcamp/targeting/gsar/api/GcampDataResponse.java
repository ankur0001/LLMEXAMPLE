package com.ford.gcamp.targeting.gsar.api;

import java.util.List;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Builder
public class GcampDataResponse {
	@Size(min = 0, max = 20)
	@Pattern(regexp = "^[\\d]*$")
	@Schema(example = "5666", description = "reportId")
	private String reportId;

	@Size(min = 0, max =100000)
	@Pattern(regexp = "^[\\d\\,]*$")
	@Schema(example = "2020", description = "Model Year")
	private String modelYear;

	@Size(min = 0, max = 300, message = "vinList")
	private List<@Valid VinList> vinList;
}
