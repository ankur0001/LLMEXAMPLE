package com.ford.gcamp.targeting.common;

import java.util.Map;

import com.ford.gcamp.targeting.common.api.BatchJobDataForPhaseByPercent;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import com.ford.gcamp.targeting.common.api.BatchJobData;
import com.ford.gcamp.targeting.common.api.LayoutBuffer;

@Repository
public class UJQBlockerDAO {
	
	private static final String BLOCKER_PROC_NAME = "CSGCSJ17";
	private static final int BLOCKER_INPUT_SIZE = 100;
	private static final int BLOCKER_OUTPUT_SIZE = 100;
	private BatchJobData batchJobData = null;

	private BatchJobDataForPhaseByPercent batchJobDataForPhaseByPercent = null;
	private String blockingBatchCode = "";
	
	private static final Logger LOGGER = LoggerFactory.getLogger(UJQBlockerDAO.class);
	
	private JdbcTemplate jdbcTemplate;
	
	private UJQDeleteJobRepository ujqDeleteJobRepository;
		
	public UJQBlockerDAO(JdbcTemplate jdbcTemplate, UJQDeleteJobRepository ujqDeleteJobRepository) {
		super();
		this.jdbcTemplate = jdbcTemplate;
		this.ujqDeleteJobRepository = ujqDeleteJobRepository;
	}

	private boolean getResults(Map<String, Object> ujqBlocker, BatchJobData batchJobData) {

		LayoutBuffer layoutBuffer = new LayoutBuffer(BLOCKER_OUTPUT_SIZE);
		// blocking batch code
		layoutBuffer.addField(LayoutBuffer.FIELDTYPE_PICX, 3);
		// CDSId
		layoutBuffer.addField(LayoutBuffer.FIELDTYPE_PICX, 8);
		// Batch short desc
		layoutBuffer.addField(LayoutBuffer.FIELDTYPE_PICX, 40);
		// filler
		layoutBuffer.addField(LayoutBuffer.FIELDTYPE_PICX, 49);

		layoutBuffer.fromString((String) ujqBlocker.get("OUTPUT_PARM1"));
		String errorParm1 = (String) ujqBlocker.get("ERROR_PARM1");
		if (StringUtils.isNotBlank(layoutBuffer.getString(0))) {
			this.setBlockingBatchCode(StringUtils.trim(layoutBuffer.getString(0)));
			if (CommonConstants.SUBMIT_EXTRACT_BATCH_CODE.equalsIgnoreCase(batchJobData.getBatchCode()) 
					&& errorParm1.length() >= 45
					&& "E0370".equalsIgnoreCase(errorParm1.substring(40, 45))) {
				ujqDeleteJobRepository.deleteUJQJob(batchJobData);
			}
			return true;
		}
		return false;
	}

	private boolean getResultsForPhase(Map<String, Object> ujqBlocker) {

		LayoutBuffer layoutBuffer = new LayoutBuffer(BLOCKER_OUTPUT_SIZE);
		// blocking batch code
		layoutBuffer.addField(LayoutBuffer.FIELDTYPE_PICX, 3);
		// CDSId
		layoutBuffer.addField(LayoutBuffer.FIELDTYPE_PICX, 8);
		// Batch short desc
		layoutBuffer.addField(LayoutBuffer.FIELDTYPE_PICX, 40);
		// filler
		layoutBuffer.addField(LayoutBuffer.FIELDTYPE_PICX, 49);

		layoutBuffer.fromString((String) ujqBlocker.get("OUTPUT_PARM1"));
		if (StringUtils.isNotBlank(layoutBuffer.getString(0))) {
			this.setBlockingBatchCode(StringUtils.trim(layoutBuffer.getString(0)));
			return true;
		}
		return false;
	}


	private String setInputParametersForPhase() {
		LayoutBuffer layoutBuffer  = new LayoutBuffer(BLOCKER_INPUT_SIZE);
		//batch code
		layoutBuffer.addField(LayoutBuffer.FIELDTYPE_PICX, 3);
		//GFSA
		layoutBuffer.addField(LayoutBuffer.FIELDTYPE_PIC9, 8);
		//LFSA
		layoutBuffer.addField(LayoutBuffer.FIELDTYPE_PICX, 10);
		//hub
		layoutBuffer.addField(LayoutBuffer.FIELDTYPE_PICX, 2);
		//country code
		layoutBuffer.addField(LayoutBuffer.FIELDTYPE_PICX, 3);
		//segment
		layoutBuffer.addField(LayoutBuffer.FIELDTYPE_PIC9, 5);
		//supplement
		layoutBuffer.addField(LayoutBuffer.FIELDTYPE_PICX, 2);
		//folder id
		layoutBuffer.addField(LayoutBuffer.FIELDTYPE_PIC9, 3);
		//vin
		layoutBuffer.addField(LayoutBuffer.FIELDTYPE_PICX, 17);
		//cdsid
		layoutBuffer.addField(LayoutBuffer.FIELDTYPE_PICX, 8);
		//filler
		layoutBuffer.addField(LayoutBuffer.FIELDTYPE_PICX, 39);

		layoutBuffer.setString(0, batchJobDataForPhaseByPercent.getBatchCode());
		layoutBuffer.setString(1, Integer.toString(batchJobDataForPhaseByPercent.getGlobalFSANo()));

		LayoutBuffer layoutBuffer1 = prefixParmForPhase(layoutBuffer);

		layoutBuffer1.setString(5, Integer.toString(batchJobDataForPhaseByPercent.getSegment()));

		LayoutBuffer layoutBuffer2 = postfixParamForPhase(layoutBuffer1);

		layoutBuffer2.setString(9, batchJobDataForPhaseByPercent.getCdsId());

		layoutBuffer2.setString(10, "");

		return layoutBuffer2.toString();
	}

	private LayoutBuffer postfixParamForPhase(LayoutBuffer layoutBuffer) {
		if(batchJobDataForPhaseByPercent.getSupplement()==null||("".equals(batchJobDataForPhaseByPercent.getSupplement().trim()))) {
			layoutBuffer.setString(6, "*");
		}else {
			layoutBuffer.setString(6, batchJobDataForPhaseByPercent.getSupplement());
		}
		//extra check
		if(batchJobDataForPhaseByPercent.getFolderId()==null||("".equals(batchJobDataForPhaseByPercent.getFolderId().trim()))){
			layoutBuffer.setString(7, "999");
		}else {
			layoutBuffer.setString(7, batchJobDataForPhaseByPercent.getFolderId());
		}
		if(batchJobDataForPhaseByPercent.getVin()==null||("".equals(batchJobDataForPhaseByPercent.getVin().trim()))) {
			layoutBuffer.setString(8, "*");
		}else {
			layoutBuffer.setString(8, batchJobDataForPhaseByPercent.getVin());
		}
		return layoutBuffer;

	}

	private LayoutBuffer prefixParmForPhase(LayoutBuffer layoutBuffer) {
		if(batchJobDataForPhaseByPercent.getLocalFSANo()==null||("".equals(batchJobDataForPhaseByPercent.getLocalFSANo().trim()))) {
			layoutBuffer.setString(2, "*");
		}else {
			layoutBuffer.setString(2, batchJobDataForPhaseByPercent.getLocalFSANo());
		}
		if(batchJobDataForPhaseByPercent.getHubCode()==null||("".equals(batchJobDataForPhaseByPercent.getHubCode().trim()))) {
			layoutBuffer.setString(3, "*");
		}else {
			layoutBuffer.setString(3, batchJobDataForPhaseByPercent.getHubCode());
		}
		if(batchJobDataForPhaseByPercent.getCountryCode()==null||("".equals(batchJobDataForPhaseByPercent.getCountryCode().trim()))) {
			layoutBuffer.setString(4, "*");
		}else {
			layoutBuffer.setString(4, batchJobDataForPhaseByPercent.getCountryCode());
		}
		return layoutBuffer;

	}
	
	private String setInputParameters() {
			LayoutBuffer layoutBuffer  = new LayoutBuffer(BLOCKER_INPUT_SIZE);
			//batch code
			layoutBuffer.addField(LayoutBuffer.FIELDTYPE_PICX, 3);
			//GFSA
			layoutBuffer.addField(LayoutBuffer.FIELDTYPE_PIC9, 8);
			//LFSA
			layoutBuffer.addField(LayoutBuffer.FIELDTYPE_PICX, 10);
			//hub
			layoutBuffer.addField(LayoutBuffer.FIELDTYPE_PICX, 2);
			//country code
			layoutBuffer.addField(LayoutBuffer.FIELDTYPE_PICX, 3);
			//segment
			layoutBuffer.addField(LayoutBuffer.FIELDTYPE_PIC9, 5);
			//supplement
			layoutBuffer.addField(LayoutBuffer.FIELDTYPE_PICX, 2);
			//folder id
			layoutBuffer.addField(LayoutBuffer.FIELDTYPE_PIC9, 3);
			//vin
			layoutBuffer.addField(LayoutBuffer.FIELDTYPE_PICX, 17);
			//cdsid
			layoutBuffer.addField(LayoutBuffer.FIELDTYPE_PICX, 8);
			//filler
			layoutBuffer.addField(LayoutBuffer.FIELDTYPE_PICX, 39);
			
			layoutBuffer.setString(0, batchJobData.getBatchCode());
			layoutBuffer.setString(1, Integer.toString(batchJobData.getGlobalFSANo()));
			
			LayoutBuffer layoutBuffer1 = prefixParm(layoutBuffer);			

			layoutBuffer1.setString(5, Integer.toString(batchJobData.getSegment()));
			
			LayoutBuffer layoutBuffer2 = postfixParam(layoutBuffer1);		
					
			layoutBuffer2.setString(9, batchJobData.getCdsId());
						
			layoutBuffer2.setString(10, "");
			
			return layoutBuffer2.toString();
	}

	private LayoutBuffer postfixParam(LayoutBuffer layoutBuffer) {
		if(batchJobData.getSupplement()==null||("".equals(batchJobData.getSupplement().trim()))) {
			layoutBuffer.setString(6, "*");
		}else {
			layoutBuffer.setString(6, batchJobData.getSupplement());
		}
		//extra check
		if(batchJobData.getFolderId()==null||("".equals(batchJobData.getFolderId().trim()))){
			layoutBuffer.setString(7, "999");
		}else {
			layoutBuffer.setString(7, batchJobData.getFolderId());
		}
		if(batchJobData.getVin()==null||("".equals(batchJobData.getVin().trim()))) {
			layoutBuffer.setString(8, "*");
		}else {
			layoutBuffer.setString(8, batchJobData.getVin());
		}
		return layoutBuffer;
		
	}

	private LayoutBuffer prefixParm(LayoutBuffer layoutBuffer) {
		if(batchJobData.getLocalFSANo()==null||("".equals(batchJobData.getLocalFSANo().trim()))) {
			layoutBuffer.setString(2, "*");
	   }else {
			layoutBuffer.setString(2, batchJobData.getLocalFSANo());
		}
		if(batchJobData.getHubCode()==null||("".equals(batchJobData.getHubCode().trim()))) {
			layoutBuffer.setString(3, "*");
		}else {
			layoutBuffer.setString(3, batchJobData.getHubCode());
		}
		if(batchJobData.getCountryCode()==null||("".equals(batchJobData.getCountryCode().trim()))) {
			layoutBuffer.setString(4, "*");
		}else {
			layoutBuffer.setString(4, batchJobData.getCountryCode());
		}
		return layoutBuffer;
		
	}

	/**
	 * Gets the batchJobData
	 * @return Returns a BatchJobData
	 */
	public BatchJobData getBatchJobData() {
		return batchJobData;
	}
	/**
	 * Sets the batchJobData
	 * @param batchJobData The batchJobData to set
	 */
	public void setBatchJobData(BatchJobData batchJobData) {
		this.batchJobData = batchJobData;
	}


	public BatchJobDataForPhaseByPercent getBatchJobDataForPhaseByPercent() {
		return batchJobDataForPhaseByPercent;
	}

	public void setBatchJobDataForPhase(BatchJobDataForPhaseByPercent batchJobDataForPhaseByPercent) {
		this.batchJobDataForPhaseByPercent = batchJobDataForPhaseByPercent;
	}


	
	public boolean hasConflict(BatchJobData batchJobData){
		this.batchJobData = batchJobData;
		
		SimpleJdbcCall simpleJdbcCall = creatSimpleJdbcCall(CommonConstants.FSA_SCHEMA_NAME,BLOCKER_PROC_NAME);
		SqlParameterSource sqlParameterSource = createSqlParameterSource("INPUT_PARM1",setInputParameters());
		LOGGER.info("input param values {}", sqlParameterSource);
		Map<String, Object> ujqBlocker = simpleJdbcCall.execute(sqlParameterSource);
		LOGGER.info("Response from Store Proc {}", ujqBlocker);
		
		//for no conflict we return false, if there is conflict an exception will be thrown
		return getResults(ujqBlocker, batchJobData);
	}

	public boolean hasConflictForPhase(BatchJobDataForPhaseByPercent batchJobDataForPhaseByPercent){
	this.batchJobDataForPhaseByPercent = batchJobDataForPhaseByPercent;

		SimpleJdbcCall simpleJdbcCall = creatSimpleJdbcCall(CommonConstants.FSA_SCHEMA_NAME,BLOCKER_PROC_NAME);
		SqlParameterSource sqlParameterSource = createSqlParameterSource("INPUT_PARM1",setInputParametersForPhase());
		LOGGER.info("input param values {}", sqlParameterSource);
		Map<String, Object> ujqBlocker = simpleJdbcCall.execute(sqlParameterSource);
		LOGGER.info("Response from Store Proc {}", ujqBlocker);

		//for no conflict we return false, if there is conflict an exception will be thrown
		return getResultsForPhase(ujqBlocker);
	}
	/**
	 * Gets the blockingBatchCode
	 * @return Returns a String
	 */
	public String getBlockingBatchCode() {
		return blockingBatchCode;
	}
	/**
	 * Sets the blockingBatchCode
	 * @param blockingBatchCode The blockingBatchCode to set
	 */
	public void setBlockingBatchCode(String blockingBatchCode) {
		this.blockingBatchCode = blockingBatchCode;
	}

	MapSqlParameterSource createSqlParameterSource(String inputParamKey1, String inputParamVal1) {
		return new MapSqlParameterSource().addValue(inputParamKey1,inputParamVal1);
	}
	
	SimpleJdbcCall creatSimpleJdbcCall(String schemaName, String procedureName) {
		return new SimpleJdbcCall(jdbcTemplate).withSchemaName(schemaName)
				.withProcedureName(procedureName);
	}

}

