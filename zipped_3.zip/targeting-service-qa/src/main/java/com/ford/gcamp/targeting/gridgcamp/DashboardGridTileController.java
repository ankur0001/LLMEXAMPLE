package com.ford.gcamp.targeting.gridgcamp;

import com.ford.cloudnative.base.api.StandardErrorResponse;
import com.ford.gcamp.targeting.common.api.CommonErrorResponse;
import com.ford.gcamp.targeting.segmentation.setup.api.SaveSegmentResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.security.access.prepost.PreAuthorize;

import com.ford.gcamp.targeting.gridgcamp.api.DashboardGridTileCountResponse;
import com.ford.gcamp.targeting.gridgcamp.api.DashboardGridTileRequest;
import com.ford.gcamp.targeting.gridgcamp.api.DashboardGridTileResponse;

@Validated
@RestController
@RequestMapping(path = "/api/v1/targeting/gridgcamp/dashboard")
public class DashboardGridTileController {
	
	private DashboardGridTileService dashboardGridTileService;

	public DashboardGridTileController(DashboardGridTileService dashboardGridTileService) {
		super();
		this.dashboardGridTileService = dashboardGridTileService;
	}
	
	@PreAuthorize("@authorizeService.isAuthorized('GCAMP:fsaSearch:GoAction','execute')")
	@PostMapping( value = "/gridcount")
	@Operation(summary = "POST Grid Count", security = {
			@SecurityRequirement(name = "ADFS"),
			@SecurityRequirement(name = "AzureAD")
	})
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "POST Grid Dashboard Count Fetched Successfully", content = @Content(mediaType = "application/problem+json", schema = @Schema(implementation = DashboardGridTileCountResponse.class))),
			@ApiResponse(responseCode = "default", description = "All Errors", content = @Content(schema = @Schema(implementation = StandardErrorResponse.class)))
	})
	public ResponseEntity<DashboardGridTileCountResponse> getUnAssignedGridVernInfoCount(@RequestBody @Valid DashboardGridTileRequest dashboardGridTileRequest) {
		DashboardGridTileCountResponse response = dashboardGridTileService.getUnAssignedGridVernInfoCount(dashboardGridTileRequest);
		return ResponseEntity.ok(response);
	}
	
	@PreAuthorize("@authorizeService.isAuthorized('GCAMP:fsaSearch:GoAction','execute')")
	@PostMapping( value = "/grid")
	@Operation(summary = "POST Grid", security = {
			@SecurityRequirement(name = "ADFS"),
			@SecurityRequirement(name = "AzureAD")
	})
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "POST Grid Dashboard Fetched Successfully", content = @Content(mediaType = "application/problem+json", schema = @Schema(implementation = DashboardGridTileResponse.class))),
			@ApiResponse(responseCode = "default", description = "All Errors", content = @Content(schema = @Schema(implementation = StandardErrorResponse.class)))
	})
	public ResponseEntity<DashboardGridTileResponse> getUnAssignedGridVernInfo(@RequestBody @Valid DashboardGridTileRequest dashboardGridTileRequest) {
		DashboardGridTileResponse response = dashboardGridTileService.getUnAssignedGridVernInfo(dashboardGridTileRequest);
		return ResponseEntity.ok(response);
	}
}
