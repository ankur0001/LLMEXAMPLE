package com.ford.gcamp.targeting.gridgcamp.grid.entity;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.IdClass;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;

import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.hibernate.annotations.NotFound;
import org.hibernate.annotations.NotFoundAction;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Entity
@IdClass(GridVernCountId.class)
@Table(name = "SGCPF61_GRID_VEHCNT")
public class GridVernCountData implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name = "GCPA15_GLOBL_FSA_R")
	private int globalFSANumber;
	@Id
	@Column(name = "GCPA09_SUPPL_C")
	private String supplementCode;

	@Column(name = "GCPA16_LOCAL_FSA_R")
	private String localFSANumber;
	@Id
	@Column(name = "COUNTRY_ISO3_C")
	private String countryCode;
	@Id
	@Column(name = "GCPE10_HUB_C")
	private String hubCode;
	
	@JoinColumn(name = "GCPA15_GLOBL_FSA_R", referencedColumnName = "GCPA15_GLOBL_FSA_R", insertable = false, updatable = false)
	@JoinColumn(name = "GCPE10_HUB_C", referencedColumnName = "GCPE10_HUB_C", insertable = false, updatable = false)
	@OneToOne
	@NotFound(action = NotFoundAction.IGNORE)
	private LocalFSADetail localFSA;
	
	@JoinColumn(name = "COUNTRY_ISO3_C", referencedColumnName = "COUNTRY_ISO3_C", insertable = false, updatable = false)
	@OneToOne
	@NotFound(action = NotFoundAction.IGNORE)
	private HubCountryLookupData hubCountry;

	@Id
	@Column(name = "GCPE11_ROI_C")
	private String roiCode;
	
	@JoinColumn(name = "COUNTRY_ISO3_C", insertable = false, updatable = false)
	@OneToOne
	private CountryLookupData country;
	
	@JoinColumn(name = "GCPB03_BRAND_C", insertable = false, updatable = false)
	@OneToOne
	private BrandLookupData brand;
	
	@Id
	@Column(name = "GCPB03_BRAND_C")
	private String brandCode;
	
	@Id
	@Column(name = "GCPB13_VEH_TYP_C")
	private String vehicleTypeCode;
	
	@JoinColumn(name = "GCPB13_VEH_TYP_C" ,referencedColumnName = "GCPB13_VEH_TYP_C", insertable = false, updatable = false)
	@JoinColumn(name = "GCPB22_VEH_LN_C", referencedColumnName = "GCPB22_VEH_LN_C", insertable = false, updatable = false)
	@JoinColumn(name = "GCPB22_MODEL_YR_C", referencedColumnName = "GCPB22_MODEL_YR_C", insertable = false, updatable = false)
	@OneToOne
	@NotFound(action = NotFoundAction.IGNORE)
	private VehicleLineLookupData vehicleLine;
	
	@Id
	@Column(name = "GCPB22_VEH_LN_C")
	private String vehicleLineCode;
	
	@Id
	@Column(name = "GCPB22_MODEL_YR_C")
	private int modelYear;
	@Id
	@Column(name = "GCPF61_SOLD_F")
	private String soldFlag;
	@Id
	@Column(name = "GCPF61_VEHLN_T")
	private int vehicleCount;
	@Transient
	private String vehicleKey;

	public String getVehicleKey() {
		StringBuilder vehKeyBuilder = new StringBuilder();
		vehKeyBuilder.append(brand.getCode())
				.append(vehicleTypeCode)
				.append(ObjectUtils.isNotEmpty(vehicleLine) ? vehicleLine.getCode() : StringUtils.EMPTY)
				.append(modelYear)
				.append(StringUtils.trim(hubCountry.getGridHubCode()))
				.append(country.getCode());
		return vehKeyBuilder.toString();
	}

}
