package com.ford.gcamp.targeting.gridgcamp.grid.entity;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Entity
@Table(name = "SGCPE09_GRID_HUB_CTRY")
public class HubCountryLookupData implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name = "COUNTRY_ISO3_C")
	private String countryCode;
	@Column(name = "GCPE10_HUB_C")
	private String hubCode;
	@Column(name = "GCPE09_GRID_HUB_C")
	private String gridHubCode;
	@Column(name = "GCPE09_EFF_FROM_Y")
	private String effFromDate;
	@Column(name = "GCPE09_EFF_TO_Y")
	private String effToDate;
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((gridHubCode == null) ? 0 : gridHubCode.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		HubCountryLookupData other = (HubCountryLookupData) obj;
		if (gridHubCode == null) {
			if (other.gridHubCode != null) {
				return false;
			}
		} else if (!gridHubCode.equals(other.gridHubCode)) {
			return false;
		}
		return true;
	}

}
