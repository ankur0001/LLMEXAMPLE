package com.ford.gcamp.targeting.gridgcamp.gcamp.api;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.*;
import lombok.experimental.SuperBuilder;

import static com.ford.gcamp.targeting.common.CommonConstants.SWAGGER_ANY_CHARACTER_REGEX;
import static com.ford.gcamp.targeting.common.CommonConstants.SWAGGER_VALIDATION_MIN_INT_ZERO;

@Data
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
public class FSAMappingTypes {

    @Size(min = SWAGGER_VALIDATION_MIN_INT_ZERO, max = 99)
    @Pattern(regexp =SWAGGER_ANY_CHARACTER_REGEX)
    @Schema(example= "25S009", description = "localFSANumber",maxLength = 99)
    private String originalFsas;
    @Size(min = SWAGGER_VALIDATION_MIN_INT_ZERO, max = 99)
    @Pattern(regexp =SWAGGER_ANY_CHARACTER_REGEX)
    @Schema(example= "25S009", description = "localFSANumber",maxLength = 99)
    private String supplementFsas;
    @Size(min = SWAGGER_VALIDATION_MIN_INT_ZERO, max = 99)
    @Pattern(regexp =SWAGGER_ANY_CHARACTER_REGEX)
    @Schema(example= "20065", description = "globalFSANumber",maxLength = 99)
    private String globalFsas;
}
