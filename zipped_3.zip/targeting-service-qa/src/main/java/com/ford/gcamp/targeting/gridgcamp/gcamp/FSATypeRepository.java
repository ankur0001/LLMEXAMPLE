package com.ford.gcamp.targeting.gridgcamp.gcamp;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ford.gcamp.targeting.gridgcamp.gcamp.entity.FSATypeLookupData;

@Repository
public interface FSATypeRepository extends JpaRepository<FSATypeLookupData, String> {

	public FSATypeLookupData findFirstByGridCode(String gridCode);
	
	public FSATypeLookupData findFirstByCode(String code);
}
