package com.ford.gcamp.targeting.gridgcamp.gcamp.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.sql.Timestamp;

@Setter
@Getter
@Entity
@Table(name = "SGCPG12_DSTLST_DTL")
public class DistributionDetailEntity {

    @EmbeddedId
    DistributionDetailId detailId;

    @Column(name = "GCPG12_UPDATE_ID_C")
    private String UpdateId;

    @Column(name = "GCPG12_UPDATE_S")
    private Timestamp UpdateIdS;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "GCPG11_DIST_LIST_D", referencedColumnName = "GCPG11_DIST_LIST_D", insertable = false, updatable = false)
    private ProcessDistributionMapEntity distributionMapEntity;

}
