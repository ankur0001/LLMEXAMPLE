package com.ford.gcamp.targeting.manualaddvin.api;

import java.util.ArrayList;
import java.util.List;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Size;
import org.springframework.stereotype.Component;

import com.ford.gcamp.targeting.common.api.CommonResponse;
import com.ford.gcamp.targeting.common.api.FSAInfoVO;
import com.ford.gcamp.targeting.common.api.SuppPopulationVo;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Component
@Getter
@Setter
@NoArgsConstructor
public class ManualUploadResponse extends CommonResponse{
	@Size(min = 0, max = 300, message = "segmentMapVo List")
	private List<@Valid SegmentMapVo> segmentMapVo;

	@Size(min = 0, max = 300, message = "vinStatus List")
	private ArrayList<String> vinStatus;

	@Size(min = 0, max = 300, message = "invalidVins List")
	private List<@Valid ManuallyAddVINsValidateVO> invalidVins;

    @Valid
	private FSAInfoVO fsaInfoVO;

	@Size(min = 0, max = 300, message = "supplements List")
	private List<@Valid SuppPopulationVo> supplements;

}
