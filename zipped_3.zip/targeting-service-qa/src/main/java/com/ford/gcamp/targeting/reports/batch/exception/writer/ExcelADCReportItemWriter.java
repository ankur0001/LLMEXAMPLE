
package com.ford.gcamp.targeting.reports.batch.exception.writer;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import com.ford.gcamp.targeting.reports.batch.common.ReportGenerationUtil;
import org.apache.poi.xssf.streaming.SXSSFSheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.item.Chunk;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import com.ford.gcamp.targeting.reports.batch.api.ExcelConfig;
import com.ford.gcamp.targeting.reports.batch.api.ReportMetaData;
import com.ford.gcamp.targeting.reports.batch.common.ReportCodeConstants;
import com.ford.gcamp.targeting.reports.batch.exception.GCAMPReportException;
import com.ford.gcamp.targeting.reports.batch.exception.api.ADCReport;
import com.ford.gcamp.targeting.reports.batch.writer.GCAMPXSSFReportWriter;

@Component(ReportCodeConstants.ADC + "itemWriter")
@StepScope
public class ExcelADCReportItemWriter extends GCAMPXSSFReportWriter implements ItemWriter<ADCReport> {

	private List<ADCReport> adcList;

	@Value("#{jobParameters['reportMetaData']}")
	private String reportMetaDataString;

	private ReportMetaData reportData;

	@Override
	public void write(Chunk<? extends ADCReport> items) throws Exception {
		reportData = ReportGenerationUtil.getReportMetaDataObject(reportMetaDataString);
		adcList = new ArrayList<>(items.getItems());
		this.createReport(reportData);
	}

	@Override
	public void createWorksheet(SXSSFWorkbook hssfWorkbook, ReportMetaData metaData) throws GCAMPReportException {

		initializeWorkbook(hssfWorkbook);

		SXSSFSheet sheet = hssfWorkbook.createSheet("Assign Default Country Report");

		try {

			createProfile(sheet, metaData, "Assign Default Country");

			List<ExcelConfig> adcExcelConfig = loadConfigFile(ReportCodeConstants.ADC, metaData.getSuppCode());

			setColumnWidth(sheet, adcExcelConfig);

			setColumnHeader(sheet, adcExcelConfig);

			setRowData(sheet,adcExcelConfig, adcList);

		} catch (Exception e) {
			throw new GCAMPReportException("Assign Default Country REPORT ERROR: Error in creating the report", e);
		}

	}

}