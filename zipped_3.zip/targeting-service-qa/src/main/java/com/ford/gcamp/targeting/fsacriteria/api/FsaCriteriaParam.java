package com.ford.gcamp.targeting.fsacriteria.api;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class FsaCriteriaParam {
	    @Size(min = 0, max = 2)
		@Pattern(regexp = "^|[a-zA-Z\\d\\s]*$")
	    @Schema(example = "02", description = "operation Type")
		private String operationType;

        @NotNull
	    @Size(min = 0, max = 10)
		@Pattern(regexp = "[a-zA-Z\\d\\s]*$")
	    @Schema(example = "20322", description = "FSA number")
		private String fsaNumber;

		@NotNull
	    @Size(min = 0, max = 1)
	    @Pattern(regexp = "^[a-zA-Z]$")
	    @Schema(example = "G", description = "G-Global, L-Local")
		private String fsaType;


        @Size(min=0 , max=2)
		@Pattern(regexp =  "^[a-zA-Z\\d]*$")
		@Schema(types = {"string","null"},example = "00", description ="Vehicle Population code")
		private String vehiclePopUpCode;

        @NotNull
	    @Size(min = 0, max = 8)
	    @Pattern(regexp = "^[a-zA-Z\\d\\-]*$")
	    @Schema(example = "DMADHUMI", description = "CDSID")
		private String cdsId;


	    @Size(min = 0, max = 2)
		@Pattern(regexp = "^[A-Za-z\\d\\s\\*]*$")
	    @Schema(example = "GH", description = "Vin Group Code")
		private String vinGrpCode;


		@Size(min = 0, max = 4)
	    @Pattern(regexp = "^[A-Za-z\\d\\s\\*]*$")
	    @Schema(example = "2", description = "Vin Grp Seq")
		private String vinGrpSeq;


	    @Size(min=0 ,max = 254)
	    @Pattern(regexp = "^[A-Za-z\\d\\s\\*,._\\-()]*$")
	    @Schema(example = "OTA Test1", description = "VinGrpDesc")
		private String vinGrpDesc;

	    @Size(min=0,max = 4)
	    @Pattern(regexp = "^[A-Za-z\\d\\s\\*]*$")
	    @Schema(example = "0000", description = "criteriaListCount")
		private String criteriaListCount;


		@Size(min = 0, max = 2)
	    @Pattern(regexp = "^[A-Za-z\\d\\s\\*]*$")
	    @Schema(example = "00", description = "Vin Group Code")
		private String supplementCode;

	    @Schema(example= "N" , description = "Flag")
	    @Size(min = 0, max = 1)
	    @Pattern(regexp ="^[A-Za-z]$")
		private String fileOnlyFlag;

	    @Schema(example= "N" , description = "Flag")
	    @Size(min = 0, max = 1)
	    @Pattern(regexp ="^[A-Za-z]$")
		private String otaIndicator;

		@Schema(example= "B" , description = "Flag")
		@Size(min = 0, max = 1)
		@Pattern(regexp ="^[A-Za-z]$")
		private String  fhmIndication;
		
		@Override
		public String toString() {
			StringBuilder builder = new StringBuilder();
			builder.append("FsaCriteriaParam [fsaNumber=");
			builder.append(fsaNumber);
			builder.append(", fsaType=");
			builder.append(fsaType);
			builder.append(", vehiclePopUpCode=");
			builder.append(vehiclePopUpCode);
			builder.append(", cdsId=");
			builder.append(cdsId);
			builder.append(", vinGrpCode=");
			builder.append(vinGrpCode);
			builder.append(", vinGrpSeq=");
			builder.append(vinGrpSeq);
			builder.append(", vinGrpDesc=");
			builder.append(vinGrpDesc);
			builder.append(", criteriaListCount=");
			builder.append(criteriaListCount);
			builder.append(", supplementCode=");
			builder.append(supplementCode);
			builder.append("]");
			return builder.toString();
		}



}
