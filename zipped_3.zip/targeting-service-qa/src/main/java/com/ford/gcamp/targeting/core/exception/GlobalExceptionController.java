package com.ford.gcamp.targeting.core.exception;


import com.ford.cloudnative.base.api.BaseBodyError;
import com.ford.cloudnative.base.api.StandardErrorResponse;
import com.ford.gcamp.targeting.common.CommonConstants;
import jakarta.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.web.HttpMediaTypeNotSupportedException;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.ford.gcamp.targeting.common.api.CommonErrorResponse;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;

import static org.springframework.http.HttpStatus.METHOD_NOT_ALLOWED;


@ControllerAdvice
@Order(1)
public class GlobalExceptionController extends ResponseEntityExceptionHandler {

	@ExceptionHandler(GCAMPException.class)
	@ResponseBody
	public ResponseEntity<CommonErrorResponse> handleGCAMPException(HttpServletResponse response, GCAMPException ex) {
		return new ResponseEntity<>(ex.getResponseStatus(), HttpStatus.PRECONDITION_FAILED);
	}

	@Override
	protected ResponseEntity<Object> handleHttpMediaTypeNotSupported(HttpMediaTypeNotSupportedException ex,
																	 HttpHeaders headers, HttpStatusCode status,

																	 WebRequest request) {

		CommonErrorResponse errorResponse = new CommonErrorResponse();
		errorResponse.setStatusCode(status.toString());
		errorResponse.setStatus(CommonConstants.FAILURE);
		errorResponse.setStatusDescription(ex.getMessage());
		return new ResponseEntity<>(errorResponse, HttpStatus.UNSUPPORTED_MEDIA_TYPE);	}


	@Override
	protected ResponseEntity<Object> handleHttpRequestMethodNotSupported(HttpRequestMethodNotSupportedException ex,
																		 HttpHeaders headers, HttpStatusCode status,

																		 WebRequest request) {
		CommonErrorResponse errorResponse = new CommonErrorResponse();
		errorResponse.setStatusCode(status.toString());
		errorResponse.setStatus(CommonConstants.FAILURE);
		errorResponse.setStatusDescription(ex.getMessage());
		return new ResponseEntity<>(errorResponse, HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(GCAMPValidationException.class)
	@ResponseBody
	public ResponseEntity<CommonErrorResponse> handleValidationException(HttpServletResponse response, GCAMPValidationException ex) {
		return new ResponseEntity<>(ex.getResponseStatus(),HttpStatus.BAD_REQUEST);
	}
	
	@ExceptionHandler(ResourceNotFoundException.class)
	@ResponseBody
	public ResponseEntity<CommonErrorResponse> handleResourceNotFoundException(HttpServletResponse response, ResourceNotFoundException ex) {
		return new ResponseEntity<>(ex.getResponseStatus(),HttpStatus.NOT_FOUND);
	}
	
	@Override
	protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex,
																   HttpHeaders headers, HttpStatusCode status,
																   WebRequest request) {
		CommonErrorResponse errorResponse = new CommonErrorResponse();
	    return new ResponseEntity<>(errorResponse, HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler({ AccessDeniedException.class })
	public ResponseEntity<Object> handleAccessDeniedException(Exception ex, WebRequest request) {
		return new ResponseEntity<>(StringUtils.EMPTY, new HttpHeaders(), HttpStatus.OK);
	}
}
