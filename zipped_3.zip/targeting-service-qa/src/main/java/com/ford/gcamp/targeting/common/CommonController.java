package com.ford.gcamp.targeting.common;

import com.ford.cloudnative.base.api.StandardErrorResponse;
import com.ford.gcamp.targeting.common.api.CommonErrorResponse;
import com.ford.gcamp.targeting.common.api.CommonResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ford.gcamp.targeting.common.api.GenericLookupResponse;
import com.ford.gcamp.targeting.common.api.RoiCountryResponse;
import com.ford.gcamp.targeting.core.exception.GCAMPException;
import com.ford.gcamp.targeting.properties.HubPropertiesResponse;

import org.springframework.web.bind.annotation.PathVariable;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping(path = "/api/v1/targeting/common")
@Validated
public class CommonController {
	private CommonService commonService;

	public CommonController(CommonService commonService) {
		this.commonService = commonService;
	}


    @Operation(summary = "Load Roi Country for a Hub selected", security = {
			@SecurityRequirement(name = "ADFS"),
			@SecurityRequirement(name = "AzureAD")
	})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Load RoiCountries request fetched successfully",
                    content = @Content(mediaType = "application/problem+json", schema = @Schema(implementation = RoiCountryResponse.class))),
            @ApiResponse(responseCode = "412", description = "Precondition Failed", content = @Content(schema = @Schema(implementation = CommonResponse.class))),
            @ApiResponse(responseCode = "default", description = "All Errors", content = @Content(schema = @Schema(implementation = StandardErrorResponse.class)))
    })
    @GetMapping(value = "/{hubCode}/roicountry/load")
    public ResponseEntity<RoiCountryResponse> loadHubRoiCountry(@PathVariable @NotNull @Size(min = 1, max = 2)
                                                                @Pattern(regexp = "^[a-zA-Z\\*\\s]*$")
                                                                @Schema(example = "NA", description = "Hub code") String hubCode) throws GCAMPException {
        RoiCountryResponse countryResponse = commonService.loadCountry(hubCode);
        return ResponseEntity.ok(countryResponse);
    }


    @Operation(summary = "Get the Global FSA Number", security = {
			@SecurityRequirement(name = "ADFS"),
			@SecurityRequirement(name = "AzureAD")
	})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Load RoiCountries request processed successfully", content = @Content(mediaType = "application/problem+json", schema = @Schema(implementation = GenericLookupResponse.class))),
            @ApiResponse(responseCode = "default", description = "All Errors", content = @Content(schema = @Schema(implementation = StandardErrorResponse.class)))
    })
    @GetMapping("/supplements/{globalFsaNumber}")
    public ResponseEntity<GenericLookupResponse> getSupplements(
            @PathVariable @Valid @Size(max= 5,message = "Global FSA should be less than 10 characters") @Parameter(required = true, schema = @Schema(example = "18070", pattern = "^[\\d]*$"))
            String globalFsaNumber) {
        GenericLookupResponse hubResponse = commonService.getSupplements(globalFsaNumber);
        return ResponseEntity.ok(hubResponse);
    }


    @Operation(summary = "Get the HubKey", security = {
			@SecurityRequirement(name = "ADFS"),
			@SecurityRequirement(name = "AzureAD")
	})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Load RoiCountries request processed successfully", content = @Content(schema = @Schema(implementation = HubPropertiesResponse.class))),
            @ApiResponse(responseCode = "default", description = "All Errors", content = @Content(mediaType = "application/problem+json", schema = @Schema(implementation = StandardErrorResponse.class)))
    })
    @GetMapping("/properties/hub/{hubKey}")
    public ResponseEntity<HubPropertiesResponse> getHubFromPropertyFile(@PathVariable @NotNull @Size(min = 0, max = 50)
                                                                        @Pattern(regexp = "^[a-zA-Z\\*]*$")
                                                                        @Schema(example = "maintainnhtsadetails", description = "Hub Key Value") String hubKey) {
        HubPropertiesResponse hub = commonService.getHubFromPropertyFile(hubKey);
        return ResponseEntity.ok(hub);
    }

    @Operation(summary = "Get the Countries for a Hub", security = {
			@SecurityRequirement(name = "ADFS"),
			@SecurityRequirement(name = "AzureAD")
	})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Load RoiCountries request processed successfully", content = @Content(schema = @Schema(implementation = GenericLookupResponse.class))),
            @ApiResponse(responseCode = "default", description = "All Errors", content = @Content(mediaType = "application/problem+json", schema = @Schema(implementation = StandardErrorResponse.class)))
    })
    @GetMapping("/countries/load/{hub}")
    public ResponseEntity<GenericLookupResponse> getCountries(@PathVariable("hub") @NotNull
                                                              @Size(min = 0, max = 2)
                                                              @Pattern(regexp = "^[A-Z\\*\\s]{1,2}$")
                                                              @Schema(example = "NA", description = "Hub Code") String hub) {
        GenericLookupResponse countryResponse = commonService.getCountries(hub);
        return ResponseEntity.ok(countryResponse);
    }
}
