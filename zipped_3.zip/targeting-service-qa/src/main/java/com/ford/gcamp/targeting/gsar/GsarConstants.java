package com.ford.gcamp.targeting.gsar;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public class GsarConstants {

	public static final String MF_FTP_CONFIG = "/ftadv:P=UNIX,RECFM=FB,LR=500,CY,PRI=80,SEC=80/__/";
	public static final Map<String, String> STOP_SHIP_REPAIR_STATUS;
	static {
		Map<String, String> stopShipRepairStatusMap = new HashMap<>();
		stopShipRepairStatusMap.put("Good", "G");
		stopShipRepairStatusMap.put("Repaired", "R");
		stopShipRepairStatusMap.put("Removed", "X");
		stopShipRepairStatusMap.put("Suspect", "S");
		stopShipRepairStatusMap.put("Bad", "B");
		STOP_SHIP_REPAIR_STATUS = Collections.unmodifiableMap(stopShipRepairStatusMap);
	}
	
	private GsarConstants() {
		
	}
	
	
}
