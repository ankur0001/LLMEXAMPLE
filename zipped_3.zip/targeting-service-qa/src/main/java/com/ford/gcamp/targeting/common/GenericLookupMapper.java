package com.ford.gcamp.targeting.common;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.commons.lang3.StringUtils;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import com.ford.gcamp.targeting.common.api.GenericLookup;
@Component
public class GenericLookupMapper implements RowMapper<GenericLookup> {

	@Override
	public GenericLookup mapRow(ResultSet rs, int rowNum) throws SQLException {
		return GenericLookup.builder()
				.code(StringUtils.trimToEmpty(rs.getString(1)))
				.description(StringUtils.trimToEmpty(rs.getString(2)))
				.build();
	}

}
