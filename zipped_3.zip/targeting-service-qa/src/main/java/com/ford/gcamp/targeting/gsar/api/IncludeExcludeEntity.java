package com.ford.gcamp.targeting.gsar.api;


import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Size;
import java.io.Serializable;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@Entity
@AllArgsConstructor
@NoArgsConstructor
@Table(name="SGCPD08_INCL_EXCL")
public class IncludeExcludeEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    @EmbeddedId
    private IncludeExcludeId includeExcludeId;

    @Column(name = "GCPD08_FLDR_PATH_X")
    private String folderPath;

    @Size(max = 2)
    @Schema(example = "00", description = "Supplement Code")
    @Column(name = "GCPA09_SUPPL_C")
    private String supplementCode;

    @Size(max = 1)
    @Schema(example = "I", description = "Folder Action Flag")
    @Column(name = "GCPD08_FLDRACTN_F")
    private String folderActionFlag;
}
