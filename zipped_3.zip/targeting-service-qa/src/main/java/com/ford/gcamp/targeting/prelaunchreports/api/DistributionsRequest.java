package com.ford.gcamp.targeting.prelaunchreports.api;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.*;

@Setter
@Getter
@JsonIgnoreProperties(ignoreUnknown = true)
public class DistributionsRequest {
	@Size(min = 0, max = 10)
	@Pattern(regexp = "^|([a-zA-Z\\d\\s]*$)")
	@Schema(example = "67984", description = "FSA number")
	private String fsaNumber;

	@Schema(example = "G", description = "fsaType")
	@Size(min = 0, max = 1)
	@Pattern(regexp = "^[A-Za-z]$", message = "FSA Type")
	private String fsaType;

	@Size(min = 0, max = 2)
	@Pattern(regexp = "^[a-zA-Z\\*\\s]*$")
	@Schema(example = "NA", description = "Hub code")
	private String hubCode;

	@Schema(example= "S" , description = "process Flag")
	@Size(min = 0, max = 1)
	@Pattern(regexp ="^[A-Za-z]$")
	private String processFlag;

	@NotNull
	@Size(min = 0, max = 8)
	@Pattern(regexp = "^[a-zA-Z\\d\\-\\s]*$")
	@Schema(example = "TDHARTI", description = "CDSID")
	private String cdsId;

	@Size(min = 0, max = 99999)
	@Pattern(regexp = "^|([a-zA-Z\\d]*$)")
	@Schema(example = "678", description = "procCode")
	private String procCode;

	@Size(min = 0, max = 40)
	@Pattern(regexp = "^|([a-zA-Z\\d\\s\\*]*$)")
	@Schema(example = "testingg1", description = "proc Desc")
	private String procDesc;

	@Size(min = 0, max = 3)
	@Pattern(regexp = "^[a-zA-Z\\*\\s\\d]*$")
	@Schema(example = "CAN", description = "CountryCode")
	private String countryCode;

	@Size(min = 0, max = 999999)
	@Pattern(regexp = "^|([\\d\\s]*$)")
	@Schema(example = "67", description = "Dist List code")
	private String distListCode;

	@Size(min = 0, max = 40)
	@Pattern(regexp = "^|([a-zA-Z\\d\\s\\*]*$)")
	@Schema(example = "new report", description = "dist List Desc")
	private String distsListDesc;

	@Size(min = 0, max = 99999)
	@Pattern(regexp = "^|([a-zA-Z\\d\\s\\*\\,]*$)")
	@Schema(example = "tdharti", description = "add member List")
	private String addMemberList;


	@Size(min = 0, max = 9999)
	@Pattern(regexp = "^|([a-zA-Z\\d\\s\\*\\,]*$)")
	@Schema(example = "tdharti", description = "remove member List")
	private String removeMemberList;


	@Schema(example= "Y" , description = "dist List Flag")
	@Size(min = 0, max = 1)
	@Pattern(regexp ="^|([A-Za-z\\s]$)")
	private String distListflag;

	@Schema(example= "Y" , description = "save Member List Flag")
	@Size(min = 0, max = 1)
	@Pattern(regexp ="^|([A-Za-z]$)")
	private String saveMemberListFlag;
	
}
