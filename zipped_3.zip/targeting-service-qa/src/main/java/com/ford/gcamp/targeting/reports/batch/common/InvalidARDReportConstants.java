package com.ford.gcamp.targeting.reports.batch.common;

public class InvalidARDReportConstants {

	public static final String COLUMN_HUB = "Hub";
	public static final String COLUMN_ROI = "ROI";
	public static final String COLUMN_BRAND = "Brand";
	public static final String COLUMN_DEALER_CODE = "Dealer Code";
	public static final String COLUMN_DEALER_NAME = "Dealer Name";
	public static final String COLUMN_COUNTRY = "Country";
	public static final String COLUMN_INVALIDITY_REASON = "Reason for Invalidity";
	public static final String COLUMN_TERMNATION_DATE = "Termination Date";

	private InvalidARDReportConstants() {
	}

}
