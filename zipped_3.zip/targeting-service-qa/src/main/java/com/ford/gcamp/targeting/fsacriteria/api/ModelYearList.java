package com.ford.gcamp.targeting.fsacriteria.api;

import com.fasterxml.jackson.annotation.JsonIgnore;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ModelYearList {

	@Size(min = 0, max = 4)
	@Pattern(regexp = "^[\\d]*$")
	@Schema(example = "2024", description = "Model Year")
	private String modelYears;
	@JsonIgnore
	private int modelYearsInt; 
	@JsonIgnore
	private String brandCode;
	@JsonIgnore
	private String vehLine;
	

	public ModelYearList(String modelYears, int modelYearsInt) {
		super();
		this.modelYears = modelYears;
		this.modelYearsInt = modelYearsInt;
	}

	
}


