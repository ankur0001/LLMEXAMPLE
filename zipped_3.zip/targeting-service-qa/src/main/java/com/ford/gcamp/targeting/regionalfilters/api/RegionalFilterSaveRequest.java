package com.ford.gcamp.targeting.regionalfilters.api;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.v3.oas.annotations.extensions.Extension;
import io.swagger.v3.oas.annotations.extensions.ExtensionProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Builder
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class RegionalFilterSaveRequest {

	@Size(min = 5, max = 6)
	@Pattern(regexp = "^\\d{2}[A-Za-z\\d]{2}\\d{1}\\d*$")
	@Schema(type="string", description = "FSA number",minLength=5,maxLength = 6, extensions = @Extension(properties = @ExtensionProperty(name = "x-42c-sample", value = "15311")))
	private String globalFsaNumber;

	@Size(min = 1, max = 8)
	@Pattern(regexp = "^[a-zA-Z\\d\\-]*$")
	@Schema(example = "TDHARTI", description = "CDSID")
	private String cdsId;

	@Size(min = 1, max = 1)
	@Pattern(regexp = "^[a-zA-Z]$")
	@Schema(example = "I", description = "indicator")
	private String indicator;


	@Size(min = 1, max = 1)
	@Pattern(regexp = "^[\\d]$")
	@Schema(example = "0", description = "parm")
	private String parm;
	@JsonProperty
	private boolean isOriginallySoldIn;
	@JsonProperty
	private boolean isCurrentlyResidesIn;


	@Size(min = 0, max = 500, message = "Hub Countries List")
	private List<@Valid HubCountry> hubCountries;

	@Size(min = 0, max = 500, message = "Country States List")
	private List<@Valid CountryState> countryStates;

	@Size(min = 0, max = 500, message = "Zip Codes List")
	private List<@Valid RegionalZipPostalCode> zipCodes;

	@Size(min = 0, max = 500, message = "Supplements List")
	private List< @Size( min = 1,max = 2) @Pattern(regexp = "^[A-Za-z\\d\\s]*$") String> supplements;
}
