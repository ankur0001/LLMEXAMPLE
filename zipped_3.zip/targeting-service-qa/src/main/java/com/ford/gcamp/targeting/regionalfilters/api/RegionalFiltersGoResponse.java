package com.ford.gcamp.targeting.regionalfilters.api;

import java.util.List;

import com.ford.gcamp.targeting.common.api.CommonResponse;
import com.ford.gcamp.targeting.common.api.FSAInfoVO;
import com.ford.gcamp.targeting.common.api.GenericLookup;
import com.ford.gcamp.targeting.common.api.HubTreeCurrent;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RegionalFiltersGoResponse  extends CommonResponse{
    @Valid
	private FSAInfoVO fsaDetails;

	@Size(min = 0, max = 500, message = "hubRoiCoutries List")
	private List<@Valid HubTreeCurrent> hubRoiCountries;

	@Size(min = 0, max = 500, message = "stateProvinces List")
	private List<@Valid StateProvCountry> stateProvinces;

	@Size(min = 0, max = 500, message = "zipPostalCodes List")
	private List<@Valid RegionalZipPostalCode> zipPostalCodes;


	private Boolean currentlyResidesIn=false;
	private Boolean originallySoldIn=false;

	@Size(min = 0, max = 500, message = "existingSupplements List")
	private List<@Valid GenericLookup> existingSupplements;
	
}
