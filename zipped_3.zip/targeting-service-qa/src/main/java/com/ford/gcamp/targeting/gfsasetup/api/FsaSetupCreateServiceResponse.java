package com.ford.gcamp.targeting.gfsasetup.api;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDate;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class FsaSetupCreateServiceResponse {

	private int globalFsaNumber;

	private String externalStatistics;

	private String fsaStatistics;

	private String fsaType;

	private LocalDate hstPurgeDate;

	private String hstPurge;

	private LocalDate deliveryRequestDate;

	private BigDecimal globalAllocation;

	private BigDecimal requestRepresentation;

	private String inspectionAllowable;

	private LocalDate fsaExpiryDate;

	private String vinLoad;

	private String fsaCartId;

	private String otherHub;

	private LocalDate vinPurgeDate;

	private String externalRequestId;

	private String author14D;

	private int externalVin;

	private LocalDate fsaCreateDate;

	private String fileOnly;

	private int fsaMonth;

	private int mlgLimit;

	private int svcLimit;

	private LocalDate launchDate;

	private String launch;

	private LocalDate countryCommunicationDate;

	private String countryCommunication;

	private LocalDate hubCommunicationDate;

	private String hubCommunication;

	private String suspenseOrderFlag;

	private String suspenseOrderCode;

	private LocalDate suspenseOrderDate;

	private LocalDate relationControlDate;

	private LocalDate frcDecisionDate;

	private String number14D;

	private String optionalHub;

	private BigDecimal buildingClaim;

	private BigDecimal buildingNoClaim;

	private String buildingId;

	private String buildingString;

	private String updateId;

	private String updateString;

	private String fsaSpecialComments;

	private String suspenseOrderDesc;

	private String globalFsa;

	private String fsaStatisticsString;

	private String nonVdm;

	private String nonVdmDesc;

	private int totalVin;

	private BigDecimal actualNoClaim;

	private String activity;

	private String targetEtl;

	private String fsaUpdateId;

	private String fsaUpdateString;

	private String ota;


}