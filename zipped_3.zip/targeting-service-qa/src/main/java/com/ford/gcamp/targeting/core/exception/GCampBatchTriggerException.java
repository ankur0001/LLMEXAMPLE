package com.ford.gcamp.targeting.core.exception;
public class GCampBatchTriggerException extends GCAMPException {
	
	private static final long serialVersionUID = 1L;
	/**
	 * Constructor for GCampDatabaseException
	 */
	public GCampBatchTriggerException() {
		super();
	}

	/**
	 * Constructor for GCampDatabaseException
	 */
	public GCampBatchTriggerException(String msg) {
		super(msg);
	}


	/**
	 * Constructor for GCampDatabaseException
	 */
	public GCampBatchTriggerException(Throwable rootCause) {
		super(rootCause);
	}

	/**
	 * Constructor for GCampDatabaseException
	 */
	public GCampBatchTriggerException(String msg, Throwable rootCause) {
		super(msg, rootCause);
	}
	

}

