package com.ford.gcamp.targeting.frozenvin;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.ford.gcamp.targeting.common.TargetingUtil;


public class FrozenVinUtil {
	
	private static final String SPLIT_REGEX = "\\s{2,}";

	public String formInputParam(String fscNumber, String optRadio) {
		StringBuilder sb = new StringBuilder();
		sb.append(optRadio);
		if ("G".equals(optRadio)) {
			sb.append(TargetingUtil.fillRemainingString(fscNumber, 8, "0"));
			sb.append(" ");
			
		} else if ("L".equals(optRadio)) {
			sb.append(TargetingUtil.fillRemainingString(fscNumber.toUpperCase(), 10, " "));
		}
		return sb.toString();
	}

	public String formInputParam2(String hub, String population) {
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.append(hub);
		stringBuilder.append(population);
		return stringBuilder.toString();
		}

	public List<String> convertTOList(List<String> outParam1List) {
		List<String> result = new ArrayList<>();
		for (String string : outParam1List) {
			String[] str = string.split(SPLIT_REGEX);
			Collections.addAll(result, str);
		}
		return result;
	}

}
