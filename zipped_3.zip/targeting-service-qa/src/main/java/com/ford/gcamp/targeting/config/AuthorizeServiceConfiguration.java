package com.ford.gcamp.targeting.config;

import com.ford.aps.spring.service.AuthorizeService;
import com.ford.gcamp.targeting.multiauth.ApsOverrideAuthorizeService;
import org.springframework.boot.autoconfigure.condition.ConditionalOnExpression;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AuthorizeServiceConfiguration {

    @Bean("authorizeService")
    @ConditionalOnExpression(value = "!'${aps.pdp-base-url:}'.equals('')")
    AuthorizeService authorizeServiceOverride(
            ApsOverrideAuthorizeService apsOverrideAuthorizeService) {
        return apsOverrideAuthorizeService;
    }
}
