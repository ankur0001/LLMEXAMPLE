package com.ford.gcamp.targeting.regionalfilters.api;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class StateProvDetail {
	private String stateProvCode;
	private String stateProvDescription;
	private String countryCode;
	private String geoCondCode;
	private String geoCondDescription;

}
