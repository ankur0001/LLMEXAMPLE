package com.ford.gcamp.targeting.common;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.RandomAccessFile;
import java.nio.charset.StandardCharsets;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.ford.gcamp.targeting.core.exception.GCAMPException;
import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpException;

@Component
public class FTPSession  {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(FTPSession.class);
	
	@Value("${FTP_HOST}")
    private String host;

    @Value("${FTP_USERNAME}")
    private String username;

    @Value("${FTP_PASSWORD}")
    private String password;
    
    @Value("${ftp.privateKeyPath}")
    private String privateKeyFilePath;
    
    @Value("${ftp.sftpPrivateKey}")
    private String privateKeyFileName;
    
    @Value("${ftp.port}")
    private String port;
    
	protected String fileName = null;

	protected boolean loggedIn = false;
	protected boolean isPartialDownloadReady = false;
	protected InputStream partialDownloadInputStream = null;

	
	private Session session;
	private Channel channel;
	private ChannelSftp channelSftp;

	/**
	 * Used to upload a file to the ftp server's machine.
	 * 
	 * @param filename - filename to write the contents to on the ftp server.
	 * @param stream   - InputStream which contains contents of the file to transfer
	 *                 to the ftp server.
	 * @throws SftpException
	 * @throws JSchException
	 */
	public void uploadFile(String filename, InputStream stream, String dataset){

		if (dataset == null) {
			dataset = "";
		}			
		uploadFile(dataset, filename, stream);
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getFileName() {
		return this.fileName;
	}

	/**
	 * Used to upload a file to the ftp server's machine.
	 * 
	 * @param filename - filename to write the contents to on the ftp server.
	 * @param contents - contents of the file to transfer to the ftp server.
	 * @throws JSchException
	 * @throws SftpException
	 */
	public void uploadFile(String filename, String contents) {
		uploadFile("/ftadv:P=WIN/___cs.test", filename, contents);
	}

	public void setRecOptions(String strRecfm, int lreclen){
		try {
			if (!session.isConnected()) {
				session.connect();
				channel = session.openChannel("sftp");
				channel.connect();
				channelSftp = (ChannelSftp) channel;
			}
			
			channelSftp.ls("/+/lrecl="+lreclen);       
			channelSftp.ls("/+/recfm="+strRecfm); 
		}catch(JSchException | SftpException e) {
			LOGGER.error("Error occured :",e);
		}
		
	}
	
	/**
	 * Used to upload a file to the ftp server's machine.
	 * 
	 * @param directory - directory to write the file to on the ftp server.
	 * @param filename  - filename to write the contents to on the ftp server.
	 * @param contents  - contents of the file to transfer to the ftp server.
	 * @throws SftpException
	 * @throws JSchException
	 */
	public void uploadFile(String dir, String filename, String contents) {
		byte[] byetsContent = contents.getBytes(StandardCharsets.US_ASCII);
		try(InputStream ftpInputStream = new ByteArrayInputStream(byetsContent)) {
			getJschInstance(host, username, password);

			if (!session.isConnected()) {
				session.connect();
				channel = session.openChannel("sftp");
				channel.connect();
				channelSftp = (ChannelSftp) channel;
			}
			if (!"''".equals(dir) && !"".equals(dir) && !dir.isEmpty()) {
				channelSftp.cd(dir);
			}
			channelSftp.put(ftpInputStream, filename);
		}catch(IOException | JSchException | SftpException e) {
			LOGGER.error("Error Uploading :",e);
		} finally {
			logout();
		}
	}

	/**
	 * Used to upload a file to the ftp server's machine.
	 * 
	 * @param directory - directory to write the file to on the ftp server.
	 * @param filename  - filename to write the contents to on the ftp server.
	 * @param stream    - InputStream which contains contents of the file to
	 *                  transfer to the ftp server.
	 * @throws JSchException
	 * @throws SftpException
	 */
	public void uploadFile(String dir, String filename, InputStream stream){

		try {
			final String strMethodName = "uploadFile";
			LOGGER.info("Entering {}", strMethodName);
			
			getJschInstance(host, username, password);

			if (!session.isConnected()) {
				session.connect();
				channel = session.openChannel("sftp");
				channel.connect();
				channelSftp = (ChannelSftp) channel;
			}
			if (!"''".equals(dir) && !"".equals(dir) && !dir.isEmpty()) {
				channelSftp.cd(dir);
			}
			channelSftp.put(stream, filename);
			LOGGER.info("Exiting {}", strMethodName);
		}catch(JSchException | SftpException e) {
			LOGGER.error("Error uploading :",e);
		} finally {
			logout();
		}
		
	}


	/**
	 * Used to read a file from the client system. NOTE: this will not work if the
	 * client is running as an Applet.
	 *
	 * @param filename - file to read from the client system.
	 * @return StringBuffer - contents of the file read from the client's system.
	 */
	public StringBuilder readFile(String filename) throws IOException {

		StringBuilder sb = new StringBuilder();
		try(RandomAccessFile raf = new RandomAccessFile(filename, "r")){
			String line = raf.readLine();
			while (line != null) {
				sb.append(line + "\n");
				line = raf.readLine();
			}
		}
		
		return (sb);
	}

	/**
	 * Used to write a file to the client system. NOTE: this will not work if the
	 * client is running as an Applet.
	 *
	 * @param filename - filename to write the contents to on the client system.
	 * @param contents - contents of the file to write to the client file system.
	 */
	public void writeFile(String filename, String contents) throws IOException {

		try(RandomAccessFile raf = new RandomAccessFile(filename, "rw")){
			raf.writeBytes(contents);
		}
		
	}

	/**
	 * Used internally to send the logout sequence to the host system via socket.
	 */
	public void logout() {

		if (session.isConnected()) {
			channelSftp.exit();
			session.disconnect();
		}

		loggedIn = false;
	}

	/**
	 * Used to prepare for File Download a file from the ftp server's machine.
	 * 
	 * @param directory - directory which the file resides on the ftp server.
	 * @param filename  - filename to read from the ftp server.
	 * @throws JSchException
	 * @throws SftpException
	 */
	public void downloadFile(String filename) throws GCAMPException {
		File file = new File("/tmp/selectedVINFile.txt");
		try(OutputStream ous = new FileOutputStream(file)) {
			getJschInstance(host, username, password);
			if (!session.isConnected()) {
				session.connect();
				channel = session.openChannel("sftp");
				channel.connect();
				channelSftp = (ChannelSftp) channel;
			}
			LOGGER.info("The FTP connection is successfull");
			channelSftp.get("/ftadv:P=UNIX,RECFM=FB/___" + filename, ous);
		}catch(JSchException | SftpException | IOException e) {
			throw new GCAMPException("Error occured while downloading file, Contact systems", e);
		} finally {
			logout();
		}

	}
	
	public JSch getJschInstance(String host, String username, String password) throws JSchException {

		java.util.Properties config = new java.util.Properties();
		config.put("StrictHostKeyChecking", "no");
		
		LOGGER.info("Private key file : {}{}",privateKeyFilePath,privateKeyFileName);

		JSch jsch = new JSch();
	    jsch.addIdentity(privateKeyFilePath+privateKeyFileName, password);
		session = jsch.getSession(username, host, Integer.parseInt(port.trim()));
		session.setConfig("PreferredAuthentications", "publickey");
		session.setConfig(config);
		return jsch;

	}

	public Session getSession() {
		return session;
	}

	public void setSession(Session session) {
		this.session = session;
	}

	public Channel getChannel() {
		return channel;
	}

	public void setChannel(Channel channel) {
		this.channel = channel;
	}

	public ChannelSftp getChannelSftp() {
		return channelSftp;
	}

	public void setChannelSftp(ChannelSftp channelSftp) {
		this.channelSftp = channelSftp;
	}

}
