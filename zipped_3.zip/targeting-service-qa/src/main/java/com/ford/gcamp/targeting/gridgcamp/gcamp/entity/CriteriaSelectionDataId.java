package com.ford.gcamp.targeting.gridgcamp.gcamp.entity;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class CriteriaSelectionDataId implements Serializable{

	private static final long serialVersionUID = 1L;

	private int globalFSANumber;
	private int filterCode;
	private int selectionSequenceNumber;
}
