package com.ford.gcamp.targeting.gsar.api;


import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;

@Setter
@Getter
@Table(name="SGCPD08_INCL_EXCL")
@AllArgsConstructor
@NoArgsConstructor
@Embeddable
public class IncludeExcludeId implements Serializable {

    private static final long serialVersionUID = 1L;

    @Column(name = "GCPA15_GLOBL_FSA_R")
    private String globalFsaNumber;

    @Column(name = "GCPD08_FOLDER_D")
    private String folderId;
}
