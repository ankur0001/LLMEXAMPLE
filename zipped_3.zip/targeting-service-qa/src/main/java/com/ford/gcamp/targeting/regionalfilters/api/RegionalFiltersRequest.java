package com.ford.gcamp.targeting.regionalfilters.api;

import java.util.List;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor

public class RegionalFiltersRequest {

	@Size(min = 0, max = 10)
	@Pattern(regexp = "^[a-zA-Z\\d\\s]*$")
	@Schema(example = "15543", description = "global FSA number")
	private String globalFsaNumber;

	@Size(min = 0, max = 8)
	@Pattern(regexp = "^[a-zA-Z\\d\\-]*$")
	@Schema(example = "tdharti", description = "CDSID")
	private String cdsId;

	@Schema(example= "Y" , description = "Flag")
	@Size(min = 0, max = 1)
	@Pattern(regexp ="^[A-Za-z]*$")
	private String flag;


	@Size(min = 0, max = 250, message = "Supplements")
	private List<@Valid @Size(min = 0, max = 10)
	@Pattern(regexp ="^[A-Za-z\\d\\s]*$") String> supplements;
}
