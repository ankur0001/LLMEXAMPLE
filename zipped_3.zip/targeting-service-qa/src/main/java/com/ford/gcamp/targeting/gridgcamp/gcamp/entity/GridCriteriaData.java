package com.ford.gcamp.targeting.gridgcamp.gcamp.entity;


import java.sql.Timestamp;

import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Table;

import org.apache.commons.lang3.StringUtils;
import org.hibernate.annotations.UpdateTimestamp;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Entity
@Table(name = "SGCPD25_GRID_CRIT")
public class GridCriteriaData {

	@EmbeddedId
	private GridCriteriaId gridCriteriaId;

	@Column(name = "GCPD02_FILTER_C")
	private int filterCode;

	@Column(name = "GCPD02_FILTER_X")
	private String filterDescription;

	@Column(name = "GCPD25_VEHATTR_C")
	private String attributeCode;

	@Column(name = "GCPD25_VEHATTR_X")
	private String attributeDescription;

	@Column(name = "GCPD25_VEHATTR_BEG_C")
	private String attributeBegin;

	@Column(name = "GCPD25_VEHATTR_END_C")
	private String attributeEnd;

	@Column(name = "GCPD25_OPERATOR_C")
	private String operator;

	@Column(name = "GCPD25_UPDATE_ID_C")
	private String updateId;
	@Setter(AccessLevel.NONE)
	@Getter(AccessLevel.NONE)	
	@Column(name = "GCPD25_UPDATE_S")
	@UpdateTimestamp
	private Timestamp updateDate;
	@Column(name = "GCPD25_OTA_F")
	private String criteriaOTAIndicator;
	
	@PrePersist
	@PreUpdate
	public void updateDefault() {
		if(StringUtils.isEmpty(attributeBegin)) {
			attributeBegin = StringUtils.EMPTY;
		}
		if(StringUtils.isEmpty(attributeEnd)) {
			attributeEnd = StringUtils.EMPTY;
		}
		if(StringUtils.isEmpty(attributeDescription)) {
			attributeDescription = StringUtils.EMPTY;
		}
		if(StringUtils.isEmpty(attributeCode)) {
			attributeCode = StringUtils.EMPTY;
		}
	}

}
