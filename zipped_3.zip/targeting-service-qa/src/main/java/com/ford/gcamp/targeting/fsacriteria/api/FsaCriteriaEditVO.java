package com.ford.gcamp.targeting.fsacriteria.api;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Size;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ToString
@JsonIgnoreProperties(ignoreUnknown = true)
public class FsaCriteriaEditVO extends FsaVehicleCommonVO {

    @Schema(types = {"array", "null"})
    @Size(min = 0, max = 1000, message = "filterOutput1")
    private List<@Valid FsaCriteriaFilterOutputVO> filterOutput1;

    @Schema(types = {"array", "null"})
    @Size(min = 0, max = 1000, message = "filterOutput2")
    private List<@Valid FsaCriteriaFilterOutputVO> filterOutput2;

    @Valid
    @Schema(types = {"object", "null"})
    private VinGroupVO vinGroupVO;

    @Schema(types = {"array", "null"})
    @Size(min = 0, max = 1000, message = "models")
    private List<@Valid VehicleModelVO> models;

    @Schema(types = {"array", "null"})
    @Size(min = 1, max = 1000, message = "brands")
    private List<@Valid BrandVO> brands;

    @Schema(types = {"array", "null"})
    @Size(min = 1, max = 1000, message = "vehicleLine")
    private List<@Valid VehicleLineVO> vehicleLine;

    @Schema(types = {"array", "null"})
    @Size(min = 0, max = 1000, message = "assemblyPlants")
    private List<@Valid VehicleAssemblyPlantVO> assemblyPlants;

    @Schema(types = {"object", "null"})
    @Valid
    private VehicleProductionVO productionVO;

    @Schema(types = {"array", "null"})
    @Size(min = 0, max = 1000, message = "wersVO")
    private List<@Valid VehicleWersVO> wersVO;

    @Schema(types = {"array", "null"})
    @Size(min = 0, max = 1000, message = "vehicleAttributeGroups")
    private List<@Valid AttributeGroupingVO> vehicleAttributeGroups;
}
