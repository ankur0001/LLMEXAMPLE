package com.ford.gcamp.targeting.gsar;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.ford.gcamp.targeting.gsar.entity.GcampDataEntity;

@Repository
public interface GcampRepository extends JpaRepository<GcampDataEntity, Integer>{

	@Query(value = "SELECT A.VIN_CD FROM APP_SERVER.GCAMP_DATA A WHERE A.RESULT_ID= :resultId AND A.U_ID= :uniqueId", nativeQuery=true)
	List<String> findByResultId(@Param("resultId") Integer resultId, @Param("uniqueId") Long uniqueId);
	
}
