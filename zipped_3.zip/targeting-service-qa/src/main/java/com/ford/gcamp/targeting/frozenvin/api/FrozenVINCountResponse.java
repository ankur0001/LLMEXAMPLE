package com.ford.gcamp.targeting.frozenvin.api;


import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class FrozenVINCountResponse {

	@Min(0)
	@Max(999999)
	@Schema(example = "1019", description = "jobId code")
	private int jobId;

	@Size(min = 0, max = 10)
	@Pattern(regexp = "^[a-zA-z]*$")
	@Schema(example = "success", description = "response code")
	private String responseCode;

	@Size(min = 0, max = 100)
	@Pattern(regexp = "^[a-zA-z\\d\\s]*$")
	@Schema(example = "success", description = "response msg")
	private String responseMsg;

}

