package com.ford.gcamp.targeting.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.reactive.function.client.WebClient;

@Configuration
public class WebClientConfiguration extends WebClientOAuthConfig {

    public WebClientConfiguration(
            @Value("${grid.entra-id.client-id}") String clientId,
            @Value("${grid.entra-id.client-secret}") String clientSecret,
            @Value("${grid.entra-id.token-uri}") String tokenUri,
            @Value("${grid.entra-id.scope}") String scope,
            WebClient.Builder webClientBuilder,
            @Value("${proxy.host:internet.ford.com}") String proxyHost,
            @Value("${proxy.port:83}") int proxyPort) {
        super(
                clientId,
                clientSecret,
                tokenUri,
                scope,
                "grid-gcamp-client",
                webClientBuilder,
                proxyHost,
                proxyPort);
    }

    @Bean(name = "grid-gcamp-client")
    WebClient gridGcampWebClient() {
        return super.buildWebClientWithProxy();
    }

}
