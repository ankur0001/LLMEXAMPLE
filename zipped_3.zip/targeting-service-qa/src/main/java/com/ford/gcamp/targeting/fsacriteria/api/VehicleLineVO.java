package com.ford.gcamp.targeting.fsacriteria.api;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class VehicleLineVO extends FsaVehicleCommonVO {

	@Size(min = 0, max = 10)
	@Pattern(regexp = "^|[a-zA-Z\\d\\s]*$")
	@Schema(example = "000000043", description = "brandFilterCode")
	private String vehicleLineFilterCode;

	@Size(min = 0, max = 3)
	@Pattern(regexp = "^|[a-zA-Z\\d\\s]*$")
	@Schema( types = {"string","null"},example = "CQP", description = "operation Type")
	private String vehicleLineCode;

	@Size(min=0, max = 500)
	@Schema(types = {"string","null"},example = "323 (MAZDA) (CQP)", description = "statusDesc")
	@Pattern(regexp ="^|[A-Za-z\\d\\s,.\\-'\\/()\"\\#\\&]*$")
	private String vehicleLineDesc;
	
	
}
