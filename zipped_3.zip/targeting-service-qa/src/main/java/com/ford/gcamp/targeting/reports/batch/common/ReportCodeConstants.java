

package com.ford.gcamp.targeting.reports.batch.common;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ReportCodeConstants {

	public static final Map<String, String> REPORT_CODE_SQL_ID_MAP;
	static {
		Map<String, String> reportCodeSqlIdMap = new HashMap<>();
		reportCodeSqlIdMap.put("T21", "21B");
		reportCodeSqlIdMap.put("T22", "22A");
		reportCodeSqlIdMap.put("T23", "23A");
		reportCodeSqlIdMap.put("T24", "24A");
		reportCodeSqlIdMap.put("T25", "25A");
		reportCodeSqlIdMap.put("T26", "26A");
		reportCodeSqlIdMap.put("T27", "27A");
		reportCodeSqlIdMap.put("T28", "28A");
		reportCodeSqlIdMap.put("T29", "29A");
		reportCodeSqlIdMap.put("T30", "30A");
		reportCodeSqlIdMap.put("T31", "31A");
		reportCodeSqlIdMap.put("T32", "32A");
		reportCodeSqlIdMap.put("T33", "33A");
		reportCodeSqlIdMap.put("T34", "34A");
		reportCodeSqlIdMap.put("T35", "35A");
		REPORT_CODE_SQL_ID_MAP = Collections.unmodifiableMap(reportCodeSqlIdMap);
	}
	
	public static final Map<String, String> REPORT_CODE_SHEET_NAME_MAP;
	static {
		Map<String, String> reportCodeSheetNameMap = new HashMap<>();
		reportCodeSheetNameMap.put("T21", "Targeting Criteria");
		reportCodeSheetNameMap.put("T22", "Vehicle Line(s)");
		reportCodeSheetNameMap.put("T23", "VIN Group(s)");
		reportCodeSheetNameMap.put("T24", "Body Style");
		reportCodeSheetNameMap.put("T25", "Engine Code");
		reportCodeSheetNameMap.put("T26", "Fleet By Vehicle Line:Fleet By Vehicle Line(Based on NAVIS FIN Code)");
		reportCodeSheetNameMap.put("T27", "Sold_UnSold");
		reportCodeSheetNameMap.put("T28", "Vehicle Count By Country");
		reportCodeSheetNameMap.put("T29", "Production Dates By Plant");
		reportCodeSheetNameMap.put("T30", "Vehicle Line By Plant");
		reportCodeSheetNameMap.put("T31", "Country By Plant");
		reportCodeSheetNameMap.put("T32", "PDC By VIN Group:Parts Distribution Center by Group (US and Canadian Vehicles Only)");
		reportCodeSheetNameMap.put("T33", "Originally Sold State_Province");
		reportCodeSheetNameMap.put("T34", "VIN Range By Plant");
		reportCodeSheetNameMap.put("T04", "VINs For Force Complete Exceptions");
		reportCodeSheetNameMap.put("T14", "VINs For ReOpen Exceptions");
		reportCodeSheetNameMap.put("T35", "VINs By Current Model Year");
		REPORT_CODE_SHEET_NAME_MAP = Collections.unmodifiableMap(reportCodeSheetNameMap);
	}

	public static final List<String> EXCEPTION_REPORTS = Collections
			.unmodifiableList(Arrays.asList("CDM","ADC", "ADE", "T01", "T02", "T03", "T04", "T08", "T09", "T10",
					"T12", "T13", "T14"));
	
	public static final String SQL_ID_A = "A";
	
	public static final String SQL_ID_B = "B";
	
	public static final String WERS_SQL_ID = "WRA";

	public static final String T20 = "T20";
	/**
	 * Constant for Targeting Criteria Report which would be as one of the inputs to
	 * stored procedure
	 */
	public static final String T21 = "T21";

	/**
	 * Constant for Vehicle Line(s) Report which would be as one of the inputs to
	 * stored procedure
	 */
	public static final String T22 = "T22";

	/**
	 * Constant for VIN Group(s) Report which would be as one of the inputs to
	 * stored procedure
	 */
	public static final String T23 = "T23";

	/**
	 * Constant for Body Style Report which would be as one of the inputs to stored
	 * procedure
	 */
	public static final String T24 = "T24";

	/**
	 * Constant for Engine Code Report which would be as one of the inputs to stored
	 * procedure
	 */
	public static final String T25 = "T25";

	/**
	 * Constant for Fleet By Vehicle Line Report which would be as one of the inputs
	 * to stored procedure
	 */
	public static final String T26 = "T26";

	/**
	 * Constant for Sold UnSold Report which would be as one of the inputs to stored
	 * procedure
	 */
	public static final String T27 = "T27";

	/**
	 * Constant for Vehicle Count By Country Report which would be as one of the
	 * inputs to stored procedure
	 */
	public static final String T28 = "T28";

	/**
	 * Constant for Production Dates By Plant Report which would be as one of the
	 * inputs to stored procedure
	 */
	public static final String T29 = "T29";

	/**
	 * Constant for Vehicle Line By Plant Report which would be as one of the inputs
	 * to stored procedure
	 */
	public static final String T30 = "T30";

	/**
	 * Constant for Country By Plant Report which would be as one of the inputs to
	 * stored procedure
	 */
	public static final String T31 = "T31";

	/**
	 * Constant for PDC By VIN Group Report which would be as one of the inputs to
	 * stored procedure
	 */
	public static final String T32 = "T32";

	/**
	 * Constant for Originally Sold State/Province Report which would be as one of
	 * the inputs to stored procedure
	 */
	public static final String T33 = "T33";
	
	
	public static final String T35 = "T35";

	/**
	 * Constant for VIN Range By Plant Report which would be as one of the inputs to
	 * stored procedure
	 */
	public static final String T34 = "T34";

	public static final String IAD = "IAD";

	public static final String WERS = "WERS";
		
	public static final String ADE = "ADE";
	
	public static final String CDM = "CDM";
	
	public static final String ADC = "ADC";
	
	public static final String T01 = "T01";
	
	public static final String T02 = "T02";
	
	public static final String T03 = "T03";
	
	public static final String T04 = "T04";
	
	public static final String T08 = "T08";
	
	public static final String T09 = "T09";
	
	public static final String T10 = "T10";
	
	public static final String T12 = "T12";
	
	public static final String T13 = "T13";
	
	public static final String T14 = "T14";
	
	public static final String ALL_REPORT_CODES="T21T22T23T24T25T26T27T28T29T30T31T33T32T34IAD";
	
	private ReportCodeConstants() {}

}
