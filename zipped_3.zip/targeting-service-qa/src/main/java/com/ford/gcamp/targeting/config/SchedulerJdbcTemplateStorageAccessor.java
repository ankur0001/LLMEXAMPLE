package com.ford.gcamp.targeting.config;

import net.javacrumbs.shedlock.core.LockConfiguration;
import net.javacrumbs.shedlock.support.AbstractStorageAccessor;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.TransactionCallbackWithoutResult;
import org.springframework.transaction.support.TransactionTemplate;

import jakarta.validation.constraints.NotNull;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.Instant;
import java.util.Calendar;
import java.util.Objects;
import java.util.TimeZone;

public class SchedulerJdbcTemplateStorageAccessor extends AbstractStorageAccessor {
    private final String tableName;
    private final JdbcTemplate jdbcTemplate;
    private final TransactionTemplate transactionTemplate;
    private final TimeZone timeZone;

    private final String columnName;
    private final String columnLockUntil;
    private final String columnLockedAt;
    private final String columnLockedBy;


    SchedulerJdbcTemplateStorageAccessor(SchedulerJdbcTemplateLockProvider.Configuration configuration) {
        this.jdbcTemplate =  Objects.requireNonNull(configuration.getJdbcTemplate(), "jdbcTemplate can not be null");
        this.tableName = Objects.requireNonNull(configuration.getTableName(), "tableName can not be null");
        this.columnName = Objects.requireNonNull(configuration.getColumnName(), "columnName can not be null");
        this.columnLockUntil = Objects.requireNonNull(configuration.getColumnLockUntil(), "columnLockUntil can not be null");
        this.columnLockedAt = Objects.requireNonNull(configuration.getColumnLockedAt(), "columnLockAt can not be null");
        this.columnLockedBy = Objects.requireNonNull(configuration.getColumnLockedBy(), "columnLockedBy can not be null");

        PlatformTransactionManager transactionManager = configuration.getTransactionManager() != null ? configuration.getTransactionManager() : new DataSourceTransactionManager(Objects.requireNonNull(this.jdbcTemplate.getDataSource()));
        this.transactionTemplate = new TransactionTemplate(transactionManager);
        this.transactionTemplate.setPropagationBehavior(3);
        this.timeZone = configuration.getTimeZone();
    }

    private String replaceQuery(String query){
        return query.replace("name",this.columnName)
                .replace("lock_until", this.columnLockUntil)
                .replace("locked_at", this.columnLockedAt)
                .replace("locked_by", this.columnLockedBy);
    }

    public boolean insertRecord(@NotNull LockConfiguration lockConfiguration) {
        String sql = replaceQuery("INSERT INTO " + this.tableName + "(name, lock_until, locked_at, locked_by) VALUES(?, ?, ?, ?)");
        return Boolean.TRUE.equals(this.transactionTemplate.execute(status -> {
            try {
                int insertedRows = this.jdbcTemplate.update(sql, preparedStatement -> {
                    preparedStatement.setString(1, lockConfiguration.getName());
                    this.setTimestamp(preparedStatement, 2, lockConfiguration.getLockAtMostUntil());
                    this.setTimestamp(preparedStatement, 3, Instant.now());
                    preparedStatement.setString(4, this.getHostname());
                });
                return insertedRows > 0;
            } catch (DataIntegrityViolationException var5) {
                return false;
            }
        }));
    }

    public boolean updateRecord(@NotNull LockConfiguration lockConfiguration) {
        String sql = replaceQuery("UPDATE " + this.tableName + " SET lock_until = ?, locked_at = ?, locked_by = ? WHERE name = ? AND lock_until <= ?");
        return Boolean.TRUE.equals(this.transactionTemplate.execute(status -> {
            int updatedRows = this.jdbcTemplate.update(sql, statement -> {
                Instant now = Instant.now();
                this.setTimestamp(statement, 1, lockConfiguration.getLockAtMostUntil());
                this.setTimestamp(statement, 2, now);
                statement.setString(3, this.getHostname());
                statement.setString(4, lockConfiguration.getName());
                this.setTimestamp(statement, 5, now);
            });
            return updatedRows > 0;
        }));
    }

    private void setTimestamp(PreparedStatement preparedStatement, int patameterIndex, Instant time) throws SQLException {
        if (this.timeZone == null) {
            preparedStatement.setTimestamp(patameterIndex, Timestamp.from(time));
        } else {
            preparedStatement.setTimestamp(patameterIndex, Timestamp.from(time), Calendar.getInstance(this.timeZone));
        }

    }

    public void unlock(@NotNull final LockConfiguration lockConfiguration) {
        final String sql = replaceQuery("UPDATE " + this.tableName + " SET lock_until = ? WHERE name = ?");
        this.transactionTemplate.execute(new TransactionCallbackWithoutResult() {
            protected void doInTransactionWithoutResult(@NotNull TransactionStatus status) {
                SchedulerJdbcTemplateStorageAccessor.this.jdbcTemplate.update(sql, statement -> {
                    SchedulerJdbcTemplateStorageAccessor.this.setTimestamp(statement, 1, lockConfiguration.getUnlockTime());
                    statement.setString(2, lockConfiguration.getName());
                });
            }
        });
    }

}
