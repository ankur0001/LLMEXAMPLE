package com.ford.gcamp.targeting.frozenvin.api;

import java.util.List;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Size;
import org.springframework.stereotype.Component;

import com.ford.gcamp.targeting.common.api.FSAInfoVO;
import com.ford.gcamp.targeting.common.api.ResponseStatusDTO;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Component
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper=false)
public class
FrozenVinHistResponse extends ResponseStatusDTO{

	@Size(min = 0, max = 250, message = "HubList")
	private List<@Valid FrozenHistory> hubList;

	@Valid
	private FSAInfoVO fsaInfoVO;
}
