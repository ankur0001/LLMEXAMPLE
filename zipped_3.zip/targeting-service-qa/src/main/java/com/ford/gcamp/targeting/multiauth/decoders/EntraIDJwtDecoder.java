package com.ford.gcamp.targeting.multiauth.decoders;

import com.ford.cloudnative.base.app.security.resourceserver.JwtAudiencesValidator;
import com.ford.cloudnative.base.app.security.resourceserver.JwtRolesAndScopesValidator;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.security.oauth2.core.DelegatingOAuth2TokenValidator;
import org.springframework.security.oauth2.core.OAuth2TokenValidator;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.security.oauth2.jwt.JwtValidators;
import org.springframework.security.oauth2.jwt.NimbusJwtDecoder;
import org.springframework.web.client.RestTemplate;

import java.net.InetSocketAddress;
import java.net.Proxy;
import java.util.ArrayList;
import java.util.List;

/**
 * Holds builder for an Entra ID {@link JwtDecoder}
 */
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class EntraIDJwtDecoder {

    /**
     * Create an Entra ID {@link JwtDecoder} builder
     *
     * @return Builder instance
     */
    public static Builder builder() {
        return new Builder();
    }

    /**
     * Builder for an Entra ID {@link JwtDecoder}
     */
    @Accessors(chain = true, fluent = true)
    @Setter
    @NoArgsConstructor(access = AccessLevel.PRIVATE)
    public static class Builder {
        private String issuerUri;
        private String jwkSetUri;
        private List<String> audiences;
        private String proxyHost;
        private int proxyPort;

        /**
         * Build {@link JwtDecoder} from configured values.
         *
         * @return {@link JwtDecoder} configured to decode and validate Entra ID tokens.
         * @throws IllegalArgumentException if any values are unset.
         */
        public JwtDecoder build() {
            NimbusJwtDecoder jwtDecoder =
                    decorateWithProxy(NimbusJwtDecoder.withJwkSetUri(jwkSetUri))
                            .build();
            jwtDecoder.setJwtValidator(new DelegatingOAuth2TokenValidator<>(determineJwtValidators()));
            return jwtDecoder;
        }

        private NimbusJwtDecoder.JwkSetUriJwtDecoderBuilder decorateWithProxy(NimbusJwtDecoder.JwkSetUriJwtDecoderBuilder jwtDecoderBuilder) {
            jwtDecoderBuilder.restOperations(proxyAwareRestTemplate());
            return jwtDecoderBuilder;
        }

        private RestTemplate proxyAwareRestTemplate() {
            SimpleClientHttpRequestFactory simpleClientHttpRequestFactory = new SimpleClientHttpRequestFactory();
            simpleClientHttpRequestFactory.setProxy(new Proxy(Proxy.Type.HTTP, new InetSocketAddress(proxyHost, proxyPort)));

            RestTemplate restTemplate = new RestTemplate();
            restTemplate.setRequestFactory(simpleClientHttpRequestFactory);
            return restTemplate;
        }

        private List<OAuth2TokenValidator<Jwt>> determineJwtValidators() {
            List<OAuth2TokenValidator<Jwt>> oAuth2TokenValidators = new ArrayList<>();

            oAuth2TokenValidators.add(JwtValidators.createDefaultWithIssuer(issuerUri));
            addJwtAudiencesValidator(audiences, oAuth2TokenValidators);


            oAuth2TokenValidators.add(new JwtRolesAndScopesValidator());

            return oAuth2TokenValidators;
        }

        private void addJwtAudiencesValidator(List<String> jwtAudiences, List<OAuth2TokenValidator<Jwt>> oAuth2TokenValidators) {
            if (jwtAudiences == null || jwtAudiences.isEmpty()) {
                throw new IllegalArgumentException("At least one Entra ID audience must be specified");
            }

            oAuth2TokenValidators.add(new JwtAudiencesValidator(jwtAudiences));
        }
    }
}
