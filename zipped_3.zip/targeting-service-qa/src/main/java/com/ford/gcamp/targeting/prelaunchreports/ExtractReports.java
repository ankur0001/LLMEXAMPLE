package com.ford.gcamp.targeting.prelaunchreports;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class ExtractReports {

	private String reports;
	private String wersReports;
	private String country;
	private String fsaLoadDataExists;
}
