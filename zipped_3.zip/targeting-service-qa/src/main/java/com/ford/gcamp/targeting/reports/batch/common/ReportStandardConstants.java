package com.ford.gcamp.targeting.reports.batch.common;

public class ReportStandardConstants {

	public static final String WS_URL_TOKEN = "~";

	public static final String AMPERSAND = "&";

	public static final String SLASH = "/";

	public static final String ATTHERATE = "@";

	public static final String EQUAL = "=";

	public static final String SEMI_COLON = ";";

	public static final String COLON = ":";

	public static final String COMMA = ",";

	public static final String FILLER = " ";

	public static final String EXCELFORMAT = "XLS";

	public static final String PDFFORMAT = "PDF";

	public static final String HTMLFORMAT = "html";

	public static final String DELIMITEDFORMAT = "delimiteddata";

	public static final String MIME = "mimetype";

	public static final String EXCEL_MIME_TYPE = "application/vnd.ms-excel";

	public static final String ERROR_SUBJECT = "Report request is in error.";

	public static final String ERROR_BODY = "This Email was generated automatically by the GCamp System. Please contact the FSA Coordinator on whose behalf this Email was automatically sent by the system. <p> -----------------------------------------------<p> Report requested has failed.  Please see the display in Universal Job Queue for potential details and/or contact GCamps System Admin. ";

	public static final String DELIM_EXCLAIM = "!";

	public static final String YES = "Y";

	public static final String NO = "N";

	public static final String ADD = "A";

	public static final String MODIFY = "M";

	public static final String RETRIEVE = "R";

	public static final String ERROR = "E";

	public static final String DIST_LIST = "DL";

	public static final String PRELIMINARY = "P";

	public static final String FINAL = "F";

	public static final String SERVER = "server=";

	public static final String DESTYPE = "destype=";

	public static final String PJDBCPDS = "p_jdbcpds=";

	public static final String ORACLE_RWERROR = "rwerror.htm";

	public static final String REPORTURL = "ReportURL";

	public static final String DESFORMAT = "DESFORMAT";

	public static final String POI_ERROR = "E0504";

	public static final String ORACLE_ERROR = "E0505";

	public static final String CONFIG_ERROR = "E0506";

	public static final String REPORT_EMAIL_ERROR = "E0545";

	public static final String LOW_DATE = "0001-01-01";

	public static final int RECORD_LENGTH = 4009;

	public static final int ORACLE_REC_LEN = 2000;

	public static final int METADATA_REC_LEN = 2000;

	public static final int RPTID_REC_LEN = 9;

	public static final long WAIT_TIME = 5 * (long) (60 * 1000);

	public static final String BMP_FLAG = "B";

	public static final String GCAMPUSER = "gcamp";
	
	private ReportStandardConstants() {}

}
