package com.ford.gcamp.targeting.reports.batch;

import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.ford.gcamp.targeting.common.TargetingUtil;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.JobParametersInvalidException;
import org.springframework.batch.core.job.builder.JobBuilder;
import org.springframework.batch.core.job.builder.SimpleJobBuilder;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.core.launch.support.TaskExecutorJobLauncher;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.repository.JobRestartException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import com.ford.gcamp.targeting.core.exception.GCAMPException;
import com.ford.gcamp.targeting.reports.batch.api.ReportMessageData;
import com.ford.gcamp.targeting.reports.batch.api.ReportMetaData;
import com.ford.gcamp.targeting.reports.batch.common.ReportCodeConstants;
import com.ford.gcamp.targeting.reports.batch.common.ReportGenerationUtil;
import com.ford.gcamp.targeting.reports.batch.common.ReportStandardConstants;
import com.ford.gcamp.targeting.reports.batch.exception.GCAMPReportException;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class TargetingReportService {

	private TaskExecutorJobLauncher jobLauncher;

	private JobRepository jobRepository;

	private ReportJobCompletionListener listener;

	private TargetingReportRepo targetingReportRepo;

	private ReportStepFactory stepFactory;

	@Value("${spring.profiles.active}")
	private String activeProfile;

	public TargetingReportService(ReportJobCompletionListener listener, TargetingReportRepo targetingReportRepo,
			ReportStepFactory stepFactory,JobRepository jobRepository, TaskExecutorJobLauncher jobLauncher) {
		this.listener = listener;
		this.targetingReportRepo = targetingReportRepo;
		this.stepFactory = stepFactory;
		this.jobRepository = jobRepository;
		this.jobLauncher = jobLauncher;
	}

	public void getBMPCompletedJobs() {

		if ("dev".equalsIgnoreCase(activeProfile) || "qa".equalsIgnoreCase(activeProfile) || "prod".equalsIgnoreCase(activeProfile)) {
			List<ReportMessageData> reportMessageDataList;
			try {
				reportMessageDataList = targetingReportRepo.getBMPCompletedJobs();
				if (CollectionUtils.isNotEmpty(reportMessageDataList)) {
					reportMessageDataList.forEach(reportMessageData -> {
						try {
							ReportMetaData reportMetaData = ReportGenerationUtil.getReportMetaData(reportMessageData);
							log.info(
									"The FSA number {} and Report Code {} and Supplement Code {} taken up for batch processing",
									reportMetaData.getGlobalFSANum(), reportMetaData.getRptCode(),
									reportMetaData.getSuppCode());

							String reportMetaDataString = TargetingUtil.prettyPrintJSON(reportMetaData);

							JobParameters jobParameter = new JobParametersBuilder()
									.addString("reportMetaData", reportMetaDataString)
									.addDate("date", new Date())
									.toJobParameters();

							Job job = createJob(reportMetaData);
							JobExecution jobExecution = jobLauncher.run(job, jobParameter);
							log.info("The Job Execution status of Job Name: {} is {}",
									jobExecution.getJobInstance().getJobName(), jobExecution.getStatus());
						
						} catch (JobExecutionAlreadyRunningException | JobRestartException
								| JobInstanceAlreadyCompleteException | JobParametersInvalidException
								| GCAMPReportException e) {
							log.info("There is an error in running the Job. The error message", e);
						}
					});

				}
			} catch (GCAMPException ex) {
				log.error("There is a error in getting BMP completed jobs", ex);
			}
		}

	}

	private Job createJob(ReportMetaData reportMetaData) throws GCAMPReportException {
		SimpleJobBuilder simpleBuilder = null;
		JobBuilder jobBuilder = new JobBuilder(getJobName(reportMetaData), jobRepository).incrementer(new RunIdIncrementer())
				.listener(listener);
		// For multiple sheets in a single workbook
		if (ReportCodeConstants.T20.equalsIgnoreCase(reportMetaData.getRptCode())) {
			try {
				List<String> reportCodes = getReportCodes(reportMetaData);
				int index = 0;
				for (String reportCode : reportCodes) {
					if (index == 0) {
						simpleBuilder = jobBuilder.start(stepFactory.getStep(reportCode, reportMetaData.getSuppCode()));
					} else {
						simpleBuilder.next(stepFactory.getStep(reportCode, reportMetaData.getSuppCode()));
					}
					index++;
				}

			} catch (GCAMPReportException e) {
				throw new GCAMPReportException(
						"There is a problem in getting report codes for " + reportMetaData.getRptCode(), e);
			}

		} else {
			simpleBuilder = jobBuilder
					.start(stepFactory.getStep(reportMetaData.getRptCode(), reportMetaData.getSuppCode()));
		}

		if (ObjectUtils.isEmpty(simpleBuilder)) {
			throw new GCAMPReportException("The Job can't be created. There is no step available for the report code "
					+ reportMetaData.getRptCode());
		}
		return simpleBuilder.build();
	}

	private String getJobName(ReportMetaData metaData) {
		StringBuilder jobName = new StringBuilder();
		jobName.append(Integer.parseInt(metaData.getGlobalFSANum())).append(ReportStandardConstants.COLON)
				.append(metaData.getRptCode()).append(ReportStandardConstants.COLON).append(metaData.getSuppCode());
		return jobName.toString();
	}

	private List<String> getReportCodes(ReportMetaData reportMetaData) throws GCAMPReportException {
		List<String> reportCodes = targetingReportRepo.getReportCodes(reportMetaData.getReportId(),
				reportMetaData.getRptFormat());
		if (CollectionUtils.isNotEmpty(reportCodes)) {
			Collections.sort(reportCodes);
			reportCodes.add(reportCodes.remove(0));
		} else {
			throw new GCAMPReportException(
					"The report can't be created since " + ReportCodeConstants.T20 + " doesn't have report codes");
		}
		return reportCodes;
	}

	@Bean
	public Map<String, SXSSFWorkbook> intializeWorkbookMap() {
		return new HashMap<>();
	}

}
