package com.ford.gcamp.targeting.gfsasetup;

import com.ford.gcamp.targeting.common.CommonConstants;
import com.ford.gcamp.targeting.common.TargetingUtil;
import com.ford.gcamp.targeting.config.WebClientAdConfiguration;
import com.ford.gcamp.targeting.core.exception.ResourceNotFoundException;
import com.ford.gcamp.targeting.fsacriteria.api.FsaCriteriaEditVO;
import com.ford.gcamp.targeting.fsacriteria.api.FsaCriteriaSaveParam;
import com.ford.gcamp.targeting.fsacriteria.api.FsaVinCriteriaRequest;
import com.ford.gcamp.targeting.gfsasetup.api.*;
import com.ford.gcamp.targeting.gridgcamp.GridGCampConstants;
import com.ford.gcamp.targeting.gridgcamp.gcamp.FSATypeRepository;
import com.ford.gcamp.targeting.gridgcamp.gcamp.GridGCampService;
import com.ford.gcamp.targeting.gridgcamp.gcamp.HubLookupDataRepository;
import com.ford.gcamp.targeting.gridgcamp.gcamp.entity.FSATypeLookupData;
import com.ford.gcamp.targeting.gridgcamp.gcamp.entity.GridVernData;
import com.ford.gcamp.targeting.properties.ConfigProperties;
import com.ford.gcamp.targeting.setupfsa.api.ModifySaveRequest;
import com.ford.gcamp.targeting.setupfsa.dependentfsa.DependentFsaService;
import com.ford.gcamp.targeting.supplement.api.SupplementRequest;
import com.ford.gcamp.targeting.vin.api.FsaCriteriaVdm;
import com.ford.gcamp.targeting.vin.api.UpdateVinSerialReq;
import com.ford.gcamp.targeting.vin.api.VinDeleteRequestDTO;
import com.ford.gcamp.targeting.vin.api.VinListResponseDTO;
import jakarta.validation.constraints.NotNull;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.MediaType;
import org.springframework.http.client.MultipartBodyBuilder;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.util.List;

@Service
@Slf4j
public class GlobalFSASetupService {

    @Value("${spring.security.oauth2.client.registration.client-fsaservice-azure-ad.scope}")
    private  String scope;

    public static final String FSA = "fsa";
    public static final String ERROR_WHILE_CREATING_GLOBAL_FSA = "Error while creating Global Fsa";
    public static final String ERROR_WHILE_SAVE_FSA_CRITERIA = "Error while save FSA criteria";
    public static final String ERROR_WHILE_UPDATE_FSA = "Error while UPDATE FSA in Targeting";
    public static final String ERROR_WHILE_UPLOAD_VIN = "Error while add vinlist and Upload file in GCS in Targeting";
    public static final String ERROR_WHILE_DELETE_VIN = "Error while deleting vin list details in Targeting";
    public static final String ERROR_WHILE_UPDATE_VIN = "Error while updating vin list details in Targeting";
    public static final String ERROR_WHILE_CREATING_SUPPLEMENT = "Error while creating supplement";

    private GlobalFSASetupDao globalFSASetupDao;
    private GridGCampService gridGCampService;
    private FSATypeRepository fsaTypeRepository;
    private HubLookupDataRepository hubLookupDataRepository;
    private WebClient webClient;
    private WebClientAdConfiguration webClientAdConfiguration;
    private ConfigProperties configProperties;
    private DependentFsaService dependentFsaService;

    public GlobalFSASetupService(GlobalFSASetupDao globalFSASetupDao, GridGCampService gridGCampService,
                                 FSATypeRepository fsaTypeRepository, HubLookupDataRepository hubLookupDataRepository,
                                 @Qualifier("fsaServiceWebClient") WebClient webClient, WebClientAdConfiguration webClientAdConfiguration,
                                 ConfigProperties configProperties, DependentFsaService dependentFsaService) {
        super();
        this.globalFSASetupDao = globalFSASetupDao;
        this.gridGCampService = gridGCampService;
        this.fsaTypeRepository = fsaTypeRepository;
        this.hubLookupDataRepository = hubLookupDataRepository;
        this.webClient = webClient;
        this.webClientAdConfiguration = webClientAdConfiguration;
        this.configProperties = configProperties;
        this.dependentFsaService = dependentFsaService;
    }

    public FsaSetupCreateResponse createGfsaSetup(FsaSetupCreateRequest fsaSetupCreateRequest)
            throws ResourceNotFoundException {
        FsaSetupCreateResponse response = new FsaSetupCreateResponse();
        int globalFSANumber;

        try {
            globalFSANumber = createGfsaUsingFsaService(fsaSetupCreateRequest);

            if (ObjectUtils.isNotEmpty(fsaSetupCreateRequest.getGridBasicVernInfo()) && CommonConstants.FLAG_Y
                    .equalsIgnoreCase(fsaSetupCreateRequest.getGridBasicVernInfo().getFsaAssignedFlag())) {
                GridVernData gridVernData = gridGCampService.updateMappingToVern(getCommonVernRequest(fsaSetupCreateRequest, globalFSANumber));

                gridGCampService.invokeInfoToGrid(gridVernData, GridGCampConstants.CREATE_GLOBAL_FSA);
            }

            response.setStatus(CommonConstants.SUCCESS);
            response.setStatusCode(CommonConstants.SUCCESS_CODE);
            response.setStatusDescription(CommonConstants.SUCCESS);
            response.setFsaNumber(String.valueOf(globalFSANumber));
        } catch (RuntimeException e) {
            log.error("RuntimeException Error occured ", e);
            throw new ResourceNotFoundException(ERROR_WHILE_CREATING_GLOBAL_FSA);
        } catch (Exception e) {
            log.error("Exception occured ", e);
            throw new ResourceNotFoundException(ERROR_WHILE_CREATING_GLOBAL_FSA);
        }
        return response;
    }

    private VernFsaMappingRequest getCommonVernRequest(FsaSetupCreateRequest fsaSetupCreateRequest, int globalFSANumber) {

        if (fsaSetupCreateRequest.isFsaTypeChanged()){
            FSATypeLookupData fsaType = fsaTypeRepository.findFirstByCode(fsaSetupCreateRequest.getSelectedGlobalFSAType());
            String gridFSATypeCode = CommonConstants.NOT_APPROVED.equalsIgnoreCase(fsaType.getCode())
                    ? fsaType.getCode()
                    : StringUtils.trimToEmpty(fsaType.getGridCode());
            if (StringUtils.isNotBlank(gridFSATypeCode)) {
                return VernFsaMappingRequest.builder().gridYearId(fsaSetupCreateRequest.getGridBasicVernInfo().getGridYearId())
                        .gridSequence(fsaSetupCreateRequest.getGridBasicVernInfo().getGridSequence()).implementationId(fsaSetupCreateRequest.getGridBasicVernInfo().getImplementationId())
                        .version(fsaSetupCreateRequest.getGridBasicVernInfo().getVersion()).supplementId(fsaSetupCreateRequest.getGridBasicVernInfo().getSupplementId())
                        .globalFSANumber(globalFSANumber).fsaTypeChanged(true).modifyFsaType(gridFSATypeCode).updateId(fsaSetupCreateRequest.getCdsid()).build();
            }
        }
        return VernFsaMappingRequest.builder().gridYearId(fsaSetupCreateRequest.getGridBasicVernInfo().getGridYearId())
                .gridSequence(fsaSetupCreateRequest.getGridBasicVernInfo().getGridSequence()).implementationId(fsaSetupCreateRequest.getGridBasicVernInfo().getImplementationId())
                .version(fsaSetupCreateRequest.getGridBasicVernInfo().getVersion()).supplementId(fsaSetupCreateRequest.getGridBasicVernInfo().getSupplementId())
                .globalFSANumber(globalFSANumber)
                .updateId(fsaSetupCreateRequest.getCdsid())
                .build();
    }

    private int createGfsaUsingFsaService(FsaSetupCreateRequest fsaSetupCreateRequest) throws ResourceNotFoundException {
        try {
            FsaSetupCreateServiceResponse fsaSetupCreateServiceResponse = webClient.post()
                    .uri("/api/v1/global")
                    .contentType(MediaType.APPLICATION_JSON)
                    .header("Authorization", "Bearer " + webClientAdConfiguration.getAccessToken(scope, FSA))
                    .body(Mono.just(fsaSetupCreateRequest), FsaSetupCreateRequest.class)
                    .retrieve()
                    .onStatus(HttpStatusCode::isError, clientResponse -> {
                        log.error("Error while creating Global Fsa. FSA Service returned status code: {}", clientResponse.statusCode());
                        return Mono.error(new ResourceNotFoundException(clientResponse.statusCode() + " Error while creating Global Fsa"));
                    })
                    .bodyToMono(FsaSetupCreateServiceResponse.class)
                    .block();
            log.info("Response from FSA Service: {}", fsaSetupCreateServiceResponse);
            return fsaSetupCreateServiceResponse.getGlobalFsaNumber();
        } catch (Exception e) {
            log.error(ERROR_WHILE_CREATING_GLOBAL_FSA, e);
            throw new ResourceNotFoundException(ERROR_WHILE_CREATING_GLOBAL_FSA);
        }
    }

    public FsaCriteriaEditVO saveFsaCriteriaInFsa(FsaVinCriteriaRequest fsaVinCriteriaRequest) throws ResourceNotFoundException {
        log.info("Request to save FSA Criteria from Targeting to FSA Service: {}", TargetingUtil.prettyPrintJSON(fsaVinCriteriaRequest));
        try {
            FsaCriteriaEditVO fsaCriteriaEditVoResp = webClient.post()
                    .uri("/api/v1/criteria/save")
                    .contentType(MediaType.APPLICATION_JSON)
                    .header("Authorization", "Bearer " + webClientAdConfiguration.getAccessToken(scope, FSA))
                    .body(Mono.just(fsaVinCriteriaRequest), FsaVinCriteriaRequest.class)
                    .exchangeToMono(this::getFsaCriteriaEditVOMono)
                    .block();
            log.info("Response from FSA Service for save FSA Criteria: {}", fsaCriteriaEditVoResp);
            return fsaCriteriaEditVoResp;
        } catch (Exception e) {
            log.error(ERROR_WHILE_SAVE_FSA_CRITERIA, e);
            throw new ResourceNotFoundException(ERROR_WHILE_SAVE_FSA_CRITERIA);
        }
    }

    @NotNull
    private Mono<FsaCriteriaEditVO> getFsaCriteriaEditVOMono(ClientResponse clientResponse) {
        if (clientResponse.statusCode().isError()) {
            return clientResponse.bodyToMono(String.class)
                    .flatMap(errorMessage -> {
                        JSONObject json = new JSONObject(errorMessage);
                        String messages = json.getJSONObject("error").getJSONArray("messages").join(", ");
                        log.error("Error while saving FSA Criteria. FSA Service returned status code: {}, error message: {}",
                                clientResponse.statusCode(), messages);

                        FsaCriteriaEditVO fsaCriteriaErrorResponse = new FsaCriteriaEditVO();
                        fsaCriteriaErrorResponse.setStatusCode("0");
                        fsaCriteriaErrorResponse.setStatusDesc(messages.replace("\"", ""));
                        return Mono.just(fsaCriteriaErrorResponse);
                    });
        } else {
            return clientResponse.bodyToMono(FsaCriteriaEditVO.class);
        }
    }

    public FsaSetupCreateServiceResponse modifyFsaDetails(ModifySaveRequest saveRequest) throws ResourceNotFoundException {
        try {
            FsaSetupCreateServiceResponse fsaSetupCreateServiceResponse = webClient.put()
                    .uri("/api/v1/global")
                    .contentType(MediaType.APPLICATION_JSON)
                    .header("Authorization", "Bearer " + webClientAdConfiguration.getAccessToken(scope, FSA))
                    .body(Mono.just(saveRequest), ModifySaveRequest.class)
                    .exchangeToMono(clientResponse -> {
                        if (clientResponse.statusCode().isError()) {
                            return clientResponse.bodyToMono(String.class)
                                    .flatMap(errorMessage -> {
                                        JSONObject json = new JSONObject(errorMessage);
                                        String messages = json.getJSONObject("error").getJSONArray("messages").join(", ");
                                        log.error("Error while updating FSA Criteria. FSA Service returned status code: {}, error message: {}",
                                                clientResponse.statusCode(), messages);
                                        return Mono.error(new ResourceNotFoundException(clientResponse.statusCode() + " Error while updating Global Fsa"));
                                    });
                        } else {
                            return clientResponse.bodyToMono(FsaSetupCreateServiceResponse.class);
                        }
                    })
                    .block();
            log.info("Response from FSA Service to update FSA : {}", fsaSetupCreateServiceResponse);
            return fsaSetupCreateServiceResponse;
        } catch (Exception e) {
            log.error(ERROR_WHILE_UPDATE_FSA, e);
            throw new ResourceNotFoundException(ERROR_WHILE_UPDATE_FSA);
        }
    }


    public GfsaTypesResponse getGfsaTypes() {

        GfsaTypesResponse response = new GfsaTypesResponse();
        try {
            List<GfsaType> gfsaTypes = globalFSASetupDao.getGfsaTypes();
            response.setStatus(CommonConstants.SUCCESS);
            response.setStatusCode(CommonConstants.SUCCESS_CODE);
            response.setStatusDescription(CommonConstants.SUCCESS);
            response.setGfsaTypes(gfsaTypes);
        } catch (Exception e) {
            log.error("Exception getGfsaTypes", e);
            response.setStatus(CommonConstants.FAILURE);
            response.setStatusCode(CommonConstants.FAILURE_CODE);
            response.setStatusDescription("Failure while getting Global Fsa Types");
        }
        return response;
    }

    public String addVinList(FsaCriteriaVdm fsaCriteriaVdm, MultipartFile vinFile) {
        String responseString = null;
        try {
            MultipartBodyBuilder builder = new MultipartBodyBuilder();
            builder.part("fsaCriteriaVdm", fsaCriteriaVdm); // will be serialized as JSON
            builder.part("vinFile", vinFile.getResource()); // file part

            responseString = webClient.post()
                    .uri("/api/v1/vinList/add")
                    .contentType(MediaType.MULTIPART_FORM_DATA)
                    .header("Authorization", "Bearer " + webClientAdConfiguration.getAccessToken(scope, FSA))
                    .body(BodyInserters.fromMultipartData(builder.build()))
                    .exchangeToMono(clientResponse -> {
                        if (clientResponse.statusCode().isError()) {
                            return clientResponse.bodyToMono(String.class)
                                    .flatMap(errorMessage -> {
                                        JSONObject json = new JSONObject(errorMessage);
                                        String messages = json.getJSONObject("error").getJSONArray("messages").join(", ");
                                        log.error("Error while add vin list. FSA Service returned status code: {}, error message: {}",
                                                clientResponse.statusCode(), messages);
                                        return Mono.just(messages.replace("\"", ""));
                                    });
                        } else {
                            return clientResponse.bodyToMono(String.class);
                        }
                    })
                    .block();
            log.info("Response from FSA Service to Add the Vin List : {}", responseString);
        } catch (Exception e) {
            log.error(ERROR_WHILE_UPLOAD_VIN, e);
            return ERROR_WHILE_UPLOAD_VIN;
        }
        return responseString;
    }

    public String deleteVinList(VinDeleteRequestDTO vinDeleteRequest) {
        String responseString = null;
        try {
            responseString = webClient.post()
                    .uri("/api/v1/vinList/delete")
                    .contentType(MediaType.APPLICATION_JSON)
                    .header("Authorization", "Bearer " + webClientAdConfiguration.getAccessToken(scope, FSA))
                    .body(Mono.just(vinDeleteRequest), VinDeleteRequestDTO.class)
                    .exchangeToMono(clientResponse -> {
                        if (clientResponse.statusCode().isError()) {
                            return clientResponse.bodyToMono(String.class)
                                    .flatMap(errorMessage -> {
                                        JSONObject json = new JSONObject(errorMessage);
                                        String messages = json.getJSONObject("error").getJSONArray("messages").join(", ");
                                        log.error("Error while deleting vin list. FSA Service returned status code: {}, error message: {}",
                                                clientResponse.statusCode(), messages);
                                        return Mono.just(messages.replace("\"", ""));
                                    });
                        } else {
                            return clientResponse.bodyToMono(String.class);
                        }
                    })
                    .block();
            log.info("Response from FSA Service to delete the Vin List : {}", responseString);
        } catch (Exception e) {
            log.error(ERROR_WHILE_DELETE_VIN, e);
            return ERROR_WHILE_DELETE_VIN;
        }
        return responseString;
    }

    public String updateVinList(UpdateVinSerialReq updateSerialList) {
        String responseString = null;
        try {
            responseString = webClient.put()
                    .uri("/api/v1/vinList/update")
                    .contentType(MediaType.APPLICATION_JSON)
                    .header("Authorization", "Bearer " + webClientAdConfiguration.getAccessToken(scope, FSA))
                    .body(Mono.just(updateSerialList), UpdateVinSerialReq.class)
                    .exchangeToMono(clientResponse -> {
                        if (clientResponse.statusCode().isError()) {
                            return clientResponse.bodyToMono(String.class)
                                    .flatMap(errorMessage -> {
                                        JSONObject json = new JSONObject(errorMessage);
                                        String messages = json.getJSONObject("error").getJSONArray("messages").join(", ");
                                        log.error("Error while updating vin list. FSA Service returned status code: {}, error message: {}",
                                                clientResponse.statusCode(), messages);
                                        return Mono.just(messages.replace("\"", ""));
                                    });
                        } else {
                            return clientResponse.bodyToMono(String.class);
                        }
                    })
                    .block();
            log.info("Response from FSA Service to update vin list : {}", responseString);
        } catch (Exception e) {
            log.error(ERROR_WHILE_UPDATE_VIN, e);
            return ERROR_WHILE_UPDATE_VIN;
        }
        return responseString;
    }

    public int invokeFsaSupplement(SupplementRequest supplementRequest) throws ResourceNotFoundException {
        try {
            return webClient.post()
                    .uri("/api/v1/supplement/addmodify")
                    .contentType(MediaType.APPLICATION_JSON)
                    .header("Authorization", "Bearer " + webClientAdConfiguration.getAccessToken(scope, FSA))
                    .body(Mono.just(supplementRequest), SupplementRequest.class)
                    .exchangeToMono(clientResponse -> {
                        if (clientResponse.statusCode().isError()) {
                            return clientResponse.bodyToMono(String.class)
                                    .flatMap(errorMessage -> {
                                        JSONObject json = new JSONObject(errorMessage);
                                        String messages = json.getJSONObject("error").getJSONArray("messages").join(", ");
                                        log.error("Error while add/modify supplement: {}, error message: {}",
                                                clientResponse.statusCode(), messages);
                                        return Mono.just(clientResponse.statusCode().value());
                                    });
                        } else {
                            return Mono.just(clientResponse.statusCode().value());
                        }
                    })
                    .block();
        } catch (Exception e) {
            log.error(ERROR_WHILE_CREATING_SUPPLEMENT, e);
            throw new ResourceNotFoundException(ERROR_WHILE_CREATING_SUPPLEMENT);
        }
    }
}


