package com.ford.gcamp.targeting.fsacriteria;

import com.ford.gcamp.targeting.common.api.CommonResponse;
import com.ford.gcamp.targeting.common.api.FSACommonGoRequest;
import com.ford.gcamp.targeting.common.api.FSATypesResponse;
import com.ford.gcamp.targeting.common.api.FscCriteriaRequest;
import com.ford.gcamp.targeting.common.api.HubResponse;
import com.ford.gcamp.targeting.core.exception.GCAMPException;
import com.ford.gcamp.targeting.fsacriteria.api.DeleteConfirmResponse;
import com.ford.gcamp.targeting.fsacriteria.api.DeleteFsaInfoReq;
import com.ford.gcamp.targeting.fsacriteria.api.FsaCriteriaParamRequest;
import com.ford.gcamp.targeting.fsacriteria.api.FsaDeleteResponseDTO;
import com.ford.gcamp.targeting.fsacriteria.api.FsaGlobalSearchDTO;
import com.ford.gcamp.targeting.fsacriteria.api.FsaGlobalSearchRequest;
import com.ford.gcamp.targeting.fsacriteria.api.FscCriteriaResponseGoDTO;
import com.ford.gcamp.targeting.fsacriteria.api.LoadFsaResponseDTO;
import com.ford.gcamp.targeting.fsacriteria.api.LoadSelectCounValDTO;
import com.ford.gcamp.targeting.fsacriteria.api.LoadStateProvinceDTO;
import com.ford.gcamp.targeting.fsacriteria.api.LoadVehAttValDTO;

public interface AddModifyCriteriaService {

	public LoadFsaResponseDTO getFscFormDetails();

	public FscCriteriaResponseGoDTO getFscSearchResult(FscCriteriaRequest fscCriteriaRequest);

	public LoadVehAttValDTO loadDynamicQueryDataForVehAtt(String attrGrpVvalue);

	public LoadStateProvinceDTO loadDynamicQueryDetailsForStateProv();

	public LoadSelectCounValDTO loadDynamicQueryDataForSelectCountry(FscCriteriaRequest fscCriteriaRequest);

	public CommonResponse saveFSACriteriaList(FsaCriteriaParamRequest fsaCriteriaParam) throws GCAMPException;

	public FscCriteriaResponseGoDTO copyFSACriteriaList(FsaCriteriaParamRequest fsaCriteriaParam);

	public FsaGlobalSearchDTO getFsaGlobalSearch(FsaGlobalSearchRequest flobalFsaSearch);

	public FsaDeleteResponseDTO deleteFSACriteriaList(FsaCriteriaParamRequest fsaCriteriaParam);

	public FsaDeleteResponseDTO deleteCompleteCriteriaList(DeleteFsaInfoReq deleteFsaInfoReq);

	public HubResponse getHubsList();

	public FSATypesResponse getFSATypes();

	public DeleteConfirmResponse getExtractTimeStamp(FSACommonGoRequest fsaCommonGoRequest) throws GCAMPException;

}
