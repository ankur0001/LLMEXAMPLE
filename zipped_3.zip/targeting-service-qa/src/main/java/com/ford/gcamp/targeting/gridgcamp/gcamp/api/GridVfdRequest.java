package com.ford.gcamp.targeting.gridgcamp.gcamp.api;

import java.util.List;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.ford.gcamp.targeting.common.api.GenericLookup;


import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;
import org.springframework.validation.annotation.Validated;

@Setter
@Getter
@Validated
@JsonIgnoreProperties
public class GridVfdRequest {


	@Schema(example = "18073",description = "globalFSANumber")
	@Min(0)
	@Max(99999999)
	private int globalFSANumber;
	@Schema(description = "supplementId")
	@Size(min = 1, max = 2, message = "length 1-2")
	@Pattern(regexp ="^[A-Za-z\\d]*$", message = "Supplement Code")
	private String supplementId;
	@Schema(description = "requester")
	@Size(min = 0, max = 8, message = "Max length 8")
	@Pattern(regexp ="^[A-Za-z\\d]*$", message = "Requester CDSId")
	private String requester;
	private boolean vfdRequested;
	@Size(min=0, max = 10)
	private List<GenericLookup> wersAttributes;
}
