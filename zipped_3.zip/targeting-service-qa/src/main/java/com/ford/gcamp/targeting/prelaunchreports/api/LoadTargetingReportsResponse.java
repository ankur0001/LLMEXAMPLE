package com.ford.gcamp.targeting.prelaunchreports.api;

import com.ford.gcamp.targeting.common.api.CommonResponse;
import com.ford.gcamp.targeting.common.api.FSAInfoVO;
import com.ford.gcamp.targeting.common.api.SuppPopulationVo;
import com.ford.gcamp.targeting.prelaunchreports.TargetingReportData;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Setter
@Getter
public class LoadTargetingReportsResponse extends CommonResponse{
	@Size(min = 0, max = 300, message = "targeting Report Data")
	private List<@Valid TargetingReportData> targetingReportData;

	@Valid
	private FSAInfoVO fsaInfoVO;

	@Size(min = 0, max = 8)
	@Pattern(regexp = "^[a-zA-Z\\d\\-]*$")
	@Schema(example = "TDHARTI", description = "last modified by")
	private String lastModifiedBy;

	@Size(min = 0, max = 20)
	@Pattern(regexp = "^[a-zA-Z\\d\\-\\s\\.\\/]$")
	@Schema(example = "05-Jun-2024", description = "Extract Last Run Date")
	private String extractLastRun;

	@Size(min = 0, max = 300, message = "Supplements List")
	private List<@Valid SuppPopulationVo> supplements;

	@Schema(description = "Report available flag")
	private boolean reportAvailableFlag;

	@Schema(description = "Batch block flag")
	private boolean batchBlockFlag;

	private boolean latestGridVernInfoExists;

	private boolean showReportsScreenFlag;
    private boolean disableConfirmVehiclePopulation;

	private boolean deepLinkFlag;
}
