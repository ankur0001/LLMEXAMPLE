package com.ford.gcamp.targeting.gridgcamp.gcamp;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Map.Entry;
import java.util.stream.Collectors;
import java.util.Optional;
import java.util.Set;
import jakarta.validation.Valid;
import org.thymeleaf.context.Context;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.ExampleMatcher;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.thymeleaf.spring6.SpringTemplateEngine;
import com.ford.gcamp.targeting.common.CommonConstants;
import com.ford.gcamp.targeting.common.CommonRepository;
import com.ford.gcamp.targeting.common.EmailSender;
import com.ford.gcamp.targeting.common.FTPSession;
import com.ford.gcamp.targeting.common.LDAPModel;
import com.ford.gcamp.targeting.common.TargetingUtil;
import com.ford.gcamp.targeting.core.exception.GCAMPException;
import com.ford.gcamp.targeting.fsacriteria.FsaCriteriaService;
import com.ford.gcamp.targeting.fsacriteria.api.LoadFsaResponseDTO;
import com.ford.gcamp.targeting.gridgcamp.GridGCampConstants;
import com.ford.gcamp.targeting.gridgcamp.gcamp.api.GridOTAUpdateResponse;
import com.ford.gcamp.targeting.gridgcamp.gcamp.api.GridVernInfo;
import com.ford.gcamp.targeting.gridgcamp.gcamp.api.GridVfdResponse;
import com.ford.gcamp.targeting.gridgcamp.gcamp.api.OTAIndicatorUpdateRequest;
import com.ford.gcamp.targeting.gridgcamp.gcamp.entity.FSAData;
import com.ford.gcamp.targeting.gridgcamp.gcamp.entity.FSATypeLookupData;
import com.ford.gcamp.targeting.gridgcamp.gcamp.entity.GridCriteriaData;
import com.ford.gcamp.targeting.gridgcamp.gcamp.entity.GridCriteriaId;
import com.ford.gcamp.targeting.gridgcamp.gcamp.entity.GridVernData;
import com.ford.gcamp.targeting.gridgcamp.gcamp.entity.GridVernId;
import com.ford.gcamp.targeting.gridgcamp.gcamp.entity.SoftwareCriteriaData;
import com.ford.gcamp.targeting.gridgcamp.gcamp.entity.SoftwareCriteriaId;
import com.ford.gcamp.targeting.properties.HubCountryProperties;
import com.ford.gcamp.targeting.user.UserService;
import com.ford.gcamp.targeting.vin.S3Service;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class GridGCampVernInfoService {

	private final SpringTemplateEngine templateEngine;
	private UserService userService;
	private HubCountryProperties hubProperties;
	private CommonRepository commonRepository;
	private EmailSender emailSender;
	private FSARepository fsaRepository;
	private FsaCriteriaService fsaCriteriaService;
	@Autowired
	private FSATypeRepository fsaTypeRepository;
	@Autowired
	private FTPSession ftpSession;
	@Autowired
	private S3Service s3Service;

	@Value("${system.email.address}")
	private String systemEmail;
	
	@Value("${spring.profiles.active}")
	private String activeProfile;

	public GridGCampVernInfoService(SpringTemplateEngine templateEngine, UserService userService,
			HubCountryProperties hubProperties, CommonRepository commonRepository, EmailSender emailSender,
			FSARepository fsaRepository, FsaCriteriaService fsaCriteriaService) {
		super();
		this.templateEngine = templateEngine;
		this.userService = userService;
		this.hubProperties = hubProperties;
		this.commonRepository = commonRepository;
		this.emailSender = emailSender;
		this.fsaRepository = fsaRepository;
		this.fsaCriteriaService = fsaCriteriaService;
	}

	public String getRequesterDeptFromLdap(String requester) {
		Optional<LDAPModel> ldapModel = userService.getByCDSId(requester);
		if (ldapModel.isPresent()) {
			return ldapModel.get().getDepartment();
		}
		return StringUtils.EMPTY;
	}

	public List<String> getHub(String hubCode) {
		if (hubProperties.getGridgcamp().containsKey(hubCode)) {
			return Arrays.asList(StringUtils.split(hubProperties.getGridgcamp().get(hubCode), ","));
		}
		return Arrays.asList(hubCode);
	}

	public String getGridRegion(String hubCode) {
		if (hubProperties.getRegion().containsKey(hubCode)) {
			return hubProperties.getRegion().get(hubCode);
		}
		// This logic works after hub re-alignment to convert two character hub to 3
		// character hub for GRID
		Optional<Entry<String, String>> matchingHub = hubProperties.getRegion().entrySet().stream()
				.filter(entry -> entry.getValue().contains(hubCode)).findFirst();
		return matchingHub.isPresent() ? matchingHub.get().getValue() : hubCode;
	}

	public String getRequesterNameFromLdap(String requester) {
		Optional<LDAPModel> ldapModel = userService.getByCDSId(requester);
		if (ldapModel.isPresent()) {
			StringBuilder requesterName = new StringBuilder();
			requesterName.append(ldapModel.get().getFirstName());
			requesterName.append(StringUtils.SPACE);
			requesterName.append(ldapModel.get().getLastName());
			return requesterName.toString();
		}
		return StringUtils.EMPTY;
	}

	public Example<GridVernData> constructGridVernInfoExample(int globalFSANumber, String supplmentCode,
			String assignedFlag) {
		ExampleMatcher fsaMatcher = ExampleMatcher.matching().withIgnorePaths("gridVernId.gridYearId",
				"gridVernId.gridSequence", "gridVernId.implementationId", GridGCampConstants.GRID_VERN_ID_VERSION);
		GridVernData gridVernData = new GridVernData();
		gridVernData.setGlobalFSANumber(globalFSANumber);
		GridVernId gridVernId = new GridVernId();
		gridVernId.setSupplementId(StringUtils.isBlank(supplmentCode) ? CommonConstants.TWO_ZEROS : supplmentCode);
		gridVernData.setGridVernId(gridVernId);
		gridVernData.setFsaAssignedFlag(assignedFlag);
		return Example.of(gridVernData, fsaMatcher);
	}

	public Example<GridCriteriaData> constructCriteriaExample(GridVernId gridVernId) {
		ExampleMatcher criteriaMatcher = ExampleMatcher.matching().withIgnorePaths("filterCode",
				"gridCriteriaId.criteriaNumber", "gridCriteriaId.sequenceId");
		GridCriteriaData gridCriteriaData = new GridCriteriaData();
		ModelMapper modelMapper = new ModelMapper();
		GridCriteriaId gridCriteriaId = modelMapper.map(gridVernId, GridCriteriaId.class);
		gridCriteriaData.setGridCriteriaId(gridCriteriaId);
		return Example.of(gridCriteriaData, criteriaMatcher);
	}

	public Example<SoftwareCriteriaData> constructSwCriteriaExample(GridVernId gridVernId) {
		ExampleMatcher swCriteriaMatcher = ExampleMatcher.matching().withIgnorePaths("id.criteriaNumber",
				"id.sequenceId");
		SoftwareCriteriaData swCriteriaData = new SoftwareCriteriaData();
		ModelMapper modelMapper = new ModelMapper();
		SoftwareCriteriaId swCriteriaId = modelMapper.map(gridVernId, SoftwareCriteriaId.class);
		swCriteriaData.setId(swCriteriaId);
		return Example.of(swCriteriaData, swCriteriaMatcher);
	}

	@Transactional(transactionManager = "jpaDb2TransactionManager", propagation = Propagation.NOT_SUPPORTED)
	public void sendFRCApprovalDateReceivedEmail(GridVernData gridVernData) {
		String gcampFrcApprovalDate = commonRepository.getFRCDecisionDate(gridVernData.getGlobalFSANumber());
		ModelMapper dateMapper = new ModelMapper();
		String gridFrcApprovalDate = dateMapper.map(gridVernData.getFrcApprovalDate(), String.class);
		if (StringUtils.isNotEmpty(gridFrcApprovalDate) && !StringUtils.trimToEmpty(gridFrcApprovalDate)
				.equals(StringUtils.trimToEmpty(gcampFrcApprovalDate))) {
			String subject = getEmailSubject("FRC Date Revised for your FSA: " + gridVernData.getGlobalFSANumber());
			StringBuilder body = new StringBuilder();
			body.append("The FRC date has been revised for your FSA " + gridVernData.getGlobalFSANumber()
					+ ". The revised date is " + TargetingUtil.formatDate(gridFrcApprovalDate) + ", ");
			body.append("Kindly update the same by logging in to GCAMP\n\n\n");
			body.append(CommonConstants.AUTOMATIC_EMAIL_TEXT);
			sendEmailOnVernUpdate(gridVernData, subject, body.toString());
		}
	}

	public void sendEmailOnNewVERNInfo(GridVernInfo gridVernInfo) {
		List<String> hubCodes = new ArrayList<>();
		hubProperties.getGridgcamp().entrySet().forEach(entry -> {
			if (entry.getValue().contains(gridVernInfo.getInitiatingHub().substring(0, 2))) {
				hubCodes.addAll(Arrays.asList(StringUtils.split(entry.getValue(), ",")));
				hubCodes.add(entry.getKey());
			}
		});
		List<String> cdsids = commonRepository.getFSACoordinatorsCdsids(
				hubCodes.isEmpty() ? Arrays.asList(gridVernInfo.getInitiatingHub().substring(0, 2)) : hubCodes);
		if (CollectionUtils.isNotEmpty(cdsids)) {
			cdsids.replaceAll(cdsid -> StringUtils.trimToEmpty(cdsid) + CommonConstants.FORD_COM);
			List<String> ccEmailIds = new ArrayList<>();
			ccEmailIds.add(gridVernInfo.getRequester() + CommonConstants.FORD_COM);
			String subject = getEmailSubject("New Version of VERN available");
			StringBuilder body = new StringBuilder();
			body.append("Hi FSA Coordinators,\n");
			body.append("This is to notify on the new version of VERN (" + gridVernInfo.getVernNumber()
					+ ") is available in GCAMP system, please utilize these enhanced criteria for targeting vehicles.\n\n");
			body.append(CommonConstants.AUTOMATIC_EMAIL_TEXT);
			emailSender.sendMailToUsers(cdsids.stream().toArray(String[]::new),
					ccEmailIds.stream().toArray(String[]::new), systemEmail, subject, body.toString(), false);
		}
	}

	public LoadFsaResponseDTO getFSACriteriaLookupData() {
		return fsaCriteriaService.getFSACriteriaLookupData();
	}

	public void updateGlobalFSAType(GridVernData vernData) {
		Optional<FSAData> fsaData = fsaRepository.findById(vernData.getGlobalFSANumber());
		if (StringUtils.isNotBlank(vernData.getGlobalFsaType())) {
			FSATypeLookupData fsaTypeResponse = vernData.getGlobalFsaType().length() > 1
					? fsaTypeRepository.findFirstByCode(vernData.getGlobalFsaType())
					: fsaTypeRepository.findFirstByGridCode(vernData.getGlobalFsaType());
			try {
				if (fsaData.isPresent()) {
					fsaData.get().setFsaType(fsaTypeResponse.getCode());
					fsaData.get().setUpdateId(vernData.getUpdateId());
					fsaRepository.save(fsaData.get());
				}
			} finally {
				log.info("Global FSA Type updated by GRID for FSA: {}", vernData.getGlobalFSANumber());
				String subject = getEmailSubject("FSA Type updated for your FSA: " + vernData.getGlobalFSANumber());
				StringBuilder body = new StringBuilder();
				body.append("The FSA Type has been updated for your FSA " + vernData.getGlobalFSANumber()
						+ ". The new FSA Type is " + fsaTypeResponse.getDescription() + ".\n\n\n");
				body.append(CommonConstants.AUTOMATIC_EMAIL_TEXT);
				sendEmailOnVernUpdate(vernData, subject, body.toString());
			}
		}
	}

	public void updateFrcApprovalData(GridVernData gridVernData) {
		Optional<FSAData> fsaData = fsaRepository.findById(gridVernData.getGlobalFSANumber());
		FSATypeLookupData fsaTypeResponse = gridVernData.getGlobalFsaType().length() > 1
				? fsaTypeRepository.findFirstByCode(gridVernData.getGlobalFsaType())
				: fsaTypeRepository.findFirstByGridCode(gridVernData.getGlobalFsaType());
		try {
			if (fsaData.isPresent() && null != fsaTypeResponse) {
				fsaData.get().setFsaType(fsaTypeResponse.getCode());
				fsaData.get().setGlobalFSADescription(gridVernData.getFsaTitle());
				fsaData.get().setFrcDecisionDate(gridVernData.getFrcApprovalDate());
				fsaRepository.save(fsaData.get());
			}
		} finally {
			if (fsaData.isPresent()) {
				log.info("FSA Title, FSA Type and FRC Decision Date received from GRID for FSA: {}",
						gridVernData.getGlobalFSANumber());
				String subject = getEmailSubject("FSA Title, FSA Type and FRC Decision Date received from GRID for FSA "
						+ gridVernData.getGlobalFSANumber());
				StringBuilder body = new StringBuilder();
				body.append("The following details received from GRID and updated in GCAMP for FSA ")
						.append(gridVernData.getGlobalFSANumber()).append(":\n\n").append("FSA Title: ")
						.append(gridVernData.getFsaTitle()).append("\n").append("FSA Type: ")
						.append(null != fsaTypeResponse ? fsaTypeResponse.getDescription() : StringUtils.EMPTY)
						.append("\n").append("FRC Descision Date: ")
						.append(TargetingUtil.formatDate(gridVernData.getFrcApprovalDate())).append("\n\n\n")
						.append(CommonConstants.AUTOMATIC_EMAIL_TEXT);
				log.info("Email Body: {}", body.toString());
				sendEmailOnVernUpdate(gridVernData, subject, body.toString());
			}
		}
	}

	private void sendEmailOnVernUpdate(GridVernData gridVernData, String subject, String emailBody) {
		Set<String> toEmailIds = new HashSet<>();
		Optional<FSAData> fsaData = fsaRepository.findById(gridVernData.getGlobalFSANumber());
		if (fsaData.isPresent()) {
			if (StringUtils.isNotBlank(fsaData.get().getCreateBy())) {
				toEmailIds.add(StringUtils.trim(fsaData.get().getCreateBy()) + CommonConstants.FORD_EMAIL_DOMAIN);
			}
			toEmailIds.add(StringUtils.trim(fsaData.get().getUpdateId()) + CommonConstants.FORD_EMAIL_DOMAIN);
			List<String> ccEmailIds = new ArrayList<>();
			String updateId = StringUtils.trim(gridVernData.getUpdateId()) + CommonConstants.FORD_EMAIL_DOMAIN;
			if (toEmailIds.stream().noneMatch(toEmailId -> toEmailId.equalsIgnoreCase(updateId))) {
				ccEmailIds.add(updateId);
			}
			log.info("Email sent To: {} and Cc: {}", toEmailIds, ccEmailIds);
			emailSender.sendMailToUsers(toEmailIds.stream().toArray(String[]::new),
					ccEmailIds.stream().toArray(String[]::new), systemEmail, subject, emailBody, false);
		}
	}

	public GridVfdResponse uploadVfdReportToS3(GridVernData gridVernData) throws GCAMPException {
		try {
			GridVfdResponse vfdResponse = new GridVfdResponse();
			String[] vfdRptDetails = StringUtils.split(StringUtils.trimToEmpty(gridVernData.getVfdReportDataset()),
					"|");
			ftpSession.downloadFile(StringUtils.trimToEmpty(vfdRptDetails[0]));
			File file = new File("/tmp/selectedVINFile.txt");
			log.info("The downloaded file exists: {}", file.exists());
			vfdResponse.setTotalVehicleCount(Integer.parseInt(vfdRptDetails[1]));
			String vfdReportFileName = gridVernData.getGlobalFSANumber() + "_"
					+ gridVernData.getGridVernId().getSupplementId() + "_" + gridVernData.getVernNumber()
					+ "_VFD_REPORT.txt";
			uploadFileToS3(vfdReportFileName, file);
			log.info("The VFD Report uploaded to S3 successfully: File Name: {}", vfdReportFileName);
			vfdResponse.setVfdFileName(vfdReportFileName);
			vfdResponse.setVfdFilePath(vfdReportFileName);
			vfdResponse.setGlobalFSANumber(gridVernData.getGlobalFSANumber());
			vfdResponse.setSupplementId(gridVernData.getGridVernId().getSupplementId());
			vfdResponse.setGridYearId(gridVernData.getGridVernId().getGridYearId());
			vfdResponse.setImplementationId(gridVernData.getGridVernId().getImplementationId());
			vfdResponse.setVersion(gridVernData.getGridVernId().getVersion());
			vfdResponse.setVernNumber(gridVernData.getVernNumber());
			vfdResponse.setGridSequence(gridVernData.getGridVernId().getGridSequence());
			return vfdResponse;
		} catch (IOException e) {
			throw new GCAMPException("Error occured while uploading VFD Report file to S3, Contact system admin ", e);
		}
	}

	private void uploadFileToS3(String fileName, File file) throws IOException {
		try (InputStream inputStream = new FileInputStream(file)) {
			s3Service.addFile(inputStream, fileName, CommonConstants.TEXT_CONTENT_TYPE, inputStream.available());
		}
	}

	Example<GridCriteriaData> constructOTACriteriaExample(@Valid OTAIndicatorUpdateRequest otaUpdateRequest) {

		ExampleMatcher criteriaMatcher = ExampleMatcher.matching().withIgnorePaths("gridCriteriaId.criteriaNumber",
				"gridCriteriaId.sequenceId", "filterCode");

		GridCriteriaData gridCriteriaData = new GridCriteriaData();
		ModelMapper modelMapper = new ModelMapper();
		GridCriteriaId gridCriteriaId = modelMapper.map(otaUpdateRequest, GridCriteriaId.class);
		gridCriteriaData.setGridCriteriaId(gridCriteriaId);
		return Example.of(gridCriteriaData, criteriaMatcher);

	}

	public void sendEmailOnOTAIndicatorUpdate(@Valid OTAIndicatorUpdateRequest otaUpdateRequest,
			GridOTAUpdateResponse response) {

		FSAData fsaData = fsaRepository.findByGlobalFSANumber(otaUpdateRequest.getGlobalFSANumber());
		List<String> hubCodes = new ArrayList<>();
		hubProperties.getGridgcamp().entrySet().forEach(entry -> {
			if (entry.getValue().contains(fsaData.getHubCode())) {
				hubCodes.addAll(Arrays.asList(StringUtils.split(entry.getValue(), ",")));
				hubCodes.add(entry.getKey());
			}
		});
		List<String> cdsids = commonRepository
				.getFSACoordinatorsCdsids(hubCodes.isEmpty() ? Arrays.asList(fsaData.getHubCode()) : hubCodes);
		if (CollectionUtils.isNotEmpty(cdsids)) {
			cdsids.replaceAll(cdsid -> StringUtils.trimToEmpty(cdsid) + CommonConstants.FORD_COM);
			List<String> ccEmailIds = new ArrayList<>();
			ccEmailIds.add(otaUpdateRequest.getRequester() + CommonConstants.FORD_COM);

			String subject = getEmailSubject("OTA Indicator update to the Existing VERN");
			StringBuilder body = new StringBuilder();
			body.append("Hi FSA Coordinators,<br /><br />");
			body.append("This is to notify that OTA Indicator in VERN (" + otaUpdateRequest.getVernNumber()
					+ ") is updated and the following updates are available in GCAMP system.<br /><br />");
			if (CollectionUtils.isEmpty(otaUpdateRequest.getVehicleCritiera())) {
				body.append(
						"The system has automatically updated all the related attributes and no manual intervention is needed.<br /><br />");
			} else {

				if (CollectionUtils.isNotEmpty(response.getEmailVehicleLineInfo())) {
					Context context = new Context();
					context.setVariable("emailVehicleLineInfo", response.getEmailVehicleLineInfo());
					String reportTempalte = templateEngine.process("ota_update_vehicleline.html", context);
					body.append(reportTempalte);
				}
				constructDynamicEmailBody(response.getUpdateFiledvehicleLines(), body);

			}
			body.append(CommonConstants.AUTOMATIC_EMAIL_TEXT);
			log.info("email content {}", body);
			emailSender.sendMailToUsers(cdsids.stream().toArray(String[]::new),
					ccEmailIds.stream().toArray(String[]::new), systemEmail, subject, body.toString(), true);
		}

	}

	private void constructDynamicEmailBody(List<String> updateFailedVehicles, StringBuilder body) {

		if (CollectionUtils.isNotEmpty(updateFailedVehicles)) {

			body.append("<br />Since the vehicle line " + updateFailedVehicles.stream().collect(Collectors.joining(","))
					+ " are split into multiple VIN Groups, system has skipped the automation for this record and you need to manually update the VIN groups for these records.<br /><br />");
			body.append(
					"For rest of the records, system has automatically updated all the related attributes and no manual intervention is needed.<br /><br />");

		} else {
			body.append(
					"<br />The system has automatically updated all the related attributes and no manual intervention is needed.<br /> <br />");
		}
	}
	
	private String getEmailSubject(String emailSubject) {
		if ("dev".equalsIgnoreCase(activeProfile)) {
			return "TEST DEV:" + emailSubject;
		} else if ("qa".equalsIgnoreCase(activeProfile)) {
			return "TEST QA:" + emailSubject;
		}
		return emailSubject;
	}

}
