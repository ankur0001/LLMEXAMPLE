package com.ford.gcamp.targeting.frozenvin.api;

import java.util.List;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Size;
import lombok.*;
import org.springframework.stereotype.Component;

import com.ford.gcamp.targeting.common.api.FSAInfoVO;
import com.ford.gcamp.targeting.common.api.ResponseStatusDTO;
import com.ford.gcamp.targeting.common.api.SuppPopulationVo;

@Component
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper=false)
public class FrozenVinResponseDTO extends ResponseStatusDTO {
	private FSAInfoVO fsaInfoVO;

	@Size(min= 0, max = 250)
	private List<@Valid HubList> hubList;

	@Size(min= 0, max = 250)
	private List<@Valid GCPSupplementList> supllList;

	@Size(min= 0, max = 250)
	private List<@Valid SuppPopulationVo> suppPopulation;

}
