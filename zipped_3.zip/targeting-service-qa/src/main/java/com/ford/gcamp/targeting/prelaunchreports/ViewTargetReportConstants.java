package com.ford.gcamp.targeting.prelaunchreports;

public class ViewTargetReportConstants {
	
	public static final String COFIRM_BATCH_CODE = "006";
    public static final String EMAIL_INDICATOR = "Y";
	public static final String SUCCESS_CODE="200";
	public static final String SUCCESS="SUCCESS";
	public static final String SUCCESS_DESC="Data Retrieved Successfully";
	public static final String FAILURE_CODE="403";
	public static final String FAILURE="FAILED";
	public static final String ERROR = "error";
	public static final String WERS_LIKE_OPERATOR="W%";
	
	private ViewTargetReportConstants() {}
	

}
