package com.ford.gcamp.targeting.gsar.api;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class StopShipRepair {
	@Size(min = 0, max = 10)
	@Schema(example = "22C03", description = "fsa Id")
	@Pattern(regexp ="^[a-zA-Z\\d]*$", message = "FSA Id")
	private String fsaId;

	@Size(min = 0, max = 17)
	@Schema(example = "WF0NXXGCHNNL29915", description = "vin")
	@Pattern(regexp ="^[a-zA-Z\\d]*$", message = "vin number")
	private String vin;

	@Size(min = 0, max = 20)
	@Schema(example = "WF0NXXGCHNNL29915", description = "stopShipNum")
	@Pattern(regexp ="^[a-zA-Z\\d]*$", message = "stopShipNum")
	private String stopShipNum;

	@Size(min = 0, max = 10)
	@Schema(example = "22637698", description = "stopShipCampId")
	@Pattern(regexp ="^[a-zA-Z\\d]*$", message = "stopShipCampId")
	private String stopShipCampId;


	@Size(min = 0, max = 10)
	@Schema(example = "2022-02-11", description = "statusDate")
	@Pattern(regexp ="^[\\d\\-]*$", message = "statusDate")
	private String statusDate;


	@Size(min = 0, max = 30)
	@Schema(example = "Good", description = "status")
	@Pattern(regexp ="^[a-zA-z\\d\\s]*$", message = "status")
	private String status;

	@Size(min = 0, max = 10)
	@Schema(example = "2022-02-11", description = "lastUpdatedDate")
	@Pattern(regexp ="^[\\d\\-]*$", message = "lastUpdatedDate")
	private String lastUpdatedDate;
}
