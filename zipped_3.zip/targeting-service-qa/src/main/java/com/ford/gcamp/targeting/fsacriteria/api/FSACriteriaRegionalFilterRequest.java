package com.ford.gcamp.targeting.fsacriteria.api;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.annotation.Nullable;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@JsonIgnoreProperties(ignoreUnknown = true)
public class FSACriteriaRegionalFilterRequest {

	@Schema(example="67921",description = "globalFSANumber")
	@Min(0)
	@Max(99999999)
	private int globalFSANumber;



	@Schema(example="00",description = "supplementId")
	@Size(min = 0, max = 2, message = "length 1-2")
	@Pattern(regexp ="^[A-Za-z\\d]*$", message = "Supplement Code")
	private String supplementId;



	@Schema(example="AA",description = "VingrpCode")
	@Size(min = 0, max = 2, message = "length 1-2")
	@Pattern(regexp ="^[A-Za-z\\d]*$", message = "Vin Group Code")
	private String vinGroupCode;


	@Size(min = 0, max = 8)
	@Pattern(regexp = "^[a-zA-Z\\d\\-]*$")
	@Schema(example = "TDHARTI", description = "CDSID")
	private String cdsid;

	@Size(min = 0, max = 250, message = "Regional Filters")
	private List<@Valid FSACriteriaRegionalFilterDetails>  regionalFilters;
	
}
