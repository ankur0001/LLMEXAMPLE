package com.ford.gcamp.targeting.core.exception;
public class GCampDatabaseException extends GCAMPException {

	/**
	 * Constructor for GCampDatabaseException
	 */
	public GCampDatabaseException() {
		super();
	}

	/**
	 * Constructor for GCampDatabaseException
	 */
	public GCampDatabaseException(String msg) {
		super(msg);
	}

	/**
	 * Constructor for GCampDatabaseException
	 */
	public GCampDatabaseException(Throwable rootCause) {
		super(rootCause);
	}

	/**
	 * Constructor for GCampDatabaseException
	 */
	public GCampDatabaseException(String msg, Throwable rootCause) {
		super(msg, rootCause);
	}

}

