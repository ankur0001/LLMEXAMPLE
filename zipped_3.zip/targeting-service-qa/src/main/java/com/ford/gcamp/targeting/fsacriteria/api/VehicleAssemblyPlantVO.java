package com.ford.gcamp.targeting.fsacriteria.api;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class VehicleAssemblyPlantVO extends FsaVehicleCommonVO {

	@Size(min = 0, max = 10)
	@Pattern(regexp = "^|[A-Za-z\\d\\s\\*]*$")
	@Schema(example = " ", description = "assemblyPlantCode")
	private String assemblyPlantCode;

	@Size(min = 0, max = 250)
	@Pattern(regexp = "^|[A-Za-z\\d\\s,.\\-'\\/()\"\\#\\&]*$")
	@Schema(example = " ", description = "assemblyPlantDesc")
	private String assemblyPlantDesc;

	@Size(min = 0, max = 9)
	@Pattern(regexp = "^|[A-Za-z\\d\\s\\*]*$")
	@Schema(example = " ", description = "assemblyPlantFilterCode")
	private String assemblyPlantFilterCode;
	
}
