package com.ford.gcamp.targeting.common.api;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class FsaApsResourceAccessResponse {
	@Size(min = 0, max = 100)
	@Pattern(regexp = "^[A-Za-z:\\d]*$")
	@Schema(example = "GCAMP:Dashboard", description = "Resource Name")
	private String resourceName;
	private boolean isAccessible;
}
