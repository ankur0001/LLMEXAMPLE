
package com.ford.gcamp.targeting.reports.batch.exception.writer;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import com.ford.gcamp.targeting.reports.batch.common.ReportGenerationUtil;
import org.apache.poi.xssf.streaming.SXSSFSheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.item.Chunk;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.ford.gcamp.targeting.reports.batch.api.ExcelConfig;
import com.ford.gcamp.targeting.reports.batch.api.ReportMetaData;
import com.ford.gcamp.targeting.reports.batch.common.ReportCodeConstants;
import com.ford.gcamp.targeting.reports.batch.exception.GCAMPReportException;
import com.ford.gcamp.targeting.reports.batch.exception.api.TargetingExceptionReport;
import com.ford.gcamp.targeting.reports.batch.writer.GCAMPXSSFReportWriter;

@Component(ReportCodeConstants.T02 + "itemWriter")
@StepScope
public class ExcelVINsNotWithinCriteriaReportItemWriter extends GCAMPXSSFReportWriter implements ItemWriter<TargetingExceptionReport> {

	private List<TargetingExceptionReport> vinsNotWithinCriteriaList;

	@Value("#{jobParameters['reportMetaData']}")
	private String reportMetaDataString;

	private ReportMetaData rptData;

	@Override
	public void write(Chunk<? extends TargetingExceptionReport> items) throws Exception {
		rptData = ReportGenerationUtil.getReportMetaDataObject(reportMetaDataString);
		vinsNotWithinCriteriaList = new ArrayList<>(items.getItems());
		this.createReport(rptData);
	}

	@Override
	public void createWorksheet(SXSSFWorkbook hssfWorkbook, ReportMetaData metaData) throws GCAMPReportException {

		initializeWorkbook(hssfWorkbook);

		SXSSFSheet sheet = hssfWorkbook.createSheet("VINs Not With in Criteria");

		try {

			createProfile(sheet, metaData, "VINs Not With in Criteria Report");

			List<ExcelConfig> vinsNotWithinCriteriaConfigList = loadConfigFile(ReportCodeConstants.T02, metaData.getSuppCode());

			setColumnWidth(sheet, vinsNotWithinCriteriaConfigList);

			setColumnHeader(sheet, vinsNotWithinCriteriaConfigList);

			setRowData(sheet,vinsNotWithinCriteriaConfigList, vinsNotWithinCriteriaList);

		} catch (Exception e) {
			throw new GCAMPReportException("VINs Not With in Criteria Report", e);
		}

	}

}