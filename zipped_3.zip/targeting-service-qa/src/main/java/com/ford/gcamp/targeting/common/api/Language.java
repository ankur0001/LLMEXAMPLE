package com.ford.gcamp.targeting.common.api;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
 @Builder
 @NoArgsConstructor
 @AllArgsConstructor
public class Language {
	
	private String code;
	private String description;
		
}
