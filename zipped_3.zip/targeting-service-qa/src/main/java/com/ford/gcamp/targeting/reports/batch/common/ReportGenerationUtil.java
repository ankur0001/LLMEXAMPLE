package com.ford.gcamp.targeting.reports.batch.common;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.StringTokenizer;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanWrapper;
import org.springframework.beans.PropertyAccessorFactory;

import com.ford.gcamp.targeting.common.DateConvert;
import com.ford.gcamp.targeting.reports.batch.api.ReportMessageData;
import com.ford.gcamp.targeting.reports.batch.api.ReportMetaData;

import lombok.extern.slf4j.Slf4j;
@Slf4j
public class ReportGenerationUtil {

	private ReportGenerationUtil() {

	}

	public static ReportMetaData getReportMetaData(ReportMessageData msgData) {

		Map<String, String> reportMetaDataMap = new HashMap<>();
		List<String> metaDataList1 = Arrays
				.asList(StringUtils.split(msgData.getOracleURL(), ReportStandardConstants.WS_URL_TOKEN));

		List<String> metaDataList2 = Arrays
				.asList(StringUtils.split(msgData.getMetaString(), ReportStandardConstants.WS_URL_TOKEN));

		List<String> dataList = new ArrayList<>(metaDataList1);
		dataList.addAll(metaDataList2);

		dataList.forEach(token -> {
			StringTokenizer dataToken = new StringTokenizer(token, "=");
			String key = dataToken.hasMoreTokens() ? dataToken.nextToken() : StringUtils.EMPTY;
			String value = dataToken.hasMoreTokens() ? dataToken.nextToken() : StringUtils.EMPTY;
			if (StringUtils.isNotBlank(key)) {
				reportMetaDataMap.put(key, StringUtils.trimToEmpty(value));
			}
		});

		return setReportMetaData(reportMetaDataMap);
	}

	private static ReportMetaData setReportMetaData(Map<String, String> reportMetaDataMap) {

		ReportMetaData reportMetaData = new ReportMetaData();
		String rptFormat = reportMetaDataMap.get(ReportConstants.DESFORMAT);

		extracted(reportMetaDataMap, reportMetaData, rptFormat);

		String rptCode = StringUtils.isNotBlank(reportMetaDataMap.get(ReportConstants.RPT_CD))
				? reportMetaDataMap.get(ReportConstants.RPT_CD)
				: reportMetaDataMap.get(ReportConstants.RPT_CODE);
		if (StringUtils.isNoneBlank(rptCode)) {
			reportMetaData.setRptCode(rptCode);
		}

		String lang = reportMetaDataMap.get(ReportConstants.LANG);
		if (StringUtils.isNoneBlank(lang)) {
			reportMetaData.setLangCode(lang);
		}

		String rptStatus = reportMetaDataMap.get(ReportConstants.RPT_STATUS);
		if (StringUtils.isNoneBlank(rptStatus)) {
			reportMetaData.setFinalRptFlag(rptStatus);
		}

		String jobQue = reportMetaDataMap.get(ReportConstants.JOB_QUE);
		if (StringUtils.isNoneBlank(jobQue)) {
			reportMetaData.setJobQue(jobQue);
		}

		String agencyCode = reportMetaDataMap.get(ReportConstants.AGENCY_CD);
		if (StringUtils.isNoneBlank(agencyCode)) {
			reportMetaData.setAgencyCode(agencyCode);
		}

		String periodEndingDate = reportMetaDataMap.get(ReportConstants.PRD_END_DT);
		if (StringUtils.isNoneBlank(periodEndingDate)) {
			reportMetaData.setPeriodEndingDate(periodEndingDate);
		}

		String hubCD = reportMetaDataMap.get(ReportConstants.HUB_CD);
		if (StringUtils.isNoneBlank(hubCD)) {
			reportMetaData.setHubCode(hubCD);
		}

		String countryCD = reportMetaDataMap.get(ReportConstants.COUNTRY_CD);
		if (StringUtils.isNoneBlank(hubCD)) {
			reportMetaData.setCountryCode(countryCD);
		}

		String reqTS = reportMetaDataMap.get(ReportConstants.REQ_TS);
		if (StringUtils.isNoneBlank(hubCD)) {
			reportMetaData.setReqTimeStamp(reqTS);
		}

		extractd(reportMetaDataMap, reportMetaData);

		return reportMetaData;

	}

	private static void extractd(Map<String, String> reportMetaDataMap, ReportMetaData reportMetaData) {
		String globalFSANum = reportMetaDataMap.get(ReportConstants.GLOBAL_FSA_NUM);
		if (StringUtils.isNoneBlank(globalFSANum)) {
			reportMetaData.setGlobalFSANum(globalFSANum);
		}

		String launchFromDate = reportMetaDataMap.get(ReportConstants.LAUNCH_FROM_DT);
		if (StringUtils.isNoneBlank(launchFromDate)) {
			reportMetaData.setLaunchFromDate(launchFromDate);
		}

		String roiCD = reportMetaDataMap.get(ReportConstants.ROI_CODE);
		if (StringUtils.isNoneBlank(roiCD)) {
			reportMetaData.setRoiCode(roiCD);
		}

		String suppCD = reportMetaDataMap.get(ReportConstants.SUPP_CD);
		if (StringUtils.isNoneBlank(suppCD)) {
			reportMetaData.setSuppCode(suppCD);
		}

		String distListFlag = reportMetaDataMap.get(ReportConstants.DIST_LIST_F);
		if (StringUtils.isNoneBlank(distListFlag)) {
			reportMetaData.setDistListFlag(distListFlag);
		}

		String batchCode = reportMetaDataMap.get(ReportConstants.BATCH_CD);
		if (batchCode != null && batchCode.trim().length() > 0) {
			reportMetaData.setBatchCode(batchCode);
		}
		String jobQueue = reportMetaDataMap.get(ReportConstants.JOB_QUE);
		if (jobQueue != null && jobQueue.trim().length() > 0) {
			reportMetaData.setJobQue(jobQueue);
			reportMetaData.setJobQueue(Integer.parseInt(jobQueue));
		}
		String hubDescription = reportMetaDataMap.get(ReportConstants.HUB_DESC);
		if (hubDescription != null && hubDescription.trim().length() > 0) {
			reportMetaData.setHubDescription(hubDescription);
		}

		String globalFSANumberDesc = reportMetaDataMap.get(ReportConstants.GLOBAL_FSA_DESC);
		if (globalFSANumberDesc != null && globalFSANumberDesc.trim().length() > 0) {
			reportMetaData.setGlobalFSANumDesc(globalFSANumberDesc);
		}

		String reportDescription = reportMetaDataMap.get(ReportConstants.RPT_DESC);
		if (reportDescription != null && reportDescription.trim().length() > 0) {
			reportMetaData.setReportDesc(reportDescription);
		}
	}

	private static void extracted(Map<String, String> reportMetaDataMap, ReportMetaData reportMetaData, String rptFormat) {
		if (StringUtils.isNotBlank(rptFormat)) {
			reportMetaData.setRptFormat(rptFormat);
		}

		String cdsid = reportMetaDataMap.get(ReportConstants.REQ_CDSID);
		if (StringUtils.isNoneBlank(cdsid)) {
			reportMetaData.setReqById(cdsid);
		}

		String processId = reportMetaDataMap.get(ReportConstants.PROCESS_ID);
		if (StringUtils.isNoneBlank(processId)) {
			reportMetaData.setProcessId(Integer.parseInt(processId));
		}

		String emailCode = reportMetaDataMap.get(ReportConstants.EMAIL_CODE);
		if (StringUtils.isNoneBlank(emailCode)) {
			reportMetaData.setEmailCode(emailCode);
		}

		String rptId = reportMetaDataMap.get(ReportConstants.RPT_ID);
		if (StringUtils.isNoneBlank(rptId)) {
			reportMetaData.setReportId(rptId);
			int reportId = Integer.parseInt(rptId);
			reportMetaData.setRptId(reportId);
		}
	}

	public static String getSupplementCode(String supplementCode) {

		if (StringUtils.isBlank(supplementCode)) {
			return "00";
		} else {
			return StringUtils.trimToEmpty(supplementCode);
		}
	}

	public static String getSupplementDescription(String supplementDescription) {

		if (StringUtils.isBlank(supplementDescription)) {
			return "ORIGINAL";
		} else {
			return StringUtils.trimToEmpty(supplementDescription);
		}
	}

	public static String capitalize(String description) {
		if (StringUtils.isNotBlank(description)) {
			StringBuilder strBuilder = new StringBuilder();
			description = StringUtils.lowerCase(description);
			String prevChar = StringUtils.EMPTY;
			int index = 0;
			for (char c : description.toCharArray()) {
				if (index == 0 || StringUtils.SPACE.equals(prevChar) || "/".equals(prevChar) || "-".equals(prevChar)
						|| "&".equals(prevChar) || "*".equals(prevChar)) {
					strBuilder.append(Character.toUpperCase(c));
				} else {
					strBuilder.append(c);
				}
				index++;
				prevChar = String.valueOf(c);

			}
			return strBuilder.toString();
		}
		return description;
	}
	
	public static String getWorkbookMapKey(ReportMetaData reportMetaData) {
		StringBuilder strBuilder = new StringBuilder();
		strBuilder.append(reportMetaData.getRptCode())
		.append(ReportStandardConstants.COLON)
		.append(reportMetaData.getReportId());
		return strBuilder.toString();
	}
	
	public static String getFormattedTimeStamp(String timeStamp) {
		if (StringUtils.isNotBlank(timeStamp)) {
			return DateConvert.getInstance().formatOutputDate(
					StringUtils.trimToEmpty(timeStamp)) + StringUtils.SPACE
					+ StringUtils.trimToEmpty(timeStamp).substring(11, 16) + " HRS";
		}
		return timeStamp;
	}
	
	public static String getPropertyValue(Object obj, String propertyName) {

		try {
			BeanWrapper wrapper = PropertyAccessorFactory.forBeanPropertyAccess(obj);
			if(!wrapper.isReadableProperty(propertyName) && "key".equalsIgnoreCase(propertyName)) {
				return StringUtils.EMPTY;
			}
			Optional<Object> value = Optional.ofNullable(wrapper.getPropertyValue(propertyName));
			if (value.isPresent()) {
				return value.get().toString();
			} 

		} catch (Exception ex) {
			log.error("Coundn't find the getter method for a given property {} in Class {} and error {}", propertyName,
					obj.getClass(), ex);
		}
		return StringUtils.EMPTY;
	}

	public static ReportMetaData getReportMetaDataObject(String reportMetaDataString) {
		ReportMetaData reportMetaData = null;
		try {
			reportMetaData = new ObjectMapper().readValue(reportMetaDataString, ReportMetaData.class);
		} catch (Exception e) {
			log.error("There is an error in getting the ReportMetaData object from reportMetaDataString", e);
		}

		return reportMetaData;
	}

}
