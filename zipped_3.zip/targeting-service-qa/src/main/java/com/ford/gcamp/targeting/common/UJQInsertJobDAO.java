package com.ford.gcamp.targeting.common;

import java.util.Map;
import com.ford.gcamp.targeting.common.api.BatchJobDataForPhaseByPercent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;
import com.ford.gcamp.targeting.common.api.BatchJobData;
import com.ford.gcamp.targeting.common.api.LayoutBuffer;

@Repository
public class UJQInsertJobDAO{
	
	private static final Logger LOGGER = LoggerFactory.getLogger(UJQInsertJobDAO.class);
	
	public static final String BATCH_INSERT_PROC_NAME = "CSGCSJ11";	
	private BatchJobData batchJobData = null;

	private BatchJobDataForPhaseByPercent batchJobDataForPhaseByPercent = null;
	
	@Autowired
	private JdbcTemplate jdbcTemplate;	
	
	protected void getResults(String output){
		final int LAYOUT_SIZE = 200;
		LayoutBuffer layoutBuffer = new LayoutBuffer(LAYOUT_SIZE);
		
		//job id
		layoutBuffer.addField(LayoutBuffer.FIELDTYPE_PIC9, 10);
		//batch short desc
		layoutBuffer.addField(LayoutBuffer.FIELDTYPE_PICX, 40);
		//job status desc
		layoutBuffer.addField(LayoutBuffer.FIELDTYPE_PICX, 40);
		//job name
		layoutBuffer.addField(LayoutBuffer.FIELDTYPE_PICX, 8); 
		//file name
		layoutBuffer.addField(LayoutBuffer.FIELDTYPE_PICX, 45); 
		//request time stamp
		layoutBuffer.addField(LayoutBuffer.FIELDTYPE_PICX, 26);
		//filler
		layoutBuffer.addField(LayoutBuffer.FIELDTYPE_PICX, 31);
		
		layoutBuffer.fromString(output);
		
		batchJobData.setJobId(Integer.parseInt(layoutBuffer.getString(0)));
		batchJobData.setJobName(layoutBuffer.getString(3));
		batchJobData.setFileName(layoutBuffer.getString(4));
		batchJobData.setRequestTime(layoutBuffer.getString(5));
	}

	protected void getResultsForPhase(String output){
		final int LAYOUT_SIZE = 200;
		LayoutBuffer layoutBuffer = new LayoutBuffer(LAYOUT_SIZE);

		//job id
		layoutBuffer.addField(LayoutBuffer.FIELDTYPE_PIC9, 10);
		//batch short desc
		layoutBuffer.addField(LayoutBuffer.FIELDTYPE_PICX, 40);
		//job status desc
		layoutBuffer.addField(LayoutBuffer.FIELDTYPE_PICX, 40);
		//job name
		layoutBuffer.addField(LayoutBuffer.FIELDTYPE_PICX, 8);
		//file name
		layoutBuffer.addField(LayoutBuffer.FIELDTYPE_PICX, 45);
		//request time stamp
		layoutBuffer.addField(LayoutBuffer.FIELDTYPE_PICX, 26);
		//filler
		layoutBuffer.addField(LayoutBuffer.FIELDTYPE_PICX, 31);

		layoutBuffer.fromString(output);

		batchJobDataForPhaseByPercent.setJobId(Integer.parseInt(layoutBuffer.getString(0)));
		batchJobDataForPhaseByPercent.setJobName(layoutBuffer.getString(3));
		batchJobDataForPhaseByPercent.setFileName(layoutBuffer.getString(4));
		batchJobDataForPhaseByPercent.setRequestTime(layoutBuffer.getString(5));
	}

   /**
    * Insert job information into job queue table
    * @param con The database connection
    * @param batchJobData The batch job data
    * @return assigned job id
    */
	public int insertJobQ(BatchJobData batchJobData){
		final String METHOD_NAME = "insertJobQ()";	
		LOGGER.info("Adding entry in UJQ :{}", METHOD_NAME);
				
		String message = null;
		NullPointerException e = null;

		this.batchJobData = batchJobData;

		//Validate non null
		if (batchJobData == null) {
			message = "Batch job data is null.";
			e = new NullPointerException(message);
			LOGGER.error(this.getClass().getName(), METHOD_NAME, e);
			throw e;
		}
		
		if (null == batchJobData.getBatchCode() || null == batchJobData.getCdsId() ||
			"".equals(batchJobData.getBatchCode().trim()) || 
			"".equals(batchJobData.getCdsId().trim())) {
			message = "Batch code and CDS id can not be blank.";
			e = new NullPointerException(message);
			LOGGER.error(this.getClass().getName(), METHOD_NAME, e);
			throw e;
		}
		
		//Reset other null fields to blank
		if (null == batchJobData.getLocalFSANo()) {
			batchJobData.setLocalFSANo("");
		}

		if (null == batchJobData.getHubCode()) {
			batchJobData.setHubCode("");
		}

		if (null == batchJobData.getCountryCode()) {
			batchJobData.setCountryCode("");
		}

		if (null == batchJobData.getEmailIndicator()) {
			batchJobData.setEmailIndicator("N");
		}

		if (null == batchJobData.getParameters()) {
			batchJobData.setParameters("");
		}

		if (null == batchJobData.getSupplement()) {
			batchJobData.setSupplement("");
		}

		if (null == batchJobData.getFolderId()) {
			batchJobData.setFolderId("");
		}

		if (null == batchJobData.getVin()) {
			batchJobData.setVin("");
		}
		try {
			
			SimpleJdbcCall simpleJdbcCall = null;
			Map<String, Object> ujqInsert = null;
			simpleJdbcCall = creatSimpleJdbcCall(CommonConstants.FSA_SCHEMA_NAME,BATCH_INSERT_PROC_NAME);
			SqlParameterSource sqlParameterSource = createSqlParameterSource("INPUT_PARM1", batchJobData.getInputString1(),"INPUT_PARM2", batchJobData.getInputString2());
			LOGGER.info("input param values {}", sqlParameterSource);
			ujqInsert = simpleJdbcCall.execute(sqlParameterSource);
			LOGGER.info("Response from Store Proc {}", ujqInsert);
			
			String outputParam = (String) ujqInsert.get("OUTPUT_PARM1");
			
			getResults(outputParam);
			
		}catch(Exception e1) {
			LOGGER.error("Exception occured ",e1);
		}
		
		
		LOGGER.info("Added entry in UJQ - JobId : {}", batchJobData.getJobId());
		return batchJobData.getJobId();
	}

	public int insertJobQForPhase(BatchJobDataForPhaseByPercent batchJobDataForPhaseByPercent){
		final String METHOD_NAME = "insertJobQ()";
		LOGGER.info("Adding entry in UJQ for Phase by Percent :{}", METHOD_NAME);
		String message = null;
		NullPointerException e = null;
		this.batchJobDataForPhaseByPercent = batchJobDataForPhaseByPercent;
		//Validate non null
		if (batchJobDataForPhaseByPercent == null) {
			message = "Batch job data is null.";
			e = new NullPointerException(message);
			LOGGER.error(this.getClass().getName(), METHOD_NAME, e);
			throw e;
		}
		if (null == batchJobDataForPhaseByPercent.getBatchCode() || null == batchJobDataForPhaseByPercent.getCdsId() ||
				"".equals(batchJobDataForPhaseByPercent.getBatchCode().trim()) ||
				"".equals(batchJobDataForPhaseByPercent.getCdsId().trim())) {
			message = "Batch code and CDS id can not be blank.";
			e = new NullPointerException(message);
			LOGGER.error(this.getClass().getName(), METHOD_NAME, e);
			throw e;
		}
		//Reset other null fields to blank
		if (null == batchJobDataForPhaseByPercent.getLocalFSANo()) {
			batchJobDataForPhaseByPercent.setLocalFSANo("");
		}
		if (null == batchJobDataForPhaseByPercent.getHubCode()) {
			batchJobDataForPhaseByPercent.setHubCode("");
		}
		if (null == batchJobDataForPhaseByPercent.getCountryCode()) {
			batchJobDataForPhaseByPercent.setCountryCode("");
		}
		if (null == batchJobDataForPhaseByPercent.getEmailIndicator()) {
			batchJobDataForPhaseByPercent.setEmailIndicator("N");
		}
		if (null == batchJobDataForPhaseByPercent.getParameters()) {
			batchJobDataForPhaseByPercent.setParameters("");
		}
		if (null == batchJobDataForPhaseByPercent.getSupplement()) {
			batchJobDataForPhaseByPercent.setSupplement("");
		}
		if (null == batchJobDataForPhaseByPercent.getFolderId()) {
			batchJobDataForPhaseByPercent.setFolderId("");
		}
		if (null == batchJobDataForPhaseByPercent.getVin()) {
			batchJobDataForPhaseByPercent.setVin("");
		}
		try {
			SimpleJdbcCall simpleJdbcCall = null;
			Map<String, Object> ujqInsert = null;
			simpleJdbcCall = creatSimpleJdbcCall(CommonConstants.FSA_SCHEMA_NAME,BATCH_INSERT_PROC_NAME);
			SqlParameterSource sqlParameterSource = createSqlParameterSource("INPUT_PARM1", batchJobDataForPhaseByPercent.getInputString1(),"INPUT_PARM2", batchJobDataForPhaseByPercent.getInputString2());
			LOGGER.info("input param values for phase by percent {}", sqlParameterSource);
			ujqInsert = simpleJdbcCall.execute(sqlParameterSource);
			LOGGER.info("Response from Store Proc for phase by percent  {}", ujqInsert);
			String outputParam = (String) ujqInsert.get("OUTPUT_PARM1");
			getResultsForPhase(outputParam);
		}catch(Exception e1) {
			LOGGER.error("Exception occured for phase by percent ",e1);
		}
		LOGGER.info("Added entry in UJQ - JobId for phase by percent: {}", batchJobDataForPhaseByPercent.getJobId());
		return batchJobDataForPhaseByPercent.getJobId();
	}
		
	MapSqlParameterSource createSqlParameterSource(String inputParamKey1, String inputParamVal1, String inputParamKey2, String inputParamVal2) {
		return new MapSqlParameterSource().addValue(inputParamKey1,inputParamVal1)
				.addValue(inputParamKey2, inputParamVal2);
	}

	SimpleJdbcCall creatSimpleJdbcCall(String schemaName, String procedureName) {
		return new SimpleJdbcCall(jdbcTemplate).withSchemaName(schemaName)
				.withProcedureName(procedureName);
	}
	
}

