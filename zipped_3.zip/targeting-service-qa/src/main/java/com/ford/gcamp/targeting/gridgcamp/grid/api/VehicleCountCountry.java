package com.ford.gcamp.targeting.gridgcamp.grid.api;

import java.util.List;

import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class VehicleCountCountry {
	@Size(min=0, max = 3)
	@Pattern(regexp ="^[A-Za-z]*$")
	String country;
	@Size(min=0, max = 500)
	List<VehicleCountDetail> vehicles;
	@Size(min=0, max = 500)
	List<String> pdc;
}
