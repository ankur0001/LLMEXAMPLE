package com.ford.gcamp.targeting.common;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ford.gcamp.targeting.common.entity.JobQueueData;
import com.ford.gcamp.targeting.common.entity.JobQueueDataId;

@Repository
public interface JobQueueRepository extends JpaRepository<JobQueueData, JobQueueDataId> {

}
