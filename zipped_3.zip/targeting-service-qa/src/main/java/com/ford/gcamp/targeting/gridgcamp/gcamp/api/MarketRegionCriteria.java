package com.ford.gcamp.targeting.gridgcamp.gcamp.api;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@JsonIgnoreProperties(ignoreUnknown = true)
public class MarketRegionCriteria {

	@Size(min=0, max = 500)
	private List< @Valid  MarketRegion> value;


	@Schema(description = "operator",example = " ")
	@Size(min = 0, max = 25, message = "length max 25")
	@Pattern(regexp ="^|[A-Za-z\\s]*$", message = "Operator Value")
	private String operator;
	
}
