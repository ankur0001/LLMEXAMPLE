package com.ford.gcamp.targeting.fsacriteria.api;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class AttributeGroupingList {
	@NotNull
	@Size(min = 1, max = 3)
	@Pattern(regexp = "^[\\d]*$")
	@Schema(example="19",description = "GCP Filter GRPC")
	private int gcpFilterGRPC;


	@NotNull
	@Size(min = 1, max = 50)
	@Pattern(regexp = "^[a-zA-Z\\d\\s]*$")
	@Schema(example="CUSTOMER STATE CODE",description = "GCP Filter GRPC Description")
	private String gcpFilterGRPX;
}
