
package com.ford.gcamp.targeting.gsar.api;

import java.util.Date;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ViewReports {
	@Size(min = 0, max = 8)
	@Pattern(regexp = "^[a-zA-Z\\d\\-]*$")
	@Schema(example = "TDHARTI", description = "CDSID")
	private String userId;


	@Min(0)
	@Max(999999999)
	@Schema(example = "1029", description = "Result Id")
	private Integer resultId;

	@Min(0)
	@Max(999999999)
	@Schema(example = "3", description = "unique Id")
	private Integer uniqueId;

	@Size(min=0,max = 254)
	@Pattern(regexp = "^[A-Za-z0-9\\s\\*]*$")
	@Schema(example = "GCAMP VINs 2022 MY Claims on PROD", description = "Description")
	private String description;


	@Size(min = 0, max = 20)
	@Pattern(regexp = "^[a-zA-Z\\d\\-\\s\\.\\/]*$")
	@Schema(example = "2021-05-19", description = "run Date")
	private String runDate;

	@Setter(AccessLevel.NONE)
	@Getter(AccessLevel.NONE)
	@Size(min = 0, max = 40)
	@Pattern(regexp = "^[a-zA-Z\\d\\-\\s\\.\\/\\:\\+]$")
	@Schema(example = "05-Jun-2024", description = "run Date")
	private Date createdDate;

	@Schema(example= "D")
	@Size(min = 0, max = 1)
	@Pattern(regexp ="^[A-Za-z]$")
	private String option;

	@Schema(example= "D")
	@Size(min = 0, max = 1)
	@Pattern(regexp ="^[A-Za-z]$")
	private String criteria;

	@Size(min = 0, max = 10)
	@Pattern(regexp ="^[\\d]$")
	@Schema(example = "788", description = "count")
	private String count;

	@Schema(example= "Y" , description = "uplaod Flag")
	@Size(min = 0, max = 1)
	@Pattern(regexp ="^[A-Za-z]$")
	private String uploadFlag;


	@Schema(example= "Y" , description = " download Flag")
	@Size(min = 0, max = 1)
	@Pattern(regexp ="^[A-Za-z]$")
	private String downloadFlag;
	private boolean showWarning;


	@Size(max = 254)
	@Pattern(regexp = "^[A-Za-z0-9\\s\\*]*$")
	@Schema(example = "GCAMP VINs 2022 MY Claims on PROD", description = "Description")
	private String warningMessage;
	
	public void setCreatedDate(Date createdDate) {
		if (createdDate == null) {
			this.createdDate = null;
		} else {
			this.createdDate = new Date(createdDate.getTime());
		}
	}

	public Date getCreatedDate() {
		if (createdDate != null) {
			return new Date(createdDate.getTime());
		} else {
			return null;
		}
	}
}
