package com.ford.gcamp.targeting.gridgcamp.grid.entity;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Entity
@Table(name = "SGCPB22_VEHICLE_LN")
public class VehicleLineLookupData  implements Serializable {

	private static final long serialVersionUID = 1L;
	@Id
	@Column(name = "GCPB22_VEH_LN_C")
	private String code;
	@Column(name = "GCPB22_VEH_LN_X")
	private String description;
	@Column(name = "GCPB13_VEH_TYP_C")
	private String vehicleTypeCode;
	@Column(name = "GCPB22_MODEL_YR_C")
	private int modelYear;
}
