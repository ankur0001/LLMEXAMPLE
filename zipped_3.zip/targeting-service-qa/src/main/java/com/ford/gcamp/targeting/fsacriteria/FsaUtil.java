package com.ford.gcamp.targeting.fsacriteria;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.ford.gcamp.targeting.common.CommonConstants;
import com.ford.gcamp.targeting.common.TargetingUtil;
import com.ford.gcamp.targeting.fsacriteria.api.DeleteFsaInfoReq;
import com.ford.gcamp.targeting.fsacriteria.api.FSACriteriaSessionData;
import com.ford.gcamp.targeting.fsacriteria.api.FSAGlobalData;
import com.ford.gcamp.targeting.fsacriteria.api.FsaGlobalSearchRequest;



@Component
public class FsaUtil {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(FsaUtil.class);


	public String formInputParamFAG(String fscNumber, String optRadio) {
		StringBuilder sb = new StringBuilder();
		if (("G").equals(optRadio)) {
			sb.append(optRadio);
			sb.append(TargetingUtil.fillRemainingString(fscNumber,8,"0"));
			sb.append(TargetingUtil.addSpaceToProc(9));
		} else if (("L").equals(optRadio)) {
			sb.append(optRadio);
			sb.append(TargetingUtil.fillRemainingString(fscNumber.toUpperCase().toUpperCase(),10," "));
			sb.append(TargetingUtil.addSpaceToProc(9));
		}
		return sb.toString();
	}

	public String formInputParam2(String population, String cdsId) {
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.append(CommonConstants.FSA_SEARCH_GO_PARM);
		stringBuilder.append(population);
		if(cdsId!=null) {
		stringBuilder.append(TargetingUtil.fillRemainingString(cdsId.toUpperCase(),8," "));
		}
		stringBuilder.append(TargetingUtil.addSpaceToProc(989));
		return stringBuilder.toString();
	}

	public List<String> splitOutparamWithPipe(List<String> outputPAramList) {
		List<String> outPutFilterdList = new ArrayList<>();
		for (String string : outputPAramList) {
			String[] str = string.split("\\|");
			Collections.addAll(outPutFilterdList,str);
		}
		return outPutFilterdList;
	}


	public FSACriteriaSessionData fsaSessionData(List<String> outParam1List) {
		FSACriteriaSessionData fscSessionData = new FSACriteriaSessionData();

		for (String string : outParam1List) {
			String[] str = string.split(CommonConstants.DOUBLE_SPACE_DELIMETER);
			LOGGER.info("lenght of the sting is {}", str.length);
			
			for (int i = 0; i < str.length; i++) {
				fscSessionData.setFsaNumber(str[0].substring(3));
				fscSessionData.setInquiry(str[1].substring(3));
				fscSessionData.setCompliance(str[2]);
				fscSessionData.setHub(str[3]);
				fscSessionData.setGloablFsa(str[4]);
				fscSessionData.setDate(str[5]);

			}
		}
		return fscSessionData;
	}

	public List<FSAGlobalData> stringSplitDelimiter(String outParam1List) {
		List<FSAGlobalData> fsaGlobalDatasList = new ArrayList<>();
		
		FSAGlobalData fsaGlobalData = null;
		outParam1List = outParam1List.replace("[", "");
		String[] arra = outParam1List.split(" I ");
		for (String string : arra) {
			String[] array1 = string.split(CommonConstants.DOUBLE_SPACE_DELIMETER);
			if (array1.length == 3) {
				fsaGlobalData = new FSAGlobalData();
				fsaGlobalData.setLocalFsaCode(array1[0]);
				fsaGlobalData.setLocalFscType(array1[2]);
			}
			fsaGlobalDatasList.add(fsaGlobalData);
		}
		return fsaGlobalDatasList;
	}

	public String getGlobalFsaParam1(FsaGlobalSearchRequest globalFsaSearch) {

		String descrition="";
		String description2="";

		if(StringUtils.isNotBlank(globalFsaSearch.getDescription())) {
			descrition="%"+globalFsaSearch.getDescription().toUpperCase()+"%";
		}
		if(StringUtils.isNotBlank(globalFsaSearch.getDescription2())) {
			description2="%"+globalFsaSearch.getDescription2().toUpperCase()+"%";
		}
		StringBuilder globalSearch = new StringBuilder();
		globalSearch.append("  ");
		globalSearch.append(globalFsaSearch.getHub());
		globalSearch.append(globalFsaSearch.getSearchType());
		if(("").equals(globalFsaSearch.getFsaNumber())) {
			globalSearch.append(TargetingUtil.addSpaceToProc(10));
		}else if(("G").equals(globalFsaSearch.getFsaType()) && !("").equals(globalFsaSearch.getFsaNumber())) {
			globalSearch.append(TargetingUtil.fillRemainingString(globalFsaSearch.getFsaNumber(),10,"0"));
		}else if(("L").equals(globalFsaSearch.getFsaType()) && !("").equals(globalFsaSearch.getFsaNumber())) {
			globalSearch.append(TargetingUtil.fillRemainingString(globalFsaSearch.getFsaNumber(),10," "));
		}
		globalSearch.append(globalFsaSearch.getStatus());
		if(StringUtils.isNotBlank(globalFsaSearch.getSearchFromDate())) {
			globalSearch.append(globalFsaSearch.getSearchFromDate());
		}else {
			globalSearch.append(CommonConstants.INVALID_DATE);
		}
		if(StringUtils.isNotBlank(globalFsaSearch.getSearchToDate())) {
			globalSearch.append(globalFsaSearch.getSearchToDate());
		}else {
			LocalDate date = LocalDate.now();
			globalSearch.append(date);
		}		
		globalSearch.append(globalFsaSearch.getOrderType());
		globalSearch.append(globalFsaSearch.getDescSearchCondition());
		globalSearch.append(TargetingUtil.fillRemainingString(descrition,254," "));
		globalSearch.append(TargetingUtil.fillRemainingString(description2,254," "));
		globalSearch.append(TargetingUtil.addSpaceToProc(550-globalSearch.length()));
		
		LOGGER.info("global fsa search inout is {}:",globalSearch);
		LOGGER.info("lenght of global fsa search inout is {}:",globalSearch.length());
		
		return globalSearch.toString();
	}


	public String getInoutParam(DeleteFsaInfoReq deleteFsaInfoReq) {

		StringBuilder globalSearch = new StringBuilder();
		if(deleteFsaInfoReq!=null) {
			globalSearch.append(deleteFsaInfoReq.getFsaType());
			globalSearch.append(TargetingUtil.fillRemainingString(deleteFsaInfoReq.getFsaNumber(),8,"0"));
			globalSearch.append(TargetingUtil.addSpaceToProc(11));
		}
		return globalSearch.toString();
	}

}
