package com.ford.gcamp.targeting.fsacriteria.api;



import java.util.List;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import org.springframework.stereotype.Component;

import lombok.Getter;
import lombok.Setter;
@Component
@Getter
@Setter
public class LoadStateProvinceDTO {
	@Size(min = 0, max = 250, message = "listCountryData List")
	private List<@Valid CountryData> listCountryData;
	public LoadStateProvinceDTO() {

	}
	
	public LoadStateProvinceDTO(List<CountryData> listCountryData) throws UnsupportedOperationException{
		//A public constructor - Sonar fix
	}

		
}
