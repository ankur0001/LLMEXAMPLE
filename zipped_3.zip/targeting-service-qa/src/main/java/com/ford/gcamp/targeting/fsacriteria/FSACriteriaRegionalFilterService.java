package com.ford.gcamp.targeting.fsacriteria;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.TreeSet;
import java.util.Map.Entry;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

import jakarta.persistence.EntityManager;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.ExampleMatcher;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ford.gcamp.targeting.common.CommonConstants;
import com.ford.gcamp.targeting.common.api.CommonResponse;
import com.ford.gcamp.targeting.common.api.FscCriteriaRequest;
import com.ford.gcamp.targeting.common.api.GenericLookup;
import com.ford.gcamp.targeting.common.api.GenericLookupResponse;
import com.ford.gcamp.targeting.fsacriteria.api.CriteriaRegionalFilterTreeView;
import com.ford.gcamp.targeting.fsacriteria.api.FSACriteriaRegionalFilterDetails;
import com.ford.gcamp.targeting.fsacriteria.api.FSACriteriaRegionalFilterRequest;
import com.ford.gcamp.targeting.fsacriteria.api.FsaCriteriaParamRequest;
import com.ford.gcamp.targeting.fsacriteria.api.FsaCriteriaSaveParam;
import com.ford.gcamp.targeting.fsacriteria.api.FscCriteriaResponseGoDTO;
import com.ford.gcamp.targeting.fsacriteria.api.GeographicTreeView;
import com.ford.gcamp.targeting.fsacriteria.api.RegionalFilterCountryTreeView;
import com.ford.gcamp.targeting.fsacriteria.api.RegionalFilterHubTreeView;
import com.ford.gcamp.targeting.fsacriteria.api.RegionalFilterRoiTreeView;
import com.ford.gcamp.targeting.fsacriteria.api.StateProvince;
import com.ford.gcamp.targeting.fsacriteria.api.VINGrpCriteriaVO;
import com.ford.gcamp.targeting.fsacriteria.api.VinGroupRegionalFilterResponse;
import com.ford.gcamp.targeting.fsacriteria.entity.FSACriteriaRegionalFilterData;
import com.ford.gcamp.targeting.fsacriteria.entity.RegionalFilterId;

import lombok.extern.slf4j.Slf4j;

import static java.util.stream.Collectors.toList;

@Service
@Slf4j
public class FSACriteriaRegionalFilterService {

	private FSACriteriaRegionalFilterRepository regionalFilterRepository;
	private EntityManager enttityManager;

	public FSACriteriaRegionalFilterService(FSACriteriaRegionalFilterRepository regionalFilterRepository,
			@Qualifier("jpaDb2EntityManager") EntityManager enttityManager) {
		super();
		this.regionalFilterRepository = regionalFilterRepository;
		this.enttityManager = enttityManager;
	}

	public List<FSACriteriaRegionalFilterData> getFSACriteriaRegionalFilters(int globalFSANumber, String population,
			String vinGroupCode) {

		RegionalFilterId regionalFilterId = new RegionalFilterId();
		regionalFilterId.setGlobalFSANumber(globalFSANumber);
		regionalFilterId.setSupplementId(population);
		if (StringUtils.isNoneBlank(vinGroupCode)) {
			regionalFilterId.setVinGroupCode(vinGroupCode);
		}

		FSACriteriaRegionalFilterData regionalFilterData = new FSACriteriaRegionalFilterData();
		regionalFilterData.setRegionalFilterId(regionalFilterId);

		ExampleMatcher regionalFilterMatcher = ExampleMatcher.matching()
				.withIgnorePaths("regionalFilterId.criteriaSequenceId").withIgnoreNullValues();
		Example<FSACriteriaRegionalFilterData> exampleInterface = Example.of(regionalFilterData, regionalFilterMatcher);
		return regionalFilterRepository.findAll(exampleInterface);

	}

	public void loadRegionalFilters(FscCriteriaRequest fscCriteriaRequest,
			FscCriteriaResponseGoDTO fsaCriteriaResponse) {

		if (CommonConstants.FLAG_L.equalsIgnoreCase(fscCriteriaRequest.getOptRadio())) {
			fscCriteriaRequest
					.setFscNumber(StringUtils.trimToEmpty(fsaCriteriaResponse.getFsaInfoVO().getGlobalFSANumber()));
		}

		List<FSACriteriaRegionalFilterData> fsaCriteriaFilters = getFSACriteriaRegionalFilters(
				Integer.parseInt(fscCriteriaRequest.getFscNumber()), fscCriteriaRequest.getPopulation(),
				StringUtils.EMPTY);
		if (CollectionUtils.isNotEmpty(fsaCriteriaFilters)) {
			List<CriteriaRegionalFilterTreeView> regionalFilterData = constructTreeView(fsaCriteriaFilters);

			List<VINGrpCriteriaVO> vinGrpCriteriaVOs = addRegionalFiltersToCriteria(
					fsaCriteriaResponse.getVinGrpCriteriaVOs(), regionalFilterData);

			fsaCriteriaResponse.setVinGrpCriteriaVOs(vinGrpCriteriaVOs);
		}

	}

	public List<CriteriaRegionalFilterTreeView> constructTreeView(
			List<FSACriteriaRegionalFilterData> fsaCriteriaFilters) {

		List<CriteriaRegionalFilterTreeView> regionaFilters = new ArrayList<>();
		Map<String, List<FSACriteriaRegionalFilterData>> regionalFilterMap = fsaCriteriaFilters.stream()
				.collect(Collectors.groupingBy(filterID -> filterID.getRegionalFilterId().getVinGroupCode(),
						LinkedHashMap::new, toList()));

		for (Entry<String, List<FSACriteriaRegionalFilterData>> regionalCriteriaEntry : regionalFilterMap.entrySet()) {

			List<FSACriteriaRegionalFilterData> regionalFiltersByVinGrp = regionalFilterMap
					.get(regionalCriteriaEntry.getKey());

			regionaFilters.add(CriteriaRegionalFilterTreeView.builder()
					.globalFSANumber(regionalFiltersByVinGrp.get(0).getRegionalFilterId().getGlobalFSANumber())
					.supplementId(regionalFiltersByVinGrp.get(0).getRegionalFilterId().getSupplementId())
					.vinGroupCode(regionalCriteriaEntry.getKey())
					.regionalFilters(getHubLevelData(regionalFiltersByVinGrp)).build());

		}

		return regionaFilters;
	}

	private List<RegionalFilterHubTreeView> getHubLevelData(
			List<FSACriteriaRegionalFilterData> regionalFiltersByVinGrp) {

		Map<String, List<FSACriteriaRegionalFilterData>> hubFilterMap = regionalFiltersByVinGrp.stream()
				.collect(Collectors.groupingBy(FSACriteriaRegionalFilterData::getHubCode, LinkedHashMap::new,
						toList()));
		List<RegionalFilterHubTreeView> regionalFilters = new ArrayList<>();
		for (Entry<String, List<FSACriteriaRegionalFilterData>> hubCriteriaEntry : hubFilterMap.entrySet()) {
			List<FSACriteriaRegionalFilterData> hubs = hubFilterMap.get(hubCriteriaEntry.getKey());

			regionalFilters.add(RegionalFilterHubTreeView.builder().hubCode(hubCriteriaEntry.getKey())
					.label(StringUtils.trimToEmpty(hubCriteriaEntry.getValue().get(0).getHub().getHubDescription()))
					.children(getRoiTreeView(hubs)).build());

		}

		return regionalFilters;
	}

	private List<RegionalFilterRoiTreeView> getRoiTreeView(List<FSACriteriaRegionalFilterData> hubs) {

		List<RegionalFilterRoiTreeView> rois = new ArrayList<>();

		Map<String, List<FSACriteriaRegionalFilterData>> roiFilterMap = hubs.stream().collect(Collectors
				.groupingBy(FSACriteriaRegionalFilterData::getRoiCode, LinkedHashMap::new, toList()));

		for (Entry<String, List<FSACriteriaRegionalFilterData>> roiCriteriaEntry : roiFilterMap.entrySet()) {
			List<FSACriteriaRegionalFilterData> roiCriteria = roiFilterMap.get(roiCriteriaEntry.getKey());

			rois.add(RegionalFilterRoiTreeView.builder().roiCode(roiCriteriaEntry.getKey())
					.label(StringUtils.trimToEmpty(roiCriteria.get(0).getRoi().getRoiDescription()))
					.children(getCountryView(roiCriteria)).build());

		}

		return rois;
	}

	private List<RegionalFilterCountryTreeView> getCountryView(List<FSACriteriaRegionalFilterData> roiCriteria) {
		List<RegionalFilterCountryTreeView> countries = new ArrayList<>();

		Map<String, List<FSACriteriaRegionalFilterData>> countryFilterMap = roiCriteria.stream().collect(Collectors
				.groupingBy(FSACriteriaRegionalFilterData::getCountryCode, LinkedHashMap::new, toList()));

		for (Entry<String, List<FSACriteriaRegionalFilterData>> countryCriteriaEntry : countryFilterMap.entrySet()) {
			List<FSACriteriaRegionalFilterData> countryCriteria = countryFilterMap.get(countryCriteriaEntry.getKey());

			countries.add(RegionalFilterCountryTreeView.builder().countryCode(countryCriteriaEntry.getKey())
					.label(StringUtils.trimToEmpty(countryCriteria.get(0).getCountry().getDescription()))
					.children(getGeographicView(countryCriteria)).build());
		}

		return countries;
	}

	private List<GeographicTreeView> getGeographicView(List<FSACriteriaRegionalFilterData> countryCriteria) {

		List<GeographicTreeView> geoGraphicView = new ArrayList<>();
		Map<String, List<FSACriteriaRegionalFilterData>> geoFilterMap = countryCriteria.stream().collect(Collectors
				.groupingBy(FSACriteriaRegionalFilterData::getGeographicCode, LinkedHashMap::new, toList()));

		for (Entry<String, List<FSACriteriaRegionalFilterData>> geoCriteriaEntry : geoFilterMap.entrySet()) {

			if (StringUtils.isNotEmpty(StringUtils.trimToEmpty(geoCriteriaEntry.getKey()))) {
				List<FSACriteriaRegionalFilterData> geoCriteria = geoFilterMap.get(geoCriteriaEntry.getKey());

				List<StateProvince> statePrvinces = geoCriteria.stream()
						.map(state -> new StateProvince(state.getStateCode(),
								StringUtils.trimToEmpty(state.getStateProvinceData().getDescription())))
						.toList();

				geoGraphicView.add(GeographicTreeView.builder().geoCode(geoCriteriaEntry.getKey())
						.label(StringUtils.trimToEmpty(geoCriteria.get(0).getGeoGraphichData().getDescription()))
						.children(statePrvinces).build());
			}

		}
		return geoGraphicView;
	}

	public List<VINGrpCriteriaVO> addRegionalFiltersToCriteria(List<VINGrpCriteriaVO> vinGrpCriteriaVOs,
			List<CriteriaRegionalFilterTreeView> regionalFilterData) {

		List<VINGrpCriteriaVO> vinGroupCriteria = new ArrayList<>();

		for (VINGrpCriteriaVO vinGrpFilterVo : vinGrpCriteriaVOs) {
			Optional<CriteriaRegionalFilterTreeView> filterCriteria = regionalFilterData.stream()
					.filter(regionalCriteria -> regionalCriteria.getVinGroupCode()
							.equalsIgnoreCase(vinGrpFilterVo.getVinGroupLabel()))
					.findFirst();
			if (filterCriteria.isPresent()) {
				vinGrpFilterVo.setRegionalFilters(filterCriteria.get());
				vinGroupCriteria.add(vinGrpFilterVo);
			} else {
				vinGroupCriteria.add(vinGrpFilterVo);
			}
		}

		return vinGroupCriteria;
	}

	@Transactional("jpaDb2TransactionManager")
	public void copyRegionalFilterData(FsaCriteriaParamRequest copyCriteriaRequest) {

		saveRegionalFilterData(copyCriteriaRequest.getRegionalFilter());
		log.info("save all successfully completed");

	}

	public GenericLookupResponse getRegionalFilterVinGrps(int globalFSANumber, String supplementCode) {

		GenericLookupResponse genericLookupResponse = new GenericLookupResponse();
		List<FSACriteriaRegionalFilterData> fsaCriteriaFilters = getFSACriteriaRegionalFilters(globalFSANumber,
				supplementCode, StringUtils.EMPTY);
		List<GenericLookup> vinGroups = fsaCriteriaFilters.stream()
				.map(regionalFilterData -> GenericLookup.builder()
						.code(regionalFilterData.getRegionalFilterId().getVinGroupCode())
						.description(StringUtils
								.trimToEmpty(regionalFilterData.getVinGroupLookup().getVinGroupDescription()))
						.build())
				.toList();

		Set<GenericLookup> vinGrpSet = vinGroups.stream()
				.collect(Collectors.toCollection(() -> new TreeSet<>(Comparator.comparing(GenericLookup::getCode))));

		genericLookupResponse.setValues(vinGrpSet.stream().toList());

		return genericLookupResponse;

	}

	public VinGroupRegionalFilterResponse getVinGroupRegionalFilters(int globalFSANumber, String supplementCode,
			String vinGroupCode) {

		List<FSACriteriaRegionalFilterData> fsaCriteriaFilters = getFSACriteriaRegionalFilters(globalFSANumber,
				supplementCode, vinGroupCode);

		List<FSACriteriaRegionalFilterDetails> vinGroupFilters = fsaCriteriaFilters.stream()
				.map(regionalFilter -> FSACriteriaRegionalFilterDetails.builder().hubCode(regionalFilter.getHubCode())
						.roiCode(regionalFilter.getRoiCode()).countryCode(regionalFilter.getCountryCode())
						.geographicCode(StringUtils.trimToEmpty(regionalFilter.getGeographicCode()))
						.stateCode(StringUtils.trimToEmpty(regionalFilter.getStateCode())).build())
				.toList();

		return VinGroupRegionalFilterResponse.builder().regionalFilters(vinGroupFilters)
				.statusCode(CommonConstants.SUCCESS_CODE).status(CommonConstants.SUCCESS)
				.statusDescription(CommonConstants.SUCCESS_DESCRIPTION).build();
	}

	public Boolean isRegionalFilterExists(int globalFSANumber, String supplementCode) {

		List<FSACriteriaRegionalFilterData> vinGroupRegionalFilters = getFSACriteriaRegionalFilters(globalFSANumber,
				supplementCode, StringUtils.EMPTY);

		return CollectionUtils.isNotEmpty(vinGroupRegionalFilters);
	}

	public CommonResponse deleteVinGroupRegionalFilters(int globalFSANumber, String supplementCode) {

		List<FSACriteriaRegionalFilterData> vinGroupRegionalFilters = getFSACriteriaRegionalFilters(globalFSANumber,
				supplementCode, StringUtils.EMPTY);
		regionalFilterRepository.deleteAll(vinGroupRegionalFilters);
		return CommonResponse.builder().statusCode(CommonConstants.SUCCESS_CODE).status(CommonConstants.SUCCESS)
				.statusDescription(CommonConstants.DELETE_SUCCESS_DESCRIPTION).build();
	}

	@Transactional("jpaDb2TransactionManager")
	public void saveVinGroupRegionalFilterData(FsaCriteriaSaveParam fsaCriteriaModifySaveParam) {

		List<FSACriteriaRegionalFilterData> regionalFilters = getFSACriteriaRegionalFilters(
				Integer.parseInt(fsaCriteriaModifySaveParam.getCriteriaParam().getFsaNumber()),
				fsaCriteriaModifySaveParam.getCriteriaParam().getVehiclePopUpCode(),
				fsaCriteriaModifySaveParam.getCriteriaParam().getVinGrpCode());

		regionalFilterRepository.deleteAll(regionalFilters);
		log.info("delete regional filters if exist{}");
		regionalFilterRepository.flush();
		if (ObjectUtils.isNotEmpty(fsaCriteriaModifySaveParam.getRegionalFilter())) {
			saveRegionalFilterData(fsaCriteriaModifySaveParam.getRegionalFilter());
		}
	}

	public void saveRegionalFilterData(FSACriteriaRegionalFilterRequest fsaRegionalFilter) {

		ModelMapper modelMapper = new ModelMapper();
		AtomicInteger criteriaSeqNum = new AtomicInteger(1);
		List<FSACriteriaRegionalFilterData> regionalFilters = fsaRegionalFilter.getRegionalFilters().stream()
				.map(regionFilter -> getRegionalFilterData(modelMapper, regionFilter, criteriaSeqNum.getAndIncrement(),
						fsaRegionalFilter))
				.toList();

		log.info("The length of regional filters retrieved from ui {}", regionalFilters.size());

		regionalFilterRepository.saveAll(regionalFilters);

		log.info("Save all regional filters completed successfully");

	}

	private FSACriteriaRegionalFilterData getRegionalFilterData(ModelMapper modelMapper,
			FSACriteriaRegionalFilterDetails regionFilter, int criteriaSeqNum,
			FSACriteriaRegionalFilterRequest fsaRegionalFilter) {
		ModelMapper regionFilterIdMapper = new ModelMapper();
		FSACriteriaRegionalFilterData regionalFilterDetails = new FSACriteriaRegionalFilterData();
		enttityManager.detach(regionalFilterDetails);
		log.info("detach privous vingroupData");
		regionalFilterDetails = modelMapper.map(regionFilter, FSACriteriaRegionalFilterData.class);
		RegionalFilterId regionalFilterId = regionFilterIdMapper.map(fsaRegionalFilter, RegionalFilterId.class);
		regionalFilterDetails.setUpdateId(fsaRegionalFilter.getCdsid());
		regionalFilterDetails.setRegionalFilterId(regionalFilterId);
		regionalFilterDetails.getRegionalFilterId().setCriteriaSequenceId(criteriaSeqNum);
		return regionalFilterDetails;
	}

}
