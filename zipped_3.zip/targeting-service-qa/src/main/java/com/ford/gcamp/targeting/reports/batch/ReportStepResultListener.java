package com.ford.gcamp.targeting.reports.batch;

import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.util.WorkbookUtil;
import org.apache.poi.xssf.streaming.SXSSFRow;
import org.apache.poi.xssf.streaming.SXSSFSheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.ford.gcamp.targeting.reports.batch.api.ReportMetaData;
import com.ford.gcamp.targeting.reports.batch.common.ReportCodeConstants;
import com.ford.gcamp.targeting.reports.batch.common.ReportGenerationUtil;
import com.ford.gcamp.targeting.reports.batch.common.ReportStandardConstants;
import com.ford.gcamp.targeting.reports.batch.exception.GCAMPReportException;
import com.ford.gcamp.targeting.reports.batch.writer.GCAMPXSSFReportWriter;

import lombok.extern.slf4j.Slf4j;

@Component
@StepScope
@Slf4j
public class ReportStepResultListener extends GCAMPXSSFReportWriter implements StepExecutionListener {

	@Value("#{jobParameters['reportMetaData']}")
	private String reportMetaDataString;

	private ReportMetaData reportMetaData;

	private String stepName;

	@Override
	public void beforeStep(StepExecution stepExecution) {
		reportMetaData = ReportGenerationUtil.getReportMetaDataObject(reportMetaDataString);

		log.info("The Step has started for the report code {}", reportMetaData.getRptCode());

	}

	@Override
	public ExitStatus afterStep(StepExecution stepExecution) {
		stepName = stepExecution.getStepName();
		if (stepExecution.getReadCount() == 0) {
			try {
				this.createReport(reportMetaData);
			} catch (GCAMPReportException e) {
				log.info(
						"There is an error in creating excel and insert into database for the report code {} and exception is ",
						reportMetaData.getRptCode(), e);
			}

		}
		return ExitStatus.COMPLETED;
	}

	@Override
	protected void createWorksheet(SXSSFWorkbook wb, ReportMetaData reportMetaData) throws GCAMPReportException {
		initializeWorkbook(wb);
		SXSSFSheet sheet;
		String sheetName = stepName;
		String headerName = stepName;
		if (StringUtils.startsWithIgnoreCase(stepName, "W")) {
			String[] codeDescription = StringUtils.split(stepName, ":");
			sheetName = headerName = ReportGenerationUtil.capitalize(codeDescription[1]);
		} else if (ReportCodeConstants.REPORT_CODE_SHEET_NAME_MAP.containsKey(stepName)) {
			String[] reportNames = StringUtils.split(ReportCodeConstants.REPORT_CODE_SHEET_NAME_MAP.get(stepName),
					ReportStandardConstants.COLON);
			sheetName = reportNames[0];
			headerName = reportNames.length > 1 ? reportNames[1] : reportNames[0];
		}
		sheet = wb.createSheet(WorkbookUtil.createSafeSheetName(sheetName));
		createProfile(sheet, reportMetaData, headerName);
		setNoDataExists(sheet);
	}

	private void setNoDataExists(SXSSFSheet sheet) {
		SXSSFRow row = sheet.createRow(0);
		sheet.setColumnWidth(0, (60 * this.pixelSize));
		this.createCell(row, this.dataFont, 0, "No data exists for this report", StringUtils.EMPTY,
				CellType.STRING, this.centerStyle);
	}

}
