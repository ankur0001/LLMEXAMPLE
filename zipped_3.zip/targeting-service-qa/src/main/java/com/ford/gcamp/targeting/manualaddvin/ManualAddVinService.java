package com.ford.gcamp.targeting.manualaddvin;


import java.nio.charset.StandardCharsets;
import java.util.*;

import com.ford.gcamp.targeting.vin.GcsService;
import com.ford.gcamp.targeting.vin.VinListsService;
import com.ford.gcamp.targeting.vin.api.FileDownloadResponseDTO;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.stereotype.Service;
import com.ford.gcamp.targeting.common.BatchTrigger;
import com.ford.gcamp.targeting.common.FscCriteriaUtil;
import com.ford.gcamp.targeting.common.api.BatchJobData;
import com.ford.gcamp.targeting.common.api.FscCriteriaRequest;
import com.ford.gcamp.targeting.common.api.GenericLookup;
import com.ford.gcamp.targeting.core.exception.GCAMPException;
import com.ford.gcamp.targeting.core.exception.GCampBatchTriggerException;
import com.ford.gcamp.targeting.common.CommonConstants;
import com.ford.gcamp.targeting.manualaddvin.api.ManualAddVinsVO;
import com.ford.gcamp.targeting.manualaddvin.api.ManualUploadResponse;
import com.ford.gcamp.targeting.prelaunchreports.ViewTargetingReportsRepository;
import com.ford.gcamp.targeting.properties.HubCountryProperties;

import lombok.extern.slf4j.Slf4j;
import org.springframework.web.multipart.MultipartFile;

@Service
@Slf4j
public class ManualAddVinService {

	FscCriteriaUtil fscCriteriaUtil;
	ManualAddVinRepository manualAddVinRepository;
	BatchTrigger trigger;
	BatchJobData job;
	ManualAddVinUtil manualAddVinUtil;
	ViewTargetingReportsRepository viewTargetingReportsRepository;

	VinListsService vinListService;

	GcsService gcsService;
	@Autowired
	HubCountryProperties properties;

	@Value("${s3.bucket}")
	private String bucket;

	public ManualAddVinService(FscCriteriaUtil fscCriteriaUtil, ManualAddVinRepository manualAddVinRepository,
							   BatchTrigger trigger, BatchJobData job, ManualAddVinUtil manualAddVinUtil,
							   ViewTargetingReportsRepository viewTargetingReportsRepository, VinListsService vinListService,
							   GcsService gcsService) {
		this.fscCriteriaUtil = fscCriteriaUtil;
		this.manualAddVinRepository = manualAddVinRepository;
		this.trigger = trigger;
		this.job = job;
		this.manualAddVinUtil = manualAddVinUtil;
		this.viewTargetingReportsRepository = viewTargetingReportsRepository;
		this.vinListService = vinListService;
		this.gcsService = gcsService;
	}

	public ManualUploadResponse queryManulLoad(FscCriteriaRequest fscCriteriaRequest) throws GCAMPException {
		ManualAddVinsVO manualAddVinVo = ManualAddVinsVO.builder().supplementCode(fscCriteriaRequest.getPopulation())
				.build();
		Map<String, Object> vinListListResponse = manualAddVinRepository.queryManualUpload(
				fscCriteriaUtil.fsaGoSerialParam(fscCriteriaRequest), CommonConstants.ZERO,
				manualAddVinUtil.getInputParam3(manualAddVinVo, "load"));
		ManualUploadResponse response = manualAddVinUtil.getManualUploadData(vinListListResponse);
		if(CommonConstants.SUCCESS_CODE.equalsIgnoreCase(response.getStatusCode())) {
			response.setSupplements(
					viewTargetingReportsRepository.getSupplements(response.getFsaInfoVO().getGlobalFSANumber()));
		}
		return response;
	}

	public ManualUploadResponse addVinsManually(ManualAddVinsVO manualVinsVo) throws GCAMPException {
		String fsaGoParm = fscCriteriaUtil.fsaManualVinsGoParam(manualVinsVo);
		String inputParam2 = fscCriteriaUtil.getManulVinInputParam2(manualVinsVo);
		Map<String, Object> vinListListResponse = manualAddVinRepository.checkVinExistence(fsaGoParm, inputParam2);
		log.info("check vin exstence error response {}:", vinListListResponse.get(CommonConstants.ERROR_PARM));
		ManualUploadResponse responseStatus = manualAddVinUtil.checkExistenceOfVin(vinListListResponse);
		String inputParam3  = fscCriteriaUtil.batchInputManualAddVins(manualVinsVo);
		if (!responseStatus.getStatusCode().equals(CommonConstants.FAILURE_CODE) && !manualVinsVo.isLocalTest()) {
			try {
				int jobId;
				if (manualVinsVo.getIsNewVinGroupAdded().equals(CommonConstants.FLAG_Y)) {
					GenericLookup lookup = addNewVinGroup(fsaGoParm, "0", manualVinsVo, CommonConstants.ADD);
					log.info("folder for segment number zero {}:", lookup.getCode());
					String segmentZeroValue = getSegmentZeroValue(lookup.getDescription(),
							manualVinsVo.getSelectedSegmentsAndVinGrps());

					manualVinsVo.setSelectedSegmentsAndVinGrps(
							segmentZeroValue + manualVinsVo.getSelectedSegmentsAndVinGrps());
					log.info("segment zero sequence number {}:", lookup.getDescription());
					log.info("complete selected segment number {}", manualVinsVo.getSelectedSegmentsAndVinGrps());
					jobId = submitBatch(manualVinsVo,inputParam3 ,lookup.getCode());
					log.info("job completed sucessfully for new vin grp with jobID and S3 upload process starts{} ",
							jobId);
					uploadFileToGCS(manualVinsVo, lookup.getCode());
					log.info("Reading and uploading file to S3 process ends");
				} else {
					GenericLookup lookup = addNewVinGroup(fsaGoParm, "0", manualVinsVo, CommonConstants.INQUIRY);
					log.info("existing vin add segment number{}", lookup.getCode());
					jobId = submitBatch(manualVinsVo, inputParam3, lookup.getCode());
					log.info(
							"job completed sucessfully for existing vin grp with jobID  and upload process starts{}",
							jobId);
					uploadFileToGCS(manualVinsVo, lookup.getCode());
					log.info("Reading and uploading file to S3 process ends");
				}
				responseStatus.setStatus(CommonConstants.SUCCESS);
				responseStatus.setStatusCode(CommonConstants.SUCCESS_CODE);
				responseStatus.setStatusDescription("Your Job has been successfully submitted with Job Id " + jobId
						+ " for the Batch Code " + CommonConstants.MANUAL_VIN_UPLOAD_BATCH_CODE);
			} catch (GCampBatchTriggerException e) {
				log.error("Exception in uploadFile", e);
				throw new GCAMPException(CommonConstants.EXCEPTION_OCCURED + " - checkVinExistence() :", e);

			}
		}
		return responseStatus;
	}

	private void uploadFileToGCS(ManualAddVinsVO manualVinsVo, String folderId){
		MultipartFile vinMultipartFile;
		String fileName = manualVinsVo.getFsaNumber() + "_" + folderId + ".txt";
		String inputVins = getVins(manualVinsVo.getVinNumbers());
		if (manualVinsVo.getIsNewVinGroupAdded().equals(CommonConstants.FLAG_N)) {
			boolean fileExists = gcsService.checkVinListFileExistence(fileName);
			log.info("Manual Add VIN -  Vin file exists in GCS Bucket -  {}",fileName);
			if (fileExists) {
				FileDownloadResponseDTO fileDnResponse = vinListService.downloadVinFile(fileName);
				inputVins = updateFileContent(fileDnResponse.getFileContent(), inputVins);
			}
		}
		vinMultipartFile = new MockMultipartFile("file", fileName, ".txt", inputVins.getBytes(StandardCharsets.UTF_8));
		vinListService.uploadFileToGcs(fileName, vinMultipartFile);
		log.info("Uploaded manually add vin file in GCS Bucket {}",fileName);
	}

	private String updateFileContent(String existingContent, String newVinsContent) {
		List<String> allVins = new ArrayList<>();

		// Process existing VINs
		if (existingContent != null && !existingContent.trim().isEmpty()) {
			Arrays.stream(existingContent.split(System.lineSeparator()))
					.map(String::trim)
					.filter(vin -> !vin.isEmpty()) // Filter out any empty lines
					.forEach(allVins::add); // Add to list
		}

		// Process new VINs
		if (newVinsContent != null && !newVinsContent.trim().isEmpty()) {
			Arrays.stream(newVinsContent.split(System.lineSeparator()))
					.map(String::trim)
					.filter(vin -> !vin.isEmpty())
					.forEach(allVins::add); // Add to list
		}

		// Reconstruct the string with each VIN on a new line, no trailing newline
		return String.join(System.lineSeparator(), allVins);
	}

	  private String getVins(String vinNumbers) {
		StringBuilder vins = new StringBuilder();
		String[] vinsArray = vinNumbers.split(",");
		for (String vin : vinsArray) {
			if (vin.length() > 0) {
				vins.append(vin);
				vins.append(System.lineSeparator());
			}
		}
		return vins.toString();
	}

	private String getSegmentZeroValue(String sequenceNumber, String segmentZero) {
		StringBuilder segmentZeroValue = new StringBuilder();
		segmentZeroValue.append("0|");
		segmentZeroValue.append(Integer.parseInt(sequenceNumber));
		segmentZeroValue.append("|");
		if (StringUtils.isNotBlank(segmentZero)) {
			segmentZeroValue.append(",");
		}
		log.info("segment number zero value {}", segmentZeroValue);
		return segmentZeroValue.toString();

	}

	private GenericLookup addNewVinGroup(String input1, String input2, ManualAddVinsVO manualVinsVo, String flag)
			throws GCAMPException {
		String inputParam3 = manualAddVinUtil.getInputParam3(manualVinsVo, flag);
		log.info("input param3 value for new stored procedure {}", inputParam3);
		Map<String, Object> addNewVinResponse = manualAddVinRepository.queryManualUpload(input1, input2, inputParam3);
		return manualAddVinUtil.addNewVinGroupResponse(addNewVinResponse);
	}

	private int submitBatch(ManualAddVinsVO manualVinsVo, String batchInput, String folderId)
			throws GCampBatchTriggerException {
		job.setBatchCode(CommonConstants.MANUAL_VIN_UPLOAD_BATCH_CODE);
		job.setHubCode(properties.getHub().get(CommonConstants.MANUAL_ADD_VIN_HUB_COUNTRY_PROP_KEY));
		job.setCountryCode(properties.getCountry().get(CommonConstants.MANUAL_ADD_VIN_HUB_COUNTRY_PROP_KEY));
		job.setGlobalFSANo(Integer.parseInt(manualVinsVo.getFsaNumber()));
		job.setParameters(batchInput);
		job.setEmailIndicator(manualVinsVo.getBatchInEmail());
		job.setCdsId(manualVinsVo.getCdsId());
		job.setSupplement(manualVinsVo.getSupplementCode());
		job.setFolderId(folderId);
		return trigger.submitJob(job);
	}
}
