package com.ford.gcamp.targeting.gfsasetup.api;

import com.ford.gcamp.targeting.gridgcamp.gcamp.api.FSAMappingTypes;
import com.ford.gcamp.targeting.gridgcamp.gcamp.api.GridBasicVernInfo;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FsaSetupCreateRequest {
	@NotNull
	@Size(min = 1 , max = 260)
	@Pattern(regexp = "^[a-zA-Z\\d\\s\\-\\.\\*\\(\\)\\,\\+\\_\\#||%^\\$\\'\\;\\:]*$")
	@Schema(example = "creating new Global FSA", description = "Global FSA Description")
	private String globalFSADesc;

	@NotNull
	@Size(min = 0, max = 2)
	@Pattern(regexp = "^[a-zA-Z\\d]*$")
	@Schema(example = "SC", description = "Safety Compliance")
	private String selectedGlobalFSAType;

	@Size(min = 0, max = 20)
	@Pattern(regexp = "^[a-zA-Z\\d\\-]*$")
	@Schema(example = "05-Jun-2024", description = "FRC Decision Date")
	private String frcDecisionDate;

	@Size(min = 0, max = 5)
	@Pattern(regexp = "^[A-Za-z\\d\\-\\s]*$")
	@Schema(example = "68712", description = "14D Number")
	private String number14D;

	@Size(min = 0, max = 8)
	@Pattern(regexp = "^[a-zA-Z\\d\\-]*$")
	@Schema(example = "", description = "14D author Name")
	private String author14D;

	@Size(min = 0 , max = 260)
	@Pattern(regexp = "^[a-zA-Z\\d\\s\\-\\.\\*\\(\\)\\,\\+\\_\\#||%^\\$\\'\\;\\:]*$")
	@Schema(example = "creating new Global FSA", description = "Global FSA Description")
	private String globalFSARemarks;

	@Size(min = 0, max = 20)
	@Pattern(regexp = "^[a-zA-Z\\d\\-]*$")
	@Schema(example = "05-Jun-2024", description = "Relinquish Date")
	private String relinquishDate;

	@Size(min = 0, max = 20)
	@Pattern(regexp = "^[a-zA-Z\\d\\-]*$")
	@Schema(example = "05-Jun-2024", description = "Global Launch Date")
	private String globalLaunchDate;

	@Schema(example= "P" , description = "Flag")
	@Size(min = 0, max = 1)
	@Pattern(regexp ="^[A-Za-z]$")
	private String fsaLaunchFlag;

	@Schema(example= "Y" , description = "Flag")
	@Size(min = 0, max = 1)
	@Pattern(regexp ="^[A-Za-z]$")
	private String otaIndicator;

	@Schema(example= "Y" , description = "Flag")
	@Size(min = 0, max = 1)
	@Pattern(regexp ="^[A-Za-z]$")
	private String tandemFlag;

	@Schema(example= "G" , description = "Input Format Type")
	@Size(min = 0, max = 1)
	@Pattern(regexp ="^[A-Za-z]$")
	private String hdInputFormatType;

	@Size(min = 0, max = 8)
	@Pattern(regexp = "^[a-zA-Z\\d\\-]*$")
	@Schema(example = "TDHARTI", description = "CDSID")
	private String cdsid;

	@Size(min = 0, max = 2)
	@Pattern(regexp = "^[a-zA-Z\\*]*$")
	@Schema(example = "NA", description = "Hub code")
	private String hub;

	@Valid
	private GridBasicVernInfo gridBasicVernInfo;
	private boolean fsaTypeChanged;


	@Size(min = 0, max = 10)
	@Pattern(regexp = "^|[a-zA-Z\\d\\s]*$")
	@Schema(example = "Y", description = "Regional Program")
	private String regionalProgram;


	@Schema(example="67892",description = "Affected Global FSANumber")
	@Min(0)
	@Max(99999999)
	private Integer affectedGlobalFsa;

	@Schema(example = "67894",description = "Non affected global FSANumber")
	@Min(0)
	@Max(99999999)
	private Integer nonAffectedGlobalFsa;

	@Schema(types = {"object","null"})
	private FSAMappingTypes fsaTypes;
}
