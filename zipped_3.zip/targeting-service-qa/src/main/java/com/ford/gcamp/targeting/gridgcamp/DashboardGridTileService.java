package com.ford.gcamp.targeting.gridgcamp;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Optional;

import org.apache.commons.lang3.StringUtils;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.Predicate;
import jakarta.persistence.criteria.Root;
import jakarta.persistence.criteria.Subquery;

import com.ford.gcamp.targeting.common.CommonConstants;
import com.ford.gcamp.targeting.gridgcamp.api.DashboardGridCount;
import com.ford.gcamp.targeting.gridgcamp.api.DashboardGridTile;
import com.ford.gcamp.targeting.gridgcamp.api.DashboardGridTileCountResponse;
import com.ford.gcamp.targeting.gridgcamp.api.DashboardGridTileRequest;
import com.ford.gcamp.targeting.gridgcamp.api.DashboardGridTileResponse;
import com.ford.gcamp.targeting.gridgcamp.gcamp.FSARepository;
import com.ford.gcamp.targeting.gridgcamp.gcamp.GridGCampEntityMapper;
import com.ford.gcamp.targeting.gridgcamp.gcamp.GridGCampRepository;
import com.ford.gcamp.targeting.gridgcamp.gcamp.GridGCampVernInfoService;
import com.ford.gcamp.targeting.gridgcamp.gcamp.api.VinAttachment;
import com.ford.gcamp.targeting.gridgcamp.gcamp.entity.FSAData;
import com.ford.gcamp.targeting.gridgcamp.gcamp.entity.GridVernData;
import com.ford.gcamp.targeting.gridgcamp.grid.LocalFSARepository;
import com.ford.gcamp.targeting.gridgcamp.grid.entity.LocalFSADetail;
import com.ford.gcamp.targeting.gridgcamp.grid.entity.LocalFSAId;
import com.nimbusds.oauth2.sdk.util.CollectionUtils;

@Service
public class DashboardGridTileService {

	private static final String INITIATING_HUB = "initiatingHub";
	private static final String GLOBAL_FSA_NUMBER = "globalFSANumber";
	private static final String SUPPLEMENT_ID = "supplementId";
	private static final String GRID_VERN_ID = "gridVernId";
	private GridGCampRepository gridGcampRepository;
	private GridGCampVernInfoService serviceHelper;
	private GridGCampEntityMapper gridGCampEntityMapper;
	private LocalFSARepository localFSARepository;
	private FSARepository fsaRepository;

	public DashboardGridTileService(GridGCampRepository gridGcampRepository, GridGCampVernInfoService serviceHelper,
			GridGCampEntityMapper gridGCampEntityMapper, LocalFSARepository localFSARepository,
			FSARepository fsaRepository) {
		super();
		this.gridGcampRepository = gridGcampRepository;
		this.serviceHelper = serviceHelper;
		this.gridGCampEntityMapper = gridGCampEntityMapper;
		this.localFSARepository = localFSARepository;
		this.fsaRepository = fsaRepository;
	}

	public DashboardGridTileCountResponse getUnAssignedGridVernInfoCount(
			DashboardGridTileRequest dashboardGridTileRequest) {
		DashboardGridTileCountResponse gridTileCountResponse = new DashboardGridTileCountResponse();
		long newVernCount = gridGcampRepository.count(
				addDashboardFilters(dashboardGridTileRequest, GridGCampConstants.DASHBOARD_GRID_TILE_NEW_VERN_REMARKS));
		long newOriginalVernVersionCount = gridGcampRepository.count(addDashboardFilters(dashboardGridTileRequest,
				GridGCampConstants.DASHBOARD_GRID_TILE_NEW_ORIG_VERN_REMARKS));
		long newSupplementVernVersionCount = gridGcampRepository.count(addDashboardFilters(dashboardGridTileRequest,
				GridGCampConstants.DASHBOARD_GRID_TILE_NEW_SUPPL_VERN_REMARKS));
		DashboardGridCount dashboardGridCount = new DashboardGridCount();
		dashboardGridCount.setCode("R07");
		dashboardGridCount.setDescription("GRID");
		dashboardGridCount.setCount(newVernCount + newOriginalVernVersionCount + newSupplementVernVersionCount);
		gridTileCountResponse.setDashboardGridCount(dashboardGridCount);
		gridTileCountResponse.setStatus(CommonConstants.SUCCESS);
		gridTileCountResponse.setStatusCode(CommonConstants.SUCCESS_CODE);
		gridTileCountResponse.setStatusDescription(CommonConstants.SUCCESS_DESCRIPTION);
		return gridTileCountResponse;
	}

	public DashboardGridTileResponse getUnAssignedGridVernInfo(DashboardGridTileRequest dashboardGridTileRequest) {
		List<DashboardGridTile> gridUnAssignedVerns = new ArrayList<>();
		DashboardGridTileResponse gridTileResponse = new DashboardGridTileResponse();
		List<GridVernData> newVerns = gridGcampRepository.findAll(
				addDashboardFilters(dashboardGridTileRequest, GridGCampConstants.DASHBOARD_GRID_TILE_NEW_VERN_REMARKS));
		setGridTileDetails(newVerns, gridUnAssignedVerns, GridGCampConstants.DASHBOARD_GRID_TILE_NEW_VERN_REMARKS);

		List<GridVernData> newOriginalVernVersions = gridGcampRepository.findAll(addDashboardFilters(
				dashboardGridTileRequest, GridGCampConstants.DASHBOARD_GRID_TILE_NEW_ORIG_VERN_REMARKS));
		setGridTileDetails(newOriginalVernVersions, gridUnAssignedVerns,
				GridGCampConstants.DASHBOARD_GRID_TILE_NEW_ORIG_VERN_REMARKS);

		List<GridVernData> newSupplementVernVersions = gridGcampRepository.findAll(addDashboardFilters(
				dashboardGridTileRequest, GridGCampConstants.DASHBOARD_GRID_TILE_NEW_SUPPL_VERN_REMARKS));
		setGridTileDetails(newSupplementVernVersions, gridUnAssignedVerns,
				GridGCampConstants.DASHBOARD_GRID_TILE_NEW_SUPPL_VERN_REMARKS);

		gridTileResponse.setGridUnAssignedVerns(gridUnAssignedVerns);
		gridTileResponse.setStatus(CommonConstants.SUCCESS);
		gridTileResponse.setStatusCode(CommonConstants.SUCCESS_CODE);
		gridTileResponse.setStatusDescription(CommonConstants.SUCCESS_DESCRIPTION);
		return gridTileResponse;
	}

	private void setGridTileDetails(List<GridVernData> unAssignedVerns, List<DashboardGridTile> gridUnAssignedVerns,
			String remarks) {
		if (CollectionUtils.isNotEmpty(unAssignedVerns)) {
			unAssignedVerns.stream().forEach(vernInfo -> {
				String lastUpdateBy = GridGCampConstants.DASHBOARD_GRID_TILE_NEW_VERN_REMARKS.equalsIgnoreCase(remarks)
						? vernInfo.getUpdateId()
						: getLastActionBy(vernInfo);
				List<VinAttachment> vinAttachment = gridGCampEntityMapper
						.convertStringToVinAttachments(vernInfo.getVinListFileDetails());
				DashboardGridTile dashboardGridTile = DashboardGridTile.builder().vernNumber(vernInfo.getVernNumber())
						.globalFsaNumber(vernInfo.getGlobalFSANumber() == 0 ? StringUtils.EMPTY
								: String.valueOf(vernInfo.getGlobalFSANumber()))
						.population(vernInfo.getGlobalFSANumber() == 0 ? StringUtils.EMPTY
								: vernInfo.getGridVernId().getSupplementId()).remarks(remarks)
						.lastActionBy(StringUtils.trimToEmpty(lastUpdateBy)).vinAttachment(vinAttachment).build();
				setLocalFSADetails(vernInfo, dashboardGridTile);
				gridUnAssignedVerns.add(dashboardGridTile);
			});
		}
	}

	private String getLastActionBy(GridVernData vernInfo) {
		Optional<FSAData> fsaData = fsaRepository.findById(vernInfo.getGlobalFSANumber());
		return fsaData.isPresent() ? fsaData.get().getUpdateId() : StringUtils.EMPTY;
	}

	private void setLocalFSADetails(GridVernData vernInfo, DashboardGridTile dashboardGridTile) {
		LocalFSAId localFsaId = new LocalFSAId();
		localFsaId.setGlobalFSANumber(vernInfo.getGlobalFSANumber());
		localFsaId.setHubCode(vernInfo.getInitiatingHub());
		Optional<LocalFSADetail> localFSA = localFSARepository.findById(localFsaId);
		if (localFSA.isPresent()) {
			dashboardGridTile.setLocalFsaNumber(StringUtils.trimToEmpty(localFSA.get().getLocalFSANumber()));
			dashboardGridTile.setLocalFsaDescription(StringUtils.trimToEmpty(localFSA.get().getLocalFSADescription()));
		} else {
			dashboardGridTile.setLocalFsaNumber(StringUtils.EMPTY);
			dashboardGridTile.setLocalFsaDescription(StringUtils.EMPTY);
		}

	}

	private Specification<GridVernData> addDashboardFilters(DashboardGridTileRequest dashboardTileRequest,
			String remarks) {
		return (root, query, criteriaBuilder) -> {
			List<Predicate> predicates = new LinkedList<>();

			// match hubCode
			predicates.add(criteriaBuilder.in(root.get(INITIATING_HUB))
					.value(serviceHelper.getHub(dashboardTileRequest.getUserHubCode())));
			// match Request Status
			predicates.add(criteriaBuilder.equal(root.get("fsaAssignedFlag"), CommonConstants.FLAG_N));

			if (GridGCampConstants.DASHBOARD_GRID_TILE_NEW_SUPPL_VERN_REMARKS.equalsIgnoreCase(remarks)) {
				predicates.add(criteriaBuilder.notEqual(root.get(GRID_VERN_ID).get(SUPPLEMENT_ID),
						CommonConstants.DOUBLE_ZEROS));
			} else {
				predicates.add(
						criteriaBuilder.equal(root.get(GRID_VERN_ID).get(SUPPLEMENT_ID), CommonConstants.DOUBLE_ZEROS));
			}

			// match VERN Submitted From and To Date
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MMM-yyyy");
			String vernSubmittedDate = "vernSubmittedDate";
			if (StringUtils.isNotBlank(dashboardTileRequest.getVernSubmittedFromDate())
					&& StringUtils.isNotBlank(dashboardTileRequest.getVernSubmittedToDate())) {
				LocalDate fromDate = LocalDate.parse(dashboardTileRequest.getVernSubmittedFromDate(), formatter);
				LocalDate toDate = LocalDate.parse(dashboardTileRequest.getVernSubmittedToDate(), formatter);
				predicates.add(criteriaBuilder.between(root.<LocalDate>get(vernSubmittedDate).as(LocalDate.class),
						fromDate, toDate));
			} else if (StringUtils.isNotBlank(dashboardTileRequest.getVernSubmittedFromDate())) {
				LocalDate fromDate = LocalDate.parse(dashboardTileRequest.getVernSubmittedFromDate(), formatter);
				predicates.add(criteriaBuilder
						.greaterThanOrEqualTo(root.<LocalDate>get(vernSubmittedDate).as(LocalDate.class), fromDate));
			} else if (StringUtils.isNotBlank(dashboardTileRequest.getVernSubmittedToDate())) {
				LocalDate toDate = LocalDate.parse(dashboardTileRequest.getVernSubmittedToDate(), formatter);
				predicates.add(criteriaBuilder
						.lessThanOrEqualTo(root.<LocalDate>get(vernSubmittedDate).as(LocalDate.class), toDate));
			}

			Subquery<Number> versionSubQuery = query.subquery(Number.class);

			Root<GridVernData> vernInfoRoot = versionSubQuery.from(GridVernData.class);

			versionSubQuery.select(criteriaBuilder.max(vernInfoRoot.get(GRID_VERN_ID).get("version")));
			if (GridGCampConstants.DASHBOARD_GRID_TILE_NEW_VERN_REMARKS.equalsIgnoreCase(remarks)) {
				predicates.add(criteriaBuilder.equal(root.get(GLOBAL_FSA_NUMBER), 0));
				newVernSubQuery(root, criteriaBuilder, versionSubQuery, vernInfoRoot);
			} else {
				predicates.add(criteriaBuilder.notEqual(root.get(GLOBAL_FSA_NUMBER), 0));
				newVernVersionSubQuery(root, criteriaBuilder, versionSubQuery, vernInfoRoot);
			}

			predicates.add(criteriaBuilder.equal(root.get(GRID_VERN_ID).get("version"), versionSubQuery));

			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));

		};
	}

	private void newVernSubQuery(Root<GridVernData> root, CriteriaBuilder criteriaBuilder,
			Subquery<Number> versionSubQuery, Root<GridVernData> vernInfoRoot) {
		versionSubQuery.where(
				criteriaBuilder.equal(root.get(GRID_VERN_ID).get("gridYearId"),
						vernInfoRoot.get(GRID_VERN_ID).get("gridYearId")),
				criteriaBuilder.equal(root.get(GRID_VERN_ID).get("gridSequence"),
						vernInfoRoot.get(GRID_VERN_ID).get("gridSequence")),
				criteriaBuilder.equal(root.get(GRID_VERN_ID).get("implementationId"),
						vernInfoRoot.get(GRID_VERN_ID).get("implementationId")));
	}

	private void newVernVersionSubQuery(Root<GridVernData> root, CriteriaBuilder criteriaBuilder,
			Subquery<Number> versionSubQuery, Root<GridVernData> vernInfoRoot) {
		versionSubQuery.where(criteriaBuilder.equal(root.get(INITIATING_HUB), vernInfoRoot.get(INITIATING_HUB)),
				criteriaBuilder.equal(root.get(GLOBAL_FSA_NUMBER), vernInfoRoot.get(GLOBAL_FSA_NUMBER)),
				criteriaBuilder.equal(root.get(GRID_VERN_ID).get(SUPPLEMENT_ID),
						vernInfoRoot.get(GRID_VERN_ID).get(SUPPLEMENT_ID)));
	}

}
