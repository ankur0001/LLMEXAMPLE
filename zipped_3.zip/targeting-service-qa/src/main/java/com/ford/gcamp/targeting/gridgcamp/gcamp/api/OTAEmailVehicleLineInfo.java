package com.ford.gcamp.targeting.gridgcamp.gcamp.api;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Builder
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class OTAEmailVehicleLineInfo {

	private String vehicleLine;
	private String modelYears;
	private String brands;
	private String previousOTAFlag;
	private String updatedOTAFlag;
}
