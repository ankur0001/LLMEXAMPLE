package com.ford.gcamp.targeting.properties;

import java.util.Map;

import org.springframework.boot.context.properties.ConfigurationProperties;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@ConfigurationProperties(prefix = "segmentation.segbypercent.aps")
@Getter
@Setter
@NoArgsConstructor
public class SegmentByPercentApsAccess {

	private String pageName;
	private Map<String, String> resources;
}
