package com.ford.gcamp.targeting.config;

import lombok.AllArgsConstructor;
import lombok.Getter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.transaction.PlatformTransactionManager;

import java.util.TimeZone;
@AllArgsConstructor
@Getter
public class ConfigurationParams {
    private final JdbcTemplate jdbcTemplate;
    private final PlatformTransactionManager transactionManager;
    private final String tableName;
    private final TimeZone timeZone;
    private final String columnName;
    private final String columnLockUntil;
    private final String columnLockedAt;
    private final String columnLockedBy;
    public PlatformTransactionManager getTransactionManager() {
        return transactionManager;
    }

    public String getTableName() {
        return tableName;
    }

    public TimeZone getTimeZone() {
        return timeZone;
    }

    public String getColumnName() {
        return columnName;
    }

    public String getColumnLockUntil() {
        return columnLockUntil;
    }

    public String getColumnLockedAt() {
        return columnLockedAt;
    }

    public String getColumnLockedBy() {
        return columnLockedBy;
    }
}
