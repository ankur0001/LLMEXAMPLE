package com.ford.gcamp.targeting.core.exception;


import org.springframework.http.HttpStatus;

import com.ford.gcamp.targeting.common.CommonConstants;
import com.ford.gcamp.targeting.common.api.CommonErrorResponse;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class GCAMPException extends Exception {

	private static final long serialVersionUID = -8720789619363341078L;

	private final CommonErrorResponse responseStatus;
	
	/**
	 * Constructor for GCampException
	 */
	public GCAMPException() {
		super();
		responseStatus = new CommonErrorResponse(CommonConstants.FAILURE, CommonConstants.FAILURE_CODE,
				CommonConstants.FAILURE_DESC);
	}
	
	/**
	 * Constructor for GCampException
	 */
	public GCAMPException(Throwable rootCause) {
		super(rootCause);
		log.error("Error in processing", rootCause);
		responseStatus = new CommonErrorResponse(CommonConstants.FAILURE, CommonConstants.FAILURE_CODE,
				CommonConstants.FAILURE_DESC);
	}

	public GCAMPException(String errorDescription) {
		super(errorDescription);
		responseStatus = new CommonErrorResponse(CommonConstants.FAILURE, HttpStatus.PRECONDITION_FAILED.toString(),
				errorDescription);
	}
	
	/**
	 * Constructor for GCampException
	 */
	public GCAMPException(String msg, Throwable rootCause) {
		super(msg, rootCause);
		log.error(msg, rootCause);
		responseStatus = new CommonErrorResponse(CommonConstants.FAILURE,  HttpStatus.PRECONDITION_FAILED.toString(), msg);
	}
	
	public GCAMPException(int errorCode, String errorDescription) {
		super(errorDescription);
		responseStatus = new CommonErrorResponse(CommonConstants.FAILURE, String.valueOf(errorCode), errorDescription);
	}

	public GCAMPException(int errorCode, String errorStatus, String errorDescription) {
		super(errorDescription);
		responseStatus = new CommonErrorResponse(errorStatus, String.valueOf(errorCode), errorDescription);
	}

	public CommonErrorResponse getResponseStatus() {
		return responseStatus;
	}

}
