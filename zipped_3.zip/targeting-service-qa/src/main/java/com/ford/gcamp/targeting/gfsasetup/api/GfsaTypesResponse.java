package com.ford.gcamp.targeting.gfsasetup.api;

import com.ford.gcamp.targeting.common.api.ResponseStatusDTO;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.util.List;

@EqualsAndHashCode(callSuper = false)
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class GfsaTypesResponse extends ResponseStatusDTO {
	@Size(min = 0, max = 250, message = "gfsaTypes")
	private List<@Valid GfsaType> gfsaTypes;
}
