package com.ford.gcamp.targeting.fsacriteria;

import com.ford.gcamp.targeting.common.CommonConstants;
import com.ford.gcamp.targeting.common.TargetingUtil;
import com.ford.gcamp.targeting.common.api.ResponseStatusDTO;
import com.ford.gcamp.targeting.core.exception.ResourceNotFoundException;
import com.ford.gcamp.targeting.fsacriteria.api.*;
import com.ford.gcamp.targeting.gfsasetup.GlobalFSASetupService;
import com.ford.gcamp.targeting.logging.LogExecutionTime;
import com.ford.gcamp.targeting.properties.ConfigProperties;
import com.ford.gcamp.targeting.properties.FsaCriteriaConfiguration;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;

@Service
@Slf4j
public class FsaCriteriaServiceImpl implements FsaCriteriaService {

	private static final String IS_NULL_OPERATOR = "ISNULL";
	private static final String IS_NOTNULL_OPERATOR = "ISNOTNULL";
	private static final String GREATER_THAN_EQUAL_TO_OPERATOR = ">=";
	private static final String LESS_THAN_EQUAL_TO_OPERATOR = "<=";
	private static final String GREATER_THAN_OPERATOR = ">";
	private static final String LESS_THAN_OPERATOR = "<";
	private static final String NOT_EQUAL_TO_OPERATOR = "!=";

	@Autowired
	private FsaCriteriaDAO fsaCriteriaDAO;
	
	@Autowired
	private FsaCriteriaConfiguration fsaCriteriaConfiguration;
	
	@Autowired
	private AddModifyCriteriaService addModifyCriteriaService;
	
	@Autowired
	private FsaCriteriaFilterService fsaCriteriaFilterService;

	@Autowired
	private FSACriteriaRegionalFilterService fsaCriteriaRegionalFilterService;

	@Autowired
	private ConfigProperties configProperties;

	@Autowired
	@Lazy
	private GlobalFSASetupService globalFsaSetupService;


	@Override
	public FsaCriteriaEditVO modify(FsaCriteriaParam criteriaParam) {
		String param1 = getFsaParam1ForModifySave(criteriaParam, fsaCriteriaConfiguration.getModifyActionFlag());
		String param2 = TargetingUtil.fillRemainingString(29700, " ");
		Map<String, Object> response = fsaCriteriaDAO.modify(param1, param2);
		FsaCriteriaResponse criteriaResponse = new FsaCriteriaResponse();
		String outputParam1 = (String) response.get("OUTPUT_PARM1");
		String outputParam2 = (String) response.get("OUTPUT_PARM2");
		criteriaResponse.setOutputParam1(Arrays.asList(outputParam1.split("\\|")));
		criteriaResponse.setOutputParam2(Arrays.asList(outputParam2.split("\\|")));
		criteriaResponse.setOutputParam3((String) response.get("OUTPUT_PARM3"));
		criteriaResponse.setErrorParam1((String) response.get("ERROR_PARM1"));
		criteriaResponse.setErrorParam2((String) response.get("ERROR_PARM2"));

		return setFsaModifyVO(criteriaResponse);
	}

	@Override
	@Transactional("jpaDb2TransactionManager")
	public FsaCriteriaEditVO saveFsaCriteria(FsaCriteriaSaveParam fsaCriteriaModifySaveParam) throws ResourceNotFoundException {

		log.info("Request for save criteria : {}", fsaCriteriaModifySaveParam);

		if (validateTotalCriteriaParamCount(fsaCriteriaModifySaveParam)) {
			FsaCriteriaEditVO criteriaEditVO = new FsaCriteriaEditVO();
			criteriaEditVO.setStatusCode("412");
			criteriaEditVO.setStatusDesc("Number of Attributes cannot be greater than 199");
			return criteriaEditVO;
		}
		FsaVinCriteriaRequest fsaVinCriteriaRequest = FsaVinCriteriaRequest.builder()
				.criteriaFlag(true)
				.fsaCriteriaRequestList(Collections.singletonList(fsaCriteriaModifySaveParam))
				.build();
		return globalFsaSetupService.saveFsaCriteriaInFsa(fsaVinCriteriaRequest);
	}


	@Override
	public DynamicQueryResponse getFsaBrandModelVehPlant(DynamicQueryMappingReq dynamicMappingRequest)  {
		DynamicQueryResponse dynamicQueryResponse;
		setRequestForAllOption(dynamicMappingRequest);
		if(validateNoInput(dynamicMappingRequest)) {
			LoadFsaResponseDTO loadFsaResponseDTO = addModifyCriteriaService.getFscFormDetails();
			dynamicQueryResponse = new DynamicQueryResponse();
			dynamicQueryResponse.setModelYear(loadFsaResponseDTO.getModelYear());
			dynamicQueryResponse.setVehicleBrandLists(loadFsaResponseDTO.getVehicleBrandLists());
			dynamicQueryResponse.setVehicleTypeList(loadFsaResponseDTO.getVehicleTypeList());
			dynamicQueryResponse.setAssemblyPlantList(loadFsaResponseDTO.getAssemblyPlantList());
			dynamicQueryResponse.setGcpFilterList(loadFsaResponseDTO.getGcpFilterList());
			dynamicQueryResponse.setAttributeGroupingLists(loadFsaResponseDTO.getAttributeGroupingLists());
		} else {
			List<FsaFilterCriteriaResponse> fsaCriteriaResponse = fsaCriteriaFilterService.getFsaBrandModelVehLinePlant();
			if(StringUtils.isNotBlank(dynamicMappingRequest.getModelYear())) {
				performModelYearOperatorFiltering(fsaCriteriaResponse,dynamicMappingRequest);
				log.info("Filtered Model Years {} for modelOperator {} ",dynamicMappingRequest.getModelYear(), dynamicMappingRequest.getModelYearOperator());
			}
			List<FsaFilterCriteriaResponse> filteredRecords = getFiltertedFsaCriteriaRecords(fsaCriteriaResponse, dynamicMappingRequest);
			getVehlineModelBrandPlant(dynamicMappingRequest, filteredRecords);
			dynamicQueryResponse = getDynamicFilterList(filteredRecords);
		}
		
		return dynamicQueryResponse;
	}
	
	private void performModelYearOperatorFiltering(
			List<FsaFilterCriteriaResponse> fsaCriteriaResponse, DynamicQueryMappingReq dynamicMappingRequest) {
		Set<String> uniqueModelYears = fsaCriteriaResponse.stream().map(FsaFilterCriteriaResponse::getModelCode).collect(Collectors.toSet());
		switch (dynamicMappingRequest.getModelYearOperator()) {
		case GREATER_THAN_EQUAL_TO_OPERATOR:
			dynamicMappingRequest.setModelYear(uniqueModelYears.stream().filter(
					modelYear -> Integer.parseInt(modelYear.trim()) >= Integer.parseInt(dynamicMappingRequest.getModelYear()))
					.collect(Collectors.joining(",")));
			break;
		case LESS_THAN_EQUAL_TO_OPERATOR:
			dynamicMappingRequest.setModelYear(uniqueModelYears.stream().filter(
					modelYear -> Integer.parseInt(modelYear.trim()) <= Integer.parseInt(dynamicMappingRequest.getModelYear()))
					.collect(Collectors.joining(",")));
			break;
		case GREATER_THAN_OPERATOR:
			dynamicMappingRequest.setModelYear(uniqueModelYears.stream().filter(
					modelYear -> Integer.parseInt(modelYear.trim()) > Integer.parseInt(dynamicMappingRequest.getModelYear()))
					.collect(Collectors.joining(",")));
			break;
		case LESS_THAN_OPERATOR:
			dynamicMappingRequest.setModelYear(uniqueModelYears.stream().filter(
					modelYear -> Integer.parseInt(modelYear.trim()) < Integer.parseInt(dynamicMappingRequest.getModelYear()))
					.collect(Collectors.joining(",")));
			break;
		case NOT_EQUAL_TO_OPERATOR:
			List<String> modelYears = getListFromString(dynamicMappingRequest.getModelYear());
			List<Integer> modelYearsInt = modelYears.stream()
                    .map(Integer::parseInt).collect(Collectors.toList());
			dynamicMappingRequest.setModelYear(uniqueModelYears.stream().filter(
					modelYear -> !modelYearsInt.contains(Integer.parseInt(modelYear.trim())))
					.collect(Collectors.joining(",")));
			break;
		default:
			break;
		}
	}
	
	
	@Override
	public ResponseStatusDTO validateAssemblyPlantSelect(DynamicQueryMappingReq dynamicMappingRequest) {
		String plant = dynamicMappingRequest.getAssemblyPlant();
		String vehline = dynamicMappingRequest.getVehicleLine();
		ResponseStatusDTO responseStatusDTO = new ResponseStatusDTO();
		
		if(StringUtils.isNotBlank(plant) && StringUtils.isNotBlank(vehline)) {
			List<String> vehLines = getListFromString(vehline);
			List<FsaFilterCriteriaResponse> fsaCriteriaResponse =  fsaCriteriaDAO.getFsaModelBrandVehLinePlant(dynamicMappingRequest);
			log.info("fsaCriteriaResponse {}",fsaCriteriaResponse);
			Set<String> resultantVehlineCodes = fsaCriteriaResponse.stream().map(FsaFilterCriteriaResponse::getVehLine).collect(Collectors.toSet());
			if(!CollectionUtils.containsAll(resultantVehlineCodes, vehLines)) {
				responseStatusDTO.setStatusCode("412");
				responseStatusDTO.setStatusDescription("You have not selected all the available assembly plant for the selected Vehicle Line(s).Are you sure you want to continue?");
			} else {
				responseStatusDTO.setStatusCode("200");
				responseStatusDTO.setStatusDescription("Combination of vehline & assembly valid.");
			}
		} else {
			responseStatusDTO.setStatusCode("200");
			responseStatusDTO.setStatusDescription("Combination of vehline & assembly not selected.");
		}
		
		return responseStatusDTO;
	}
	
	
	private List<FsaFilterCriteriaResponse> getFiltertedFsaCriteriaRecords(List<FsaFilterCriteriaResponse> fsaCriteriaResponse, DynamicQueryMappingReq dynamicMappingRequest) {
		List<String> models = getListFromString(dynamicMappingRequest.getModelYear());
		List<String> brands = getListFromString(dynamicMappingRequest.getBrand());
		List<String> vehLines = getListFromString(dynamicMappingRequest.getVehicleLine());
		List<String> plants = getListFromString(dynamicMappingRequest.getAssemblyPlant());
		List<FsaFilterCriteriaResponse> filteredRecords;
		if(CollectionUtils.isNotEmpty(models)) {
			filteredRecords = processFsaCriteriaOnModel(models, brands, vehLines, plants, fsaCriteriaResponse);
		} else if(CollectionUtils.isNotEmpty(brands)) {
			filteredRecords = processFsaCriteriaOnBrand(brands, vehLines, plants, fsaCriteriaResponse);
		} else if(CollectionUtils.isNotEmpty(vehLines)) {
			if(CollectionUtils.isNotEmpty(plants)) {
				filteredRecords = fsaCriteriaResponse.stream()
						.filter(criteria -> vehLines.contains(criteria.getVehLine())
								&& plants.contains(criteria.getPlant()))
						.collect(Collectors.toList());
			} else {
				filteredRecords = fsaCriteriaResponse.stream()
						.filter(criteria -> vehLines.contains(criteria.getVehLine()))
						.collect(Collectors.toList());
			} 
		} else if(CollectionUtils.isNotEmpty(plants)) {
			filteredRecords = fsaCriteriaResponse.stream()
					.filter(criteria -> plants.contains(criteria.getPlant()))
					.collect(Collectors.toList());
		} else {
			filteredRecords = fsaCriteriaResponse;
		}
		return filteredRecords;
		
	}
	
	private List<FsaFilterCriteriaResponse> processFsaCriteriaOnBrand(List<String> brands,List<String> vehLines,List<String> plants, 
			List<FsaFilterCriteriaResponse> fsaCriteriaResponse) {
		List<FsaFilterCriteriaResponse> filteredRecords = null;
		if(CollectionUtils.isNotEmpty(vehLines)) {
			if(CollectionUtils.isNotEmpty(plants)) {
				filteredRecords = fsaCriteriaResponse.stream()
						.filter(criteria -> brands.contains(criteria.getBrandDesc().trim())
								&& vehLines.contains(criteria.getVehLine())
								&& plants.contains(criteria.getPlant()))
						.collect(Collectors.toList());
			} else {
				filteredRecords = fsaCriteriaResponse.stream()
						.filter(criteria -> brands.contains(criteria.getBrandDesc().trim())
								&& vehLines.contains(criteria.getVehLine()))
						.collect(Collectors.toList());
			}
		} else {
			if(CollectionUtils.isNotEmpty(plants)) {
				filteredRecords = fsaCriteriaResponse.stream()
						.filter(criteria -> brands.contains(criteria.getBrandDesc().trim())
								&& plants.contains(criteria.getPlant()))
						.collect(Collectors.toList());
			} else {
				filteredRecords = fsaCriteriaResponse.stream()
						.filter(criteria -> brands.contains(criteria.getBrandDesc().trim()))
						.collect(Collectors.toList());
			}
		}
		return filteredRecords;
	}
	
	private List<FsaFilterCriteriaResponse> processFsaCriteriaOnModel(List<String> models,List<String> brands,List<String> vehLines,List<String> plants, 
			List<FsaFilterCriteriaResponse> fsaCriteriaResponse) {
		List<FsaFilterCriteriaResponse> filteredRecords = null;
		if(CollectionUtils.isNotEmpty(brands)) {
			filteredRecords = processFsaCriteriaOnModelBrand(models, brands, vehLines, plants, fsaCriteriaResponse);
		} else {
			filteredRecords = processFsaCriteriaOnModelVehLine(models, vehLines, plants, fsaCriteriaResponse);
		}
		return filteredRecords;
	}
	
	private List<FsaFilterCriteriaResponse> processFsaCriteriaOnModelBrand(List<String> models,List<String> brands,List<String> vehLines,List<String> plants, 
			List<FsaFilterCriteriaResponse> fsaCriteriaResponse) {
		List<FsaFilterCriteriaResponse> filteredRecords = null;
		if(CollectionUtils.isNotEmpty(vehLines)) {
			if (CollectionUtils.isNotEmpty(plants)) {
				filteredRecords = fsaCriteriaResponse.stream()
						.filter(criteria -> models.contains(criteria.getModelCode())
								&& brands.contains(criteria.getBrandDesc().trim())
								&& vehLines.contains(criteria.getVehLine())
								&& plants.contains(criteria.getPlant()))
						.collect(Collectors.toList());
			} else {
				filteredRecords = fsaCriteriaResponse.stream()
						.filter(criteria -> models.contains(criteria.getModelCode())
								&& brands.contains(criteria.getBrandDesc().trim())
								&& vehLines.contains(criteria.getVehLine()))
						.collect(Collectors.toList());
			}
		} else {
			if(CollectionUtils.isNotEmpty(plants)) {
				filteredRecords = fsaCriteriaResponse.stream()
						.filter(criteria -> models.contains(criteria.getModelCode())
								&& brands.contains(criteria.getBrandDesc().trim())
								&& plants.contains(criteria.getPlant()))
						.collect(Collectors.toList());
			} else {
				filteredRecords = fsaCriteriaResponse.stream()
						.filter(criteria -> models.contains(criteria.getModelCode())
								&& brands.contains(criteria.getBrandDesc().trim()))
						.collect(Collectors.toList());
			}
		}
		return filteredRecords;
	}
	
	private List<FsaFilterCriteriaResponse> processFsaCriteriaOnModelVehLine(List<String> models,List<String> vehLines,List<String> plants, 
			List<FsaFilterCriteriaResponse> fsaCriteriaResponse) {
		List<FsaFilterCriteriaResponse> filteredRecords = null;
		if(CollectionUtils.isNotEmpty(vehLines)) {
			if(CollectionUtils.isNotEmpty(plants)) {
				filteredRecords = fsaCriteriaResponse.stream()
						.filter(criteria -> models.contains(criteria.getModelCode())
								&& vehLines.contains(criteria.getVehLine())
								&& plants.contains(criteria.getPlant()))
						.collect(Collectors.toList());
			} else {
				filteredRecords = fsaCriteriaResponse.stream()
						.filter(criteria -> models.contains(criteria.getModelCode())
								&& vehLines.contains(criteria.getVehLine()))
						.collect(Collectors.toList());
			}
		} else {
			if(CollectionUtils.isNotEmpty(plants)) {
				filteredRecords = fsaCriteriaResponse.stream()
						.filter(criteria -> models.contains(criteria.getModelCode())
								&& plants.contains(criteria.getPlant()))
						.collect(Collectors.toList());
			} else {
				filteredRecords = fsaCriteriaResponse.stream()
						.filter(criteria -> models.contains(criteria.getModelCode()))
						.collect(Collectors.toList());
			}
		}
		return filteredRecords;
	}
	
	
	private List<String> getListFromString(String value){
		if(StringUtils.isNotBlank(value)) {
			return Arrays.asList(value.split(","));
		}else {
			return new ArrayList<>();
		}
	}
	
	@Override
	public DynamicQueryResponse getFsaWersWersValue(DynamicQueryMappingReq dynamicMappingRequest)  {
		DynamicQueryResponse dynamicQueryResponse = null;
		List<FsaFilterCriteriaResponse> fsaCriteriaResponse = fsaCriteriaFilterService.getAllWersDetails();
		List<FsaFilterCriteriaResponse> filteredRecords = getFsaCriteriaForWersValue(dynamicMappingRequest, fsaCriteriaResponse);
		
		getVehlineModelBrandPlant(dynamicMappingRequest, filteredRecords);
		dynamicQueryResponse = getDynamicFilterList(filteredRecords);
		return dynamicQueryResponse;
	}
	
	
	private List<FsaFilterCriteriaResponse> getFsaCriteriaForWersValue(DynamicQueryMappingReq dynamicMappingRequest, List<FsaFilterCriteriaResponse> fsaCriteriaResponse) {
		String wersCode = dynamicMappingRequest.getWers();
		List<String> wersValue = getListFromString(dynamicMappingRequest.getWersValue());
		List<FsaFilterCriteriaResponse> filteredRecords;
		List<String> relatedIds;
		Set<String> uniqueRelatedIds = new HashSet<>();
		List<FsaFilterCriteriaResponse> fsaNonWersCriteriaResponse = fsaCriteriaFilterService.getFsaBrandModelVehLinePlant();
		if(StringUtils.isNotBlank(dynamicMappingRequest.getModelYear())) {
			performModelYearOperatorFiltering(fsaNonWersCriteriaResponse,dynamicMappingRequest);
		}
		List<FsaFilterCriteriaResponse> filteredFsaNonWersRecords = getFiltertedFsaCriteriaRecords(fsaNonWersCriteriaResponse, dynamicMappingRequest);
		List<String> uniqueRowIds = filteredFsaNonWersRecords.stream().map(FsaFilterCriteriaResponse::getId).map(String::valueOf).collect(Collectors.toList());
		
		List<FsaFilterCriteriaResponse> fsaCriteriaFilteredWers = new ArrayList<>();
		if(validateNoNonWersInput(dynamicMappingRequest)) {
			fsaCriteriaFilteredWers = fsaCriteriaResponse;
		} else {
			for (FsaFilterCriteriaResponse criteria : fsaCriteriaResponse) {
				String relatedId = criteria.getRelatedId().trim();
				List<String> uniqueRelatedIdsInt = Arrays.asList(relatedId.split(","));
				if(CollectionUtils.containsAny(uniqueRelatedIdsInt, uniqueRowIds)) {
					fsaCriteriaFilteredWers.add(criteria);
				}
			}
		}
		
		if(CollectionUtils.isNotEmpty(wersValue)) {
			relatedIds = fsaCriteriaFilteredWers.stream()
					.filter(criteria -> wersValue.contains(criteria.getWersValue()) && StringUtils.isNotEmpty(wersCode)
							&& criteria.getWersCode() == Integer.valueOf(wersCode.trim()))
					.map(FsaFilterCriteriaResponse::getRelatedId).map(String::trim).collect(Collectors.toList());
		} else {
			relatedIds = fsaCriteriaFilteredWers.stream()
					.filter(criteria -> criteria.getWersCode() == Integer.valueOf(wersCode.trim()))
					.map(FsaFilterCriteriaResponse::getRelatedId).map(String::trim).collect(Collectors.toList());
		}
		
		relatedIds.stream().forEach(relatedId-> uniqueRelatedIds.addAll(Arrays.asList(relatedId.split(","))));
		Set<Integer> uniqueRelatedIdsInt = uniqueRelatedIds.stream().map(Integer::parseInt).collect(Collectors.toSet());
		filteredRecords = filteredFsaNonWersRecords.stream().filter(criteria->uniqueRelatedIdsInt.contains(criteria.getId())).collect(Collectors.toList());
		List<FsaFilterCriteriaResponse> fsaCriteriaWersValue = fsaCriteriaFilteredWers.stream()
				.filter(criteria -> criteria.getWersCode() == Integer.valueOf(wersCode.trim()))
				.collect(Collectors.toList());
		List<FsaFilterCriteriaResponse> fsaCriteriaWers = fsaCriteriaFilteredWers.stream()
				.map(wersCriteria-> new FsaFilterCriteriaResponse(wersCriteria.getWersCode(),wersCriteria.getWersDesc(),wersCriteria.getWersValue()))
				.collect(Collectors.toList());
		filteredRecords.addAll(fsaCriteriaWersValue);
		filteredRecords.addAll(fsaCriteriaWers);
		return filteredRecords;
	}
	
	@Override
	@LogExecutionTime
	public DynamicQueryResponse getFsaWersDetail(DynamicQueryMappingReq dynamicMappingRequest) {
		DynamicQueryResponse dynamicQueryResponse = new DynamicQueryResponse();
		if(validateNoInput(dynamicMappingRequest)) {
			LoadFsaResponseDTO loadFsaResponseDTO = addModifyCriteriaService.getFscFormDetails();
			dynamicQueryResponse.setGcpFilterList(loadFsaResponseDTO.getGcpFilterList());
		} else {
			List<FsaFilterCriteriaResponse> fsaCriteriaNonWers = fsaCriteriaFilterService.getFsaBrandModelVehLinePlant();
			if(StringUtils.isNotBlank(dynamicMappingRequest.getModelYear())) {
				performModelYearOperatorFiltering(fsaCriteriaNonWers,dynamicMappingRequest);
			}
			List<FsaFilterCriteriaResponse> filteredRecords = getFiltertedFsaCriteriaRecords(fsaCriteriaNonWers, dynamicMappingRequest);
			List<String> uniqueRowIds = filteredRecords.stream().map(FsaFilterCriteriaResponse::getId).map(String::valueOf).collect(Collectors.toList());
			List<FsaFilterCriteriaResponse> fsaCriteriaWers = fsaCriteriaFilterService.getAllWersDetails();
			List<FsaFilterCriteriaResponse> fsaCriteriaFilteredWers = new ArrayList<>();
			fsaCriteriaWers.stream().forEach(criteria->{
				String relatedId = criteria.getRelatedId().trim();
				List<String> uniqueRelatedIdsInt = Arrays.asList(relatedId.split(","));
				if(CollectionUtils.containsAny(uniqueRelatedIdsInt, uniqueRowIds)) {
					fsaCriteriaFilteredWers.add(criteria);
				}
			});
			dynamicQueryResponse = getDynamicFilterList(fsaCriteriaFilteredWers);
			if(StringUtils.isBlank(dynamicMappingRequest.getWers())) {
				dynamicQueryResponse.setWersValue(new ArrayList<>());
			}
		}
		return dynamicQueryResponse;
	}
	
	public LoadFsaResponseDTO getFSACriteriaLookupData() {
		 return addModifyCriteriaService.getFscFormDetails();
	}

	
	private void setRequestForAllOption(DynamicQueryMappingReq dynamicMappingRequest) {
		if(StringUtils.equalsAnyIgnoreCase(dynamicMappingRequest.getModelYear(), "ALL")) {
			dynamicMappingRequest.setModelYear(StringUtils.EMPTY);
		}
		if(StringUtils.equalsAnyIgnoreCase(dynamicMappingRequest.getVehicleLine(), "ALL")) {
			dynamicMappingRequest.setVehicleLine(StringUtils.EMPTY);
		}
		if(StringUtils.equalsAnyIgnoreCase(dynamicMappingRequest.getBrand(), "ALL")) {
			dynamicMappingRequest.setBrand(StringUtils.EMPTY);
		}
	}
	
	private void getVehlineModelBrandPlant(DynamicQueryMappingReq dynamicMappingRequest,List<FsaFilterCriteriaResponse> fsaCriteriaResponse){
		List<FsaFilterCriteriaResponse> fsaCriteriaAllNonWers = fsaCriteriaFilterService.getFsaBrandModelVehLinePlant();
		List<String> modelYear = getListFromString(dynamicMappingRequest.getModelYear());
		List<String> brands = getListFromString(dynamicMappingRequest.getBrand());
		List<String> vehLine = getListFromString(dynamicMappingRequest.getVehicleLine());
		List<String> plant = getListFromString(dynamicMappingRequest.getAssemblyPlant());
		fsaCriteriaAllNonWers.stream().forEach(vehBrand->{
			getNonSelectModels(vehBrand, modelYear, brands, vehLine, plant, fsaCriteriaResponse);
			getNonSelectBrand(vehBrand, modelYear, brands, vehLine, plant, fsaCriteriaResponse);
			getNonSelectVehLine(vehBrand, modelYear, brands, vehLine, plant, fsaCriteriaResponse);
			getNonSelectPlant(vehBrand, modelYear, brands, vehLine, plant, fsaCriteriaResponse);
		});
	}
	
	private void getNonSelectModels(FsaFilterCriteriaResponse vehBrand, List<String> modelYear, List<String> brands, List<String> vehLine, List<String> plant, List<FsaFilterCriteriaResponse> fsaCriteriaResponse) {
		if(CollectionUtils.isNotEmpty(modelYear)) {
			if(CollectionUtils.isEmpty(brands) && CollectionUtils.isEmpty(vehLine) && CollectionUtils.isEmpty(plant) && !modelYear.contains(vehBrand.getModelCode())) {
				FsaFilterCriteriaResponse criteriaResponse = new FsaFilterCriteriaResponse();
				criteriaResponse.setModelCode(vehBrand.getModelCode());
				fsaCriteriaResponse.add(criteriaResponse);
			} else {
				if(CollectionUtils.isNotEmpty(brands)) {
					getNonSelectBrandModel(vehBrand, modelYear, brands, vehLine, plant, fsaCriteriaResponse);
				} else if(CollectionUtils.isNotEmpty(vehLine)) {
					getNonSelectModelVehline(vehBrand, modelYear, vehLine, plant, fsaCriteriaResponse);
				} else if(CollectionUtils.isNotEmpty(plant) && !modelYear.contains(vehBrand.getModelCode()) && plant.contains(vehBrand.getPlant())) {
					FsaFilterCriteriaResponse criteriaResponse = new FsaFilterCriteriaResponse();
					criteriaResponse.setModelCode(vehBrand.getModelCode());
					fsaCriteriaResponse.add(criteriaResponse);
				} 
			}
		}
	}
	
	private void getNonSelectModelVehline(FsaFilterCriteriaResponse vehBrand, List<String> modelYear,
			List<String> vehLine, List<String> plant, List<FsaFilterCriteriaResponse> fsaCriteriaResponse) {
		if(CollectionUtils.isNotEmpty(plant)) {
			if(!modelYear.contains(vehBrand.getModelCode()) && vehLine.contains(vehBrand.getVehLine()) && plant.contains(vehBrand.getPlant())) {
				FsaFilterCriteriaResponse criteriaResponse = new FsaFilterCriteriaResponse();
				criteriaResponse.setModelCode(vehBrand.getModelCode());
				fsaCriteriaResponse.add(criteriaResponse);
			}
		} else {
			if(!modelYear.contains(vehBrand.getModelCode()) && vehLine.contains(vehBrand.getVehLine())) {
				FsaFilterCriteriaResponse criteriaResponse = new FsaFilterCriteriaResponse();
				criteriaResponse.setModelCode(vehBrand.getModelCode());
				fsaCriteriaResponse.add(criteriaResponse);
			}
		}
	}
	
	private void getNonSelectBrandModel(FsaFilterCriteriaResponse vehBrand, List<String> modelYear, List<String> brands, 
			List<String> vehLine, List<String> plant, List<FsaFilterCriteriaResponse> fsaCriteriaResponse) {
		if(CollectionUtils.isNotEmpty(vehLine)) {
			if(CollectionUtils.isNotEmpty(plant)) {
				if(!modelYear.contains(vehBrand.getModelCode()) && brands.contains(vehBrand.getBrandDesc().trim()) && vehLine.contains(vehBrand.getVehLine()) && plant.contains(vehBrand.getPlant())) {
					FsaFilterCriteriaResponse criteriaResponse = new FsaFilterCriteriaResponse();
					criteriaResponse.setModelCode(vehBrand.getModelCode());
					fsaCriteriaResponse.add(criteriaResponse);
				}
			} else {
				if(!modelYear.contains(vehBrand.getModelCode()) && brands.contains(vehBrand.getBrandDesc().trim()) && vehLine.contains(vehBrand.getVehLine())) {
					FsaFilterCriteriaResponse criteriaResponse = new FsaFilterCriteriaResponse();
					criteriaResponse.setModelCode(vehBrand.getModelCode());
					fsaCriteriaResponse.add(criteriaResponse);
				}
			}
		} else {
			getNonSelectBrandModelPlant(vehBrand, modelYear, brands, plant, fsaCriteriaResponse);
			
		} 
	}
	
	private void getNonSelectBrandModelPlant(FsaFilterCriteriaResponse vehBrand, List<String> modelYear, List<String> brands, List<String> plant, List<FsaFilterCriteriaResponse> fsaCriteriaResponse) {
		if(CollectionUtils.isNotEmpty(plant)) {
			if(!modelYear.contains(vehBrand.getModelCode()) && brands.contains(vehBrand.getBrandDesc().trim()) && plant.contains(vehBrand.getPlant())) {
				FsaFilterCriteriaResponse criteriaResponse = new FsaFilterCriteriaResponse();
				criteriaResponse.setModelCode(vehBrand.getModelCode());
				fsaCriteriaResponse.add(criteriaResponse);
			}
		} else {
			if(!modelYear.contains(vehBrand.getModelCode()) && brands.contains(vehBrand.getBrandDesc().trim())) {
				FsaFilterCriteriaResponse criteriaResponse = new FsaFilterCriteriaResponse();
				criteriaResponse.setModelCode(vehBrand.getModelCode());
				fsaCriteriaResponse.add(criteriaResponse);
			}
		}
	}
	
	private void getNonSelectBrand(FsaFilterCriteriaResponse vehBrand, List<String> modelYear, List<String> brands, List<String> vehLine, List<String> plant, List<FsaFilterCriteriaResponse> fsaCriteriaResponse) {
		if(CollectionUtils.isNotEmpty(brands)) {
			if(CollectionUtils.isEmpty(modelYear) && CollectionUtils.isEmpty(vehLine) && CollectionUtils.isEmpty(plant) 
					&& !brands.contains(vehBrand.getBrandDesc().trim())) {
				FsaFilterCriteriaResponse criteriaResponse = new FsaFilterCriteriaResponse();
				criteriaResponse.setBrandCode(vehBrand.getBrandCode());
				criteriaResponse.setBrandDesc(vehBrand.getBrandDesc());
				fsaCriteriaResponse.add(criteriaResponse);
			} else {
				if(CollectionUtils.isNotEmpty(modelYear)) {
					getNonSelectForBrand(vehBrand, modelYear, brands, vehLine, plant, fsaCriteriaResponse);
				} else if(CollectionUtils.isNotEmpty(vehLine)) {
					getNonSelectBrandVehline(vehBrand, brands, vehLine, plant, fsaCriteriaResponse);
				} else if(CollectionUtils.isNotEmpty(plant) && !brands.contains(vehBrand.getBrandDesc().trim()) && plant.contains(vehBrand.getPlant())) {
					FsaFilterCriteriaResponse criteriaResponse = new FsaFilterCriteriaResponse();
					criteriaResponse.setBrandCode(vehBrand.getBrandCode());
					criteriaResponse.setBrandDesc(vehBrand.getBrandDesc());
					fsaCriteriaResponse.add(criteriaResponse);
				}
			}
			
		}
	}
	
	private void getNonSelectBrandVehline(FsaFilterCriteriaResponse vehBrand, List<String> brands, List<String> vehLine, List<String> plant, List<FsaFilterCriteriaResponse> fsaCriteriaResponse) {
		if(CollectionUtils.isNotEmpty(plant)) {
			getNonSelectForBrandVehLine(vehBrand, brands, vehLine, plant, fsaCriteriaResponse);
		} else {
			if(!brands.contains(vehBrand.getBrandDesc().trim()) && vehLine.contains(vehBrand.getVehLine())) {
				FsaFilterCriteriaResponse criteriaResponse = new FsaFilterCriteriaResponse();
				criteriaResponse.setBrandCode(vehBrand.getBrandCode());
				criteriaResponse.setBrandDesc(vehBrand.getBrandDesc());
				fsaCriteriaResponse.add(criteriaResponse);
			}
		}
	}
	
	private void getNonSelectForBrandVehLine(FsaFilterCriteriaResponse vehBrand, List<String> brands, List<String> vehLine, List<String> plant, List<FsaFilterCriteriaResponse> fsaCriteriaResponse) {
		if(!brands.contains(vehBrand.getBrandDesc().trim()) && vehLine.contains(vehBrand.getVehLine()) && plant.contains(vehBrand.getPlant())) {
			FsaFilterCriteriaResponse criteriaResponse = new FsaFilterCriteriaResponse();
			criteriaResponse.setBrandCode(vehBrand.getBrandCode());
			criteriaResponse.setBrandDesc(vehBrand.getBrandDesc());
			fsaCriteriaResponse.add(criteriaResponse);
		}
	}
	
	private void getNonSelectForBrand(FsaFilterCriteriaResponse vehBrand, List<String> modelYear, List<String> brands, List<String> vehLine, List<String> plant, List<FsaFilterCriteriaResponse> fsaCriteriaResponse) {

		if(CollectionUtils.isNotEmpty(vehLine)) {
			if(CollectionUtils.isNotEmpty(plant)) {
				if(!brands.contains(vehBrand.getBrandDesc().trim()) && modelYear.contains(vehBrand.getModelCode()) && vehLine.contains(vehBrand.getVehLine()) && plant.contains(vehBrand.getPlant())) {
					FsaFilterCriteriaResponse criteriaResponse = new FsaFilterCriteriaResponse();
					criteriaResponse.setBrandCode(vehBrand.getBrandCode());
					criteriaResponse.setBrandDesc(vehBrand.getBrandDesc());
					fsaCriteriaResponse.add(criteriaResponse);
				}
			} else {
				if(!brands.contains(vehBrand.getBrandDesc().trim()) && modelYear.contains(vehBrand.getModelCode()) && vehLine.contains(vehBrand.getVehLine())) {
					FsaFilterCriteriaResponse criteriaResponse = new FsaFilterCriteriaResponse();
					criteriaResponse.setBrandCode(vehBrand.getBrandCode());
					criteriaResponse.setBrandDesc(vehBrand.getBrandDesc());
					fsaCriteriaResponse.add(criteriaResponse);
				}
			}
		} else {
			getNonSelectForBrandPlant(vehBrand, modelYear, brands, plant, fsaCriteriaResponse);
		}
	
	}
	
	private void getNonSelectForBrandPlant(FsaFilterCriteriaResponse vehBrand, List<String> modelYear, List<String> brands, List<String> plant, List<FsaFilterCriteriaResponse> fsaCriteriaResponse) {
		if(CollectionUtils.isNotEmpty(plant)) {
			if(!brands.contains(vehBrand.getBrandDesc().trim()) && modelYear.contains(vehBrand.getModelCode())  && plant.contains(vehBrand.getPlant())) {
				FsaFilterCriteriaResponse criteriaResponse = new FsaFilterCriteriaResponse();
				criteriaResponse.setBrandCode(vehBrand.getBrandCode());
				criteriaResponse.setBrandDesc(vehBrand.getBrandDesc());
				fsaCriteriaResponse.add(criteriaResponse);
			}
		} else {
			if(!brands.contains(vehBrand.getBrandDesc().trim()) && modelYear.contains(vehBrand.getModelCode())) {
				FsaFilterCriteriaResponse criteriaResponse = new FsaFilterCriteriaResponse();
				criteriaResponse.setBrandCode(vehBrand.getBrandCode());
				criteriaResponse.setBrandDesc(vehBrand.getBrandDesc());
				fsaCriteriaResponse.add(criteriaResponse);
			}
		}
	}
	
	private void getNonSelectVehLine(FsaFilterCriteriaResponse vehBrand, List<String> modelYear, List<String> brands, 
			List<String> vehLine, List<String> plant, List<FsaFilterCriteriaResponse> fsaCriteriaResponse) {
		if(CollectionUtils.isNotEmpty(vehLine)) {
			if(CollectionUtils.isEmpty(brands) && CollectionUtils.isEmpty(modelYear) && CollectionUtils.isEmpty(plant) && !vehLine.contains(vehBrand.getVehLine())) {
				FsaFilterCriteriaResponse criteriaResponse = new FsaFilterCriteriaResponse();
				criteriaResponse.setVehLine(vehBrand.getVehLine());
				criteriaResponse.setVehLineDesc(vehBrand.getVehLineDesc());
				fsaCriteriaResponse.add(criteriaResponse);
			} else {
				if(CollectionUtils.isNotEmpty(brands)) {
					getNonSelectVehLineBrand(vehBrand, modelYear, brands, vehLine, plant, fsaCriteriaResponse);
				} else if(CollectionUtils.isNotEmpty(modelYear)) {
					getNonSelectVehlineModel(vehBrand, modelYear, vehLine, plant, fsaCriteriaResponse);
				} else if(CollectionUtils.isNotEmpty(plant) && !vehLine.contains(vehBrand.getVehLine()) && plant.contains(vehBrand.getPlant())) {
					FsaFilterCriteriaResponse criteriaResponse = new FsaFilterCriteriaResponse();
					criteriaResponse.setVehLine(vehBrand.getVehLine());
					criteriaResponse.setVehLineDesc(vehBrand.getVehLineDesc());
					fsaCriteriaResponse.add(criteriaResponse);
				}
			}
			
		}
	}
	
	private void getNonSelectVehlineModel(FsaFilterCriteriaResponse vehBrand, List<String> modelYear, 
			List<String> vehLine, List<String> plant, List<FsaFilterCriteriaResponse> fsaCriteriaResponse) {
		if(CollectionUtils.isNotEmpty(plant)) {
			if(!vehLine.contains(vehBrand.getVehLine()) && modelYear.contains(vehBrand.getModelCode()) && plant.contains(vehBrand.getPlant())) {
				FsaFilterCriteriaResponse criteriaResponse = new FsaFilterCriteriaResponse();
				criteriaResponse.setVehLine(vehBrand.getVehLine());
				criteriaResponse.setVehLineDesc(vehBrand.getVehLineDesc());
				fsaCriteriaResponse.add(criteriaResponse);
			} 
		} else {
			if(!vehLine.contains(vehBrand.getVehLine()) && modelYear.contains(vehBrand.getModelCode())) {
				FsaFilterCriteriaResponse criteriaResponse = new FsaFilterCriteriaResponse();
				criteriaResponse.setVehLine(vehBrand.getVehLine());
				criteriaResponse.setVehLineDesc(vehBrand.getVehLineDesc());
				fsaCriteriaResponse.add(criteriaResponse);
			}
		}
	}
	
	private void getNonSelectVehLineBrand(FsaFilterCriteriaResponse vehBrand, List<String> modelYear, List<String> brands, List<String> vehLine, List<String> plant, List<FsaFilterCriteriaResponse> fsaCriteriaResponse) {
		if(CollectionUtils.isNotEmpty(modelYear)) {
			if(CollectionUtils.isNotEmpty(plant)) {
				if(!vehLine.contains(vehBrand.getVehLine()) && modelYear.contains(vehBrand.getModelCode()) && brands.contains(vehBrand.getBrandDesc().trim()) && plant.contains(vehBrand.getPlant())) {
					FsaFilterCriteriaResponse criteriaResponse = new FsaFilterCriteriaResponse();
					criteriaResponse.setVehLine(vehBrand.getVehLine());
					criteriaResponse.setVehLineDesc(vehBrand.getVehLineDesc());
					fsaCriteriaResponse.add(criteriaResponse);
				}
			} else {
				if(!vehLine.contains(vehBrand.getVehLine()) && modelYear.contains(vehBrand.getModelCode()) && brands.contains(vehBrand.getBrandDesc().trim())) {
					FsaFilterCriteriaResponse criteriaResponse = new FsaFilterCriteriaResponse();
					criteriaResponse.setVehLine(vehBrand.getVehLine());
					criteriaResponse.setVehLineDesc(vehBrand.getVehLineDesc());
					fsaCriteriaResponse.add(criteriaResponse);
				}
			}
		} else {
			getNonSelectVehlineBrandPlant(vehBrand, brands, vehLine, plant, fsaCriteriaResponse);
		}
	}
	
	private void getNonSelectVehlineBrandPlant(FsaFilterCriteriaResponse vehBrand, List<String> brands, List<String> vehLine, List<String> plant, List<FsaFilterCriteriaResponse> fsaCriteriaResponse) {
		if(CollectionUtils.isNotEmpty(plant)) {
			if(!vehLine.contains(vehBrand.getVehLine()) && brands.contains(vehBrand.getBrandDesc().trim()) && plant.contains(vehBrand.getPlant())) {
				FsaFilterCriteriaResponse criteriaResponse = new FsaFilterCriteriaResponse();
				criteriaResponse.setVehLine(vehBrand.getVehLine());
				criteriaResponse.setVehLineDesc(vehBrand.getVehLineDesc());
				fsaCriteriaResponse.add(criteriaResponse);
			}
		} else {
			if(!vehLine.contains(vehBrand.getVehLine()) && brands.contains(vehBrand.getBrandDesc().trim())) {
				FsaFilterCriteriaResponse criteriaResponse = new FsaFilterCriteriaResponse();
				criteriaResponse.setVehLine(vehBrand.getVehLine());
				criteriaResponse.setVehLineDesc(vehBrand.getVehLineDesc());
				fsaCriteriaResponse.add(criteriaResponse);
			}
		}
	}
	
	private void getNonSelectPlant(FsaFilterCriteriaResponse vehBrand, List<String> modelYear, 
			List<String> brands, List<String> vehLine, List<String> plant, List<FsaFilterCriteriaResponse> fsaCriteriaResponse) {
		if(CollectionUtils.isNotEmpty(plant)) {
			if(CollectionUtils.isEmpty(brands) && CollectionUtils.isEmpty(modelYear) && CollectionUtils.isEmpty(vehLine)
					&& !plant.contains(vehBrand.getPlant())) {
				FsaFilterCriteriaResponse criteriaResponse = new FsaFilterCriteriaResponse();
				criteriaResponse.setPlant(vehBrand.getPlant());
				criteriaResponse.setPlantDesc(vehBrand.getPlantDesc());
				fsaCriteriaResponse.add(criteriaResponse);
			} else {
				if(CollectionUtils.isNotEmpty(brands)) {
					getNonSelectForPlantBrand(vehBrand, modelYear, brands, vehLine, plant, fsaCriteriaResponse);
				} else if(CollectionUtils.isNotEmpty(modelYear)) {
					getNonSelectForPlantModel(vehBrand, modelYear, vehLine, plant, fsaCriteriaResponse);
				} else if(CollectionUtils.isNotEmpty(vehLine) && !plant.contains(vehBrand.getPlant()) && vehLine.contains(vehBrand.getVehLine())) {
					FsaFilterCriteriaResponse criteriaResponse = new FsaFilterCriteriaResponse();
					criteriaResponse.setPlant(vehBrand.getPlant());
					criteriaResponse.setPlantDesc(vehBrand.getPlantDesc());
					fsaCriteriaResponse.add(criteriaResponse);
				}
			}
		}
	}
	
	private void getNonSelectForPlantModel(FsaFilterCriteriaResponse vehBrand, List<String> modelYear, 
			List<String> vehLine, List<String> plant, List<FsaFilterCriteriaResponse> fsaCriteriaResponse) {
		if(CollectionUtils.isNotEmpty(vehLine)) {
			if(!plant.contains(vehBrand.getPlant()) && modelYear.contains(vehBrand.getModelCode()) && vehLine.contains(vehBrand.getVehLine())) {
				FsaFilterCriteriaResponse criteriaResponse = new FsaFilterCriteriaResponse();
				criteriaResponse.setPlant(vehBrand.getPlant());
				criteriaResponse.setPlantDesc(vehBrand.getPlantDesc());
				fsaCriteriaResponse.add(criteriaResponse);
			}
		} else {
			if(!plant.contains(vehBrand.getPlant()) && modelYear.contains(vehBrand.getModelCode())) {
				FsaFilterCriteriaResponse criteriaResponse = new FsaFilterCriteriaResponse();
				criteriaResponse.setPlant(vehBrand.getPlant());
				criteriaResponse.setPlantDesc(vehBrand.getPlantDesc());
				fsaCriteriaResponse.add(criteriaResponse);
			}
		}
	}
	
	private void getNonSelectForPlantBrand(FsaFilterCriteriaResponse vehBrand, List<String> modelYear, 
			List<String> brands, List<String> vehLine, List<String> plant, List<FsaFilterCriteriaResponse> fsaCriteriaResponse) {
		if(CollectionUtils.isNotEmpty(modelYear)) {
			if(CollectionUtils.isNotEmpty(vehLine)) {
				if(!plant.contains(vehBrand.getPlant()) && modelYear.contains(vehBrand.getModelCode()) && brands.contains(vehBrand.getBrandDesc().trim()) && vehLine.contains(vehBrand.getVehLine())) {
					FsaFilterCriteriaResponse criteriaResponse = new FsaFilterCriteriaResponse();
					criteriaResponse.setPlant(vehBrand.getPlant());
					criteriaResponse.setPlantDesc(vehBrand.getPlantDesc());
					fsaCriteriaResponse.add(criteriaResponse);
				}
			} else {
				if(!plant.contains(vehBrand.getPlant()) && modelYear.contains(vehBrand.getModelCode()) && brands.contains(vehBrand.getBrandDesc().trim())) {
					FsaFilterCriteriaResponse criteriaResponse = new FsaFilterCriteriaResponse();
					criteriaResponse.setPlant(vehBrand.getPlant());
					criteriaResponse.setPlantDesc(vehBrand.getPlantDesc());
					fsaCriteriaResponse.add(criteriaResponse);
				}
			}
		} else {
			getNonSelectForPlantBrandVehline(vehBrand, brands, vehLine, plant, fsaCriteriaResponse);
		}
	}
	
	private void getNonSelectForPlantBrandVehline(FsaFilterCriteriaResponse vehBrand, 
			List<String> brands, List<String> vehLine, List<String> plant, List<FsaFilterCriteriaResponse> fsaCriteriaResponse) {
		if(CollectionUtils.isNotEmpty(vehLine)) {
			if(!plant.contains(vehBrand.getPlant()) && brands.contains(vehBrand.getBrandDesc().trim()) && vehLine.contains(vehBrand.getVehLine())) {
				FsaFilterCriteriaResponse criteriaResponse = new FsaFilterCriteriaResponse();
				criteriaResponse.setPlant(vehBrand.getPlant());
				criteriaResponse.setPlantDesc(vehBrand.getPlantDesc());
				fsaCriteriaResponse.add(criteriaResponse);
			}
		} else {
			if(!plant.contains(vehBrand.getPlant()) && brands.contains(vehBrand.getBrandDesc().trim())) {
				FsaFilterCriteriaResponse criteriaResponse = new FsaFilterCriteriaResponse();
				criteriaResponse.setPlant(vehBrand.getPlant());
				criteriaResponse.setPlantDesc(vehBrand.getPlantDesc());
				fsaCriteriaResponse.add(criteriaResponse);
			}
		}
	}
	
	private boolean validateNoInput(DynamicQueryMappingReq dynamicMappingRequest) {
		
		return (StringUtils.isBlank(dynamicMappingRequest.getModelYear()) && StringUtils.isBlank(dynamicMappingRequest.getBrand()) 
				&& StringUtils.isBlank(dynamicMappingRequest.getVehicleLine())
				&& StringUtils.isBlank(dynamicMappingRequest.getAssemblyPlant()) 
				&& StringUtils.isBlank(dynamicMappingRequest.getWers()) 
				&& StringUtils.isBlank(dynamicMappingRequest.getWersValue()));
	}
	
	private boolean validateNoNonWersInput(DynamicQueryMappingReq dynamicMappingRequest) {
		
		return (StringUtils.isBlank(dynamicMappingRequest.getModelYear()) && StringUtils.isBlank(dynamicMappingRequest.getBrand()) 
				&& StringUtils.isBlank(dynamicMappingRequest.getVehicleLine())
				&& StringUtils.isBlank(dynamicMappingRequest.getAssemblyPlant()));
	}
	
	private DynamicQueryResponse getDynamicFilterList(List<FsaFilterCriteriaResponse> fsaCriteriaResponse) {
		DynamicQueryResponse dynamicQueryResponse = new DynamicQueryResponse();
		List<ModelYearList> modelYear = new ArrayList<>();
		List<AssemblyPlantList> assemblyPlantList = new ArrayList<>();
		List<VehicleTypeList> vehicleTypeList = new ArrayList<>();
		List<VehicleBrandList> vehicleBrandLists = new ArrayList<>();
		List<GCPFilterList> gcpFilterList = new ArrayList<>();
		List<AttributeGroupingList> attributeGroupingLists = new ArrayList<>();
		List<WersValuesList> wersValue = new ArrayList<>();
		Set<String> uniqueValue = new HashSet<>();
		fsaCriteriaResponse.forEach(fsaCriteria->{
			processUniqueModelBrandVehLine(fsaCriteria, uniqueValue, modelYear, vehicleTypeList, vehicleBrandLists);
			if(StringUtils.isNotBlank(fsaCriteria.getPlant()) && StringUtils.isNotBlank(fsaCriteria.getPlantDesc()) && uniqueValue.add(fsaCriteria.getPlant())) {
				assemblyPlantList.add(new AssemblyPlantList(fsaCriteria.getPlant(), getPlantDesc(fsaCriteria)));
				}
			if(uniqueValue.add(String.valueOf(fsaCriteria.getWersCode())) && StringUtils.isNotBlank(fsaCriteria.getWersDesc())) {
				String wersDesc = StringUtils.trimToEmpty(fsaCriteria.getWersDesc());
				String wersFamilyCode = StringUtils.isNotBlank(fsaCriteria.getWersValue()) ? StringUtils.trimToEmpty(fsaCriteria.getWersValue()).substring(0,3):StringUtils.EMPTY;
				gcpFilterList.add(new GCPFilterList(fsaCriteria.getWersCode(), TargetingUtil.getWersDescWithFamilyCode(wersDesc, wersFamilyCode),wersFamilyCode)); 
				}
			if(StringUtils.isNotBlank(fsaCriteria.getWersValue()) && StringUtils.isNotBlank(fsaCriteria.getWersValueDesc()) && uniqueValue.add(fsaCriteria.getWersValue())) {
				wersValue.add(new WersValuesList(fsaCriteria.getWersValue(), TargetingUtil.getWersDescWithFamilyCode(StringUtils.trimToEmpty(fsaCriteria.getWersValueDesc()),StringUtils.trimToEmpty(fsaCriteria.getWersValue()))));
				}
		});
		List<ModelYearList> sortedModelYear = modelYear.stream().sorted(Comparator.comparingInt(ModelYearList::getModelYearsInt).reversed()).collect(Collectors.toList()); 
		vehicleBrandLists.sort((VehicleBrandList s1, VehicleBrandList s2)->s1.getBrandX().compareTo(s2.getBrandX())); 
		vehicleTypeList.sort((VehicleTypeList s1, VehicleTypeList s2)->s1.getVehicleLnX().compareTo(s2.getVehicleLnX())); 
		assemblyPlantList.sort((AssemblyPlantList s1, AssemblyPlantList s2)->s1.getGcpWersFtrX().compareTo(s2.getGcpWersFtrX())); 
		wersValue.sort((WersValuesList s1, WersValuesList s2)->s1.getWrsFilterDescription().compareTo(s2.getWrsFilterDescription())); 
		gcpFilterList.sort((GCPFilterList s1, GCPFilterList s2)->s1.getGcpFilterX().compareTo(s2.getGcpFilterX())); 
		dynamicQueryResponse.setAssemblyPlantList(assemblyPlantList);
		dynamicQueryResponse.setGcpFilterList(gcpFilterList);
		dynamicQueryResponse.setModelYear(sortedModelYear);
		dynamicQueryResponse.setVehicleTypeList(vehicleTypeList);
		dynamicQueryResponse.setVehicleBrandLists(vehicleBrandLists);
		dynamicQueryResponse.setWersValue(wersValue);
		dynamicQueryResponse.setAttributeGroupingLists(attributeGroupingLists);
		return dynamicQueryResponse;
	}
	
	private void processUniqueModelBrandVehLine(FsaFilterCriteriaResponse fsaCriteria, Set<String> uniqueValue,List<ModelYearList> modelYear, 
			List<VehicleTypeList> vehicleTypeList, List<VehicleBrandList> vehicleBrandLists) {
		if(StringUtils.isNotBlank(fsaCriteria.getModelCode()) && uniqueValue.add(fsaCriteria.getModelCode())) {
			modelYear.add(new ModelYearList(fsaCriteria.getModelCode(), Integer.valueOf(fsaCriteria.getModelCode().trim())));
		}
		if(StringUtils.isNotBlank(fsaCriteria.getVehLine()) && StringUtils.isNotBlank(fsaCriteria.getVehLineDesc()) && uniqueValue.add(fsaCriteria.getVehLine())) {
			vehicleTypeList.add(new VehicleTypeList(fsaCriteria.getVehLine(), getVehLineDesc(fsaCriteria)));
		}
		if(StringUtils.isNotBlank(fsaCriteria.getBrandCode()) && StringUtils.isNotBlank(fsaCriteria.getBrandDesc()) &&  uniqueValue.add(fsaCriteria.getBrandDesc().trim())) {
			vehicleBrandLists.add(new VehicleBrandList(fsaCriteria.getBrandCode(), fsaCriteria.getBrandDesc().trim()));
			}
	}
	
	private String getVehLineDesc(FsaFilterCriteriaResponse fsaCriteria) {
		StringBuilder builder = new StringBuilder();
		builder.append(fsaCriteria.getVehLineDesc().trim());
		builder.append(" (");
		builder.append(fsaCriteria.getVehLine());
		builder.append(")");
		return builder.toString();
	}
	
	private String getPlantDesc(FsaFilterCriteriaResponse fsaCriteria) {
		StringBuilder builder = new StringBuilder();
		builder.append(fsaCriteria.getPlantDesc().trim());
		builder.append(" ( ");
		builder.append(fsaCriteria.getPlant().charAt(fsaCriteria.getPlant().length()-1));
		builder.append(" )");
		return builder.toString();
	}
	
	private String getFsaParam1ForModifySave(FsaCriteriaParam fsaCriteriaParam, String operationType) {
		StringBuilder builder = new StringBuilder();
		builder.append(operationType);
		builder.append(TargetingUtil.fillFsaTypeValue(fsaCriteriaParam.getFsaNumber(), 8, fsaCriteriaParam.getFsaType()));
		builder.append(TargetingUtil.fillRemainingString(fsaCriteriaParam.getSupplementCode(), 2, " "));
		builder.append(TargetingUtil.fillWithZeros(fsaCriteriaParam.getVinGrpSeq(),4));
		builder.append(TargetingUtil.fillWithZeros(fsaCriteriaParam.getCriteriaListCount(),4));
		builder.append(TargetingUtil.fillRemainingString(fsaCriteriaParam.getCdsId(), 8, " "));
		builder.append("N");
		builder.append(TargetingUtil.fillRemainingString(fsaCriteriaParam.getVinGrpCode(), 2, " "));
		builder.append(TargetingUtil.fillRemainingString(fsaCriteriaParam.getVinGrpDesc(), 254, " "));
		builder.append(TargetingUtil.fillRemainingString(fsaCriteriaParam.getOtaIndicator(), 1, " "));
		builder.append(TargetingUtil.fillRemainingString(fsaCriteriaParam.getFhmIndication(), 1, " "));
		builder.append(TargetingUtil.fillRemainingString(18, " "));
		return builder.toString();
	}
	
	private boolean validateTotalCriteriaParamCount(FsaCriteriaSaveParam fsaCriteriaModifySaveParam) {
		String criteriaCount = fsaCriteriaModifySaveParam.getCriteriaParam().getCriteriaListCount();
		log.info("criteriaCount on save fsa {}", criteriaCount);
		int totalCriteriaCount = 0;
		if(StringUtils.isNotBlank(criteriaCount)) {
			totalCriteriaCount = Integer.valueOf(criteriaCount.trim());
		}
		
		return totalCriteriaCount>99;
	}
	

	private String getFsaParam2ForModifySave(FsaCriteriaSaveParam fsaCriteriaModifySaveParam) {
		FsaCriteriaEditVO fsaModify = fsaCriteriaModifySaveParam.getFsaEdit();
		setOrderNumberFields(fsaModify);
		List<VehicleModelVO> models = fsaModify.getModels();
		List<BrandVO> brands = fsaModify.getBrands();
		List<VehicleLineVO> vehicleLine = fsaModify.getVehicleLine();
		List<VehicleAssemblyPlantVO> assemblyPlants = fsaModify.getAssemblyPlants();
		VehicleProductionVO productionVO = fsaModify.getProductionVO();
		List<VehicleWersVO> wersVO = fsaModify.getWersVO();
		List<AttributeGroupingVO> vehicleAttributeGroups = fsaModify.getVehicleAttributeGroups();
		StringBuilder builder = new StringBuilder();
		builder.append(setModelForSave(models));
		builder.append(setBrandForSave(brands));
		builder.append(setVehicleLineForSave(vehicleLine));
		builder.append(setAssemblyPlantForSave(assemblyPlants));
		if(productionVO != null) {
			builder.append(setProdDateForSave(productionVO));
		}
		builder.append(setWersForSave(wersVO));
		builder.append(setVehAttrGroupsForSave(vehicleAttributeGroups));
		return builder.toString();
	}
	
	private void setOrderNumberFields(FsaCriteriaEditVO fsaModify) {
		int orderNumber = 1;
		if(null != fsaModify && CollectionUtils.isNotEmpty(fsaModify.getModels())) {
			for (VehicleModelVO modelVO : fsaModify.getModels()) {
				modelVO.setOrderNumber(String.valueOf(orderNumber));
			}
			orderNumber = orderNumber+1;
		}
		if(null != fsaModify && CollectionUtils.isNotEmpty(fsaModify.getBrands())) {
			for (BrandVO brandVO : fsaModify.getBrands()) {
				brandVO.setOrderNumber(String.valueOf(orderNumber));
			}
			orderNumber = orderNumber+1;
		}
		if(null != fsaModify && CollectionUtils.isNotEmpty(fsaModify.getVehicleLine())) {
			for (VehicleLineVO vehicleLineVO : fsaModify.getVehicleLine()) {
				vehicleLineVO.setOrderNumber(String.valueOf(orderNumber));
			}
			orderNumber = orderNumber+1;
		}
		extracted(fsaModify, orderNumber);

	}

	private void extracted(FsaCriteriaEditVO fsaModify, int orderNumber) {
		if(null != fsaModify && CollectionUtils.isNotEmpty(fsaModify.getAssemblyPlants())) {
			for (VehicleAssemblyPlantVO assemblyPlantVO : fsaModify.getAssemblyPlants()) {
				assemblyPlantVO.setOrderNumber(String.valueOf(orderNumber));
			}
			orderNumber = orderNumber+1;
		}
		
		if(null != fsaModify && null != fsaModify.getProductionVO()) {
			fsaModify.getProductionVO().setOrderNumber(String.valueOf(orderNumber));
			orderNumber = orderNumber+1;
		}
		
		if(null != fsaModify) {
			setWersAttributeGroupOrderNumber(orderNumber, fsaModify);
		}
		
	}
	
	private void setWersAttributeGroupOrderNumber(int orderNumber, FsaCriteriaEditVO fsaModify) {
		List<AttributeGroupingVO> vehicleAttributeGroups = fsaModify.getVehicleAttributeGroups();
		List<VehicleWersVO> wers = fsaModify.getWersVO();
		int orderNum = orderNumber;
		if(CollectionUtils.isNotEmpty(wers)) {
			Map<String,Integer> wersCodeMap = new HashMap<>(); 
			for (VehicleWersVO wersVO : wers) {
				if(wersCodeMap.containsKey(wersVO.getWersFilterCode())) {
					Integer wersOrderNumber = wersCodeMap.get(wersVO.getWersFilterCode());
					wersVO.setOrderNumber(String.valueOf(wersOrderNumber));
				} else {
					wersVO.setOrderNumber(String.valueOf(orderNum));
					wersCodeMap.put(wersVO.getWersFilterCode(), orderNum);
					orderNum = orderNum +1;
				}
			}
		}
		if(CollectionUtils.isNotEmpty(vehicleAttributeGroups)) {
			Map<String,Integer> attributeCodeMap = new HashMap<>(); 
			for (AttributeGroupingVO attributeGroupingVO : vehicleAttributeGroups) {
				if(attributeCodeMap.containsKey(attributeGroupingVO.getVehicleAttributeCode())) {
					Integer attributeOrderNumber = attributeCodeMap.get(attributeGroupingVO.getVehicleAttributeCode());
					attributeGroupingVO.setOrderNumber(String.valueOf(attributeOrderNumber));
				} else {
					attributeGroupingVO.setOrderNumber(String.valueOf(orderNum));
					attributeCodeMap.put(attributeGroupingVO.getVehicleAttributeCode(), orderNum);
					orderNum = orderNum +1;
				}
				
			}
		}
		
	}
	
	private String setVehAttrGroupsForSave(List<AttributeGroupingVO> vehicleAttributeGroups) {
		StringBuilder builder = new StringBuilder();
		
		if (vehicleAttributeGroups != null && !vehicleAttributeGroups.isEmpty()) {
			vehicleAttributeGroups.forEach(attrGroup -> {
				if(attrGroup.getAttributeGroupCode().equalsIgnoreCase(fsaCriteriaConfiguration.getTraceabilityAttrCode())) {
					builder.append(TargetingUtil.fillWithZeros(fsaCriteriaConfiguration.getTraceabilityFilterCode(), 9));
					builder.append(TargetingUtil.fillRemainingString(getAttributeValueForTraceability(attrGroup.getVehicleAttrValue(), attrGroup.getOperator(), attrGroup.getVehicleAttributeCode()), 83, " "));
					builder.append(TargetingUtil.fillRemainingString(getAttributeBeginEndForTraceability(attrGroup.getVehicleAttrBegin(), attrGroup.getOperator(), attrGroup.getVehicleAttributeCode()), 83, " "));
					builder.append(TargetingUtil.fillRemainingString(getAttributeBeginEndForTraceability(attrGroup.getVehicleAttrEnd(), attrGroup.getOperator(), attrGroup.getVehicleAttributeCode()), 83, " "));
					builder.append(TargetingUtil.fillRemainingString(getAttributeGroupOperator(attrGroup), 10, " "));
					builder.append(TargetingUtil.fillWithZeros(attrGroup.getOrderNumber(), 9));
					builder.append(TargetingUtil.fillRemainingString(23, " "));
				} else {
					builder.append(TargetingUtil.fillWithZeros(attrGroup.getVehicleAttributeCode(), 9));
					builder.append(TargetingUtil.fillRemainingString(attrGroup.getVehicleAttrValue(), 83, " "));
					builder.append(TargetingUtil.fillRemainingString(IS_NULL_OPERATOR.equals(attrGroup.getOperator()) || IS_NOTNULL_OPERATOR.equals(attrGroup.getOperator())?CommonConstants.INVALID_DATE:formatDate(attrGroup.getVehicleAttrBegin(),
									CommonConstants.DD_MM_YYYY, CommonConstants.YYYY_MM_DD), 83, " "));
					builder.append(TargetingUtil.fillRemainingString(formatDate(attrGroup.getVehicleAttrEnd(),
							CommonConstants.DD_MM_YYYY, CommonConstants.YYYY_MM_DD), 83, " "));
					builder.append(TargetingUtil.fillRemainingString(getAttributeGroupOperator(attrGroup), 10, " "));
					builder.append(TargetingUtil.fillWithZeros(attrGroup.getOrderNumber(), 9));
					builder.append(TargetingUtil.fillRemainingString(23, " "));
				}
			});
		}
		return builder.toString();
	}
	
	private String getAttributeValueForTraceability(String attributeValue, String attributeOperator, String vehicleAttrCode) {
		if(StringUtils.isNotBlank(attributeOperator)) {
			return vehicleAttrCode+" "+attributeValue;
		} else {
			return StringUtils.EMPTY;
		}
	}
	
	private String getAttributeBeginEndForTraceability(String attributeValue, String attributeOperator, String vehicleAttrCode) {
		if(StringUtils.isBlank(attributeOperator)) {
			return vehicleAttrCode+" "+attributeValue;
		} else {
			return StringUtils.EMPTY;
		}
	}
	
	private String getAttributeGroupOperator(AttributeGroupingVO attrGroup) {
		String operatorText;
		String attributeOperator = attrGroup.getOperator().trim();
		if(StringUtils.isNotBlank(attrGroup.getVehicleAttrBegin()) && StringUtils.isNotBlank(attrGroup.getVehicleAttrEnd()) 
				&& StringUtils.contains(attrGroup.getVehicleAttrBegin(), "-") && StringUtils.contains(attrGroup.getVehicleAttrEnd(), "-")) {
			operatorText = StringUtils.EMPTY;
		} else if(StringUtils.isNotBlank(attributeOperator) && StringUtils.equalsAnyIgnoreCase(attributeOperator, "!=")) {
			operatorText = "<>";
		} else if(StringUtils.isNotBlank(attributeOperator) && StringUtils.equalsAnyIgnoreCase(attributeOperator, IS_NULL_OPERATOR)) {
			operatorText = "=";
		}else if(StringUtils.isNotBlank(attributeOperator) && StringUtils.equalsAnyIgnoreCase(attributeOperator, IS_NOTNULL_OPERATOR)) {
			operatorText = ">";
		}else if(StringUtils.isNotBlank(attributeOperator) && StringUtils.equalsAnyIgnoreCase(attributeOperator, "Between")) {
			operatorText = "";
		}else {
			operatorText = attrGroup.getOperator();
		}
		return operatorText;
			
	}
	
	private String setWersForSave(List<VehicleWersVO> wersVO) {
		StringBuilder builder = new StringBuilder();
		if (wersVO != null && !wersVO.isEmpty()) {
			wersVO.forEach(wers -> {
				  builder.append(TargetingUtil.fillWithZeros(wers.getWersFilterCode(), 9));
				  builder.append(TargetingUtil.fillRemainingString(wers.getWersValueCode(), 83, " "));
				  builder.append(TargetingUtil.fillRemainingString(83, " "));
				  builder.append(TargetingUtil.fillRemainingString(83, " ")); 
				  builder.append(TargetingUtil.fillRemainingString(returnOperatorSymbol(wers.getWersOperator()), 10, " "));
				  builder.append(TargetingUtil.fillWithZeros(wers.getOrderNumber(), 9)); 
				  builder.append(TargetingUtil.fillRemainingString(23, " "));
				 
			});
		}
		return builder.toString();
	}

	private String setProdDateForSave(VehicleProductionVO productionVO) {
		StringBuilder builder = new StringBuilder();
		builder.append(TargetingUtil.fillWithZeros(productionVO.getProdFilterCode(), 9));
		builder.append(TargetingUtil.fillRemainingString(83, " "));
		if(StringUtils.isNotBlank(productionVO.getProdStartDate())) {
			builder.append(TargetingUtil.fillRemainingString(formatDate(productionVO.getProdStartDate(),
					CommonConstants.DD_MM_YYYY, CommonConstants.YYYY_MM_DD), 83, " "));
		} else {
			builder.append(TargetingUtil.fillRemainingString(CommonConstants.INVALID_DATE, 83, " "));
		}
		if(StringUtils.isNotBlank(productionVO.getProdEndDate())) {
			builder.append(TargetingUtil.fillRemainingString(formatDate(productionVO.getProdEndDate(),
					CommonConstants.DD_MM_YYYY, CommonConstants.YYYY_MM_DD), 83, " "));
		} else {
			builder.append(TargetingUtil.fillRemainingString(CommonConstants.DEFAULT_END_DATE, 83, " "));
		}
		
		builder.append(TargetingUtil.fillRemainingString(10, " "));
		builder.append(TargetingUtil.fillWithZeros(productionVO.getOrderNumber(), 9));
		builder.append(TargetingUtil.fillRemainingString(23, " "));
		return builder.toString();
	}
	
	private String setModelForSave(List<VehicleModelVO> models) {
		StringBuilder builder = new StringBuilder();
		if (models != null && !models.isEmpty()) {
			models.forEach(model -> {
				  builder.append(TargetingUtil.fillWithZeros(model.getModelFilterCode(), 9));
				  builder.append(TargetingUtil.fillRemainingString(model.getModelCode(), 83, " "));
				  builder.append(TargetingUtil.fillRemainingString(83, " "));
				  builder.append(TargetingUtil.fillRemainingString(83, " ")); 
				  builder.append(TargetingUtil.fillRemainingString(returnOperatorSymbol(model.getOperator()), 10, " "));
				  builder.append(TargetingUtil.fillWithZeros(model.getOrderNumber(), 9)); 
				  builder.append(TargetingUtil.fillRemainingString(23, " "));
				 
			});
		}
		return builder.toString();
	}
	
	private String setBrandForSave(List<BrandVO> brands) {
		StringBuilder builder = new StringBuilder();
		if (brands != null && !brands.isEmpty()) {
			brands.forEach(brand -> {
				  builder.append(TargetingUtil.fillWithZeros(brand.getBrandFilterCode(), 9));
				  builder.append(TargetingUtil.fillRemainingString(brand.getBrandCode(), 83, " "));
				  builder.append(TargetingUtil.fillRemainingString(83, " "));
				  builder.append(TargetingUtil.fillRemainingString(83, " ")); 
				  builder.append(TargetingUtil.fillRemainingString(returnOperatorSymbol(brand.getOperator()), 10, " "));
				  builder.append(TargetingUtil.fillWithZeros(brand.getOrderNumber(), 9)); 
				  builder.append(TargetingUtil.fillRemainingString(23, " "));
				 
			});
		}
		return builder.toString();
	}

	private String setVehicleLineForSave(List<VehicleLineVO> vehicleLine) {
		StringBuilder builder = new StringBuilder();
		if (vehicleLine != null && !vehicleLine.isEmpty()) {
			vehicleLine.forEach(vehLine -> {
				  builder.append(TargetingUtil.fillWithZeros(vehLine.getVehicleLineFilterCode(), 9));
				  builder.append(TargetingUtil.fillRemainingString(vehLine.getVehicleLineCode(), 83, " "));
				  builder.append(TargetingUtil.fillRemainingString(83, " "));
				  builder.append(TargetingUtil.fillRemainingString(83, " ")); 
				  builder.append(TargetingUtil.fillRemainingString(returnOperatorSymbol(vehLine.getOperator()), 10, " "));
				  builder.append(TargetingUtil.fillWithZeros(vehLine.getOrderNumber(), 9)); 
				  builder.append(TargetingUtil.fillRemainingString(23, " "));
				 
			});
		}
		return builder.toString();
	}
	
	private String setAssemblyPlantForSave(List<VehicleAssemblyPlantVO> assemblyPlants) {
		StringBuilder builder = new StringBuilder();
		if (assemblyPlants != null && !assemblyPlants.isEmpty()) {
			assemblyPlants.forEach(assemblePlant -> {
				  builder.append(TargetingUtil.fillWithZeros(assemblePlant.getAssemblyPlantFilterCode(), 9));
				  builder.append(TargetingUtil.fillRemainingString(assemblePlant.getAssemblyPlantCode(), 83, " "));
				  builder.append(TargetingUtil.fillRemainingString(83, " "));
				  builder.append(TargetingUtil.fillRemainingString(83, " ")); 
				  builder.append(TargetingUtil.fillRemainingString(returnOperatorSymbol(assemblePlant.getOperator()), 10, " "));
				  builder.append(TargetingUtil.fillWithZeros(assemblePlant.getOrderNumber(), 9)); 
				  builder.append(TargetingUtil.fillRemainingString(23, " "));
				 
			});
		}
		return builder.toString();
	}

	
	private FsaCriteriaEditVO setFsaModifyVO(FsaCriteriaResponse criteriaResponse) {
		FsaCriteriaEditVO fsaCriteriaModifyVO = null;
		List<String> firstOutputParamList = criteriaResponse.getOutputParam1();
		List<String> secondOutputParamList = criteriaResponse.getOutputParam2();
		String vinGrpOutput = criteriaResponse.getOutputParam3();

		FsaCriteriaError criteriaError = getErrorDetails(criteriaResponse.getErrorParam1());
		if(criteriaError.getErrorInd() != null && "Y".equalsIgnoreCase(criteriaError.getErrorInd().trim())) {
			fsaCriteriaModifyVO = new FsaCriteriaEditVO();
			fsaCriteriaModifyVO.setStatusCode(criteriaError.getErrorCode());
			fsaCriteriaModifyVO.setStatusDesc(criteriaError.getErrorMessage());
			return fsaCriteriaModifyVO;
		}
		
		VinGroupVO vinGroupVO = new VinGroupVO();

		if (StringUtils.isNotBlank(vinGrpOutput)) {
			vinGroupVO.setVinGrpLabel(vinGrpOutput.substring(0, 2).trim());
			vinGroupVO.setVinGrpDesc(vinGrpOutput.substring(2, 256).trim());
			vinGroupVO.setVinGrpSeq(vinGrpOutput.substring(256,260).trim());
			vinGroupVO.setOtaIndicator(StringUtils.trimToEmpty(vinGrpOutput.substring(260)).isBlank() ? CommonConstants.FLAG_N : StringUtils.trimToEmpty(vinGrpOutput.substring(260)));
			vinGroupVO.setFhmIndicator(StringUtils.trimToEmpty(vinGrpOutput.substring(261)).isBlank() ? CommonConstants.FLAG_N : StringUtils.trimToEmpty(vinGrpOutput.substring(261)));
		}
		FsaCriteriaModifySaveVO criteriaModifySaveVO = processFirstOutputRecords(firstOutputParamList);
		List<FsaCriteriaFilterOutputVO> firstFilterOutputVOs = criteriaModifySaveVO.getFirstOutputResults();
		List<FsaCriteriaFilterOutputVO> secondFilterOutputVOs = processSecondOutputRecords(secondOutputParamList, criteriaModifySaveVO.getRowId());
		if(CollectionUtils.isNotEmpty(secondFilterOutputVOs)) {
			firstFilterOutputVOs.addAll(secondFilterOutputVOs);
		}

		Map<String, List<FsaCriteriaFilterOutputVO>> firstFsaCriteriaMap = firstFilterOutputVOs.stream()
				.collect(Collectors.groupingBy(FsaCriteriaFilterOutputVO::getFormattedFilterCode));
		
		if(CollectionUtils.isNotEmpty(firstFilterOutputVOs)) {
			fsaCriteriaModifyVO = setFsaCriteriaResults(firstFsaCriteriaMap);
			setOrderNumberFields(fsaCriteriaModifyVO);
			fsaCriteriaModifyVO.setVinGroupVO(vinGroupVO);
			fsaCriteriaModifyVO.setStatusCode("200");
			fsaCriteriaModifyVO.setStatusDesc("Process executed successfully");
		}
		
		return fsaCriteriaModifyVO;
	}
	
	private FsaCriteriaModifySaveVO processFirstOutputRecords(List<String> firstOutputParamList) {
		List<FsaCriteriaFilterOutputVO> filterOutputVOs = new ArrayList<>();
		FsaCriteriaModifySaveVO criteriaModifySaveVO = new FsaCriteriaModifySaveVO(); 
		if (firstOutputParamList != null && !firstOutputParamList.isEmpty()) {
			int counter = 1;
			for (String recordData : firstOutputParamList) {
				if (recordData != null && recordData.trim().length() > 0) {
					FsaCriteriaFilterOutputVO fsaCriteriaFilterOutputVO = new FsaCriteriaFilterOutputVO();
					fsaCriteriaFilterOutputVO.setFilterCode(recordData.substring(0, 9).trim());
					fsaCriteriaFilterOutputVO.setFilterDesc(recordData.substring(9, 9 + 30).trim());
					fsaCriteriaFilterOutputVO.setFormattedFilterCode(
							String.valueOf(Integer.parseInt(fsaCriteriaFilterOutputVO.getFilterCode())));
					fsaCriteriaFilterOutputVO.setVehAttrDesc(recordData.substring(9 + 30 + 83, 30 + 83 + 30 + 10).trim());
					fsaCriteriaFilterOutputVO.setVehAttrVal(recordData.substring(9 + 30, 30 + 83).trim());
					fsaCriteriaFilterOutputVO.setVehAttrEnd(recordData.substring(9 + 30 + 83 + 30 + 83, 30 + 83 + 30 + 83 + 83).trim());
					fsaCriteriaFilterOutputVO.setVehAttrBegin(recordData.substring(9 + 30 + 83 + 30, 30 + 83 + 30 + 83).trim());
					fsaCriteriaFilterOutputVO.setOrderNumber(recordData.substring(9 + 30 + 83 + 30 + 83 + 83 + 10 + 1).trim());
					fsaCriteriaFilterOutputVO.setOperator(recordData.substring(9 + 30 + 83 + 30 + 83 + 83, 30 + 83 + 30 + 83 + 83 + 10 + 1).trim());
					fsaCriteriaFilterOutputVO.setRowId(counter);
					filterOutputVOs.add(fsaCriteriaFilterOutputVO);
					counter++;
				}

			}
			criteriaModifySaveVO.setFirstOutputResults(filterOutputVOs);
			criteriaModifySaveVO.setRowId(counter);
		}
		return criteriaModifySaveVO;
	}
	
	
	
	private List<FsaCriteriaFilterOutputVO> processSecondOutputRecords(List<String> secondOutputParamList, int rowId) {
		List<FsaCriteriaFilterOutputVO> filterOutputVOs = new ArrayList<>();
		
		if (CollectionUtils.isNotEmpty(secondOutputParamList)) {
			int counter = rowId;
			for (String recordData : secondOutputParamList) {
				if (recordData != null && recordData.trim().length() > 0) {
					FsaCriteriaFilterOutputVO fsaCriteriaFilterOutputVO = new FsaCriteriaFilterOutputVO();
					fsaCriteriaFilterOutputVO.setFilterCode(recordData.substring(0, 9).trim());
					fsaCriteriaFilterOutputVO.setFormattedFilterCode(
							String.valueOf(Integer.parseInt(fsaCriteriaFilterOutputVO.getFilterCode())));
					fsaCriteriaFilterOutputVO.setFilterDesc(recordData.substring(9, 9 + 30).trim());
					fsaCriteriaFilterOutputVO.setVehAttrVal(recordData.substring(9 + 30, 30 + 83).trim());
					fsaCriteriaFilterOutputVO.setVehAttrDesc(recordData.substring(9 + 30 + 83, 30 + 83 + 30 + 10).trim());
					fsaCriteriaFilterOutputVO.setVehAttrBegin(recordData.substring(9 + 30 + 83 + 30, 30 + 83 + 30 + 83).trim());
					fsaCriteriaFilterOutputVO.setVehAttrEnd(recordData.substring(9 + 30 + 83 + 30 + 83, 30 + 83 + 30 + 83 + 83).trim());
					fsaCriteriaFilterOutputVO.setOperator(recordData.substring(9 + 30 + 83 + 30 + 83 + 83, 30 + 83 + 30 + 83 + 83 + 10 + 1).trim());
					fsaCriteriaFilterOutputVO.setOrderNumber(recordData.substring(9 + 30 + 83 + 30 + 83 + 83 + 10 + 1).trim());
					counter++;
					fsaCriteriaFilterOutputVO.setRowId(counter);
					filterOutputVOs.add(fsaCriteriaFilterOutputVO);
					
				}

			}
		}
		return filterOutputVOs;
	}

	private FsaCriteriaEditVO setFsaCriteriaResults(Map<String, List<FsaCriteriaFilterOutputVO>> fsaCriteriaMap) {
		FsaCriteriaEditVO fsaCriteriaModifyVO = new FsaCriteriaEditVO();
		List<FsaCriteriaFilterFields> criteriaFilterFields = fsaCriteriaDAO.getFsaCriteriaFilters();

		Map<String, List<FsaCriteriaFilterFields>> fsaCriteriaFilterMap = criteriaFilterFields.stream()
				.collect(Collectors.groupingBy(FsaCriteriaFilterFields::getFilterGroup));
		List<VehicleModelVO> models = getModelList(fsaCriteriaMap);
		fsaCriteriaMap.remove(fsaCriteriaConfiguration.getModelFilterCode());
		fsaCriteriaModifyVO.setModels(models);
		List<BrandVO> brands = getBrandList(fsaCriteriaMap);
		fsaCriteriaMap.remove(fsaCriteriaConfiguration.getBrandFilterCode());
		fsaCriteriaModifyVO.setBrands(brands);
		List<VehicleLineVO> vehicleLine = getVehicleLineList(fsaCriteriaMap);
		fsaCriteriaMap.remove(fsaCriteriaConfiguration.getVehLineFilterCode());
		fsaCriteriaModifyVO.setVehicleLine(vehicleLine);
		List<VehicleAssemblyPlantVO> assemblyPlants = getVehicleAssemblyList(fsaCriteriaMap);
		fsaCriteriaMap.remove(fsaCriteriaConfiguration.getAssemblyPlantFilterCode());
		fsaCriteriaModifyVO.setAssemblyPlants(assemblyPlants);
		VehicleProductionVO productionVO = getVehicleProduction(fsaCriteriaMap);
		fsaCriteriaModifyVO.setProductionVO(productionVO);
		fsaCriteriaMap.remove(fsaCriteriaConfiguration.getProductionFilterCode());
		// VIN Range(Not request in the response for existing saved records)
		fsaCriteriaMap.remove(fsaCriteriaConfiguration.getVinRangeFilterCode()); 
		// Excluded Warranty Cancellations(Not request in the response for existing saved records)
		fsaCriteriaMap.remove(fsaCriteriaConfiguration.getWarrantyFilterCode()); 
		List<FsaCriteriaFilterFields> wersCriteriaFileds = fsaCriteriaFilterMap.get(fsaCriteriaConfiguration.getWersFilterCode());
		List<VehicleWersVO> wersVO = getWersDetails(wersCriteriaFileds, fsaCriteriaMap);
		fsaCriteriaModifyVO.setWersVO(wersVO);
		fsaCriteriaMap.remove(fsaCriteriaConfiguration.getWersFilterCode());
		List<AttributeGroupingVO> vehicleAttributeGroups = getVehicleAttrGroups(fsaCriteriaMap, criteriaFilterFields);
		fsaCriteriaModifyVO.setVehicleAttributeGroups(vehicleAttributeGroups);
		return fsaCriteriaModifyVO;

	}

	private List<AttributeGroupingVO> getVehicleAttrGroups(Map<String, List<FsaCriteriaFilterOutputVO>> fsaCriteriaMap, List<FsaCriteriaFilterFields> criteriaFilterFields) {
		List<AttributeGroupingVO> vehicleAttributeGroups = new ArrayList<>();
		Map<String, FsaCriteriaFilterFields> fsaCriteriaFilterMap = getFsaFilterCriteriaMappingDetails(criteriaFilterFields);
		Set<String> filterKeys = fsaCriteriaMap.keySet();
		filterKeys.forEach(filter -> {
			List<FsaCriteriaFilterOutputVO> fsaCriteria = fsaCriteriaMap.get(filter);
			if (fsaCriteria != null && !fsaCriteria.isEmpty()) {
				fsaCriteria.forEach(vehicleAttr -> {
					if (vehicleAttr.getFilterCode() != null) {
						
						FsaCriteriaFilterFields criteriaFilterField = getFsaCriteriaFilterGroup(fsaCriteriaFilterMap, vehicleAttr.getFilterCode());
						if(criteriaFilterField!=null && !criteriaFilterField.getFilterGroup().trim().equalsIgnoreCase(fsaCriteriaConfiguration.getWersFilterCode())) {
							AttributeGroupingVO attributeGroupingVO = new AttributeGroupingVO();
							attributeGroupingVO.setAttributeGroupCode(criteriaFilterField.getFilterGroup());
							attributeGroupingVO.setAttributeGroupDesc(criteriaFilterField.getFilterGroupName());
							attributeGroupingVO.setOperator(processAttributeGroupOperator(vehicleAttr));
							setVehicleAttributeOnModify(vehicleAttr, criteriaFilterField, attributeGroupingVO);
							attributeGroupingVO.setOrderNumber(vehicleAttr.getOrderNumber());
							attributeGroupingVO.setRowId(vehicleAttr.getRowId());
							vehicleAttributeGroups.add(attributeGroupingVO);
						}
						
					}

				});
			}
		});

		return vehicleAttributeGroups;

	}
	
	private void setVehicleAttributeOnModify(FsaCriteriaFilterOutputVO vehicleAttr, FsaCriteriaFilterFields criteriaFilterField, AttributeGroupingVO attributeGroupingVO) {
		if(criteriaFilterField.getFilterGroup().equalsIgnoreCase(fsaCriteriaConfiguration.getTraceabilityAttrCode())) {
			if(StringUtils.isNotBlank(vehicleAttr.getOperator())) {
				attributeGroupingVO.setVehicleAttrBegin(StringUtils.EMPTY);
				attributeGroupingVO.setVehicleAttrEnd(StringUtils.EMPTY);
				String attributeValue = vehicleAttr.getVehAttrVal();
				if(StringUtils.startsWith(attributeValue, "EN ")) {
					attributeGroupingVO.setVehicleAttrValue(vehicleAttr.getVehAttrVal().replace("EN ", ""));
					attributeGroupingVO.setVehicleAttributeCode("EN");
					attributeGroupingVO.setVehicleAttributeDesc(fsaCriteriaConfiguration.getTraceabilityEngineAttrDesc());
				} else {
					attributeGroupingVO.setVehicleAttrValue(vehicleAttr.getVehAttrVal().replace("TR ", ""));
					attributeGroupingVO.setVehicleAttributeCode("TR");
					attributeGroupingVO.setVehicleAttributeDesc(fsaCriteriaConfiguration.getTraceabilityTransmisionAttrDesc());
				}
			} else {
				String attributeValue = vehicleAttr.getVehAttrBegin();
				if(StringUtils.startsWith(attributeValue, "EN ")) {
					attributeGroupingVO.setVehicleAttrBegin(vehicleAttr.getVehAttrBegin().replace("EN ", ""));
					attributeGroupingVO.setVehicleAttrEnd(vehicleAttr.getVehAttrEnd().replace("EN ", ""));
					attributeGroupingVO.setVehicleAttributeCode("EN");
					attributeGroupingVO.setVehicleAttributeDesc(fsaCriteriaConfiguration.getTraceabilityEngineAttrDesc());
				} else {
					attributeGroupingVO.setVehicleAttrBegin(vehicleAttr.getVehAttrBegin().replace("TR ", ""));
					attributeGroupingVO.setVehicleAttrEnd(vehicleAttr.getVehAttrEnd().replace("TR ", ""));
					attributeGroupingVO.setVehicleAttributeCode("TR");
					attributeGroupingVO.setVehicleAttributeDesc(fsaCriteriaConfiguration.getTraceabilityTransmisionAttrDesc());
				}
				attributeGroupingVO.setVehicleAttrValue(StringUtils.EMPTY);
			}
		} else {
			attributeGroupingVO.setVehicleAttrBegin(vehicleAttr.getVehAttrBegin().equals(CommonConstants.INVALID_DATE)?StringUtils.EMPTY:formatDate(vehicleAttr.getVehAttrBegin(), CommonConstants.YYYY_MM_DD, CommonConstants.DD_MM_YYYY));
			attributeGroupingVO.setVehicleAttrEnd(formatDate(vehicleAttr.getVehAttrEnd(), CommonConstants.YYYY_MM_DD, CommonConstants.DD_MM_YYYY));
			attributeGroupingVO.setVehicleAttributeCode(vehicleAttr.getFilterCode());
			attributeGroupingVO.setVehicleAttributeDesc(vehicleAttr.getFilterDesc());
			attributeGroupingVO.setVehicleAttrValue(vehicleAttr.getVehAttrVal());
		}
	}
	
	private FsaCriteriaFilterFields getFsaCriteriaFilterGroup(Map<String, FsaCriteriaFilterFields> fsaCriteriaFilterMap, String filterCode) {
		return fsaCriteriaFilterMap.get(String.valueOf(Integer.valueOf(filterCode)));
	}

	private List<VehicleWersVO> getWersDetails(List<FsaCriteriaFilterFields> wersCriteriaFields,
			Map<String, List<FsaCriteriaFilterOutputVO>> fsaCriteriaMap) {
		List<VehicleWersVO> wersVO = new ArrayList<>();
		if(wersCriteriaFields!=null) {
			wersCriteriaFields.forEach(wersCode -> {
				List<FsaCriteriaFilterOutputVO> wersValues = fsaCriteriaMap.get(wersCode.getFilterCode());
				if (wersValues != null && !wersValues.isEmpty()) {
					wersValues.forEach(werValue -> {
						VehicleWersVO vehicleWersVO = new VehicleWersVO();
						String wersValueCode = StringUtils.trimToEmpty(werValue.getVehAttrVal());
						String wersFamilyCode = (StringUtils.isNotBlank(wersValueCode) && wersValueCode.length() > 3 ) ? wersValueCode.substring(0,3):StringUtils.EMPTY;
						vehicleWersVO.setMappedFilterCode(Integer.valueOf(werValue.getFilterCode()));
						vehicleWersVO.setWersFilterCode(String.valueOf(Integer.valueOf(werValue.getFilterCode())));
						vehicleWersVO.setWersFilterDesc(TargetingUtil.getWersDescWithFamilyCode(werValue.getFilterDesc(), wersFamilyCode));
						vehicleWersVO.setWersOperator(processWersNotEqualOperator(werValue.getOperator()));
						vehicleWersVO.setWersValueCode(wersValueCode);
						vehicleWersVO.setWersValueDesc(werValue.getVehAttrDesc() +" ("+werValue.getVehAttrVal()+")");
						vehicleWersVO.setOrderNumber(werValue.getOrderNumber());
						vehicleWersVO.setRowId(werValue.getRowId());
						wersVO.add(vehicleWersVO);
					});
				}
			});
		}
		
		return wersVO;

	}
	
	private String processAttributeGroupOperator(FsaCriteriaFilterOutputVO vehicleAttr) {
		String operatorText;
		String attributeOperator = vehicleAttr.getOperator().trim();
		if (StringUtils.isNotBlank(vehicleAttr.getVehAttrBegin()) && StringUtils.isNotBlank(vehicleAttr.getVehAttrEnd()) 
				&& StringUtils.contains(vehicleAttr.getVehAttrBegin(), "-") && StringUtils.contains(vehicleAttr.getVehAttrEnd(), "-")) {
			operatorText = "Between";
		} else if(StringUtils.isNotBlank(attributeOperator) && StringUtils.equalsAnyIgnoreCase(attributeOperator, "=") && (StringUtils.isBlank(vehicleAttr.getVehAttrBegin()) || StringUtils.equals(vehicleAttr.getVehAttrBegin(), CommonConstants.INVALID_DATE)) && StringUtils.isBlank(vehicleAttr.getVehAttrVal())) {
			operatorText = IS_NULL_OPERATOR;
		}else if(StringUtils.isNotBlank(attributeOperator) && StringUtils.equalsAnyIgnoreCase(attributeOperator, ">") && (StringUtils.isBlank(vehicleAttr.getVehAttrBegin()) || StringUtils.equals(vehicleAttr.getVehAttrBegin(), CommonConstants.INVALID_DATE)) && StringUtils.isBlank(vehicleAttr.getVehAttrVal())) {
			operatorText = IS_NOTNULL_OPERATOR;
		} else if(StringUtils.isNotBlank(attributeOperator) && StringUtils.equalsAnyIgnoreCase(attributeOperator, "<>")) {
			operatorText = "!=";
		}else {
			operatorText = vehicleAttr.getOperator();
		}
		return operatorText;
	}

	private String processWersNotEqualOperator(String operator) {
		if (operator != null && !operator.isEmpty()
				&& ("!".equalsIgnoreCase(operator.trim()) || "<".equalsIgnoreCase(operator.trim()) || "<>".equalsIgnoreCase(operator.trim()))) {
			return "!=";
		} else {
			return operator;
		}
	}

	private VehicleProductionVO getVehicleProduction(Map<String, List<FsaCriteriaFilterOutputVO>> fsaCriteriaMap) {
		VehicleProductionVO productionVO = new VehicleProductionVO();
		List<FsaCriteriaFilterOutputVO> vehicleProd = fsaCriteriaMap.get(fsaCriteriaConfiguration.getProductionFilterCode());

		if (CollectionUtils.isNotEmpty(vehicleProd)) {
			vehicleProd.forEach(vehProd -> {
				if(!StringUtils.equalsIgnoreCase(vehProd.getVehAttrBegin(), CommonConstants.INVALID_DATE)) {
					productionVO.setProdStartDate(formatDate(vehProd.getVehAttrBegin(), CommonConstants.YYYY_MM_DD, CommonConstants.DD_MM_YYYY));
				}
				if(!StringUtils.equalsIgnoreCase(vehProd.getVehAttrEnd(), CommonConstants.DEFAULT_END_DATE) && !StringUtils.equalsIgnoreCase(vehProd.getVehAttrEnd(), CommonConstants.INVALID_DATE)) {
					productionVO.setProdEndDate(formatDate(vehProd.getVehAttrEnd(),  CommonConstants.YYYY_MM_DD, CommonConstants.DD_MM_YYYY));
				}
				productionVO.setProdFilterCode(TargetingUtil.fillWithZeros(vehProd.getFilterCode(), 9));
				productionVO.setProdFilterName(vehProd.getFilterDesc());
				productionVO.setOrderNumber(vehProd.getOrderNumber());
				productionVO.setRowId(vehProd.getRowId());
			});
		} else {
			productionVO.setProdFilterCode(TargetingUtil.fillWithZeros(fsaCriteriaConfiguration.getProductionFilterCode(), 9));
		}
		return productionVO;
	}
	
	private String formatDate(String attributeValue, String srcDateFormat, String destDateFormat) {
		SimpleDateFormat dateFormatSrc = new SimpleDateFormat(srcDateFormat);
		SimpleDateFormat dateFormatDest = new SimpleDateFormat(destDateFormat);
		if(StringUtils.isBlank(attributeValue)) {
			return StringUtils.EMPTY;
		} else if(attributeValue.contains("-")) {
			try {
				return dateFormatDest.format(dateFormatSrc.parse(attributeValue.trim()));
			} catch (ParseException e) {
				log.error("Error while parsing date", e);
			}
		}
		return attributeValue;
	}

	private List<VehicleAssemblyPlantVO> getVehicleAssemblyList(
			Map<String, List<FsaCriteriaFilterOutputVO>> fsaCriteriaMap) {
		List<VehicleAssemblyPlantVO> assemblyPlants = new ArrayList<>();
		List<FsaCriteriaFilterOutputVO> vehicleAttrDetail = fsaCriteriaMap.get(fsaCriteriaConfiguration.getAssemblyPlantFilterCode());

		if (vehicleAttrDetail != null && !vehicleAttrDetail.isEmpty()) {
			vehicleAttrDetail.forEach(assemblyPlant -> {
				VehicleAssemblyPlantVO vehicleAssemblyVO = new VehicleAssemblyPlantVO();
				vehicleAssemblyVO.setAssemblyPlantCode(assemblyPlant.getVehAttrVal());
				vehicleAssemblyVO.setAssemblyPlantDesc(assemblyPlant.getVehAttrDesc() +" ("+assemblyPlant.getVehAttrVal()+")");
				vehicleAssemblyVO.setAssemblyPlantFilterCode(TargetingUtil.fillWithZeros(assemblyPlant.getFilterCode(), 9));
				vehicleAssemblyVO.setOrderNumber(assemblyPlant.getOrderNumber());
				vehicleAssemblyVO.setRowId(assemblyPlant.getRowId());
				assemblyPlants.add(vehicleAssemblyVO);
			});
		}

		return assemblyPlants;
	}

	private List<VehicleLineVO> getVehicleLineList(Map<String, List<FsaCriteriaFilterOutputVO>> fsaCriteriaMap) {
		List<VehicleLineVO> vehicleLines = new ArrayList<>();
		List<FsaCriteriaFilterOutputVO> vehicleLineCriteria = fsaCriteriaMap.get(fsaCriteriaConfiguration.getVehLineFilterCode());
		if(vehicleLineCriteria != null && !vehicleLineCriteria.isEmpty()) {
			vehicleLineCriteria.forEach(vehLine -> {
				VehicleLineVO vehicleLineVO = new VehicleLineVO();
				vehicleLineVO.setVehicleLineCode(vehLine.getVehAttrVal());
				vehicleLineVO.setVehicleLineDesc(vehLine.getVehAttrDesc()+" ("+vehLine.getVehAttrVal()+")");
				vehicleLineVO.setVehicleLineFilterCode(TargetingUtil.fillWithZeros(vehLine.getFilterCode(), 9));
				vehicleLineVO.setOrderNumber(vehLine.getOrderNumber());
				vehicleLineVO.setRowId(vehLine.getRowId());
				vehicleLines.add(vehicleLineVO);
			});
		}
		
		return vehicleLines;
	}

	private List<VehicleModelVO> getModelList(Map<String, List<FsaCriteriaFilterOutputVO>> fsaCriteriaMap) {
		List<VehicleModelVO> vehicleModels = new ArrayList<>();
		List<FsaCriteriaFilterOutputVO> modelCriteria = fsaCriteriaMap.get(fsaCriteriaConfiguration.getModelFilterCode());
		if(modelCriteria != null && !modelCriteria.isEmpty()) {
			modelCriteria.forEach(model -> {
				VehicleModelVO vehicleModelVO = new VehicleModelVO();
				vehicleModelVO.setModelCode(model.getVehAttrVal());
				vehicleModelVO.setModelDesc(model.getVehAttrVal());
				vehicleModelVO.setModelFilterCode(TargetingUtil.fillWithZeros(model.getFilterCode(), 9));
				vehicleModelVO.setOperator("<>".equals(model.getOperator())?"!=":model.getOperator());
				vehicleModelVO.setOrderNumber(model.getOrderNumber());
				vehicleModelVO.setRowId(model.getRowId());
				vehicleModels.add(vehicleModelVO);
			});
		}
		
		return vehicleModels;
	}

	private List<BrandVO> getBrandList(Map<String, List<FsaCriteriaFilterOutputVO>> fsaCriteriaMap) {
		List<BrandVO> brands = new ArrayList<>();
		List<FsaCriteriaFilterOutputVO> brandCritria = fsaCriteriaMap.get(fsaCriteriaConfiguration.getBrandFilterCode());
		if(brandCritria != null && !brandCritria.isEmpty()) {
			brandCritria.forEach(brand -> {
				BrandVO brandVO = new BrandVO();
				brandVO.setBrandCode(brand.getVehAttrVal());
				brandVO.setBrandName(brand.getVehAttrDesc());
				brandVO.setBrandFilterCode(TargetingUtil.fillWithZeros(brand.getFilterCode(), 9));
				brandVO.setOrderNumber(brand.getOrderNumber());
				brandVO.setRowId(brand.getRowId());
				brands.add(brandVO);
			});
		}
		
		return brands;
	}

	private Map<String, FsaCriteriaFilterFields> getFsaFilterCriteriaMappingDetails(List<FsaCriteriaFilterFields> criteriaFilterFields) {
		Map<String, String> fsaCriteriaFilterGroup = fsaCriteriaDAO.getFsaCriteriaGroupFilters();
		criteriaFilterFields.forEach(fsaCriteria -> fsaCriteria.setFilterGroupName(fsaCriteriaFilterGroup.get(fsaCriteria.getFilterGroup())));
		return criteriaFilterFields.stream()
			      .collect(Collectors.toMap(FsaCriteriaFilterFields::getFilterCode, fsaCriteriaGroup -> fsaCriteriaGroup));

	}
	
	private String returnOperatorSymbol(String operatorText) {
		if(operatorText == null || operatorText.trim().length()==0) {
			return "=";
		}else if("!=".equalsIgnoreCase(operatorText.trim())) {
			return "<>";
		}
		
		return operatorText;
			
	}
	
	private FsaCriteriaError getErrorDetails(String dbErrorDetails) {
		FsaCriteriaError criteriaError = new FsaCriteriaError();
		criteriaError.setErrorInd(dbErrorDetails.substring(9, 10));
		criteriaError.setErrorFlag(dbErrorDetails.substring(10, 13));
		criteriaError.setErrorCode(dbErrorDetails.substring(37, 40));
		criteriaError.setErrorMessage(dbErrorDetails.substring(40, 150));
		return criteriaError;
	}

}
