package com.ford.gcamp.targeting.reports.batch.common;

public class ReportConstants {

	public static final String READER_NAME_SUFFIX = "itemReader";

	public static final String WRITER_NAME_SUFFIX = "itemWriter";

	public static final String COMPLETED_JOBS_STORE_PROC = "CSGCSG19";

	public static final String COMPLETED_JOBS_STORE_PROC_NEW = "CSGCSG24";

	public static final String REPORT_SERVICE_PROC_NAME = "CSGCSG20";

	public static final String BLOB_KEY_PROC_NAME = "CSGCSG22";

	public static final String REPORT_ALL_POPULATION_STORED_PROC_NAME = "CSGCSC41";

	public static final String REPORT_ORIG_SUPPL_STORED_PROC_NAME = "CSGCSA41";

	public static final String EXCEPTION_REPORT_STORE_PROC = "CSGCSA42";

	public static final String DIST_PROC_NAME = "CSGCSJ18";

	public static final String BLOB_TABLE_SUFFIX = "H00";

	public static final String BMP_FLAG = "S";

	public static final int FETCH_SIZE = 1000000;
	
	public static final int EXP_REPORT_FETCH_SIZE = 2000000;

	public static final String ALL_POPULATION = "*";

	public static final String SUPPLEMENT_CODE = "Supplement Code";

	public static final String SUPPLEMENT_DESCRIPTION = "Supplement Description";

	/**
	 * Constant for REPORT ID key, which would be used to get the value of Report Id
	 * from the (inputURLMap) HashMap using getKeyValue function.
	 */
	public static final String RPT_ID = "RPT_ID";

	/**
	 * Constant for REQUESTOR CDSID key, which would be used to get the value of the
	 * requestor CDSID from the (inputURLMap) HashMap using getKeyValue function.
	 */
	public static final String RPT_REQID = "RPT_REQID";
	public static final String REQ_CDSID = "REQ_CDSID";

	/**
	 * Constant for JOB QUEUE ID key, which would be used to get the value of Job
	 * Queue Id from the (inputURLMap) HashMap using getKeyValue function.
	 */
	public static final String JOB_QUE = "JOB_QUE";

	/**
	 * Constant for REPORT CODE key, which would be used to get the value of Report
	 * Code from the (inputURLMap) HashMap using getKeyValue function.
	 * 
	 *
	 */

	/**
	 * Constant for LANGUAGE key, which would be used to get the value of Language
	 * from the HashMap (inputURLMap) using getKeyValue function.
	 */
	public static final String LANG = "LANG";

	/**
	 * Constant for SCRIPT key, which would be used to get the value of Language
	 * from the HashMap (inputURLMap) using getKeyValue function.
	 */
	public static final String SCRIPT = "SCRIPT";

	/**
	 * Constant for REGION key, which would be used to get the value of Language
	 * from the HashMap (inputURLMap) using getKeyValue function.
	 */
	public static final String REGION = "REGION";

	/**
	 * Constant for RPT_CD key, which would be used to get the value of Language
	 * from the HashMap (inputURLMap) using getKeyValue function.
	 */
	public static final String RPT_CD = "RPT_CD";

	public static final String RPT_CODE = "RPT_CODE";

	public static final String WERS_RPT_CODE = "WERS";

	/**
	 * Constant for REPORT FORMAT key, which would be used to get the value of
	 * Report Format from the HashMap (inputURLMap) using getKeyValue
	 * function.DESFORMAT IS CHANGED ACCORDINGLY TO REFLECT THE ORACLE
	 */

	public static final String DESFORMAT = "DESFORMAT";

	/**
	 * Constant for REPORT STATUS key, which would be used to get the value of
	 * Report Status from the HashMap (inputURLMap) using getKeyValue function.
	 */
	public static final String RPT_STATUS = "RPT_STATUS";

	/**
	 * Constant for PERIOD END DATE key, which would be used to get the value of
	 * Period End Date from the HashMap (inputURLMap) using getKeyValue function.
	 */
	public static final String PRD_END_DT = "PRD_END_DT";

	/**
	 * Constant for LAUNCH FROM DATE key, which would be used to get the value of
	 * Launch From Date from the HashMap (inputURLMap) using getKeyValue function.
	 */
	public static final String LAUNCH_FROM_DT = "LAUNCH_FROM_DT";

	/**
	 * Constant for LAUNCH FROM DATE key, which would be used to get the value of
	 * Launch From Date from the HashMap (inputURLMap) using getKeyValue function.
	 * used in performance reports
	 */
	public static final String LAUNCH_FR_DT = "LAUNCH_FR_DT";

	/**
	 * Constant for LAUNCH TO DATE key, which would be used to get the value of
	 * Launch To Date from the HashMap (inputURLMap) using getKeyValue function.
	 */
	public static final String LAUNCH_TO_DT = "LAUNCH_TO_DT";

	/**
	 * Constant for HUB CODE key, which would be used to get the value of Hub Code
	 * from the HashMap (inputURLMap) using getKeyValue function.
	 */
	public static final String HUB_CD = "HUB_CD";

	/**
	 * Constant for HUB DESC key, which would be used to get the value of Hub Code
	 * from the HashMap (inputURLMap) using getKeyValue function.
	 */
	public static final String HUB_DESC = "HUB_DESC";

	/**
	 * Constant for COUNTRY CODE key, which would be used to get the value of
	 * Country Code from the HashMap (inputURLMap) using getKeyValue function.
	 */
	public static final String COUNTRY_CD = "COUNTRY_CD";

	/**
	 * Constant for COUNTRY NAME key, which would be used to get the value of
	 * Country Name from the HashMap (inputURLMap) using getKeyValue function.
	 */
	public static final String COUNTRY_NAME = "COUNTRY_NAME";

	/**
	 * Constant for DISTRIBUTION LIST FLAG key, which would be used to get the value
	 * of Distribution List Flag from the HashMap (inputURLMap) using getKeyValue
	 * function.
	 */
	public static final String DIST_LIST_F = "DIST_LIST_F";

	/**
	 * Constant for GLOBAL FSA NUM key, which would be used to get the value of
	 * Distribution List Flag from the HashMap (inputURLMap) using getKeyValue
	 * function.
	 */
	public static final String GLOBAL_FSA_N = "GLOBAL_FSA_N";

	/**
	 * Constant for SUPPLEMENT CODE key, which would be used to get the value of
	 * Supplement Code from the HashMap (inputURLMap) using getKeyValue function.
	 */
	public static final String SUPP_CD = "SUPP_CD";

	/**
	 * Constant for REPORT NAME key, which would be used to get the value of Report
	 * Name from the HashMap (inputURLMap) using getKeyValue function.
	 */
	public static final String RPT_NAME = "RPT_NAME";

	/**
	 * Constant for LAUNCN DATE key, which would be used to get the value of Launch
	 * Date from the HashMap (inputURLMap) using getKeyValue function.
	 */
	public static final String LAUNCH_DT = "LAUNCH_DT";

	/**
	 * Constant for REPORT END DATE key, which would be used to get the value of
	 * Report End Date from the HashMap (inputURLMap) using getKeyValue function.
	 */
	public static final String RPT_END_DT = "RPT_END_DT";

	/**
	 * Constant for EMAIL CODE key, which would be used to get the value of Email
	 * Code from the HashMap (inputURLMap) using getKeyValue function.
	 */
	public static final String EMAIL_CODE = "EMAIL_CODE";

	/**
	 * Constant for REGION CODE key, which would be used to get the value of Region
	 * Code from the HashMap (inputURLMap) using getKeyValue function.
	 */
	public static final String REGION_CODE = "REGION_CODE";

	/**
	 * Constant for ZONE CODE key, which would be used to get the value of Zone Code
	 * from the HashMap (inputURLMap) using getKeyValue function.
	 */
	public static final String ZONE_CODE = "ZONE_CODE";

	/**
	 * Constant for DEALER NAME key, which would be used to get the value of Dealer
	 * Name from the HashMap (inputURLMap) using getKeyValue function.
	 */
	public static final String DEALER_NAME = "DEALER_NAME";

	/**
	 * Constant for REPORT END NOTE key, which would be used to get the value of
	 * Footnote Name from the HashMap (inputURLMap) using getKeyValue function.
	 */
	public static final String FOOTNOTE = "FOOTNOTE";

	/**
	 * Constant for REPORT key, which would be used to get the value of ROI code
	 * from the HashMap (inputURLMap) using getKeyValue function.
	 */
	public static final String ROI_CODE = "ROI_CODE";

	/**
	 * Constant for REQ_TS key, which would be used to get the value of Dealer Name
	 * from the HashMap (inputURLMap) using getKeyValue function.
	 */
	public static final String REQ_TS = "REQ_TS";

	/**
	 * Constant for ROI_CD key, which would be used to get the value of ROI_CD from
	 * the HashMap (inputURLMap) using getKeyValue function.
	 */
	public static final String ROI_CD = "ROI_CD";

	/**
	 * Constant for AGENCY_CD key, which would be used to get the value of AGENCY_CD
	 * from the HashMap (inputURLMap) using getKeyValue function.
	 */

	public static final String AGENCY_CD = "AGENCY_CD";

	/**
	 * Constant for PROCESS_CD key, which would be used to get the value of
	 * PROCESS_CD from the HashMap (inputURLMap) using getKeyValue function.
	 */

	public static final String PROCESS_ID = "PROCESS_ID";

	/**
	 * Constant for GLOBAL_FSA_NUM key, which would be used to get the value of
	 * GLOBAL_FSA_NUM from the HashMap (inputURLMap) using getKeyValue function.
	 */

	public static final String GLOBAL_FSA_NUM = "GLOBAL_FSA_NUM";

	/**
	 * Constant for REGION_DESC key, which would be used to get the value of
	 * REGION_DESC from the HashMap (inputURLMap) using getKeyValue function.
	 */

	public static final String REGION_DESC = "REGION_DESC";

	/**
	 * Constant for ZONE_DESC key, which would be used to get the value of ZONE_DESC
	 * from the HashMap (inputURLMap) using getKeyValue function.
	 */
	public static final String ZONE_DESC = "ZONE_DESC";

	/**
	 * Constant for GLOBAL_FSA_DESC key, which would be used to get the value of
	 * GLOBAL_FSA_DESC from the HashMap (inputURLMap) using getKeyValue function.
	 */
	public static final String GLOBAL_FSA_DESC = "GLOBAL_FSA_DESC";

	/**
	 * Constant for REPORT key, which would be used to get the value of REPORT from
	 * the HashMap (inputURLMap) using getKeyValue function.
	 */

	public static final String REPORT = "REPORT";

	/**
	 * Constant for MANUF key, which would be used to get the value of MANUF from
	 * the HashMap (inputURLMap) using getKeyValue function.
	 */
	public static final String MANUF = "MANUF";

	/**
	 * Constant for AGENCY_DESC key, which would be used to get the value of
	 * AGENCY_DESC from the HashMap (inputURLMap) using getKeyValue function.
	 */
	public static final String AGENCY_DESC = "AGENCY_DESC";

	/**
	 * Constant for AGENCY_FOOTER key, which would be used to get the value of
	 * AGENCY_FOOTER from the HashMap (inputURLMap) using getKeyValue function.
	 */
	public static final String AGENCY_FOOTER = "AGENCY_FOOTER";

	/**
	 * Constant for CYCLE key, which would be used to get the value of CYCLE from
	 * the HashMap (inputURLMap) using getKeyValue function.
	 */
	public static final String CYCLE = "CYCLE";

	/**
	 * Constant for BATCU CODE key, which would be used to get the value of BATCH_CD
	 * from the HashMap (inputURLMap) using getKeyValue function.
	 */
	public static final String BATCH_CD = "BATCH_CD";

	/**
	 * Constant for WS_URL_TOKEN key, which would be as a URL seperator used to
	 * parse the input URL and build the HashMap (inputURLMap)
	 */
	public static final String WS_URL_TOKEN = "~&";

	/**
	 * Constant for PGM_DATA key, which would be as a URL seperator used to parse
	 * the input URL and build the HashMap (inputURLMap) added for QOS and
	 * performance reports
	 */
	public static final String PGM_DATA = "PGM_DATA";

	public static final String OPTION_CODE = "OPTION_CODE";

	public static final String FSA_FORMAT = "FSA_FMT";

	public static final String RPT_DESC = "RPT_DESC";

	public static final String MODEL_YEAR_FIELD = "modelYear";
	
	public static final String SALE_MODEL_YEAR_FIELD = "saleModelYear";

	public static final String PLANT_NAME_FIELD = "plantName";

	public static final String VIN_GROUP_FIELD = "vinGroup";

	public static final String DYNAMIC_COLUMN_CURRENTMY_PROP = " MY:saleModelYearCount";

	public static final String DYNAMIC_COLUMN_MY_PROP = " MY:count";

	public static final String DYNAMIC_COLUMN_EMPTY_PROP = " :count";

	public static final String DYNAMIC_COLUMN_SOLD_PROP = " Sold:soldCount";

	public static final String DYNAMIC_COLUMN_UNSOLD_PROP = " UnSold:unSoldCount";

	public static final String REPORT_SERVICE = "Reporting Service";

	public static final String SUBMITTED_BY = "<br>Report Submitted By ";

	public static final String META_DATA_TABLE = "SGCPF02_RPTCHILD ";

	public static final String FORD_EMAIL_DOMAIN = "@ford.com";

	public static final String FROM_KEYWORD = " FROM ";

	public static final String AND_KEYWORD = " AND ";
	
	public static final String REPORT_ID = ":reportId";
	
	public static final String NAVIS_FETCH_SUCCESS_MSG ="<br>NAVIS name and address fetch successfully completed";
		
	private ReportConstants() {}

}
