package com.ford.gcamp.targeting.frozenvin;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.ford.gcamp.targeting.common.CommonConstants;
import com.ford.gcamp.targeting.common.DateConvert;
import com.ford.gcamp.targeting.common.api.FSAInfoVO;
import com.ford.gcamp.targeting.frozenvin.api.FrozenVinHistResponse;
import com.ford.gcamp.targeting.frozenvin.api.FrozenVinResponseDTO;
import com.ford.gcamp.targeting.frozenvin.api.CountryList;
import com.ford.gcamp.targeting.frozenvin.api.FrozenHistory;
import com.ford.gcamp.targeting.frozenvin.api.GCPSupplementList;
import com.ford.gcamp.targeting.frozenvin.api.HubList;

@Component
public class FrozenVinStorProc {

	private static final Logger LOGGER = LoggerFactory.getLogger(FrozenVinStorProc.class);
	
	private static final String GCPA02_UPDATE_ID_C = "GCPA02_UPDATE_ID_C";
	private static final String GCPE10_HUB_C = "GCPE10_HUB_C";

	public FrozenVinResponseDTO invokeStorProc(Map<String, Object> mapResponse, String filterByFlag,String population) {
		FrozenVinResponseDTO frozenVinResponse = new FrozenVinResponseDTO();

		FSAInfoVO fsaInfoVO = new FSAInfoVO();
		List<HubList> listHub = new ArrayList<>();
		List<GCPSupplementList> listSupp = new ArrayList<>();
		String outPutFSA02 = null;
		String outPutFSA012 = null;

		String errorParam = (String) mapResponse.get("ERROR_PARM1");
		LOGGER.info("errorParam::{}", errorParam);
		String statusInd = errorParam.substring(9, 10);
		if (statusInd != null && "Y".equalsIgnoreCase(statusInd)) {
			String errorCode = errorParam.substring(37, 40);
			String errorDesc = errorParam.substring(40, 150);
			frozenVinResponse.setStatus(CommonConstants.FAILURE);
			frozenVinResponse.setStatusCode(CommonConstants.FAILURE_CODE);
			frozenVinResponse.setStatusDescription(errorCode + errorDesc);
		} else {

			@SuppressWarnings("unchecked")
			List<Map<String, Object>> supplmntList = (List<Map<String, Object>>) mapResponse.get("#result-set-1");
			listSupp = getSuppList(supplmntList,listSupp);
			
			@SuppressWarnings("unchecked")
			List<Map<String, Object>> hublists = (List<Map<String, Object>>) mapResponse.get("#result-set-2");
			listHub = getHubList(hublists, listHub, filterByFlag,population);
			

			for (Map.Entry<String, Object> entry : mapResponse.entrySet()) {
				if (entry.getKey().contains("OUTPUT_PARM1")) {
					outPutFSA02 = (String) entry.getValue();
					LOGGER.info("outparamlist: {} " , outPutFSA02);
				}
				if (entry.getKey().contains("OUTPUT_PARM2")) {
					outPutFSA012 = (String) entry.getValue();
					LOGGER.info("outparamlist: {}",outPutFSA012);
				}
			}
			fsaInfoVO.setString(outPutFSA02, outPutFSA012);
			frozenVinResponse.setFsaInfoVO(fsaInfoVO);
			frozenVinResponse.setHubList(listHub);
			frozenVinResponse.setSupllList(listSupp);
			frozenVinResponse.setStatus(CommonConstants.SUCCESS);
			frozenVinResponse.setStatusCode(CommonConstants.SUCCESS_CODE);
			frozenVinResponse.setStatusDescription(CommonConstants.SUCCESS_DESC);
		}
		
		return frozenVinResponse;
	}

	private List<HubList> getHubList(List<Map<String, Object>> hublists, List<HubList> listHub, String filterFlag,String population) {
		if (hublists != null) {
			String count=null;
			for (Map<String, Object> map1 : hublists) {
				
				count = getPopCount(population, map1);
				
				HubList hubList = new HubList();
				hubList.setHubCode(String.valueOf(map1.get(GCPE10_HUB_C)).trim());
				hubList.setHubDesc(String.valueOf(map1.get("GCPE10_HUB_DESC_X")).trim());
				hubList.setCountIsoC(String.valueOf(map1.get("COUNTRY_ISO3_C")).trim());
				hubList.setCountName(String.valueOf(map1.get("COUNTRY_NAME_X")).trim());
				setParamFiveValue(hubList, count);
				
				hubList.setFrznByC(String.valueOf(map1.get("GCPA17_FRZN_BY_C")).trim());
				hubList.setParmSev(DateConvert.getInstance().formatOutputDate(String.valueOf(map1.get("7"))));
				setUpdateIndCValue(hubList,map1);
				
				if(map1.get("9") != null) {
					hubList.setParamNine(String.valueOf(map1.get("9")).trim());
				}else {
					hubList.setParamNine("");
				}
				if ("C".equalsIgnoreCase(filterFlag)) {
					if(Integer.parseInt(hubList.getParamFive()) > 0) {
					listHub.add(hubList);
					}
				}else if("A".equalsIgnoreCase(filterFlag)) {
					listHub.add(hubList);
				}

			}
			
		}
		return listHub;
	}

	private String getPopCount(String population, Map<String, Object> map1) {
		if("00".equals(population)) {
			return String.valueOf(map1.get("5")).trim();
		}else {
			return String.valueOf(map1.get("GCPF24_COUNT_T")).trim();
		}
	}

	private void setUpdateIndCValue(HubList hubList, Map<String, Object> map1) {
		if(map1.get(GCPA02_UPDATE_ID_C) != null) {
			hubList.setUpdateIndC(String.valueOf(map1.get(GCPA02_UPDATE_ID_C)).trim());
		}else {
			hubList.setUpdateIndC("");
		}
	}

	private void setParamFiveValue(HubList hubList, String count) {
		if(!("null".equals(count))) {
			hubList.setParamFive(count);
		}else {
			hubList.setParamFive("0");
		}
		
	}

  private List<GCPSupplementList> getSuppList(List<Map<String, Object>> supplmntList,
			List<GCPSupplementList> listSupp) {
		if (supplmntList != null) {
			for (Map<String, Object> map1 : supplmntList) {
				GCPSupplementList suplmntList = new GCPSupplementList();
				suplmntList.setGcpSuppCode((String) map1.get("GCPA09_SUPPL_C"));
				suplmntList.setGcpsupDesc(String.valueOf(map1.get("GCPA09_SUPP_DESC_X")).trim());

				listSupp.add(suplmntList);

			}
		}
		return listSupp;
	}

	public FrozenVinHistResponse getHistoryOfFrozen(Map<String, Object> frozenMap, String filterFlag) {

		FrozenVinHistResponse frozenVinHistResponse = new FrozenVinHistResponse();
		String errorParam = (String) frozenMap.get("OERR1");
		LOGGER.info("errorParam::{}", errorParam);
		String statusInd = errorParam.substring(9, 10);
		if (statusInd != null && "Y".equalsIgnoreCase(statusInd)) {
			String errorCode = errorParam.substring(37, 40);
			String errorDesc = errorParam.substring(40, 150);
			frozenVinHistResponse.setStatus(CommonConstants.FAILURE);
			frozenVinHistResponse.setStatusCode(CommonConstants.FAILURE_CODE);
			frozenVinHistResponse.setStatusDescription(errorCode + errorDesc);
		} else {
			FSAInfoVO fsaInfoVO = new FSAInfoVO();
			String oparm1 = (String) frozenMap.get("OPARM1");
			String oparm12 = (String) frozenMap.get("OPARM2");
			fsaInfoVO.setString(oparm1, oparm12);
			frozenVinHistResponse.setFsaInfoVO(fsaInfoVO);
			List<FrozenHistory> hubList = new ArrayList<>();
			@SuppressWarnings("unchecked")
			List<Map<String, Object>> historyList = (List<Map<String, Object>>) frozenMap.get("#result-set-1");
			if (historyList != null) {
				hubList = getListOfHubs(historyList,filterFlag);
				

			}
			frozenVinHistResponse.setHubList(hubList);
			frozenVinHistResponse.setStatus(CommonConstants.SUCCESS);
			frozenVinHistResponse.setStatusCode(CommonConstants.SUCCESS_CODE);
			frozenVinHistResponse.setStatusDescription(CommonConstants.SUCCESS_DESC);
		}

		return frozenVinHistResponse;
	}

	private List<FrozenHistory> getListOfHubs(List<Map<String, Object>> historyList, String filterFlag) {
		List<FrozenHistory> hubList = new ArrayList<>();
		CountryList coountryList;
		List<CountryList> countryList = new ArrayList<>();
		FrozenHistory frozenVin = null;
		String tempHubCode = null;
		for (Map<String, Object> map1 : historyList) {

			String hubCode = String.valueOf(((String) map1.get(GCPE10_HUB_C)).trim());

			if (!hubCode.equalsIgnoreCase(tempHubCode)) {
				if (tempHubCode != null) {
					frozenVin.setCountryList(countryList);
					hubList.add(frozenVin);
				}
				
				tempHubCode = hubCode;
				frozenVin = new FrozenHistory();
				frozenVin.setHubCode(((String) map1.get(GCPE10_HUB_C)).trim());
				frozenVin.setHubDesc(((String) map1.get("GCPE10_HUB_DESC_X")).trim());
				countryList = new ArrayList<>();
			}
			coountryList = new CountryList();
			coountryList.setCountryCode((String.valueOf(map1.get("COUNTRY_ISO3_C"))).trim());
			coountryList.setCountryDesc((String.valueOf(map1.get("COUNTRY_NAME_X"))).trim());
			coountryList.setOriginalCount((String.valueOf(map1.get("GCPA17_CRNT_VINS_T"))));
			
			coountryList.setFrozenCount((String.valueOf(map1.get("6"))).trim());
			
			coountryList.setSupplementCount((String.valueOf(map1.get("GCPA17_CNSP_VINS_T"))).trim());
			coountryList.setSupplementfrozenCount((String.valueOf(map1.get("GCPA17_FRZN_SUPP_T"))).trim());
			
			coountryList.setRevisedfrozenCount((String.valueOf(map1.get("GCPA17_FRZN_GOVT_T"))).trim());
			
			coountryList.setFrozenUserId((String.valueOf(map1.get("GCPA17_FRZN_BY_C"))).trim());
			
			coountryList.setFrozenDate(DateConvert.getInstance().formatOutputDate(String.valueOf(map1.get("11"))));
			
			coountryList.setUnfreezeUserId((String.valueOf(map1.get("GCPA17_UNFRZ_BY_C"))).trim());
			
			coountryList.setUnfreezeDate(DateConvert.getInstance().formatOutputDate((String.valueOf(map1.get("13"))).trim()));
			coountryList.setEmissionFrozenUserId((String.valueOf(map1.get(GCPA02_UPDATE_ID_C))).trim());
			coountryList.setEmissionFrozenDate(DateConvert.getInstance().formatOutputDate((String.valueOf(map1.get("15")).trim())));
			if("C".equalsIgnoreCase(filterFlag)) {
			if((Integer.parseInt(String.valueOf(map1.get("GCPA17_CRNT_VINS_T")))>0 || Integer.parseInt(String.valueOf(map1.get("GCPA17_CNSP_VINS_T")))>0)) { 
			countryList.add(coountryList);
			}
			}else if("A".equalsIgnoreCase(filterFlag)){
				countryList.add(coountryList);
			}

		}
		if (frozenVin != null) {
			frozenVin.setCountryList(countryList);
			hubList.add(frozenVin);

		}
		return hubList;
	}


}
