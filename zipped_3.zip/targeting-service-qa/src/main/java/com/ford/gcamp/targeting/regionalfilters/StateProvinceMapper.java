package com.ford.gcamp.targeting.regionalfilters;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.commons.lang3.StringUtils;
import org.springframework.jdbc.core.RowMapper;

import com.ford.gcamp.targeting.regionalfilters.api.StateProvinceDetail;

public class StateProvinceMapper implements RowMapper<StateProvinceDetail> {

	@Override
	public StateProvinceDetail mapRow(ResultSet rs, int rowNum) throws SQLException {

		return StateProvinceDetail.builder().countryCode(StringUtils.trimToEmpty(rs.getString(1)))
				.countryDescription(StringUtils.trimToEmpty(rs.getString(2)))
				.stateCode(StringUtils.trimToEmpty(rs.getString(3)))
				.stateDescription(StringUtils.trimToEmpty(rs.getString(4)))
				.geoCode(StringUtils.trimToEmpty(rs.getString(5)))
				.geoDescription(StringUtils.trimToEmpty(rs.getString(6))).build();
	}
}
