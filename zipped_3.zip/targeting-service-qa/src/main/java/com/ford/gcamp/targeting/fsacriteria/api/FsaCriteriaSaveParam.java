package com.ford.gcamp.targeting.fsacriteria.api;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@JsonIgnoreProperties(ignoreUnknown = true)
public class FsaCriteriaSaveParam extends FsaVehicleCommonVO {

    @NotNull @Valid private FsaCriteriaParam criteriaParam;

    @NotNull @Valid private FsaCriteriaEditVO fsaEdit;

    @NotNull @Valid private FSACriteriaRegionalFilterRequest regionalFilter;
}
