package com.ford.gcamp.targeting.prelaunchreports.api;

import com.ford.gcamp.targeting.common.api.CommonResponse;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class SaveDistributionsResponse extends CommonResponse{

	private String distListId;
	private String procCode;
	private String countryCode;
	private String defaultFlag;
	private String countryName;
	private String distListName;
	private String procDesc;
}
