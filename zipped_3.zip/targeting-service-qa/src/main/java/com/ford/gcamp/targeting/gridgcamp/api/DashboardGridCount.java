package com.ford.gcamp.targeting.gridgcamp.api;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DashboardGridCount {

	@Size(min = 0, max = 3)
	@Pattern(regexp = "^[A-Z\\d]*$")
	@Schema(example = "R07", description = "Code")
	private String code;

	@Min(0)
	@Max(99999)
	@Schema(example = "185", description = "Count")
	private Long count;

	@Size(min = 0, max = 11)
	@Pattern(regexp = "^|[\\w\\-\\\\]*$")
	@Schema(example = "21-Aug-2024", description = "Last Updated Date")
	private String lastUpdatedDate;

	@Size(max = 100)
	@Pattern(regexp = "^|[\\w\\-\\.\\:\\s]*$")
	@Schema(example = "TEST", description = "Description")
	private String description;
}
