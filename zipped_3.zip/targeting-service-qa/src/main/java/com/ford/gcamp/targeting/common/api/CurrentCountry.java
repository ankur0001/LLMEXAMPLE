package com.ford.gcamp.targeting.common.api;




import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CurrentCountry {

	@Size(min = 0, max = 3)
	@Pattern(regexp = "^[a-zA-Z\\*\\s]*$")
	@Schema(example = "CAN", description = "CountryCode")
	private String countryCode;


	@Size(min = 1, max = 250)
	@Pattern(regexp = "^[a-zA-Z\\d\\\\s&().,\\-\\_\\&]*$")
	@Schema(example = "INDIA", description = "Country Description")
	private String label;



	@Min(0)
	@Max(99999999)
	@Schema(example = "0", description = "Count")
	private int count;
}
