package com.ford.gcamp.targeting.gridgcamp.gcamp.api;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Size;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@JsonIgnoreProperties(ignoreUnknown = true)
public class VehicleCriteria {

	@Valid
	@Schema(types = {"object", "null"})
	private GridVehicleCriteria modelYear;
	@Valid
	@Schema(types = {"object", "null"})
	private GridVehicleCriteria brand;
	@Valid
	@Schema(types = {"object", "null"})
	private GridVehicleCriteria vehicleLine;
	@Valid
	@Schema(types = {"object", "null"})
	private GridVehicleCriteria plant;
	@Valid
	@Schema(types = {"object", "null"})
	private ProductionDate production;

	@Size(min = 0, max = 500)
	@Schema(types = {"array", "null"})
	private List< @Valid  GridVehicleCriteria> wers;


	@Size(min = 0, max = 500)
	@Schema(types = {"array", "null"})
	private List< @Valid  VehicleCode> vehicleCode;


	@Schema(types = {"object", "null"})
	@Valid
	private MarketRegionCriteria marketRegions;

	@Schema(types = {"array", "null"})
	@Size(min = 0, max = 500)
	private List< @Valid SoftwareCriteria> software;

	private boolean otaIndicator;

}
