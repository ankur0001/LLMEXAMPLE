package com.ford.gcamp.targeting.reports.batch.exception;

public class GCAMPReportDB2Exception extends GCAMPReportException {

	private static final long serialVersionUID = -7547954318899061366L;

	/**
	 * Constructor for GCampDB2Exception
	 */
	public GCAMPReportDB2Exception() {
		super();
	}

	/**
	 * Constructor for GCampDB2Exception
	 */
	public GCAMPReportDB2Exception(String msg) {
		super(msg);
	}

	/**
	 * Constructor for GCampDB2Exception
	 */
	public GCAMPReportDB2Exception(Throwable rootCause) {
		super(rootCause);
	}

	/**
	 * Constructor for GCampReportException
	 */
	public GCAMPReportDB2Exception(String msg, Throwable rootCause) {
		super(msg, rootCause);
	}

}
