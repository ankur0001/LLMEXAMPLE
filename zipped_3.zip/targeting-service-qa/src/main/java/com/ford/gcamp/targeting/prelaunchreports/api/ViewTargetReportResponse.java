package com.ford.gcamp.targeting.prelaunchreports.api;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ViewTargetReportResponse {
	
	private int jobId;
	private String responseCode;
	private String responseMsg;

}
