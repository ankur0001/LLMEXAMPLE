package com.ford.gcamp.targeting.reports.batch.api;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SoldUnSold extends GenericReportData {

    private String hub;

    private String localFSA;

    private String roi;

    private String country;

    private String vinGroupLabel;

    private String vinGroupDesc;

    private String modelYear;

    private long soldCount;

    private long unSoldCount;

}
