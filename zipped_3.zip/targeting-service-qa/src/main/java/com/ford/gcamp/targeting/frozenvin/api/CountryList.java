package com.ford.gcamp.targeting.frozenvin.api;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class CountryList {


	@Size(min = 1, max = 3)
	@Pattern(regexp = "^[a-zA-Z\\*\\s]*$")
	@Schema(example = "USA", description = "Country ISO Code")
	private String countryCode;


	@Size(min = 1, max = 64)
	@Pattern(regexp = "^[\\w\\s&\\.\\(\\)'\\*]*$")
	@Schema(example = "INDIA", description = "Country Description")
	private String countryDesc;


	@Schema(example= "3456" , description = "Original count")
	@Size(min = 0, max =10)
	@Pattern(regexp ="^[\\d]*$")
	private String originalCount;

	@Schema(example= "3756" , description = "Frozen count")
	@Size(min = 0, max =10)
	@Pattern(regexp ="^[\\d]*$")
	private String frozenCount;

	@Schema(example= "tdharti" , description = "userID")
	@Size(min = 0, max = 8)
	@Pattern(regexp ="^[a-zA-Z\\d\\-]*$")
	private String emissionFrozenUserId;


	@Size(min = 0, max = 20)
	@Pattern(regexp = "^[a-zA-Z\\d\\-\\s\\.\\/]$")
	@Schema(example = "05-Jun-2024 /  11.54", description = "Emission frozen Date")
	private String emissionFrozenDate;

	@Schema(example= "3756" , description = "supplement count")
	@Size(min = 0, max = 10)
	@Pattern(regexp ="^[\\d]*$")
	private String supplementCount;

	@Schema(example= "3756" , description = "Frozen count")
	@Size(min = 0, max = 10)
	@Pattern(regexp ="^[\\d]*$")
	private String supplementfrozenCount;

	@Schema(example= "3756" , description = "Frozen count")
	@Size(min = 0, max =10)
	@Pattern(regexp ="^[\\d]*$")
	private String revisedfrozenCount;



	@Schema(example= "tdharti" , description = "userID")
	@Size(min = 0, max = 8)
	@Pattern(regexp ="^[a-zA-Z\\d\\-]*$")
	private String frozenUserId;

	@Size(min = 0, max = 20)
	@Pattern(regexp = "^[a-zA-Z\\d\\-\\s\\.\\/]$")
	@Schema(example = "05-Jun-2024", description = "Frozen Date")
	private String frozenDate;



	@Schema(example= "tdharti" , description = "userID")
	@Size(min = 0, max = 8)
	@Pattern(regexp ="^[a-zA-Z\\d\\-]*$")
	private String unfreezeUserId;


	@Size(min = 0, max = 20)
	@Pattern(regexp = "^[a-zA-Z\\d\\-\\s\\.\\/]$")
	@Schema(example = "05-Jun-2024", description = "Frozen Date")
	private String unfreezeDate;
	
}
