package com.ford.gcamp.targeting.prelaunchreports;

import com.ford.gcamp.targeting.common.BatchTrigger;
import com.ford.gcamp.targeting.common.CommonConstants;
import com.ford.gcamp.targeting.common.api.BatchJobData;
import com.ford.gcamp.targeting.common.api.FSAInfoVO;
import com.ford.gcamp.targeting.common.api.ReportBatchStatusResponse;
import com.ford.gcamp.targeting.common.api.SuppPopulationVo;
import com.ford.gcamp.targeting.core.exception.GCAMPException;
import com.ford.gcamp.targeting.gridgcamp.gcamp.GridGCampService;
import com.ford.gcamp.targeting.gridgcamp.grid.GridVernCountService;
import com.ford.gcamp.targeting.prelaunchreports.api.DownloadReportRequest;
import com.ford.gcamp.targeting.prelaunchreports.api.FsaGoRequest;
import com.ford.gcamp.targeting.prelaunchreports.api.LoadTargetingReportsResponse;
import com.ford.gcamp.targeting.prelaunchreports.api.ReportsResponse;
import com.ford.gcamp.targeting.prelaunchreports.api.ViewTargetReportRequest;
import com.ford.gcamp.targeting.prelaunchreports.api.ViewTargetReportResponse;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class ViewTargetingReportsService {

    @Value("${config.toggle.showReportScreenFlag}")
    private boolean showReportsScreenFlag;

    @Value("${config.toggle.disableConfirmVehiclePopulation}")
    private boolean disableConfirmVehiclePopulation;

    private ViewTargetingReportsRepository reportsRepository;
    private ExtractOptionMapper extractOptionMapper;
    private BatchTrigger batch;
    private GridGCampService gridGCampService;
    private GridVernCountService gridVernCountService;

    public ViewTargetingReportsService(
            ViewTargetingReportsRepository reportsRepository,
            ExtractOptionMapper extractOptionMapper,
            BatchTrigger batch,
            GridGCampService gridGCampService,
            GridVernCountService gridVernCountService) {
        super();
        this.reportsRepository = reportsRepository;
        this.extractOptionMapper = extractOptionMapper;
        this.batch = batch;
        this.gridGCampService = gridGCampService;
        this.gridVernCountService = gridVernCountService;
    }

    public LoadTargetingReportsResponse loadAllReports(FsaGoRequest fsaGoRequestParm)
            throws GCAMPException {
        String population = fsaGoRequestParm.getPopulation().trim();
        if (StringUtils.equals("*", population)) {
            validateFsaStatus(fsaGoRequestParm);
            population = "00";
        }
        log.info(
                "Loading Targeting Reports for FSA Number: {}, Population: {}, and Updated Population: {}",
                fsaGoRequestParm.getFsaNumber(),
                fsaGoRequestParm.getPopulation(),
                population);

        LoadTargetingReportsResponse loadTargetingReportsResponse = loadReports(fsaGoRequestParm);
        loadTargetingReportsResponse.setShowReportsScreenFlag(showReportsScreenFlag);
        loadTargetingReportsResponse.setDisableConfirmVehiclePopulation(disableConfirmVehiclePopulation);
        if (loadTargetingReportsResponse.getFsaInfoVO() != null) {
            boolean latestGridVernInfoExists =
                    gridGCampService.checkIfLatestGridVernExists(
                            Integer.parseInt(
                                    loadTargetingReportsResponse
                                            .getFsaInfoVO()
                                            .getGlobalFSANumber()),
                            fsaGoRequestParm.getPopulation());
            loadTargetingReportsResponse.setLatestGridVernInfoExists(latestGridVernInfoExists);
            // Fetch report batch status and set individual fields
            ReportBatchStatusResponse reportBatchStatus =
                    gridVernCountService.getReportBatchStatus(
                            Integer.parseInt(
                                    loadTargetingReportsResponse
                                            .getFsaInfoVO()
                                            .getGlobalFSANumber()),
                            population);
            loadTargetingReportsResponse.setReportAvailableFlag(
                    reportBatchStatus.isReportAvailableFlag());
            loadTargetingReportsResponse.setBatchBlockFlag(reportBatchStatus.isBatchBlockFlag());
            loadTargetingReportsResponse.setDeepLinkFlag(reportBatchStatus.isDeepLinkFlag());
        }
        return loadTargetingReportsResponse;
    }

    public LoadTargetingReportsResponse loadReports(FsaGoRequest fsaGoRequestParm)
            throws GCAMPException {
        String inputParam1 = extractOptionMapper.loadReportsParam1(fsaGoRequestParm);
        String inputParam2 = extractOptionMapper.loadReportsParam2(fsaGoRequestParm);
        Map<String, Object> responseMap = reportsRepository.getAllReports(inputParam1, inputParam2);

        LoadTargetingReportsResponse loadTargetingReportsResponse =
                extractOptionMapper.parseAllReports(responseMap);
        List<SuppPopulationVo> populationList = new ArrayList<>();
        if (CommonConstants.SUCCESS.equalsIgnoreCase(loadTargetingReportsResponse.getStatus())
                && ObjectUtils.isNotEmpty(loadTargetingReportsResponse.getFsaInfoVO())
                && StringUtils.isNotBlank(
                        loadTargetingReportsResponse.getFsaInfoVO().getGlobalFSANumber())) {
            String globalFsaNumber =
                    loadTargetingReportsResponse.getFsaInfoVO().getGlobalFSANumber();
            populationList = reportsRepository.getSupplements(globalFsaNumber);
        }
        loadTargetingReportsResponse.setSupplements(populationList);
        return loadTargetingReportsResponse;
    }

    private void validateFsaStatus(FsaGoRequest fsaGoRequestParm) throws GCAMPException {
        String param1 =
                extractOptionMapper.fsaGoParam(
                        fsaGoRequestParm.getFsaNumber(), fsaGoRequestParm.getFsaType());
        Map<String, Object> statusCheckMap = reportsRepository.getFsaDetails(param1);
        String errorParam = (String) statusCheckMap.get(CommonConstants.OUTPUT_ERR1);
        String statusInd = errorParam != null ? errorParam.substring(9, 10) : "N";
        if (errorParam != null && statusInd != null && "Y".equalsIgnoreCase(statusInd)) {
            String errorCode = errorParam.substring(37, 40);
            String errorDesc = errorParam.substring(40, 150);
            throw new GCAMPException(errorCode + errorDesc.trim());
        } else {
            String outparam1 = (String) statusCheckMap.get(CommonConstants.OUTPUT_PARM1);
            String outparam2 = (String) statusCheckMap.get(CommonConstants.OUTPUT_PARM2);
            FSAInfoVO fsaInfoVo = new FSAInfoVO();
            fsaInfoVo.setString(outparam1, outparam2);
            String fsaStatus = fsaInfoVo.getFsaStatus().getDescription();
            if (!CommonConstants.LAUNCHED_STATUS.equalsIgnoreCase(fsaStatus)) {
                throw new GCAMPException(CommonConstants.POPULATION_ALL_EMPTY);
            } else {
                List<SuppPopulationVo> populationList =
                        reportsRepository.getSupplements(fsaInfoVo.getGlobalFSANumber());
                if (populationList.isEmpty()) {
                    throw new GCAMPException(CommonConstants.POPULATION_ALL_EMPTY);
                }
            }
        }
    }

    public ViewTargetReportResponse confirmPopulation(
            ViewTargetReportRequest viewTargetReportRequest) throws GCAMPException {
        int jobId = 0;
        ViewTargetReportResponse confirmPopulationResponse = new ViewTargetReportResponse();
        if (viewTargetReportRequest != null) {
            jobId = submitJob(viewTargetReportRequest);
            confirmPopulationResponse.setJobId(jobId);
            confirmPopulationResponse.setResponseCode(ViewTargetReportConstants.SUCCESS);
            confirmPopulationResponse.setResponseMsg(
                    "Your Job has been successfully submitted with Job Id "
                            + jobId
                            + " for the Batch Code "
                            + ViewTargetReportConstants.COFIRM_BATCH_CODE
                            + ".");
        } else {
            confirmPopulationResponse.setJobId(jobId);
            confirmPopulationResponse.setResponseCode(ViewTargetReportConstants.ERROR);
            confirmPopulationResponse.setResponseMsg("ERROR = INPUT VALUE OBJECTS ARE NULL");
        }
        return confirmPopulationResponse;
    }

    private int submitJob(ViewTargetReportRequest viewTargetReportRequest) throws GCAMPException {

        int jobId = 0;
        String supplement = null;
        BatchJobData job = new BatchJobData();
        job.setBatchCode(ViewTargetReportConstants.COFIRM_BATCH_CODE);
        if ("G".equalsIgnoreCase(viewTargetReportRequest.getFsaType())) {
            job.setGlobalFSANo(Integer.parseInt(viewTargetReportRequest.getFsaNumber()));
        } else {
            job.setGlobalFSANo(viewTargetReportRequest.getLocalFsaNumber());
        }
        job.setCdsId(viewTargetReportRequest.getCdsId());
        if ("".equals(viewTargetReportRequest.getSupplementCode().trim())) {
            supplement = "00";
        } else {
            supplement = viewTargetReportRequest.getSupplementCode().trim();
        }
        job.setHubCode(viewTargetReportRequest.getUserHub());
        job.setCountryCode(viewTargetReportRequest.getUserCountryCode());
        job.setEmailIndicator(ViewTargetReportConstants.EMAIL_INDICATOR);
        job.setSupplement(supplement);
        log.info("Confirm vehicle poulation Batch Code : {}", job.getBatchCode());

        boolean blockerExists =
                reportsRepository.checkBatchBlockerExists(
                        job.getGlobalFSANo(), job.getSupplement());
        if (blockerExists) {
            throw new GCAMPException(CommonConstants.BATCH_BLOCKER_MESSAGE);
        }
        jobId = batch.submitJob(job);
        return jobId;
    }

    public ReportsResponse downloadReport(DownloadReportRequest downloadRequest)
            throws GCAMPException {

        return reportsRepository.getReportBlob(downloadRequest);
    }
}
