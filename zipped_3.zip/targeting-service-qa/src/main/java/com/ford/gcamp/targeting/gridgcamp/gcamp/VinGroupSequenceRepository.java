package com.ford.gcamp.targeting.gridgcamp.gcamp;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ford.gcamp.targeting.gridgcamp.gcamp.entity.VinGroupSequenceData;
import com.ford.gcamp.targeting.gridgcamp.gcamp.entity.VinGroupSequenceId;

public interface VinGroupSequenceRepository extends JpaRepository<VinGroupSequenceData, VinGroupSequenceId>{

}
