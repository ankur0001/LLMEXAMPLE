
package com.ford.gcamp.targeting.fsacriteria.api;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class FsaVehicleCommonVO {

	@Schema(types = {"string", "null"},example = "2", description = "orderNumber")
	@Size(min=1,max=2)
	@Pattern(regexp ="^[\\d]*$")
	private String orderNumber;

	@Min(0)
	@Max(99999999)
	@Schema(types = {"integer","null"}, example = " ",type= "integer", description = "rowId")
	private int rowId;

	@Schema(types = {"string", "null"},example = "=", description = "operator")
	@Size(min=0, max = 50)
	@Pattern(regexp ="^[A-Za-z\\d\\s_.,'()\"\\=\\<>!]*$")
	private String operator;

	@Schema(types = {"string", "null"},example = "200", description = "statusCode")
	@Size(min=0, max = 50)
	@Pattern(regexp ="^[A-Za-z\\d\\s_.,'()\"]*$")
	private String statusCode;

	@Size(min=0, max = 500)
	@Schema(types = {"string", "null"},example = "E0068-INVALID NUMBER OF ROWS OR COUNTER", description = "statusDesc")
	@Pattern(regexp ="^[A-Za-z\\d\\s,.\\-'()\"]*$")
	private String statusDesc;
	
}