package com.ford.gcamp.targeting.multiauth;


import com.ford.gcamp.targeting.multiauth.decoders.ADFSJwtDecoder;
import com.ford.gcamp.targeting.multiauth.decoders.EntraIDJwtDecoder;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.oauth2.core.OAuth2AuthenticationException;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.security.oauth2.jwt.JwtException;

/**
 * Configuration class for setting up a JwtDecoder that supports both ADFS and Entra ID authentication.
 */
@Slf4j
@Configuration
@EnableConfigurationProperties(MultiAuthConfigurationProperties.class)
@ConditionalOnProperty(value = "decode.multi-auth.enabled", havingValue = "true")
public class MultiAuthJwtDecoderConfiguration {



    /**
     * Create a JwtDecoder that attempts to decode tokens using Entra ID first, then ADFS if that fails.
     *
     * @param adfsJwtDecoderBuilder    configured Builder for ADFS JwtDecoder
     * @param entraIDJwtDecoderBuilder configured Builder for Entra ID JwtDecoder
     * @return JwtDecoder that supports both ADFS and Entra ID tokens
     */
    @Bean(name = "multiAuthJwtDecoder")
    public JwtDecoder multiAuthJwtDecoder(ADFSJwtDecoder.Builder adfsJwtDecoderBuilder, EntraIDJwtDecoder.Builder entraIDJwtDecoderBuilder) {
        JwtDecoder adfsJwtDecoder = adfsJwtDecoderBuilder.build();
        JwtDecoder entraJwtDecoder = entraIDJwtDecoderBuilder.build();
        return token -> {
            try {
                return entraJwtDecoder.decode(token);
            } catch (JwtException e) {
                log.trace("Failed to decode JWT token with EntraID decoder, trying ADFS decoder", e);
            }
            try {
                return adfsJwtDecoder.decode(token);
            } catch (JwtException e) {
                throw new OAuth2AuthenticationException("Invalid or expired token");
            }
        };
    }

    /**
     * Create an ADFS JwtDecoder builder from configuration properties.
     *
     * @param properties configuration properties containing ADFS settings
     * @return Builder for ADFS JwtDecoder with all required properties set
     */
    @Bean
    public ADFSJwtDecoder.Builder adfsJwtDecoderBuilder( MultiAuthConfigurationProperties properties) {
        return ADFSJwtDecoder.builder()
                .issuerUri(properties.getAdfs().getIssuerUri())
                .jwkSetUri(properties.getAdfs().getJwkSetUri())
                .audiences(properties.getAdfs().getAudiences());

    }

    /**
     * Create an Entra ID JwtDecoder builder from configuration properties.
     * @param properties configuration properties containing Entra ID settings
     * @return Builder for Entra ID JwtDecoder with all required properties set
     */
    @Bean
    public EntraIDJwtDecoder.Builder entraIdJwtDecoderBuilder(MultiAuthConfigurationProperties properties) {
        return EntraIDJwtDecoder.builder()
                .issuerUri(properties.getEntraId().getIssuerUri())
                .jwkSetUri(properties.getEntraId().getJwkSetUri())
                .audiences(properties.getEntraId().getAudiences())
                .proxyHost(properties.getEntraId().getProxyHost())
                .proxyPort(properties.getEntraId().getProxyPort());
    }
}
