package com.ford.gcamp.targeting.reports.batch.api;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class ProductionDatesByPlant extends GenericReportData {

    /**
     * Contains the plant
     */
    private String plant;

    /**
     * Contains the model year
     */
    private String modelYear;

    /**
     * Contains the earliest production date
     */
    private String earliestProdDate;

    /**
     * Contains the latest production date
     */
    private String latestProdDate;
    
    /**
     * Contains vehicle line
     */
    private String vehicleLine;
    
    /**
     * Contains count for each record
     */
    private String count;

}
