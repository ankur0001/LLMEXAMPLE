package com.ford.gcamp.targeting.fsacriteria.api;

import com.fasterxml.jackson.annotation.JsonIgnore;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class AssemblyPlantList {

	@Size(min = 0, max = 6)
	@Pattern(regexp = "^[a-zA-Z\\d]*$")
	@Schema(example = "AAGDZC", description = "AssemblyPlantCode")
	private String wsrFilterCode;


	@Size(min = 0, max = 50)
	@Pattern(regexp = "^[a-zA-Z\\d\\(\\)\\s\\/\\-\\.\\,]*$")
	@Schema(example = "AAT- RAYONG ASSEMBLY PLT-LS ( C )", description = "Assembly Plant Name")
	private String gcpWersFtrX;
	@JsonIgnore
	private String vehLine;
	@JsonIgnore
	private String modelYear;
	
	public AssemblyPlantList(String wsrFilterCode, String gcpWersFtrX) {
		super();
		this.wsrFilterCode = wsrFilterCode;
		this.gcpWersFtrX = gcpWersFtrX;
	}

}
