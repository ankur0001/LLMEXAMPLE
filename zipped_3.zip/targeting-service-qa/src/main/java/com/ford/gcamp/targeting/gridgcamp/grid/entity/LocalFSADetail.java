package com.ford.gcamp.targeting.gridgcamp.grid.entity;

import java.io.Serializable;
import java.sql.Timestamp;
import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.IdClass;
import jakarta.persistence.Table;

import org.hibernate.annotations.CreationTimestamp;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Entity
@IdClass(LocalFSAId.class)
@Table(name = "SGCPA16_GLBFSAHUB")
public class LocalFSADetail implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "GCPA15_GLOBL_FSA_R")
	private int globalFSANumber;
	@Id
	@Column(name = "GCPE10_HUB_C")
	private String hubCode;
	@Column(name = "GCPA16_LOCAL_FSA_R")
	private String localFSANumber;
	@Column(name = "GCPA16_LOCFSACRT_Y")
	private String localFSACreateDate;
	@Column(name = "GCPA16_LAUNCH_Y")
	private String localFSALaunchDate;

	@Column(name = "GCPA16_LOCAL_FSA_X")
	private String localFSADescription;

	@Column(name = "GCPA07_FSA_STAT_C")
	private String fsaStatus;

	@Column(name = "GCPA11_FSA_TYPE_C")
	private String fsaTypeCode;

	@Column(name = "GCPA16_EXPIRE_Y")
	private LocalDate expiryDate;

	@Column(name = "GCPA16_CUR_USER_C")
	private String currentUserId;

	@Column(name = "GCPA16_LAUNCH_F")
	private String launchFlag;

	@Column(name = "GCPA16_LOCFSAUPD_ID_C")
	private String localFsaUpdateId;

	@Column(name = "GCPA16_LCFSA_ACT_S")
	private Timestamp localFsaCreationTimestamp;

	@Column(name = "GCPA16_INTR_NOTY_Y")
	private LocalDate notificationCircularDate;

	@Column(name = "GCPA16_COMM_REQ_Y")
	private LocalDate communicationRequestDate;

	@Column(name = "GCPA16_PARTS_REQ_Y")
	private LocalDate partReqDate;

	@Setter(AccessLevel.NONE)
	@Getter(AccessLevel.NONE)
	@Column(name = "GCPA16_FSA_STAT_S")
	@CreationTimestamp
	private Timestamp fsaStatusTimestamp;

	@Column(name = "GCPA16_BUDG_S")
	private Timestamp budgetTimestamp;

	@Column(name = "GCPA16_UPDATE_ID_C")
	private String updateId;

	@Column(name = "GCPA16_INCLD_EXCLD_F")
	private String globalVisibilityIndicator;

}
