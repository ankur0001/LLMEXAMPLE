package com.ford.gcamp.targeting.fsacriteria.api;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class FsaCriteriaModifySaveVO extends FsaVehicleCommonVO {
	
	private List<FsaCriteriaFilterOutputVO> firstOutputResults;
	
}
