package com.ford.gcamp.targeting.fsacriteria.api;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class TraceablityList {
	@Schema(description = "Comp Code")
	@Size(min = 0, max = 30)
	@Pattern(regexp ="^[A-Za-z\\d]*$")
	private String compCode;

	@Schema(description = "Comp Description")
	@Size(min = 0, max = 254)
	@Pattern(regexp ="^[A-Za-z\\d\\s\\.\\,\\_\\-]*$")
	private String compDescription;
	
}
