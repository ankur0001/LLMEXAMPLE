package com.ford.gcamp.targeting.core.exception;



public class GCampEmailException extends GCAMPException {

	/**
	 * Constructor for GCampDatabaseException
	 */
	public GCampEmailException() {
		super();
	}

	/**
	 * Constructor for GCampDatabaseException
	 */
	public GCampEmailException(String msg) {
		super(msg);
	}

	/**
	 * Constructor for GCampDatabaseException
	 */
	public GCampEmailException(Throwable rootCause) {
		super(rootCause);
	}

	/**
	 * Constructor for GCampDatabaseException
	 */
	public GCampEmailException(String msg, Throwable rootCause) {
		super(msg, rootCause);
	}

}


