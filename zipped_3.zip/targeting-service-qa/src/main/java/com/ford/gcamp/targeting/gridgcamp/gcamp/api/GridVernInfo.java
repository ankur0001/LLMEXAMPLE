package com.ford.gcamp.targeting.gridgcamp.gcamp.api;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.ford.gcamp.targeting.common.api.GenericLookup;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.util.List;

@EqualsAndHashCode(callSuper = false)
@Data
@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
public class GridVernInfo extends GridBasicVernInfo {
	@Schema(description = "requesterName")
	@Size(min = 0, max = 40, message = "length 8")
	@Pattern(regexp = "^[A-Za-z\\d\\s.,]*$", message = "Request Name Invalid")
	private String requesterName;

	private String requesterDept;

	@Schema(example = "2020-12-31")
	@Size(min = 0, max = 10, message = "Valid pattern YYYY-MM-DD")
	private String requestDate;

	@Schema(description = "implementationDesc")
	@Pattern(regexp = "^[A-Za-z\\d\\s,.#_\\-'()\"{}]*$", message = "Implementation Desc Invalid")
	@Size(min = 0, max = 2000, message = "length 2000")
	private String implementationDesc;

	@Schema(example = "2020-12-31")
	@Size(min = 0, max = 10, message = "Valid pattern YYYY-MM-DD")
	private String frcApprovalDate;

	@Schema(description = "concernDescription")
	@Size(min = 0, max = 5000, message = "length 5000")
	@Pattern(regexp = "^[A-Za-z\\d\\s,.#_\\-'()\"{}]*$", message = "Concern Desc Invalid")
	private String concernDescription;

	@Schema(description = "requestForUpdate")
	@Size(min = 0, max = 2000, message = "length 2000")
	@Pattern(regexp = "^[A-Za-z\\d\\s,.#_\\-'()\"{}]*$", message = "Request for update invalid")
	private String requestForUpdate;

	@Schema(description = "specialRequest")
	@Size(min = 0, max = 2000, message = "length 2000")
	@Pattern(regexp = "^[A-Za-z\\d\\s,.#_\\-'()\"{}]*$", message = "Special Request")
	private String specialRequest;


	@Schema(example = "NA")
	@Size(min = 2, max = 3, message = "length 2 or 3")
	@Pattern(regexp = "^[A-Za-z]*$", message = "Initiating hub code invalid")
	private String initiatingHub;


	@Schema(description = "initiatingHubDesc")
	@Size(min = 1, max = 100, message = "length 100")
	@Pattern(regexp = "^[A-Za-z\\s]*$", message = "Initiating hub code invalid")
	private String initiatingHubDesc;

	@Schema(types = {"string","null"},description = "fsaType")
	@Size(min = 1, max = 2, message = "length 2")
	@Pattern(regexp = "^[A-Za-z\\d]*$", message = "FSA Type")
	private String fsaType;


	@Schema(example= "Y" , description = "vinlist Avail Flag")
	@Size(min = 0, max = 1)
	@Pattern(regexp ="^[A-Za-z]$")
	private String vinListAvailFlag;

	@Schema(example= "abc|abc|abc,abc|abc|abc,abc|abc|abc" , description = "vin List File Details")
	@Size(min = 0, max = 500)
	@Pattern(regexp ="^[A-Za-z\\d\\-\\s.,\\|\\_()]*$")
	private String vinListFileDetails;

	@Size(min = 0, max = 10)
	@Schema(types={"object","null"})
	private GenericLookup fsaTypeResponse;

	@Size(min = 0, max = 500)
	@Schema(types = {"array","null"})
	private List<VehicleCriteria> vehicleCritiera;

	@Size(min = 0, max = 500)
	private List<VinAttachment> vinAttachment;

	private boolean vfdRequested;

	@Size(min = 0, max = 10)
	@Schema(types={"array","null"})
	private List<GenericLookup> wersAttributes;

	private boolean otaIndicator;

	@JsonProperty("isTandem")
	private boolean isTandem;

	@Schema(types = {"object","null"})
	private FSAMappingTypes fsaTypes;

	@Size(min = 0, max = 100)
	@Schema(types = {"array","null"})
	private List<String> hubCoordinatorIds;
}
