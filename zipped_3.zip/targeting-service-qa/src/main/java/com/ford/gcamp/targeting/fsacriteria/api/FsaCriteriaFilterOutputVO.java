package com.ford.gcamp.targeting.fsacriteria.api;



import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class FsaCriteriaFilterOutputVO extends FsaVehicleCommonVO {

	@Size(min = 0, max = 10)
	@Pattern(regexp = "^|[a-zA-Z\\d\\-\\s]*$")
	@Schema(example = " ", description = "filterCode")
	private String filterCode;

	@Size(min = 0, max = 10)
	@Pattern(regexp = "^|[a-zA-Z\\d\\-()\\-\\_,.#\\s]*$")
	@Schema(example = " ", description = "formattedFilterCode")
	private String formattedFilterCode;

	@Size(min = 0, max = 250)
	@Pattern(regexp = "^|[a-zA-Z\\d\\-()\\-\\_,.#\\s]*$")
	@Schema(example = " ", description = "filterDesc")
	private String filterDesc;

	@Size(min = 0, max = 50)
	@Pattern(regexp = "^|[a-zA-Z\\d\\-()\\-\\_,.#\\s]*$")
	@Schema(example = " ", description = "vehAttrVal")
	private String vehAttrVal;

	@Size(min = 0, max = 50)
	@Pattern(regexp = "^|[a-zA-Z\\d\\-()\\-\\_,.#\\s]*$")
	@Schema(example = " ", description = "vehAttrDesc")
	private String vehAttrDesc;

	@Size(min = 0, max = 50)
	@Pattern(regexp = "^|[a-zA-Z\\d\\-()\\-\\_,.#\\s]*$")
	@Schema(example = " ", description = "vehAttrBegin")
	private String vehAttrBegin;

	@Size(min = 0, max = 50)
	@Pattern(regexp = "^|[a-zA-Z\\d\\-()\\-\\_,.#\\s]*$")
	@Schema(example = " ", description = "vehAttrEnd")
	private String vehAttrEnd;
	
	
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("FsaCriteriaFilterOutputVO [filterCode=");
		builder.append(filterCode);
		builder.append(", formattedFilterCode=");
		builder.append(formattedFilterCode);
		builder.append(", filterDesc=");
		builder.append(filterDesc);
		builder.append(", vehAttrVal=");
		builder.append(vehAttrVal);
		builder.append(", vehAttrDesc=");
		builder.append(vehAttrDesc);
		builder.append(", vehAttrBegin=");
		builder.append(vehAttrBegin);
		builder.append(", vehAttrEnd=");
		builder.append(vehAttrEnd);
		builder.append("]");
		return builder.toString();
	}
	
	
	
}
