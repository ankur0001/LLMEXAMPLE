package com.ford.gcamp.targeting.gridgcamp.grid;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.ford.gcamp.targeting.gridgcamp.grid.entity.LocalFSADetail;
import com.ford.gcamp.targeting.gridgcamp.grid.entity.LocalFSAId;

@Repository
public interface LocalFSARepository extends JpaRepository<LocalFSADetail, LocalFSAId> {

	public Optional<LocalFSADetail> findFirstByGlobalFSANumber(Integer globalFSANumber);

	public Optional<LocalFSADetail> findFirstByLocalFSANumber(String localFSANumber);

	@Query("select DISTINCT(localFsa.hubCode) from LocalFSADetail localFsa where localFsa.globalFSANumber = ?1")
	public List<String> findHubsByGlobalFSANumber(Integer globalFSANumber);

}
