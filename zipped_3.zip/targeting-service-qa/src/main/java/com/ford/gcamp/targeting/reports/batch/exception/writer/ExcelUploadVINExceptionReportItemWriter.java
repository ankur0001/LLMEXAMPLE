
package com.ford.gcamp.targeting.reports.batch.exception.writer;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import com.ford.gcamp.targeting.reports.batch.common.ReportGenerationUtil;
import org.apache.commons.collections4.ListUtils;
import org.apache.poi.xssf.streaming.SXSSFSheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.item.Chunk;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.ford.gcamp.targeting.reports.batch.api.ExcelConfig;
import com.ford.gcamp.targeting.reports.batch.api.ReportMetaData;
import com.ford.gcamp.targeting.reports.batch.common.ReportCodeConstants;
import com.ford.gcamp.targeting.reports.batch.exception.GCAMPReportException;
import com.ford.gcamp.targeting.reports.batch.exception.api.TargetingExceptionReport;
import com.ford.gcamp.targeting.reports.batch.writer.GCAMPXSSFReportWriter;

@Component(ReportCodeConstants.T09 + "itemWriter")
@StepScope
public class ExcelUploadVINExceptionReportItemWriter extends GCAMPXSSFReportWriter implements ItemWriter<TargetingExceptionReport> {

	private List<TargetingExceptionReport> uploadVINExceptionList;
	
	@Value("#{jobParameters['reportMetaData']}")
	private String reportMetaDataString;

	private ReportMetaData reportData;
	
	@Value("${exception.report.xlsx.maxrecords}")
	private int xlsxMaxRecords;

	@Override
	public void write(Chunk<? extends TargetingExceptionReport> items) throws Exception {
		reportData = ReportGenerationUtil.getReportMetaDataObject(reportMetaDataString);
		uploadVINExceptionList = new ArrayList<>(items.getItems());
	    this.createReport(reportData);
	}

	@Override
	public void createWorksheet(SXSSFWorkbook hssfWorkbook, ReportMetaData metaData) throws GCAMPReportException {

		initializeWorkbook(hssfWorkbook);
		
		
		List<List<TargetingExceptionReport>> uploadVINExceptionLists = ListUtils.partition(uploadVINExceptionList,
				xlsxMaxRecords);
		List<ExcelConfig> uploadVINExceptionConfigList = loadConfigFile(ReportCodeConstants.T09,
				metaData.getSuppCode());
		int index = 1;
		for (List<TargetingExceptionReport> tempUploadVINExceptionList : uploadVINExceptionLists) {

			SXSSFSheet sheet = hssfWorkbook
					.createSheet(uploadVINExceptionList.size() > xlsxMaxRecords ? "Upload VIN Exception " + index
							: "Upload VIN Exception");

			try {

				createProfile(sheet, metaData, "Upload VIN Exception Report");

				setColumnWidth(sheet, uploadVINExceptionConfigList);

				setColumnHeader(sheet, uploadVINExceptionConfigList);

				setRowData(sheet, uploadVINExceptionConfigList, tempUploadVINExceptionList);

			} catch (Exception e) {
				throw new GCAMPReportException("VIN Not Found In VDM REPORT ERROR", e);
			}
			index++;

		}

	}
	
	public void setXlsxMaxRecords(int xlsxMaxRecords) {
		this.xlsxMaxRecords = xlsxMaxRecords;
	}

	public void setRptData(ReportMetaData metadata) {
		this.reportData = metadata;
	}
	

}