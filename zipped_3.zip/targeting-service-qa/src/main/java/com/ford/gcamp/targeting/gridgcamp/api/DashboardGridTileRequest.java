package com.ford.gcamp.targeting.gridgcamp.api;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class DashboardGridTileRequest {

	@Size(min = 0, max = 2)
	@Pattern(regexp = "^[a-zA-Z\\*\\s]*$")
	@Schema(example = "NA", description = "Hub code")
	private String userHubCode;


	@Size(min = 0, max = 20)
	@Pattern(regexp = "^|[\\w\\-\\\\]*$")
	@Schema(example = "21-Aug-2024", description = "Vern Submitted From Date")
	private String vernSubmittedFromDate;

	@Size(min = 0, max = 20)
	@Pattern(regexp = "^|[\\w\\-\\\\]*$")
	@Schema(example = "21-Aug-2024", description = "Vern Submitted To Date")
	private String vernSubmittedToDate;
	
}
