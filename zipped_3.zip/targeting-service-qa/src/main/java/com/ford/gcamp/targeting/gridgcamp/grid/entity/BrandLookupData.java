package com.ford.gcamp.targeting.gridgcamp.grid.entity;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Entity
@Table(name = "SGCPB03_BRAND")
public class BrandLookupData implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name = "GCPB03_BRAND_C")
	private String code;
	@Column(name = "GCPB03_BRAND_X")
	private String description;

}
