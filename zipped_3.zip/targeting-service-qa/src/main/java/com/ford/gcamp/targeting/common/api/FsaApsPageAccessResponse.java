package com.ford.gcamp.targeting.common.api;

import java.util.Map;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class FsaApsPageAccessResponse {

	@Size(min = 0, max = 30)
	@Pattern(regexp = "^[a-zA-Z\\s]*$")
	@Schema(example = "globalFsaSetup", description = "pageName")
	private String pageName;
	private boolean isAccessible;


	@Min(0)
	@Max(999)
	@Schema(example = "200", description = "Status Code")
	private int statusCode;

	@Size(min = 0, max = 250, message = "resources access List")
	private Map<String,Boolean> resourcesAccess;
	
}
