package com.ford.gcamp.targeting.fsacriteria;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import com.ford.gcamp.targeting.fsacriteria.api.DynamicQueryMappingReq;
import com.ford.gcamp.targeting.fsacriteria.api.DynamicQueryResponse;
import com.ford.gcamp.targeting.common.TargetingUtil;
import com.ford.gcamp.targeting.fsacriteria.api.AssemblyPlantList;
import com.ford.gcamp.targeting.fsacriteria.api.AttributeGroupingList;
import com.ford.gcamp.targeting.fsacriteria.api.FsaFilterCriteriaResponse;
import com.ford.gcamp.targeting.fsacriteria.api.GCPFilterList;
import com.ford.gcamp.targeting.fsacriteria.api.ModelYearList;
import com.ford.gcamp.targeting.fsacriteria.api.VehicleBrandList;
import com.ford.gcamp.targeting.fsacriteria.api.VehicleTypeList;
import com.ford.gcamp.targeting.fsacriteria.api.WersValuesList;

@Service
public class FsaCriteriaFilterServiceImpl implements FsaCriteriaFilterService {
	

	@Autowired
	private FsaCriteriaDAO fsaCriteriaDAO;
	
	@Override
	@Cacheable("getFsaBrandModelVehLinePlant")
	public List<FsaFilterCriteriaResponse> getFsaBrandModelVehLinePlant(){
		DynamicQueryMappingReq dynamicMappingRequest = new DynamicQueryMappingReq();
		return fsaCriteriaDAO.getFsaModelBrandVehLinePlant(dynamicMappingRequest);
	}
	
	@Override
	public DynamicQueryResponse getFsaDetails(DynamicQueryMappingReq dynamicMappingRequest){
		return getDynamicFilterList(fsaCriteriaDAO.getFsaModelBrandVehLinePlant(dynamicMappingRequest));
	}
	
	
	@Override
	@Cacheable("getAllWersDetails")
	public List<FsaFilterCriteriaResponse> getAllWersDetails(){
		DynamicQueryMappingReq dynamicMappingRequest = new DynamicQueryMappingReq();
		return fsaCriteriaDAO.getFsaWersDetails(dynamicMappingRequest);
	}
	
	private DynamicQueryResponse getDynamicFilterList(List<FsaFilterCriteriaResponse> fsaCriteriaResponse) {
		DynamicQueryResponse dynamicQueryResponse = new DynamicQueryResponse();
		List<AssemblyPlantList> assemblyPlantList = new ArrayList<>();
		List<ModelYearList> modelYear = new ArrayList<>();
		List<VehicleBrandList> vehicleBrandLists = new ArrayList<>();
		List<VehicleTypeList> vehicleTypeList = new ArrayList<>();
		List<AttributeGroupingList> attributeGroupingLists = new ArrayList<>();
		List<GCPFilterList> gcpFilterList = new ArrayList<>();
		Set<String> uniqueValue = new HashSet<>();
		List<WersValuesList> wersValue = new ArrayList<>();
		
		fsaCriteriaResponse.forEach(fsaCriteria->{
			processUniqueModelBrandVehLine(fsaCriteria, uniqueValue, modelYear, vehicleTypeList, vehicleBrandLists);
			if(StringUtils.isNotBlank(fsaCriteria.getPlant()) && StringUtils.isNotBlank(fsaCriteria.getPlantDesc()) && uniqueValue.add(fsaCriteria.getPlant())) {
				assemblyPlantList.add(new AssemblyPlantList(fsaCriteria.getPlant(), fsaCriteria.getPlantDesc().trim()));
			}
			if(uniqueValue.add(String.valueOf(fsaCriteria.getWersCode())) && StringUtils.isNotBlank(fsaCriteria.getWersDesc())) {
				String wersDesc = StringUtils.trimToEmpty(fsaCriteria.getWersDesc());
				String wersFamilyCode = StringUtils.isNotBlank(fsaCriteria.getWersValue()) ? StringUtils.trimToEmpty(fsaCriteria.getWersValue()).substring(0,3):StringUtils.EMPTY;
				gcpFilterList.add(new GCPFilterList(fsaCriteria.getWersCode(), TargetingUtil.getWersDescWithFamilyCode(wersDesc, wersFamilyCode),wersFamilyCode));
			}
			if(StringUtils.isNotBlank(fsaCriteria.getWersValue()) && StringUtils.isNotBlank(fsaCriteria.getWersValueDesc()) && uniqueValue.add(fsaCriteria.getWersValue())) {
				wersValue.add(new WersValuesList(fsaCriteria.getWersValue(), TargetingUtil.getWersDescWithFamilyCode(StringUtils.trimToEmpty(fsaCriteria.getWersValueDesc()),StringUtils.trimToEmpty(fsaCriteria.getWersValue()))));
			}
		});
		List<ModelYearList> sortedModelYear = modelYear.stream().sorted(Comparator.comparingInt(ModelYearList::getModelYearsInt).reversed()).collect(Collectors.toList());
		vehicleTypeList.sort((VehicleTypeList s1, VehicleTypeList s2)->s1.getVehicleLnX().compareTo(s2.getVehicleLnX())); 
		vehicleBrandLists.sort((VehicleBrandList s1, VehicleBrandList s2)->s1.getBrandX().compareTo(s2.getBrandX())); 
		wersValue.sort((WersValuesList s1, WersValuesList s2)->s1.getWrsFilterDescription().compareTo(s2.getWrsFilterDescription())); 
		assemblyPlantList.sort((AssemblyPlantList s1, AssemblyPlantList s2)->s1.getGcpWersFtrX().compareTo(s2.getGcpWersFtrX())); 		
		gcpFilterList.sort((GCPFilterList s1, GCPFilterList s2)->s1.getGcpFilterX().compareTo(s2.getGcpFilterX())); 
		dynamicQueryResponse.setGcpFilterList(gcpFilterList);
		dynamicQueryResponse.setAssemblyPlantList(assemblyPlantList);
		dynamicQueryResponse.setVehicleTypeList(vehicleTypeList);
		dynamicQueryResponse.setModelYear(sortedModelYear);
		dynamicQueryResponse.setWersValue(wersValue);
		dynamicQueryResponse.setVehicleBrandLists(vehicleBrandLists);		
		dynamicQueryResponse.setAttributeGroupingLists(attributeGroupingLists);
		return dynamicQueryResponse;
	}
	
	private void processUniqueModelBrandVehLine(FsaFilterCriteriaResponse fsaCriteria, Set<String> uniqueValue,List<ModelYearList> modelYear, 
			List<VehicleTypeList> vehicleTypeList, List<VehicleBrandList> vehicleBrandLists) {
		if(StringUtils.isNotBlank(fsaCriteria.getModelCode()) && uniqueValue.add(fsaCriteria.getModelCode())) {
			modelYear.add(new ModelYearList(fsaCriteria.getModelCode(), Integer.valueOf(fsaCriteria.getModelCode().trim())));
		}
		if(StringUtils.isNotBlank(fsaCriteria.getVehLine()) && StringUtils.isNotBlank(fsaCriteria.getVehLineDesc()) && uniqueValue.add(fsaCriteria.getVehLine())) {
			vehicleTypeList.add(new VehicleTypeList(fsaCriteria.getVehLine(), fsaCriteria.getVehLineDesc().trim()));
	   }
		if(StringUtils.isNotBlank(fsaCriteria.getBrandCode()) && StringUtils.isNotBlank(fsaCriteria.getBrandDesc()) &&  uniqueValue.add(fsaCriteria.getBrandDesc().trim())) {
			vehicleBrandLists.add(new VehicleBrandList(fsaCriteria.getBrandCode(), fsaCriteria.getBrandDesc().trim()));
	   }
	}
}
