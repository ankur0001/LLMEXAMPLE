package com.ford.gcamp.targeting.gridgcamp.gcamp.entity;


import java.sql.Timestamp;

import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Table;

import org.apache.commons.lang3.StringUtils;
import org.hibernate.annotations.UpdateTimestamp;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Entity
@Table(name = "SGCPD26_GRID_SFT_CRIT")
public class SoftwareCriteriaData {
	
	@EmbeddedId
	private SoftwareCriteriaId id;
	@Column(name = "GCPD26_NODE_C")
	private String node;
	@Column(name = "GCPD26_MODULE_C")
	private String module;
	@Column(name = "GCPD26_DID_C")
	private String did;
	@Column(name = "GCPD26_DFCT_SFT_VERSION_C")
	private String defectiveSoftwareVersion;
	@Column(name = "GCPD26_TGT_SFT_VERSION_C")
	private String targetSoftwareVersion;
	@Column(name = "GCPD26_OPERATOR_C")
	private String operator;
	@Column(name = "GCPD26_UPDATE_ID_C")
	private String updateId;
	@Setter(AccessLevel.NONE)
	@Getter(AccessLevel.NONE)	
	@Column(name = "GCPD26_UPDATE_S")
	@UpdateTimestamp
	private Timestamp updateTimeStamp;
	
	@PrePersist
	@PreUpdate
	public void updateDefault() {
		if(targetSoftwareVersion == null) {
			targetSoftwareVersion = StringUtils.EMPTY;
		}
	}
}
