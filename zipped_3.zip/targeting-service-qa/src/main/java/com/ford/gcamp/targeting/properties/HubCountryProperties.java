package com.ford.gcamp.targeting.properties;

import java.util.Map;

import org.springframework.boot.context.properties.ConfigurationProperties;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@ConfigurationProperties(prefix = "targeting")
@Getter
@Setter
@NoArgsConstructor
public class HubCountryProperties {
	private Map<String, String> hub;
	private Map<String, String> country;
	private Map<String, String> gridgcamp;
	private Map<String, String> region;
}