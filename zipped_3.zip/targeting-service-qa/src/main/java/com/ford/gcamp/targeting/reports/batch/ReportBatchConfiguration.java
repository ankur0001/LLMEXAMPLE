package com.ford.gcamp.targeting.reports.batch;


import javax.sql.DataSource;

import lombok.RequiredArgsConstructor;
import org.springframework.batch.core.configuration.BatchConfigurationException;
import org.springframework.batch.core.configuration.support.DefaultBatchConfiguration;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.launch.support.TaskExecutorJobLauncher;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.repository.support.JobRepositoryFactoryBean;
import org.springframework.batch.item.database.support.DefaultDataFieldMaxValueIncrementerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.task.TaskExecutor;
import org.springframework.scheduling.TaskScheduler;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.concurrent.ThreadPoolTaskScheduler;
import org.springframework.transaction.PlatformTransactionManager;

import java.util.prefs.BackingStoreException;

@EnableAsync
@Configuration
@RequiredArgsConstructor
public class ReportBatchConfiguration extends DefaultBatchConfiguration {

	@Value("${report.scheduler.threadpool.size}")
	private int schedulerThreadPoolSize;

	@Value("${report.job.threadpool.size}")
	private int jobThreadPoolSize;

	@Value("${spring.batch.jdbc.table-prefix}")
	private String tablePrefix;

	@Autowired
	private DataSource dataSource;

	@Autowired
	private PlatformTransactionManager transactionManager;

	@Bean
	public TaskScheduler taskScheduler() {
		ThreadPoolTaskScheduler taskScheduler = new ThreadPoolTaskScheduler();
		taskScheduler.setPoolSize(schedulerThreadPoolSize);
		taskScheduler.setThreadGroupName("Targeting-TaskScheduler-Report");
		taskScheduler.afterPropertiesSet();
		return taskScheduler;

	}

	@Bean
	@Override
	public TaskExecutor getTaskExecutor() {
		ThreadPoolTaskScheduler taskExecutor = new ThreadPoolTaskScheduler();
		taskExecutor.setPoolSize(jobThreadPoolSize);
		taskExecutor.setWaitForTasksToCompleteOnShutdown(true);
		taskExecutor.setThreadGroupName("Targeting-TaskExecutor-Report");
		taskExecutor.initialize();
		return taskExecutor;
	}

	@Bean
	@Override
	public TaskExecutorJobLauncher jobLauncher(JobRepository jobRepository) throws BatchConfigurationException {
		TaskExecutorJobLauncher jobLauncher = new TaskExecutorJobLauncher();
		try {
			jobLauncher.setTaskExecutor(getTaskExecutor());
			jobLauncher.setJobRepository(jobRepository());
			jobLauncher.afterPropertiesSet();
			return jobLauncher;
		} catch (Exception e) {
			throw new BatchConfigurationException("Unable to configure the default job launcher", e);
		}
	}

	@Bean
	@Override
	public JobRepository jobRepository() throws BatchConfigurationException {
		JobRepositoryFactoryBean jobRepositoryFactoryBean = new JobRepositoryFactoryBean();

		try {
			jobRepositoryFactoryBean.setDataSource(dataSource);
			jobRepositoryFactoryBean.setTransactionManager(transactionManager);
			jobRepositoryFactoryBean.setDatabaseType("DB2");
			jobRepositoryFactoryBean.setTablePrefix(tablePrefix);
			DefaultDataFieldMaxValueIncrementerFactory incrementerFactory = new DefaultDataFieldMaxValueIncrementerFactory(dataSource);
			jobRepositoryFactoryBean.setIncrementerFactory(incrementerFactory);
			jobRepositoryFactoryBean.afterPropertiesSet();

			return jobRepositoryFactoryBean.getObject();
		} catch (Exception e) {
			throw new BatchConfigurationException("Unable to configure the default job repository", e);
		}
	}
}
