package com.ford.gcamp.targeting.core.exception;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class GCampDB2Exception extends GCampDatabaseException {

	private static final long serialVersionUID = -7547954318899061366L;
	private static final DataErrorInfoLayout dataErrorInfoLayout = null;
	private static final DB2ErrorDetailLayout db2ErrorDetailLayout = null;
	
	private static final Logger LOGGER = LoggerFactory.getLogger(GCampDB2Exception.class);
	

	/**
	 * Constructor for GCampDB2Exception
	 */
	public GCampDB2Exception() {
		super();
	}
	
	/**
	 * Constructor for GCampDB2Exception
	 */
	public GCampDB2Exception(String msg) {
		super(msg);
	}

	/**
	 * Constructor for GCampDB2Exception
	 */
	public GCampDB2Exception(Throwable rootCause) {
		super(rootCause);
	}

	/**
	 * Constructor for GCampDB2Exception
	 */
	public GCampDB2Exception(String msg, Throwable rootCause) {
		super(msg, rootCause);
	}

	public boolean isStoreProcError(){
		return dataErrorInfoLayout!=null && dataErrorInfoLayout.isStoredProcError();
	}

	public boolean isStoreProcDB2Error(){
		return dataErrorInfoLayout!=null && dataErrorInfoLayout.isStoredProcDB2Error();
	}

	/**
	 * Gets the dataErrorInfoLayout
	 * @return Returns a DataErrorInfoLayout
	 */
	public DataErrorInfoLayout getDataErrorInfoLayout() {
		return dataErrorInfoLayout;
	}
	

	/**
	 * Gets the db2ErrorDetailLayout
	 * @return Returns a DB2ErrorDetailLayout
	 */
	public DB2ErrorDetailLayout getDb2ErrorDetailLayout() {
		return db2ErrorDetailLayout;
	}
	
	
	@Override
	public void printStackTrace(){
		super.printStackTrace();
		LOGGER.info("Details are: {}" , getErrorDetails());
	}

	@Override
	public void printStackTrace(java.io.PrintWriter pw){
		super.printStackTrace(pw);
		pw.println("Details are: " + getErrorDetails());
	}

	@Override
	public void printStackTrace(java.io.PrintStream ps){
		super.printStackTrace(ps);
		ps.println("Details are: " + getErrorDetails());
	}	
	public String getErrorDetails(){
		StringBuilder answer = new StringBuilder("");
		if(dataErrorInfoLayout!=null){
			answer.append(" Error Program:");
			answer.append(dataErrorInfoLayout.getPrgName());
			answer.append(" Error SqlCode:");
			answer.append(dataErrorInfoLayout.getSqlCode());
			answer.append(" Error Message: ");
			answer.append(dataErrorInfoLayout.getErrMessage());
			answer.append(" Error Paragraph:");
			answer.append(dataErrorInfoLayout.getParagraph());
			answer.append(" Error TableName: ");
			answer.append(dataErrorInfoLayout.getTableName());
		}
		return answer.toString();
	}
}

