package com.ford.gcamp.targeting.gridgcamp.grid.entity;


import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Entity
@Table(name = "SGCPE10_HUB")
public class HubLookupData implements Serializable{

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "GCPE10_HUB_C")
	private String hubCode;
	@Column(name = "GCPE10_HUB_DESC_X")
	private String hubDescription;
	@Column(name = "COUNTRY_ISO3_C")
	private String defaultCountryCode;
	
}
