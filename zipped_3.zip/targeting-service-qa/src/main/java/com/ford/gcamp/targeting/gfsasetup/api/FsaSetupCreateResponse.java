package com.ford.gcamp.targeting.gfsasetup.api;

import com.ford.gcamp.targeting.common.api.ResponseStatusDTO;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@EqualsAndHashCode(callSuper = false)
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FsaSetupCreateResponse extends ResponseStatusDTO {
	@NotNull
	@Schema(description = "globalFSANumber")
	@Size(min = 1, max = 8, message = "Max length 8")
	@Pattern(regexp = "^\\d*$", message = "Global FSA Invalid")
	private String fsaNumber;
}
