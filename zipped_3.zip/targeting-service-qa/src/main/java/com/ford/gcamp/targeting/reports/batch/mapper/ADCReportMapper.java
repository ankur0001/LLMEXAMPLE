package com.ford.gcamp.targeting.reports.batch.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.commons.lang3.StringUtils;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;
import com.ford.gcamp.targeting.reports.batch.exception.api.ADCReport;

@Component
public class ADCReportMapper implements RowMapper<ADCReport> {

	@Override
	public ADCReport mapRow(ResultSet rs, int rowNum) throws SQLException {
		return ADCReport.builder().reportId(StringUtils.trimToEmpty(rs.getString(1)))
				.globalFsa(StringUtils.trimToEmpty(rs.getString(2)))
				.supplementCode(StringUtils.trimToEmpty(rs.getString(3)))
				.vinGroupCode(StringUtils.trimToEmpty(rs.getString(4)))
				.vin(StringUtils.trimToEmpty(rs.getString(5)))
				.hubCode(StringUtils.trimToEmpty(rs.getString(6)))
				.countryCode(StringUtils.trimToEmpty(rs.getString(7)))
				.remarks(StringUtils.trimToEmpty(rs.getString(8)))
				.timestamp(StringUtils.trimToEmpty(rs.getString(9)))
				.build();
	}

}
