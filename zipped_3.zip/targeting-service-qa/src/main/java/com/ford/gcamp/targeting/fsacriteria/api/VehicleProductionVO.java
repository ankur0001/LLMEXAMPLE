package com.ford.gcamp.targeting.fsacriteria.api;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.web.bind.annotation.PathVariable;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class VehicleProductionVO extends FsaVehicleCommonVO {

	@Size(min = 0, max = 10)
	@Pattern(regexp = "^|[a-zA-Z\\d\\s]*$")
	@Schema(example = "000000016", description = "prodFilterCode")
	private String prodFilterCode;

	@Size(min = 0, max = 250)
	@Pattern(regexp = "^|[a-zA-Z\\d\\s]*$")
	@Schema(example = "PRODUCTION DATE", description = "prodFilterCode")
	private String prodFilterName;

	@Size(min = 0, max = 20)
	@Schema(example = "05-Jan-2022", description = "prodStartDate")
	@Pattern(regexp ="^[A-Za-z\\d\\-]*$", message = "prodStartDate")
	private String prodStartDate;

	@Size(min = 0, max = 20)
	@Schema(example = "08-May-2024", description = "prodEndDate")
	@Pattern(regexp ="^[A-Za-z\\d\\-]*$", message = "prodEndDate")
	private String prodEndDate;
	
}
