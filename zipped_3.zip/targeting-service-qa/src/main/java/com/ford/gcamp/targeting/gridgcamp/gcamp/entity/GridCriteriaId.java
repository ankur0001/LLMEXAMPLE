package com.ford.gcamp.targeting.gridgcamp.gcamp.entity;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import jakarta.persistence.Table;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@Embeddable
@Table(name="SGCPD25_GRID_CRIT")
public class GridCriteriaId implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Column(name = "GCPF59_GRID_YR_D")
	private int gridYearId;
	@Column(name = "GCPF59_GRID_VERSION_R")
	private int version;
	@Column(name = "GCPF59_GRID_IMPL_D")
	private int implementationId;
	@Column(name = "GCPF59_GRID_SUPPL_C")
	private String supplementId;
	@Column(name = "GCPF59_GRID_SEQ_R")
	private int gridSequence;
	@Column(name = "GCPD25_SEQ_R")
	private int sequenceId;
	@Column(name = "GCPF59_CRIT_R")
	private int criteriaNumber;
	
	
	public GridCriteriaId(GridCriteriaId gridCriteriaId, int criteriaSeqId, int seqNum) {
		super();
		this.gridYearId = gridCriteriaId.getGridYearId();
		this.gridSequence = gridCriteriaId.getGridSequence();
		this.implementationId = gridCriteriaId.getImplementationId();
		this.version = gridCriteriaId.getVersion();
		this.supplementId = gridCriteriaId.getSupplementId();
		this.criteriaNumber = criteriaSeqId;
		this.sequenceId = seqNum;
	}
	
	
}
