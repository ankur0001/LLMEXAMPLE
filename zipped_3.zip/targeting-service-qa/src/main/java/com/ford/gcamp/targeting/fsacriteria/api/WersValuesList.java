package com.ford.gcamp.targeting.fsacriteria.api;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Component
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class WersValuesList {
	@Size(min = 0, max = 6)
	@Pattern(regexp = "^[a-zA-Z\\d]*$")
	@Schema(example = "AAGDZC", description = "AssemblyPlantCode")
	private String wrsFilterCode;


	@NotNull
	@Size(max = 254)
	@Pattern(regexp = "^[A-Za-z0-9\\s\\*]*$")
	@Schema(example = "AAGDZC", description = "wrsFilterDescription")
	private String wrsFilterDescription;
	@JsonIgnore
	private String vehLine;
	
	public WersValuesList(String wrsFilterCode, String wrsFilterDescription) {
		super();
		this.wrsFilterCode = wrsFilterCode;
		this.wrsFilterDescription = wrsFilterDescription;
	}

}
