package com.ford.gcamp.targeting.gfsasetup;

import com.ford.cloudnative.base.api.StandardErrorResponse;
import com.ford.gcamp.targeting.common.CommonConstants;
import com.ford.gcamp.targeting.common.api.CommonErrorResponse;
import com.ford.gcamp.targeting.core.exception.ResourceNotFoundException;
import com.ford.gcamp.targeting.gfsasetup.api.FsaSetupCreateRequest;
import com.ford.gcamp.targeting.gfsasetup.api.FsaSetupCreateResponse;
import com.ford.gcamp.targeting.gfsasetup.api.GfsaTypesResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping(path = "/api/v1/targeting/gfsasetup")
@Validated
public class GlobalFSASetupController {

	@Autowired
	private GlobalFSASetupService globalFSASetupService;

	@PreAuthorize("@authorizeService.isAuthorized('GCAMP:globalFsaSetup:CREATE','execute')")
	@PostMapping
	@Operation(summary = "Create global FSA", security = {
			@SecurityRequirement(name = "ADFS"),
			@SecurityRequirement(name = "AzureAD")
	})
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Create Global FSA data request fetched successfully",
					content = @Content(mediaType = "application/problem+json",schema = @Schema(implementation = FsaSetupCreateResponse.class))),
			@ApiResponse(responseCode = "412", description = "Precondition Failed", content = @Content(schema = @Schema(implementation = CommonErrorResponse.class))),
			@ApiResponse(responseCode = "default", description = "All Errors", content = @Content(schema = @Schema(implementation = StandardErrorResponse.class)))
	})
	public ResponseEntity<FsaSetupCreateResponse> createGfsaSetup(
			@RequestBody @Valid FsaSetupCreateRequest fsaSetupCreateRequest) throws ResourceNotFoundException {
		FsaSetupCreateResponse response = null;
		if (fsaSetupCreateRequest != null) {			
			response = globalFSASetupService.createGfsaSetup(fsaSetupCreateRequest);
		} else {
			response = new FsaSetupCreateResponse();
			response.setStatus(CommonConstants.FAILURE);
			response.setStatusCode(CommonConstants.FAILURE_CODE);
			response.setStatusDescription(CommonConstants.INVALID_INPUT);
		}

		return ResponseEntity.ok(response);
	}

	@PreAuthorize("@authorizeService.isAuthorized('GCAMP:globalFsaSetup:CREATENEW','execute')")
	@Operation(summary = "Create global FSA", security = {
			@SecurityRequirement(name = "ADFS"),
			@SecurityRequirement(name = "AzureAD")
	})
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Create Global FSA data request fetched successfully",
					content = @Content(mediaType = "application/problem+json",schema = @Schema(implementation = GfsaTypesResponse.class))),
			@ApiResponse(responseCode = "default", description = "All Errors", content = @Content(schema = @Schema(implementation = StandardErrorResponse.class)))
	})
	@GetMapping
	public ResponseEntity<GfsaTypesResponse> getGfsaTypes() {
		GfsaTypesResponse response = globalFSASetupService.getGfsaTypes();
		return ResponseEntity.ok(response);
	}
	
}
