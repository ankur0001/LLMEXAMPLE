package com.ford.gcamp.targeting.fsacriteria.api;

import java.util.List;


import com.ford.gcamp.targeting.common.api.CommonResponse;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.SuperBuilder;

@Setter
@Getter
@SuperBuilder(toBuilder = true)
@NoArgsConstructor
public class VinGroupRegionalFilterResponse extends CommonResponse {

	@Size(min = 0, max = 250, message = "regionalFilters List")
	private List<@Valid FSACriteriaRegionalFilterDetails> regionalFilters;
}
