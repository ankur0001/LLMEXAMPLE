package com.ford.gcamp.targeting.gsar.api;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import io.swagger.v3.oas.annotations.media.Schema;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonInclude(Include.NON_NULL)
public class FscCriteriaRequestForGsar {


    @NotNull
    @Size(min =1,max = 10)
    @Pattern(regexp = "^[a-zA-Z\\d\\s]*$")
    @Schema(type="string",example = "00015543", description = "Local FSA number")
    private String fscNumber;



    @Size(min=0, max = 8)
    @Pattern(regexp ="^[A-Za-z\\d\\s*]*$", message = "population Code")
    @Schema(type="string",example = "Original", description = "Population")
    private String population;

    @NotNull
    @Size(max =1)
    @Pattern(regexp = "^[a-zA-Z\\s]*$")
    @Schema(type="string",example = "G", description = "FSA Type Global or Local")
    private String optRadio;



    @Size(min=0, max = 8)
    @Pattern(regexp = "^[a-zA-Z\\d\\-]*$")
    @Schema(type="string",example = "SDUDIWAR", description = "CDSID")
    private String cdsId;

}