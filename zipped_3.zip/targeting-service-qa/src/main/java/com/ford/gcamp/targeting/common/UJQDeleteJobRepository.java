package com.ford.gcamp.targeting.common;

import java.util.HashMap;
import java.util.Map;

import com.ford.gcamp.targeting.common.api.BatchJobDataForPhaseByPercent;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import com.ford.gcamp.targeting.common.api.BatchJobData;

import lombok.extern.slf4j.Slf4j;

@Repository
@Slf4j
public class UJQDeleteJobRepository {

	@Value("${DB_OWNER}")
	private String ownerId;

	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

	public UJQDeleteJobRepository(NamedParameterJdbcTemplate namedParameterJdbcTemplate) {
		super();
		this.namedParameterJdbcTemplate = namedParameterJdbcTemplate;
	}

	public void deleteUJQJob(BatchJobData batchJobData) {

		StringBuilder sql = new StringBuilder();
		Map<String, Object> valueByParamName = new HashMap<>();
		sql.append("DELETE FROM ")
				.append(ownerId)
				.append("SGCPE21_JOB_DEPEND ")
				.append("WHERE ");

		if (StringUtils.isNotBlank(batchJobData.getBatchCode())) {
			valueByParamName.put("batchCode", batchJobData.getBatchCode());
			sql.append("GCPC01_BATCH_C = :batchCode ");
		}
		if (batchJobData.getGlobalFSANo() > 0) {
			valueByParamName.put("globalFSANum", batchJobData.getGlobalFSANo());
			sql.append(" AND GCPA15_GLOBL_FSA_R = :globalFSANum ");
		}
		if (StringUtils.isNotBlank(batchJobData.getLocalFSANo())) {
			valueByParamName.put("localFsaNum", batchJobData.getLocalFSANo());
			sql.append(" AND GCPA16_LOCAL_FSA_R = :localFsaNum ");
		}
		if (StringUtils.isNotBlank(batchJobData.getHubCode())) {
			valueByParamName.put("hubCode", batchJobData.getHubCode());
			sql.append(" AND GCPE10_HUB_C = :hubCode ");
		}
		if (StringUtils.isNotBlank(batchJobData.getCountryCode())) {
			valueByParamName.put("countryCode", batchJobData.getCountryCode());
			sql.append(" AND COUNTRY_ISO3_C = :countryCode ");
		}
		if (batchJobData.getSegment() != 9999) {
			valueByParamName.put("segmentNum", batchJobData.getSegment());
			sql.append(" AND GCPD14_SEGMENT_R = :segmentNum ");
		}
		if (StringUtils.isNotBlank(batchJobData.getSupplement())) {
			valueByParamName.put("supplCode", batchJobData.getSupplement());
			sql.append(" AND GCPA09_SUPPL_C = :supplCode ");
		}
		if (!"999".equalsIgnoreCase(batchJobData.getFolderId())) {
			valueByParamName.put("folderId", batchJobData.getFolderId());
			sql.append(" AND GCPD08_FOLDER_D = :folderId ");
		}
		if (StringUtils.isNotBlank(batchJobData.getVin())) {
			valueByParamName.put("vin", batchJobData.getVin());
			sql.append(" AND GCPB15_VIN_C = :vin ");
		}
		SqlParameterSource parameters = new MapSqlParameterSource().addValues(valueByParamName);
		log.info("Delete UJQ Job Query: {}", sql.toString());
		log.info("Delete UJQ Job Query Parameters: {}", valueByParamName);
		try {
			namedParameterJdbcTemplate.update(sql.toString(), parameters);
			log.info("Delete is successful");
		} catch (Exception ex) {
			log.error("Error in deleting the UJQ Job", ex);
		}

	}
}
