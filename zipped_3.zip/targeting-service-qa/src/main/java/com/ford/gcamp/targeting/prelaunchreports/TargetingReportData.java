package com.ford.gcamp.targeting.prelaunchreports;

import lombok.Builder;
import lombok.Data;

@Builder
@Data
public class TargetingReportData {

	private String reportId;
	private String reportCode;
	private String reportName;
	private String agencyCode;
	private String reportFormat;
	private String requestedBy;
	private String generatedDate;
	private String generatedTimeStamp;
}
