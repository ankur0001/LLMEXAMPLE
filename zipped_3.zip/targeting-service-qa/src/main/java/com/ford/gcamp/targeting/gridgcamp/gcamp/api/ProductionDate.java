package com.ford.gcamp.targeting.gridgcamp.gcamp.api;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.validation.constraints.Size;


import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@JsonIgnoreProperties(ignoreUnknown = true)
public class ProductionDate extends GridVehicleCriteria {

	@Schema(example = "2020-12-31")
	@Size(min = 0, max = 25, message = "Valid pattern YYYY-MM-DD")
	private String startDate;

	@Schema(example = "2020-12-31")
	@Size(min = 0, max = 25, message = "Valid pattern YYYY-MM-DD")
	private String endDate;
}
