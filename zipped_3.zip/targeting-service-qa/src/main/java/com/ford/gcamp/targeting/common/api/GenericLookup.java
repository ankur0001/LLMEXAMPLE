package com.ford.gcamp.targeting.common.api;

import com.ford.gcamp.targeting.common.CommonConstants;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.io.Serial;
import java.io.Serializable;

@Getter
@Setter
@Builder
public class GenericLookup implements Serializable{
	@Serial
	private static final long serialVersionUID = -8658766453274792576L;


	@Schema(types={"string","null"},description = "code")
	@Size(min = 0, max = 100, message = "Max length 100")
	@Pattern(regexp ="^[A-Za-z\\d\\*\\s]*$", message = "Code Name Invalid")
	String code;

	@Schema(types={"string","null"},description = "description")
	@Size(min = 0, max = 300, message = "Max length 300")
	@Pattern(regexp ="^[A-Za-z\\d\\s,_\\-()&.\\/]*$", message = "Description Name Invalid")
	String description;

	@Size(min = 1, max = 1)
	@Pattern(regexp = "^-$")
	private static final  String  DELIMETER = "-";

	public GenericLookup()	{
		code = "";
		description = "";
	}

	public GenericLookup(String code, String description)	{
		this.code = code;
		this.description = description;	
	}

	@Schema(types={"string","null"},description= "description")
	@Size(min = 0, max = 300, message = "Max length 300")
	@Pattern(regexp = CommonConstants.SWAGGER_ANY_CHARACTER_REGEX, message = "code Name Invalid")
	public String getCodeAndDescription() {
		
		StringBuilder buffer = new StringBuilder();
		String desc=this.getDescription();
		
		buffer.append(this.getCode());
		buffer.append(GenericLookup.DELIMETER);
		if(desc != null && !desc.trim().isEmpty()){
			
			if(desc.trim().length() > 30 ){
				
				desc=desc.substring(0,30);
			}
			
			buffer.append(desc.trim());
		}
		
		return buffer.toString();
	}

	public String toString (){
		return String.format("""
				com.ford.fcsd.gcamp.common.data.GenericLookup
				[
				Code=%s,\
				
				Description=%s,\
				
				]
				""", this.getCode(), this.getDescription());
	}
}


