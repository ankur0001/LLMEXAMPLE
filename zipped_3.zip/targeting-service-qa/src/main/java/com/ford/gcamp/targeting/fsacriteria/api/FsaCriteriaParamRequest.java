package com.ford.gcamp.targeting.fsacriteria.api;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.v3.oas.annotations.extensions.Extension;
import io.swagger.v3.oas.annotations.extensions.ExtensionProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.web.bind.annotation.PathVariable;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class FsaCriteriaParamRequest {
	@NotNull
	@Size(min = 5, max = 6)
	@Pattern(regexp = "^\\d{2}[A-Za-z\\d]{2}\\d{1}\\d*$")
	@Schema(type="string", description = "FSA number",minLength=5,maxLength = 6, extensions = @Extension(properties = @ExtensionProperty(name = "x-42c-sample", value = "15311")))
	private String fsaNumber;

	@NotNull
	@Size(min = 0, max = 1)
	@Pattern(regexp = "^[A-Z]$")
	@Schema(example = "L", description = "G-Global, L-Local")
	private String fsaType;


	@Schema(example ="00", description = "supplementId")
	@Size(min = 0, max = 2)
	@Pattern(regexp ="^[A-Za-z\\d]*$")
	private String vehiclePopUpCode;

	@Schema(example="TDHARTI",description = "requester")
	@Size(min = 0, max = 8)
	@Pattern(regexp ="^[A-Za-z\\d]*$")
	private String cdsId;


	private boolean isLocalTest;

	@Schema(example= "GH", description = "Vin group code")
	@Size(min = 0, max = 100)
	@Pattern(regexp ="^[A-Za-z\\d,]*$")
	private String vinGrpCode;

	@Schema(example = "2" ,description = "Vin group Sequence Number")
	@Size(min = 0, max = 100)
	@Pattern(regexp ="^[\\d,]*$")
	private String vinGrpSeq;



	@Schema(example="test",description = "Vin group Sequence Description")
	@Size(min = 0, max = 254)
	@Pattern(regexp ="^[a-zA-Z\\d\\s\\-\\.\\*\\(\\)\\,\\+\\_\\#||%^\\$\\'\\;\\:/]*$")
	private String vinGrpDesc;


	@Schema(example= "D" , description = "Delete Confirm Flag")
	@Size(min = 0, max = 1)
	@Pattern(regexp ="^[A-Za-z]*$")
	private String deleteConfirmFlag;
	private boolean extractRun;

	@Schema(example = "GH",description = "Vin group code Copied")
	@Size(min = 0, max = 2)
	@Pattern(regexp ="^[A-Za-z\\d]*$")
	private String copiedVinGroupCode;

	@Schema(example = "Y" , description = "Delete Confirm Flag")
	@Size(min = 0, max = 1)
	@Pattern(regexp ="^[A-Za-z]*$")
	private String otaIndicator;

	@Schema(example = "Y" , description = "Flag")
	@Size(min = 0, max = 1)
	@Pattern(regexp ="^[A-Za-z]*$")
	private String flag;

	@Schema(example= "B" , description = "Flag")
	@Size(min = 0, max = 1)
	@Pattern(regexp ="^[A-Za-z]$")
	private String fhmIndicator;

	@Valid
	private FSACriteriaRegionalFilterRequest regionalFilter;

}
