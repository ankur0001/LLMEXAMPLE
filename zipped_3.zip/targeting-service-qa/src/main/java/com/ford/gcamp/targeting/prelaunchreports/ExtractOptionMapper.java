package com.ford.gcamp.targeting.prelaunchreports;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import com.ford.gcamp.targeting.common.CommonConstants;
import com.ford.gcamp.targeting.common.DateConvert;
import com.ford.gcamp.targeting.common.TargetingUtil;
import com.ford.gcamp.targeting.common.api.CommonJobResponse;
import com.ford.gcamp.targeting.common.api.FSAInfoVO;
import com.ford.gcamp.targeting.prelaunchreports.api.DistributionsRequest;
import com.ford.gcamp.targeting.prelaunchreports.api.DownloadReportRequest;
import com.ford.gcamp.targeting.prelaunchreports.api.ExtractOptionRequest;
import com.ford.gcamp.targeting.prelaunchreports.api.ExtractOptionResponse;
import com.ford.gcamp.targeting.prelaunchreports.api.FsaGoRequest;
import com.ford.gcamp.targeting.prelaunchreports.api.LoadTargetingReportsResponse;
import com.ford.gcamp.targeting.prelaunchreports.api.SaveAsDefaultResponse;
import com.ford.gcamp.targeting.prelaunchreports.api.SaveDistributionsResponse;
import com.ford.gcamp.targeting.reports.batch.common.ReportGenerationUtil;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

@Slf4j
@Component
public class ExtractOptionMapper {

	@Value("${top10.werscodes}")
	private String top10Wers;

	@Value("${werscodes.remove.reports}")
	private String wersReports;

	public static final String PROCESS_CODE = "GCPG13_PROCESS_D";
	public static final String PROCESS_DESC = "GCPG13_PROCESS_X";
	public static final String GENRATED_TIMESTAMP = "GCPF38_REQUESTED_S";
	
	public String loadReportsParam1(FsaGoRequest fsaGoRequestParm) {
		StringBuilder param1 = new StringBuilder();
		param1.append(fsaGoRequestParm.getFsaType());
		if (StringUtils.equalsIgnoreCase("G", fsaGoRequestParm.getFsaType())) {
			param1.append(TargetingUtil.fillRemainingString(fsaGoRequestParm.getFsaNumber(), 8, "0"));
		} else {
			param1.append(TargetingUtil.fillRemainingString(fsaGoRequestParm.getFsaNumber(), 10, " "));
		}
		return param1.toString();
	}

	public String loadReportsParam2(FsaGoRequest fsaGoRequestParm) {
		StringBuilder param2 = new StringBuilder();
		param2.append(fsaGoRequestParm.getPopulation());
		param2.append(fsaGoRequestParm.getRequestType());
		return param2.toString();
	}

	public LoadTargetingReportsResponse parseAllReports(Map<String, Object> responseMap) {
		log.info("load targeting response::{}", responseMap);
		LoadTargetingReportsResponse response = new LoadTargetingReportsResponse();
		String eParam = (String) responseMap.get(CommonConstants.ERROR_PARM);
		String statusInd = eParam.substring(9, 10);
		if (statusInd != null && CommonConstants.FLAG_Y.equalsIgnoreCase(statusInd)) {
			String code = StringUtils.trimToEmpty(eParam.substring(37, 40));
			String desc = StringUtils.trimToEmpty(eParam.substring(40, 150));
			if ("305".equalsIgnoreCase(code)) {
				getAllReports(responseMap, response);
			} else {
				response.setStatus(CommonConstants.FAILURE);
				response.setStatusCode(CommonConstants.FAILURE_CODE);
				response.setStatusDescription(code + desc);
			}
		} else {
			getAllReports(responseMap, response);
		}
		return response;
	}
	
	private void getAllReports(Map<String, Object> responseMap, LoadTargetingReportsResponse response) {
		FSAInfoVO fsaInfoVO = new FSAInfoVO(); 
		String outPam1 = (String) responseMap.get(CommonConstants.OUTPUT_PARM1);
		String outPam2 = (String) responseMap.get(CommonConstants.OUTPUT_PARM2);
		String outparam3 = (String) responseMap.get("OUTPUT_PARM3");
		String lastModifiled = DateConvert.getInstance().formatOutputDate(outparam3.substring(8, 19)) + " by "
				+ (outparam3.substring(0, 8));
		String extractRunDate = outparam3.substring(34, 44);
		if (!extractRunDate.equals(CommonConstants.INVALID_DATE)) {
			response.setExtractLastRun(DateConvert.getInstance().formatOutputDate(extractRunDate));
		}
		fsaInfoVO.setString(outPam1, outPam2);
		response.setLastModifiedBy(lastModifiled);
		List<Map<String, Object>> reportResponse = (List<Map<String, Object>>) responseMap.get("#result-set-2");
		List<TargetingReportData> targetingReports = new ArrayList<>();
		if (reportResponse!=null) {
			reportResponse.stream().forEach(extractReportMap -> {
				TargetingReportData reportData = TargetingReportData.builder()
						.reportId(String.valueOf(extractReportMap.get("GCPF01_REPORT_ID_D")))
						.reportCode(String.valueOf(extractReportMap.get("GCPF04_REPORT_C")).trim())
						.reportName(capitalizeFirstChar(String.valueOf(extractReportMap.get("GCPF04_REPORT_X")).trim(), String.valueOf(extractReportMap.get("GCPF04_REPORT_C")).trim()))
						.agencyCode(String.valueOf(extractReportMap.get("GCPE44_AGENCY_C")).trim())
						.reportFormat(String.valueOf(extractReportMap.get("GCPF02_RPT_FMT_C")).trim())
						.requestedBy(String.valueOf(extractReportMap.get("GCPF38_REQ_BY_ID_D")).trim())
						.generatedDate(DateConvert.getInstance().formatOutputDate(String.valueOf(extractReportMap.get(GENRATED_TIMESTAMP)))
								+ " by " + (String.valueOf(extractReportMap.get("GCPF38_REQ_BY_ID_D"))))
						.generatedTimeStamp(DateConvert.getInstance().formatOutputDate(
						String.valueOf(extractReportMap.get(GENRATED_TIMESTAMP))) +" " +String.valueOf(extractReportMap.get(GENRATED_TIMESTAMP)).substring(11, 16)+" HRS")
						.build();
				targetingReports.add(reportData);
			});
			applySorting(targetingReports);
			response.setFsaInfoVO(fsaInfoVO);
			
		}
		response.setTargetingReportData(targetingReports);
		response.setStatus(CommonConstants.SUCCESS);
		response.setStatusCode(CommonConstants.SUCCESS_CODE);
		response.setStatusDescription(CommonConstants.SUCCESS_DESC);
	}
	
	private String capitalizeFirstChar(String reportName, String reportCode) {
		if (StringUtils.startsWithIgnoreCase(reportCode, "W")) {
			return ReportGenerationUtil.capitalize(reportName);
		}
		return reportName;
	}

	private void applySorting(List<TargetingReportData> targetingReports) {
		Collections.sort(targetingReports,Comparator.comparing(TargetingReportData::getReportCode));
		List<TargetingReportData> sortedTargetingReports=targetingReports.stream().filter(report->report.getReportCode().startsWith("T")).collect(Collectors.toList());
		Optional<TargetingReportData> iadReport=targetingReports.stream().filter(report->"IAD".equalsIgnoreCase(report.getReportCode())).findFirst();
		if(iadReport.isPresent()){
			targetingReports.remove(0);
			targetingReports.add(sortedTargetingReports.size(),iadReport.get());
		}
		
	}

	public String parmj18(String hubcode) {
		StringBuilder param = new StringBuilder();
		param.append("7");
		param.append("CSGCBA34");
		param.append(hubcode);
		param.append("*  ");
		return param.toString();
	}

	public String savedSelectParm1(ExtractOptionRequest extractOptionReq) {
		StringBuilder saveSlectFsaGo = new StringBuilder();
		saveSlectFsaGo.append(extractOptionReq.getFsaType());
		if (StringUtils.equalsIgnoreCase("G", extractOptionReq.getFsaType())) {
			saveSlectFsaGo.append(TargetingUtil.fillRemainingString(extractOptionReq.getFsaNumber(), 8, "0"));
		} else {
			saveSlectFsaGo.append(TargetingUtil.fillRemainingString(extractOptionReq.getFsaNumber(), 10, " "));
		}
		return saveSlectFsaGo.toString();
	}

	public String savedSelectParm2(ExtractOptionRequest extractOptionReq) {

		if (StringUtils.isNotBlank(extractOptionReq.getWersCodeSelected())) {
			String wersSelected = splitByComma(extractOptionReq.getWersCodeSelected(), 4, "");
			extractOptionReq.setWersCodeSelected(wersSelected);
		}
		StringBuilder saveSlectParm2 = new StringBuilder();
		saveSlectParm2.append(extractOptionReq.getProcessFlag());
		saveSlectParm2.append(TargetingUtil.fillRemainingString(extractOptionReq.getCdsId(),8," "));
		saveSlectParm2.append(extractOptionReq.getHubCode());
		saveSlectParm2.append(extractOptionReq.getPopulation());
		saveSlectParm2
				.append(TargetingUtil.fillRemainingString(String.valueOf(extractOptionReq.getReportCount()), 2, "0"));
		saveSlectParm2.append(TargetingUtil.fillRemainingString(extractOptionReq.getReportChecked(), 99, " "));
		saveSlectParm2
				.append(TargetingUtil.fillRemainingString(String.valueOf(extractOptionReq.getWersCodeCount()), 2, "0"));
		saveSlectParm2.append(TargetingUtil.fillRemainingString(extractOptionReq.getWersCodeSelected(), 40, " "));
		return saveSlectParm2.toString();
	}

	@SuppressWarnings("unchecked")
	public List<Wers> getWersList(Map<String, Object> wersListMap) {
		List<Map<String, Object>> wersMapList = (List<Map<String, Object>>) wersListMap.get("#result-set-5");

		String[] wersArry = top10Wers.split(",");

		String[] removedWers = wersReports.split(",");

		List<Wers> wersList = new ArrayList<>();

		if (CollectionUtils.isNotEmpty(wersMapList)) {
			for (Map<String, Object> map1 : wersMapList) {
				Wers gcpFilterList = new Wers();
				String wersDesc = ReportGenerationUtil.capitalize(StringUtils.trimToEmpty(String.valueOf(map1.get("GCPD02_FILTER_X"))));
				String wersFamilyCode = StringUtils.trimToEmpty(String.valueOf(map1.get("GCPB09_WERS_FMLY_C")));
				gcpFilterList.setWersCode(String.valueOf(map1.get("GCPD02_FILTER_C")));
				gcpFilterList.setWersValue(TargetingUtil.getWersDescWithFamilyCode(wersDesc,wersFamilyCode)); 
				gcpFilterList.setWersFamilyCode(wersFamilyCode);
				wersList.add(gcpFilterList);
			}
		}

		// remove the default selection reports 46 and 49
		for (String reportsRemoved : removedWers) {
			wersList.removeIf(wers -> wers.getWersCode().equals(reportsRemoved));
		}
		// creating a new list for removed id's
		List<String> listOfWers = Arrays.asList(wersArry);
		List<Wers> wersListAdd = wersList.stream()
				.filter(wers -> listOfWers.stream()
						.anyMatch(wersValuesList -> wersValuesList.equalsIgnoreCase(wers.getWersCode())))
				.collect(Collectors.toList());

		// remove the selected list
		for (String wesTop : wersArry) {
			wersList.removeIf(wers -> wers.getWersCode().equals(wesTop));
		}
		wersListAdd.addAll(wersList);
		return wersListAdd;
	}

	public ExtractOptionResponse getDefaultSelection(Map<String, Object> responseMap) {
		ExtractOptionResponse response = new ExtractOptionResponse();

		log.info("default selections ::{}", responseMap);
		String errorParm = (String) responseMap.get(CommonConstants.ERROR_PARM);
		log.info("error-Param::{}", errorParm);
		String statusInd = errorParm.substring(9, 10);
		if (statusInd != null && "Y".equalsIgnoreCase(statusInd)) {
			String errorCode = errorParm.substring(37, 40);
			String errorDesc = errorParm.substring(40, 150);
			response.setStatus(CommonConstants.FAILURE);
			response.setStatusCode(CommonConstants.FAILURE_CODE);
			response.setStatusDescription(errorCode + errorDesc);
		} else {

			FSAInfoVO fsaInfoVO = new FSAInfoVO();
			ReportsSelection reportSelection = new ReportsSelection();
			String fsaG01 = (String) responseMap.get("OUTPUT_FSAGO1");
			String fsaG02 = (String) responseMap.get("OUTPUT_FSAGO2");
			String outparam1 = (String) responseMap.get(CommonConstants.OUTPUT_PARM1);
			String outparam2 = (String) responseMap.get(CommonConstants.OUTPUT_PARM2);
			reportSelection.setReportCount(outparam1.substring(0, 2));
			reportSelection.setWersreportCount(outparam2.substring(0, 2));
			reportSelection.setCountry(outparam1.substring(101, 104));
			reportSelection.setFsaLoadDataExists(outparam1.substring(104, 105));
			List<String> listOfReports = getReportList(outparam1);
			List<String> wersReportList = getWersReportList(outparam2);
			reportSelection.setReportList(listOfReports);
			reportSelection.setWersReportList(wersReportList);
			fsaInfoVO.setString(fsaG01, fsaG02);
			response.setFsaInfoVO(fsaInfoVO);
			response.setReportSelection(reportSelection);
			response.setStatus(CommonConstants.SUCCESS);
			response.setStatusCode(CommonConstants.SUCCESS_CODE);
			response.setStatusDescription(CommonConstants.SUCCESS_DESC);
		}
		return response;
	}

	private List<String> getReportList(String outparam1) {
		String reports = outparam1.substring(2, 101);
		int count = Integer.parseInt(outparam1.substring(0, 2));
		List<String> reportCodes = new ArrayList<>();
		for (int i = 0; i < count * 3; i = i + 3) {
			String str = reports.substring(i, i + 3);
			reportCodes.add(str);

		}
		return reportCodes;
	}

	private List<String> getWersReportList(String outparam2) {
		String reports = outparam2.substring(2);
		int count = Integer.parseInt(outparam2.substring(0, 2));
		List<String> reportCodes = new ArrayList<>();
		for (int i = 0; i < count * 4; i = i + 4) {
			String str = reports.substring(i, i + 4);
			reportCodes.add(str);

		}
		return reportCodes;
	}

	@SuppressWarnings("unchecked")
	public List<String> getLastUpdatedIds(Map<String, Object> responseMap) {
		List<Map<String, Object>> cdsIdListMap = (List<Map<String, Object>>) responseMap
				.get(CommonConstants.RESULT_SET_1);
		List<String> cdsIdList = new ArrayList<>();
		if (CollectionUtils.isNotEmpty(cdsIdListMap)) {

			for (Map<String, Object> map1 : cdsIdListMap) {
				cdsIdList.add(String.valueOf(map1.get("GCPG12_CDS_ID_C")));

			}
		}
		return cdsIdList;
	}

	public SaveAsDefaultResponse saveDefaultSelections(Map<String, Object> responseMap) {
		SaveAsDefaultResponse saveDefaultResponse = new SaveAsDefaultResponse();
		log.info("save as default response::{}", responseMap);
		if (responseMap != null) {
			String errorParm = (String) responseMap.get(CommonConstants.ERROR_PARM);
			String statusInd = errorParm.substring(9, 10);
			if (statusInd != null && "Y".equalsIgnoreCase(statusInd)) {
				String errorCode = errorParm.substring(37, 40);
				String errorDesc = errorParm.substring(40, 150);
				saveDefaultResponse.setStatus(CommonConstants.FAILURE);
				saveDefaultResponse.setStatusCode(CommonConstants.FAILURE_CODE);
				saveDefaultResponse.setStatusDescription(errorCode + errorDesc);
			} else {
				ReportsSelection defaultReports = new ReportsSelection();
				String outparam1 = (String) responseMap.get(CommonConstants.OUTPUT_PARM1);

				String outparam2 = (String) responseMap.get(CommonConstants.OUTPUT_PARM2);

				defaultReports.setReportCount(outparam1.substring(0, 2));
				defaultReports.setWersreportCount(outparam2.substring(0, 2));
				defaultReports.setCountry(outparam1.substring(101, 104));
				defaultReports.setFsaLoadDataExists(outparam1.substring(104, 105));
				List<String> listOfReports = getReportList(outparam1);
				List<String> wersReportList = getWersReportList(outparam2);
				defaultReports.setReportList(listOfReports);
				defaultReports.setWersReportList(wersReportList);
				saveDefaultResponse.setReportSelection(defaultReports);
				saveDefaultResponse.setStatus(CommonConstants.SUCCESS);
				saveDefaultResponse.setStatusCode(CommonConstants.SUCCESS_CODE);
				saveDefaultResponse.setStatusDescription(CommonConstants.SUCCESS_DESC);
			}
		}
		return saveDefaultResponse;
	}

	public String inputParm1H1Q(DistributionsRequest distributionRequest) {
		StringBuilder inputParm1 = new StringBuilder();
		inputParm1.append(distributionRequest.getProcessFlag());
		inputParm1.append(TargetingUtil.fillRemainingString(distributionRequest.getCdsId(),8," "));
		inputParm1.append(TargetingUtil.fillRemainingString(distributionRequest.getProcCode(), 4, "0"));
		inputParm1.append(TargetingUtil.fillRemainingString(distributionRequest.getProcDesc(), 30, " "));
		inputParm1.append(TargetingUtil.addSpaceToProc(7));
		return inputParm1.toString();
	}

	public String input2PArmH1Q() {
		StringBuilder inputParm2 = new StringBuilder();
		inputParm2.append(TargetingUtil.addSpaceToProc(100));
		return inputParm2.toString();
	}

	public String inputParm1A50(DistributionsRequest distributionRequest) {
		StringBuilder inputParm1 = new StringBuilder();
		inputParm1.append(distributionRequest.getProcessFlag());
		inputParm1.append(TargetingUtil.fillRemainingString(distributionRequest.getCdsId(), 8, " "));
		inputParm1.append(TargetingUtil.fillRemainingString(distributionRequest.getProcCode(), 4, "0"));
		inputParm1.append(TargetingUtil.fillRemainingString(distributionRequest.getHubCode(), 2, " "));
		inputParm1.append(TargetingUtil.fillRemainingString(distributionRequest.getCountryCode(), 3, " "));
		inputParm1.append(TargetingUtil.fillRemainingString(distributionRequest.getDistsListDesc(), 30, " "));
		return inputParm1.toString();
	}

	public String inputParm2A50(DistributionsRequest distributionRequest) {
		StringBuilder inputParm2 = new StringBuilder();
		inputParm2.append(TargetingUtil.fillRemainingString(distributionRequest.getProcCode(), 4, "0"));
		inputParm2.append(distributionRequest.getHubCode());
		inputParm2.append(TargetingUtil.fillRemainingString(distributionRequest.getCountryCode(), 3, " "));
		inputParm2.append(TargetingUtil.fillRemainingString(distributionRequest.getDistListCode(), 9, "0"));
		inputParm2.append(TargetingUtil.fillRemainingString(distributionRequest.getDistsListDesc(), 32, " "));
		return inputParm2.toString();
	}

	public List<Processes> parseProcessList(Map<String, Object> processListMap) {

		List<Map<String, Object>> reportResponse = (List<Map<String, Object>>) processListMap
				.get(CommonConstants.RESULT_SET_1);

		List<Processes> processLists = new ArrayList<>();
		if (CollectionUtils.isNotEmpty(reportResponse)) {

			for (Map<String, Object> map1 : reportResponse) {
				Processes processList = new Processes();
				processList.setProcessId(String.valueOf(map1.get(PROCESS_CODE)));
				processList.setProcessDesc(String.valueOf(map1.get(PROCESS_DESC)).trim());
				processList.setUpdatedBy(String.valueOf(map1.get("GCPG13_UPDATE_ID_C")).trim());
				processList.setTimeStamp(String.valueOf(map1.get("GCPG13_UPDATE_S")));
				processLists.add(processList);
			}
		}

		return processLists;
	}

	public List<Distributions> parseDistributionsList(Map<String, Object> distributionListMap) {

		List<Map<String, Object>> distributionsMap = (List<Map<String, Object>>) distributionListMap
				.get(CommonConstants.RESULT_SET_1);

		List<Distributions> distsList = new ArrayList<>();
		if (CollectionUtils.isNotEmpty(distributionsMap)) {

			for (Map<String, Object> map1 : distributionsMap) {
				Distributions distList = new Distributions();
				distList.setDistListId(String.valueOf(map1.get("GCPG11_DIST_LIST_D")));
				distList.setProcessDesc(String.valueOf(map1.get(PROCESS_CODE)).trim());
				distList.setCountryCode(String.valueOf(map1.get("COUNTRY_ISO3_C")).trim());
				distList.setDefaultFlag((String.valueOf(map1.get("GCPG14_DEFAULT_F"))));
				distList.setCountryName(String.valueOf(map1.get("COUNTRY_NAME_X")).trim());
				distList.setDistListName(String.valueOf(map1.get("GCPG11_DIST_LIST_N")).trim());
				distList.setProcessDesc(String.valueOf(map1.get(PROCESS_DESC)).trim());
				distsList.add(distList);
			}
		}

		return distsList;
	}

	public CommonJobResponse saveDistLists(Map<String, Object> saveListMap) {

		CommonJobResponse reposne = new CommonJobResponse();
		log.info("save list response::{}", saveListMap);
		String errorParm = (String) saveListMap.get(CommonConstants.OUTPUT_ERR1);
		String statusInd = errorParm.substring(9, 10);
		if (statusInd != null && "Y".equalsIgnoreCase(statusInd)) {
			String errorCode = errorParm.substring(37, 40);
			String errorDesc = errorParm.substring(40, 150);
			reposne.setStatus(CommonConstants.FAILURE);
			reposne.setStatusCode(CommonConstants.FAILURE_CODE);
			reposne.setStatusDescription(errorCode + errorDesc);
		} else {
			reposne.setStatus(CommonConstants.SUCCESS);
			reposne.setStatusCode(CommonConstants.SUCCESS_CODE);
			reposne.setStatusDescription(CommonConstants.SUCCESS_DESC);

		}
		return reposne;
	}

	public String inputParam1H51(DistributionsRequest distributionRequest) {
		StringBuilder inputParm1 = new StringBuilder();
		inputParm1.append(TargetingUtil.fillRemainingString(distributionRequest.getDistListCode(), 8, "0"));
		inputParm1.append(distributionRequest.getDistListflag());
		inputParm1.append(distributionRequest.getHubCode());
		inputParm1.append(distributionRequest.getCountryCode());
		inputParm1.append(TargetingUtil.fillRemainingString(distributionRequest.getProcCode(), 4, "0"));
		inputParm1.append(TargetingUtil.fillRemainingString(distributionRequest.getCdsId(), 8, " "));
		return inputParm1.toString();
	}

	public String inputParam2H51(DistributionsRequest distributionRequest) {
		StringBuilder inputParm2 = new StringBuilder();
		if (StringUtils.isNotBlank(distributionRequest.getAddMemberList())) {
			String addList = distributionRequest.getAddMemberList();
			addList = splitByComma(addList, 11, "A");
			inputParm2.append(addList);
		}
		if (StringUtils.isNotBlank(distributionRequest.getRemoveMemberList())) {
			String removeList = distributionRequest.getRemoveMemberList();
			removeList = splitByComma(removeList, 11, "D");
			inputParm2.append(removeList);
		}

		return inputParm2.toString();
	}

	private String splitByComma(String memberList, int length, String appender) {
		String[] arr = memberList.split(",");
		StringBuilder splitList = new StringBuilder();
		for (String string : arr) {
			splitList.append(appender + TargetingUtil.fillRemainingString(string.toUpperCase(), length, " "));

		}
		return splitList.toString();
	}

	public SaveDistributionsResponse updateMemberList(Map<String, Object> memberListMap,
			SaveDistributionsResponse commonResponse) {

		log.info("save list response::{}", memberListMap);
		String errorParm = (String) memberListMap.get(CommonConstants.ERROR_PARM);
		String statusInd = errorParm.substring(9, 10);
		if (statusInd != null && CommonConstants.FLAG_Y.equalsIgnoreCase(statusInd)) {
			String eCode = errorParm.substring(37, 40);
			String eDesc = errorParm.substring(40, 150);
			commonResponse.setStatusCode(CommonConstants.FAILURE_CODE);
			commonResponse.setStatus(CommonConstants.FAILURE);
			commonResponse.setStatusDescription(eCode + eDesc);
		} else {
			commonResponse.setStatusCode(CommonConstants.SUCCESS_CODE);
			commonResponse.setStatusDescription(CommonConstants.SUCCESS_DESC);
			commonResponse.setStatus(CommonConstants.SUCCESS);

		}
		return commonResponse;
	}

	public String fsaGoParam(String fsaNumber, String fsaType) {
		StringBuilder fsaGoParm = new StringBuilder();
		fsaGoParm.append(fsaType);
		fsaGoParm.append("G".equalsIgnoreCase(fsaType)?TargetingUtil.fillRemainingString(fsaNumber, 8, "0"):TargetingUtil.fillRemainingString(fsaNumber, 10, " "));
		return fsaGoParm.toString();
	}

	public CommonJobResponse processExtractSelections(Map<String, Object> processExtractMap) {
		CommonJobResponse commonResponse = new CommonJobResponse();
		log.info("save as default response::{}", processExtractMap);
		if (processExtractMap != null) {
			String errorParm = (String) processExtractMap.get(CommonConstants.ERROR_PARM);
			String statusInd = errorParm.substring(9, 10);
			if (statusInd != null && "Y".equalsIgnoreCase(statusInd)) {
				String errorCode = errorParm.substring(37, 40);
				String errorDesc = errorParm.substring(40, 150);
				commonResponse.setStatus(CommonConstants.FAILURE);
				commonResponse.setStatusCode(CommonConstants.FAILURE_CODE);
				commonResponse.setStatusDescription(errorCode + errorDesc);
			} else {
				commonResponse.setStatus(CommonConstants.SUCCESS);
				commonResponse.setStatusCode(CommonConstants.SUCCESS_CODE);
				commonResponse.setStatusDescription(CommonConstants.SUCCESS_DESC);
			}
		}
		return commonResponse;
	}

	public ExtractReports getReportLists(Map<String, Object> processExtractMap) {
		ExtractReports reportSelection = new ExtractReports();
		String outparam1 = (String) processExtractMap.get(CommonConstants.OUTPUT_PARM1);
		String outparam2 = (String) processExtractMap.get(CommonConstants.OUTPUT_PARM2);
		reportSelection.setReports(outparam1.substring(2, 101));
		reportSelection.setWersReports(outparam2.substring(2));
		reportSelection.setCountry(outparam1.substring(101, 104));
		reportSelection.setFsaLoadDataExists(outparam1.substring(104, 105));
		return reportSelection;
	}

	public SaveDistributionsResponse saveDistributionsList(Map<String, Object> saveDistMap) {

		SaveDistributionsResponse commonResponse = new SaveDistributionsResponse();
		log.info("save distributions response::{}", saveDistMap);
		if (saveDistMap != null) {
			String errorParm = (String) saveDistMap.get(CommonConstants.ERROR_PARM);
			String statusInd = errorParm.substring(9, 10);
			if (statusInd != null && "Y".equalsIgnoreCase(statusInd)) {
				String errorCode = errorParm.substring(37, 40);
				String errorDesc = errorParm.substring(40, 150);
				commonResponse.setStatus(CommonConstants.FAILURE);
				commonResponse.setStatusCode(CommonConstants.FAILURE_CODE);
				commonResponse.setStatusDescription(errorCode + errorDesc);
			} else {

				List<Map<String, Object>> distributionsMap = (List<Map<String, Object>>) saveDistMap
						.get(CommonConstants.RESULT_SET_1);

				if (CollectionUtils.isNotEmpty(distributionsMap)) {

					for (Map<String, Object> map1 : distributionsMap) {
						commonResponse.setDistListId(String.valueOf(map1.get("GCPG11_DIST_LIST_D")));
						commonResponse.setProcCode(String.valueOf(map1.get(PROCESS_CODE)));
						commonResponse.setCountryCode(String.valueOf(map1.get("COUNTRY_ISO3_C")));
						commonResponse.setDefaultFlag(String.valueOf(map1.get("GCPG14_DEFAULT_F")));
						commonResponse.setCountryName(String.valueOf(map1.get("COUNTRY_NAME_X")).trim());
						commonResponse.setDistListName(String.valueOf(map1.get("GCPG11_DIST_LIST_N")).trim());
						commonResponse.setProcDesc(String.valueOf(map1.get(PROCESS_DESC)).trim());
					}
				}
				commonResponse.setStatus(CommonConstants.SUCCESS);
				commonResponse.setStatusCode(CommonConstants.SUCCESS_CODE);
				commonResponse.setStatusDescription(CommonConstants.SUCCESS_DESC);
			}
		}
		return commonResponse;

	}

	public String parmj18MemberList(String distListId) {
		StringBuilder paramJ18MemList = new StringBuilder();
		paramJ18MemList.append("1");
		paramJ18MemList.append(TargetingUtil.fillRemainingString(distListId, 9, "0"));
		paramJ18MemList.append(TargetingUtil.addSpaceToProc(70));
		return paramJ18MemList.toString();
	}

	public String inputParam1G20(DownloadReportRequest downloadRequest) {
		StringBuilder paramG20 = new StringBuilder();
		paramG20.append("R");
		paramG20.append(String.format("%09d", Integer.parseInt(downloadRequest.getReportId())));
		paramG20.append(StringUtils.rightPad(downloadRequest.getReportCode(), 5, StringUtils.SPACE));
		paramG20.append(StringUtils.rightPad(downloadRequest.getAgencyCode(), 5, StringUtils.SPACE));
		paramG20.append(downloadRequest.getReportFormat());
		paramG20.append(TargetingUtil.fillRemainingString(downloadRequest.getJobQueueId(), 9, "0"));
		paramG20.append(StringUtils.rightPad(downloadRequest.getBatchCode(), 3, StringUtils.SPACE));
		paramG20.append(StringUtils.rightPad(downloadRequest.getBlobId(), 9, StringUtils.SPACE));

		return paramG20.toString();
	}

	public String reportSavedParam2(ExtractOptionRequest processExtractRequest) {
		if (StringUtils.isNotBlank(processExtractRequest.getWersCodeSelected())) {
			String wersSelected = splitByComma(processExtractRequest.getWersCodeSelected(), 4, "");
			processExtractRequest.setWersCodeSelected(wersSelected);
		}
		StringBuilder saveSlectParm2 = new StringBuilder();
		saveSlectParm2.append(processExtractRequest.getProcessFlag());		
		saveSlectParm2.append(TargetingUtil.fillRemainingString(processExtractRequest.getCdsId(), 8, " "));
		saveSlectParm2.append(processExtractRequest.getHubCode());
		saveSlectParm2.append(processExtractRequest.getPopulation());
		saveSlectParm2.append(
				TargetingUtil.fillRemainingString(String.valueOf(processExtractRequest.getReportCount()), 2, "0"));
		saveSlectParm2.append(processExtractRequest.getReportChecked());
		saveSlectParm2.append(
				TargetingUtil.fillRemainingString(String.valueOf(processExtractRequest.getWersCodeCount()), 2, "0"));
		saveSlectParm2.append(TargetingUtil.fillRemainingString(processExtractRequest.getWersCodeSelected(), 40, " "));
		return saveSlectParm2.toString();

	}

}
