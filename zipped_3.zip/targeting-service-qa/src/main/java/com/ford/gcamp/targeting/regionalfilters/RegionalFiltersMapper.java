package com.ford.gcamp.targeting.regionalfilters;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;
import java.util.stream.Collectors;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;
import com.ford.gcamp.targeting.common.CommonConstants;
import com.ford.gcamp.targeting.common.TargetingUtil;
import com.ford.gcamp.targeting.common.api.CommonResponse;
import com.ford.gcamp.targeting.common.api.CurrentCountry;
import com.ford.gcamp.targeting.common.api.FSACommonGoRequest;
import com.ford.gcamp.targeting.common.api.FSAInfoVO;
import com.ford.gcamp.targeting.common.api.GenericLookup;
import com.ford.gcamp.targeting.common.api.HubTreeCurrent;
import com.ford.gcamp.targeting.common.api.RoiCountryResponse;
import com.ford.gcamp.targeting.common.api.RoiDataCurrent;
import com.ford.gcamp.targeting.core.exception.GCAMPException;
import com.ford.gcamp.targeting.properties.HubCountryProperties;
import com.ford.gcamp.targeting.regionalfilters.api.CountryState;
import com.ford.gcamp.targeting.regionalfilters.api.GeoCode;
import com.ford.gcamp.targeting.regionalfilters.api.HubCountry;
import com.ford.gcamp.targeting.regionalfilters.api.HubRoiCountry;
import com.ford.gcamp.targeting.regionalfilters.api.RegionalFilterSaveRequest;
import com.ford.gcamp.targeting.regionalfilters.api.RegionalFilterStateProvinceResponse;
import com.ford.gcamp.targeting.regionalfilters.api.RegionalFilterStateRequest;
import com.ford.gcamp.targeting.regionalfilters.api.RegionalFiltersGoResponse;
import com.ford.gcamp.targeting.regionalfilters.api.RegionalFiltersRequest;
import com.ford.gcamp.targeting.regionalfilters.api.RegionalZipPostalCode;
import com.ford.gcamp.targeting.regionalfilters.api.StateProvCountry;
import com.ford.gcamp.targeting.regionalfilters.api.StateProvDetail;
import com.ford.gcamp.targeting.regionalfilters.api.StateProvince;
import com.ford.gcamp.targeting.regionalfilters.api.StateProvinceDetail;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class RegionalFiltersMapper {

	public static final String OUTPUT_COUNTRY_CODE = "COUNTRY_ISO3_C";
	HubCountryProperties properties;

	public RegionalFiltersMapper(HubCountryProperties properties) {
		this.properties = properties;
	}

	public String loadRegionalFilterSearchParam2(FSACommonGoRequest fsaGoRequest) {
		StringBuilder param2 = new StringBuilder();
		param2.append("1");
		param2.append(TargetingUtil.fillRemainingString(getListCount(fsaGoRequest.getSupplements()), 3, "0"));
		param2.append(TargetingUtil.addSpaceToProc(6));
		return param2.toString();
	}

	public String loadRegionalFilterSearchParam3(FSACommonGoRequest fsaGoRequest) {
		StringBuilder param3 = new StringBuilder();
		if (CollectionUtils.isNotEmpty(fsaGoRequest.getSupplements())) {
			for (String supplement : fsaGoRequest.getSupplements()) {
				param3.append(supplement);
			}
		}

		return param3.toString();
	}

	public RegionalFiltersGoResponse parseRegionalFilterGoResponse(Map<String, Object> goResponseMap,
			List<GenericLookup> countries, Map<String, Object> hubRoiCountriesMap) {
		RegionalFiltersGoResponse response = new RegionalFiltersGoResponse();
		String errorParm = (String) goResponseMap.get(CommonConstants.ERROR_PARM);
		log.info("RegionalFilter Search Response Error Param1::{}", errorParm);
		TargetingUtil.getResponseStatus(errorParm, response);
		if (CommonConstants.SUCCESS.equalsIgnoreCase(response.getStatus())) {
			FSAInfoVO fsaInfo = new FSAInfoVO();
			String oParam1 = (String) goResponseMap.get(CommonConstants.OUTPUT_PARM1);
			String oParam2 = (String) goResponseMap.get(CommonConstants.OUTPUT_PARM2);
			fsaInfo.setString(oParam1, oParam2);
			response.setFsaDetails(fsaInfo);

			@SuppressWarnings("unchecked")
			List<Map<String, Object>> hubRoiCountryData = (List<Map<String, Object>>) goResponseMap
					.get(CommonConstants.RESULT_SET_1);
			List<HubRoiCountry> hubRoiCountries = new ArrayList<>();
			if (CollectionUtils.isNotEmpty(hubRoiCountryData)) {
				for (Map<String, Object> hubRoiCountryMap : hubRoiCountryData) {

					HubRoiCountry hubRoiCountry = HubRoiCountry.builder()
							.hub(String.valueOf(hubRoiCountryMap.get("GCPE10_HUB_C")).trim())
							.hubDescription(String.valueOf(hubRoiCountryMap.get("GCPE10_HUB_DESC_X")).trim())
							.country(String.valueOf(hubRoiCountryMap.get(OUTPUT_COUNTRY_CODE)).trim())
							.countryDescription(String.valueOf(hubRoiCountryMap.get("COUNTRY_NAME_X")).trim())
							.roi(String.valueOf(hubRoiCountryMap.get("GCPE11_ROI_C")).trim())
							.roiDescription(String.valueOf(hubRoiCountryMap.get("GCPE11_ROI_DESC_X")).trim()).build();

					hubRoiCountries.add(hubRoiCountry);

				}
			}

			@SuppressWarnings("unchecked")
			List<Map<String, Object>> stateProvinceResponse = (List<Map<String, Object>>) goResponseMap
					.get(CommonConstants.RESULT_SET_2);
			List<StateProvDetail> stateProvinces = new ArrayList<>();
			extracted(hubRoiCountriesMap, hubRoiCountries, stateProvinceResponse, stateProvinces);
			response.setHubRoiCountries(getHubTreeView(hubRoiCountries));
			response.setStateProvinces(getStateProvTreeView(stateProvinces, countries));

			@SuppressWarnings("unchecked")
			List<Map<String, Object>> zipPostalCodeResponse = (List<Map<String, Object>>) goResponseMap
					.get(CommonConstants.RESULT_SET_3);
			if (CollectionUtils.isNotEmpty(zipPostalCodeResponse)) {

				response.setZipPostalCodes(regionalZipPostalCodeStatus(zipPostalCodeResponse));

			}

			@SuppressWarnings("unchecked")
			List<Map<String, Object>> restrictionFilterResponse = (List<Map<String, Object>>) goResponseMap
					.get(CommonConstants.RESULT_SET_4);
			if (CollectionUtils.isNotEmpty(restrictionFilterResponse)) {
				restrictionFilterStatus(restrictionFilterResponse, response);

			}
		}

		return response;
	}

	private void extracted(Map<String, Object> hubRoiCountriesMap, List<HubRoiCountry> hubRoiCountries, List<Map<String, Object>> stateProvinceResponse, List<StateProvDetail> stateProvinces) {
		if (CollectionUtils.isNotEmpty(stateProvinceResponse)) {

				for (Map<String, Object> stateProvinceMap : stateProvinceResponse) {

					StateProvDetail stateProvince = StateProvDetail.builder()
							.stateProvCode(String.valueOf(stateProvinceMap.get("STPR_STATE_C")).trim())
							.stateProvDescription(String.valueOf(stateProvinceMap.get("STPR_NAME_X")).trim())
							.countryCode(String.valueOf(stateProvinceMap.get(OUTPUT_COUNTRY_CODE)).trim())
							.geoCondCode(String.valueOf(stateProvinceMap.get("GCPA32_REG_GRP_C")).trim())
							.geoCondDescription(String.valueOf(stateProvinceMap.get("GCPA32_REG_GRP_X")).trim())
							.build();
					stateProvinces.add(stateProvince);

				}
				Map<String, List<StateProvDetail>> stateProvDetailMap = stateProvinces.stream().collect(
						Collectors.groupingBy(StateProvDetail::getCountryCode, HashMap::new, Collectors.toList()));

				List<HubRoiCountry> hubRoiCountryDetails = getHubRoiCountries(hubRoiCountriesMap);
				hubRoiCountryDetails.removeIf(hubRoiCountry -> properties.getHub()
						.get(CommonConstants.REGIONAL_FILTERS_UNSUPPORTED_HUB_PROP_KEY).trim()
						.equalsIgnoreCase(hubRoiCountry.getHub().trim()));
				stateProvDetailMap.entrySet().forEach(stateEntry -> {
					Optional<HubRoiCountry> roiCountry = hubRoiCountryDetails.stream()
							.filter(hubRoiCountry -> stateEntry.getKey().equalsIgnoreCase(hubRoiCountry.getCountry()))
							.findFirst();
					if (roiCountry.isPresent()) {
						hubRoiCountries.add(roiCountry.get());
					}
				});

		}
	}

	private List<HubTreeCurrent> getHubTreeView(List<HubRoiCountry> hubRoiInfo) {
		Map<String, List<HubRoiCountry>> hubCodeGroup = hubRoiInfo.stream()
				.sorted(Comparator.comparing(HubRoiCountry::getHub).reversed())
				.collect(Collectors.groupingBy(HubRoiCountry::getHub, LinkedHashMap::new, Collectors.toList()));
		List<HubTreeCurrent> hubTree = new ArrayList<>();
		if (MapUtils.isNotEmpty(hubCodeGroup)) {

			for (Entry<String, List<HubRoiCountry>> hub : hubCodeGroup.entrySet()) {

				List<HubRoiCountry> gridData = hubCodeGroup.get(hub.getKey());

				HubTreeCurrent hubTreeData = HubTreeCurrent.builder().hubCode(gridData.get(0).getHub())
						.label(gridData.get(0).getHubDescription()).children(getRoiDetails(gridData)).build();

				hubTree.add(hubTreeData);
			}
		}
		return hubTree;
	}

	private List<RoiDataCurrent> getRoiDetails(List<HubRoiCountry> gridData) {
		List<RoiDataCurrent> rois = new ArrayList<>();
		Map<String, List<HubRoiCountry>> roiDetailGroup = gridData.stream()
				.sorted(Comparator.comparing(HubRoiCountry::getRoi))
				.collect(Collectors.groupingBy(HubRoiCountry::getRoi, LinkedHashMap::new, Collectors.toList()));
		for (Entry<String, List<HubRoiCountry>> roiCode : roiDetailGroup.entrySet()) {

			List<HubRoiCountry> gridDetails = roiDetailGroup.get(roiCode.getKey());

			RoiDataCurrent roiDetails = RoiDataCurrent.builder().roiCode(gridDetails.get(0).getRoi())
					.label(gridDetails.get(0).getRoiDescription()).build();
			List<CurrentCountry> countries = new ArrayList<>();
			gridDetails.forEach(countryDetails -> {

				CurrentCountry country = CurrentCountry.builder().countryCode(countryDetails.getCountry())
						.label(countryDetails.getCountryDescription()).build();
				countries.add(country);
				roiDetails.setChildren(countries);
			});

			rois.add(roiDetails);
		}
		return rois;

	}

	private List<StateProvCountry> getStateProvTreeView(List<StateProvDetail> stateProvince,
			List<GenericLookup> countries) {
		Map<String, List<StateProvDetail>> stateCodeGroup = stateProvince.stream()
				.sorted(Comparator.comparing(StateProvDetail::getCountryCode)).collect(Collectors
						.groupingBy(StateProvDetail::getCountryCode, LinkedHashMap::new, Collectors.toList()));

		List<StateProvCountry> stateTree = new ArrayList<>();
		if (MapUtils.isNotEmpty(stateCodeGroup)) {
			for (String countryCode : stateCodeGroup.keySet()) {
				List<StateProvDetail> gridData = stateCodeGroup.get(countryCode.trim());
				StateProvCountry countryTreeData = StateProvCountry.builder().countryCode(countryCode)
						.label(TargetingUtil.getCntryDesc(countries, countryCode)).children(getGeoCodeDetails(gridData))
						.build();
				stateTree.add(countryTreeData);
			}
		}
		return stateTree;
	}

	private List<GeoCode> getGeoCodeDetails(List<StateProvDetail> stateprovinces) {
		List<GeoCode> geoInfo = new ArrayList<>();
		Map<String, List<StateProvDetail>> geoCondGroup = stateprovinces.stream()
				.sorted(Comparator.comparing(StateProvDetail::getGeoCondCode)).collect(Collectors
						.groupingBy(StateProvDetail::getGeoCondCode, LinkedHashMap::new, Collectors.toList()));
		for (Entry<String, List<StateProvDetail>> roiCode : geoCondGroup.entrySet()) {

			List<StateProvDetail> gridDetails = geoCondGroup.get(roiCode.getKey());
			GeoCode geoDataInfo = GeoCode.builder().code(gridDetails.get(0).getGeoCondCode())
					.label(gridDetails.get(0).getGeoCondDescription()).build();
			List<StateProvince> stateProvs = new ArrayList<>();
			gridDetails.forEach(stateDetails -> {

				StateProvince stateInfo = StateProvince.builder().code(stateDetails.getStateProvCode())
						.label(stateDetails.getStateProvDescription()).build();
				stateProvs.add(stateInfo);
				geoDataInfo.setChildren(stateProvs);
			});

			geoInfo.add(geoDataInfo);

		}
		return geoInfo;
	}

	private List<RegionalZipPostalCode> regionalZipPostalCodeStatus(List<Map<String, Object>> zipPostalCodeResponse) {
		List<RegionalZipPostalCode> postalCodes = new ArrayList<>();
		for (Map<String, Object> zipCode : zipPostalCodeResponse) {
			RegionalZipPostalCode zipPostalCode = RegionalZipPostalCode.builder()
					.startValue(String.valueOf(zipCode.get("GCPA30_POST_BEGN_R")).trim())
					.endValue(String.valueOf(zipCode.get("GCPA30_POST_END_R")).trim()).build();
			postalCodes.add(zipPostalCode);

		}
		return postalCodes;
	}

	private RegionalFiltersGoResponse restrictionFilterStatus(List<Map<String, Object>> restrictionFilterResponse,
			RegionalFiltersGoResponse response) {

		for (Map<String, Object> filterData : restrictionFilterResponse) {

			String regionalParam = String.valueOf(filterData.get("GCPA31_REG_PARM_C")).trim();
			if (StringUtils.equalsIgnoreCase("3", regionalParam)) {
				response.setCurrentlyResidesIn(true);
				response.setOriginallySoldIn(true);
			} else if (StringUtils.equalsIgnoreCase("2", regionalParam)) {
				response.setCurrentlyResidesIn(true);
			} else if (StringUtils.equalsIgnoreCase("1", regionalParam)) {
				response.setOriginallySoldIn(true);
			}

		}
		return response;
	}

	public String getStatesProvincesparam1(RegionalFilterStateRequest regionalFilterStateRequest) {
		StringBuilder param1 = new StringBuilder();
		List<GenericLookup> country = regionalFilterStateRequest.getCountries();
		param1.append(TargetingUtil.fillRemainingString(getListCount(country), 3, "0"));
		param1.append(TargetingUtil.addSpaceToProc(47));
		return param1.toString();
	}

	public String getStatesProvincesparam2(RegionalFilterStateRequest regionalFilterStateRequest) {
		StringBuilder param2 = new StringBuilder();
		for (GenericLookup countryInfo : regionalFilterStateRequest.getCountries()) {
			param2.append(countryInfo.getCode());
		}
		param2.append(TargetingUtil.addSpaceToProc(100));
		return param2.toString();
	}

	public RegionalFilterStateProvinceResponse getStateProvincesResponse(Map<String, Object> responseStateProvince)
			throws GCAMPException {
		RegionalFilterStateProvinceResponse response = RegionalFilterStateProvinceResponse.builder().build();
		TargetingUtil.getResponseStatus((String) responseStateProvince.get(CommonConstants.ERROR_PARM1), response);
		String errorParam1 = (String) responseStateProvince.get(CommonConstants.ERROR_PARM1);
		String errorParam2 = (String) responseStateProvince.get(CommonConstants.ERROR_PARM2);
		log.info("FsaExpirationReportResponse procResponse of error-pram1::{}", errorParam1);
		log.info("FsaExpirationReportResponse procResponse of error-pram2::{}", errorParam2);
		@SuppressWarnings("unchecked")
		List<StateProvinceDetail> stateProvinceDetails = (List<StateProvinceDetail>) responseStateProvince
				.get("stateprovinces");
		response.setCountry(getCountry(stateProvinceDetails));
		return response;
	}

	private List<StateProvCountry> getCountry(List<StateProvinceDetail> stateProvinceDetails) {
		Map<String, List<StateProvinceDetail>> hubCodeGroup = stateProvinceDetails.stream()
				.sorted(Comparator.comparing(StateProvinceDetail::getCountryCode)).collect(Collectors
						.groupingBy(StateProvinceDetail::getCountryCode, LinkedHashMap::new, Collectors.toList()));
		List<StateProvCountry> countryInfo = new ArrayList<>();
		for (Entry<String, List<StateProvinceDetail>> stateProvince : hubCodeGroup.entrySet()) {
			List<StateProvinceDetail> gridData = hubCodeGroup.get(stateProvince.getKey());
			StateProvCountry country = StateProvCountry.builder().countryCode(gridData.get(0).getCountryCode())
					.label(gridData.get(0).getCountryDescription()).children(getGeoDetails(gridData)).build();
			countryInfo.add(country);
		}
		return countryInfo;
	}

	private List<GeoCode> getGeoDetails(List<StateProvinceDetail> stateProvinceDetails) {
		List<GeoCode> children = new ArrayList<>();
		Map<String, List<StateProvinceDetail>> geoGroup = stateProvinceDetails.stream()
				.sorted(Comparator.comparing(StateProvinceDetail::getGeoCode)).collect(Collectors
						.groupingBy(StateProvinceDetail::getGeoCode, LinkedHashMap::new, Collectors.toList()));
		for (Entry<String, List<StateProvinceDetail>> stateProvince : geoGroup.entrySet()) {
			GeoCode geoInfo = new GeoCode();
			List<StateProvinceDetail> gridDetails = geoGroup.get(stateProvince.getKey());
			Map<String, List<StateProvinceDetail>> stateGroup = gridDetails.stream()
					.sorted(Comparator.comparing(StateProvinceDetail::getStateDescription))
					.collect(Collectors.groupingBy(StateProvinceDetail::getStateDescription, LinkedHashMap::new,
							Collectors.toList()));
			geoInfo.setCode(gridDetails.get(0).getGeoCode());
			geoInfo.setLabel(gridDetails.get(0).getGeoDescription());

			List<StateProvince> statechildren = new ArrayList<>();
			for (Entry<String, List<StateProvinceDetail>> statedetail : stateGroup.entrySet()) {
				List<StateProvinceDetail> stateDetails = stateGroup.get(statedetail.getKey());
				StateProvince state = StateProvince.builder().code(stateDetails.get(0).getStateCode())
						.label(stateDetails.get(0).getStateDescription()).build();
				statechildren.add(state);
				geoInfo.setChildren(statechildren);
			}
			children.add(geoInfo);
		}
		return children;
	}

	public String deleteInputParam1(RegionalFiltersRequest deleteRequest) {

		StringBuilder param1 = new StringBuilder();
		param1.append(TargetingUtil.fillRemainingString(deleteRequest.getGlobalFsaNumber(), 8, "0"));
		param1.append(TargetingUtil.fillRemainingString(deleteRequest.getCdsId(), 8, " "));
		param1.append(deleteRequest.getFlag());
		param1.append(TargetingUtil.addSpaceToProc(10));
		param1.append(TargetingUtil.fillRemainingString(getListCount(deleteRequest.getSupplements()), 3, "0"));
		param1.append(TargetingUtil.addSpaceToProc(20));
		return param1.toString();

	}

	public CommonResponse parseDeleteResponseMap(Map<String, Object> deletedResponseMap) {
		String errorParam = (String) deletedResponseMap.get(CommonConstants.ERROR_PARM1);
		log.info("ProcResponse of error-param1::{}", errorParam);
		return TargetingUtil.getCommonResponse(errorParam);
	}

	public String countryParam2() {
		StringBuilder param2 = new StringBuilder();
		param2.append("2");
		param2.append(TargetingUtil.addSpaceToProc(9));

		return param2.toString();
	}

	public RoiCountryResponse parseCountryResponseMap(Map<String, Object> countryResponseMap, String hubCode) {
		RoiCountryResponse response = new RoiCountryResponse();
		String errorParm = (String) countryResponseMap.get(CommonConstants.ERROR_PARM);
		log.info("RegionalFilter country Response Error Param1::{}", errorParm);
		TargetingUtil.getResponseStatus(errorParm, response);
		if (CommonConstants.SUCCESS.equalsIgnoreCase(response.getStatus())) {
			List<HubRoiCountry> hubRoiCountryDetails = getHubRoiCountries(countryResponseMap);
			if (StringUtils.isNotBlank(hubCode)) {
				hubRoiCountryDetails = hubRoiCountryDetails.stream()
						.filter(roiCountry -> hubCode.equalsIgnoreCase(roiCountry.getHub()))
						.collect(Collectors.toList());
			}

			response.setHubRoiCountries(getHub(hubRoiCountryDetails));
		}
		return response;
	}

	@SuppressWarnings("unchecked")
	public List<HubRoiCountry> getHubRoiCountries(Map<String, Object> countryResponseMap) {
		List<Map<String, Object>> hubRoiCountryInfo = (List<Map<String, Object>>) countryResponseMap
				.get(CommonConstants.RESULT_SET_1);
		List<HubRoiCountry> hubRoiCountryDetails = new ArrayList<>();
		if (hubRoiCountryInfo != null) {
			for (Map<String, Object> map : hubRoiCountryInfo) {
				HubRoiCountry result = HubRoiCountry.builder().hub(String.valueOf(map.get("GCPE10_HUB_C")).trim())
						.hubDescription(String.valueOf(map.get("GCPE10_HUB_DESC_X")).trim())
						.country(String.valueOf(map.get(OUTPUT_COUNTRY_CODE)).trim())
						.countryDescription(String.valueOf(map.get("COUNTRY_NAME_X")).trim())
						.roi(String.valueOf(map.get("GCPE11_ROI_C")).trim())
						.roiDescription(String.valueOf(map.get("GCPE11_ROI_DESC_X")).trim()).build();
				hubRoiCountryDetails.add(result);
			}
		}
		return hubRoiCountryDetails;
	}

	private List<HubTreeCurrent> getHub(List<HubRoiCountry> hubRoiInfo) {
		Map<String, List<HubRoiCountry>> hubData = hubRoiInfo.stream()
				.sorted(Comparator.comparing(HubRoiCountry::getHubDescription))
				.collect(Collectors.groupingBy(HubRoiCountry::getHub, LinkedHashMap::new, Collectors.toList()));
		List<HubTreeCurrent> hubTreeInfo = new ArrayList<>();
		if (hubData != null && !hubData.isEmpty()) {
			for (Entry<String, List<HubRoiCountry>> hubRoiCountryInfo : hubData.entrySet()) {
				List<HubRoiCountry> gridDetail = hubData.get(hubRoiCountryInfo.getKey());
				HubTreeCurrent hubTreeDetails = HubTreeCurrent.builder().hubCode(gridDetail.get(0).getHub())
						.label(gridDetail.get(0).getHubDescription()).children(getRoi(gridDetail)).build();
				hubTreeInfo.add(hubTreeDetails);
			}
		}
		return hubTreeInfo;
	}

	private List<RoiDataCurrent> getRoi(List<HubRoiCountry> resultData) {
		List<RoiDataCurrent> roiData = new ArrayList<>();
		Map<String, List<HubRoiCountry>> roiDetails = resultData.stream()
				.sorted(Comparator.comparing(HubRoiCountry::getRoiDescription))
				.collect(Collectors.groupingBy(HubRoiCountry::getRoi, LinkedHashMap::new, Collectors.toList()));
			for (Entry<String, List<HubRoiCountry>> roiCodeGroup : roiDetails.entrySet()) {
				List<HubRoiCountry> roiGrid = roiDetails.get(roiCodeGroup.getKey());
				RoiDataCurrent roiInfo = RoiDataCurrent.builder().roiCode(roiGrid.get(0).getRoi())
						.label(roiGrid.get(0).getRoiDescription()).build();
				List<CurrentCountry> countriesResult = new ArrayList<>();
				roiGrid.forEach(countryDetails -> {
					CurrentCountry countryInfo = CurrentCountry.builder().countryCode(countryDetails.getCountry())
							.label(countryDetails.getCountryDescription()).build();
					countriesResult.add(countryInfo);
					roiInfo.setChildren(countriesResult);
				});
				roiData.add(roiInfo);
			}
		return roiData;
	}

	public void filterHubCountries(RegionalFilterSaveRequest regionalFilterSaveRequest) {
		if (CollectionUtils.isNotEmpty(regionalFilterSaveRequest.getCountryStates())) {
			List<HubCountry> hubCountries = new ArrayList<>();
			for (HubCountry hubCountry : regionalFilterSaveRequest.getHubCountries()) {
				Optional<CountryState> countryState = regionalFilterSaveRequest.getCountryStates().stream()
						.filter(cntryState -> hubCountry.getCountry().equalsIgnoreCase(cntryState.getCountry()))
						.findFirst();
				if (!countryState.isPresent()) {
					hubCountries.add(hubCountry);
				}

			}
			regionalFilterSaveRequest.setHubCountries(hubCountries);
		}
	}

	public String saveRegionalFiltersparam1(RegionalFilterSaveRequest regionalFilterSaveRequest) {
		StringBuilder param1 = new StringBuilder();
		regionalFilterSaveRequest.setIndicator("I");
		param1.append(TargetingUtil.fillRemainingString(regionalFilterSaveRequest.getGlobalFsaNumber(), 8, "0"));
		param1.append(TargetingUtil.fillRemainingString(regionalFilterSaveRequest.getCdsId(), 8, StringUtils.SPACE));
		param1.append(regionalFilterSaveRequest.getIndicator());
		param1.append(regionalFilterSaveRequest.getParm());
		param1.append(
				TargetingUtil.fillRemainingString(getListCount(regionalFilterSaveRequest.getHubCountries()), 3, "0"));
		param1.append(
				TargetingUtil.fillRemainingString(getListCount(regionalFilterSaveRequest.getCountryStates()), 3, "0"));
		param1.append(TargetingUtil.fillRemainingString(getListCount(regionalFilterSaveRequest.getZipCodes()), 3, "0"));
		param1.append(
				TargetingUtil.fillRemainingString(getListCount(regionalFilterSaveRequest.getSupplements()), 3, "0"));
		param1.append(TargetingUtil.addSpaceToProc(20));
		return param1.toString();
	}

	public String saveRegionalFiltersparam2(RegionalFilterSaveRequest regionalFilterSaveRequest) {
		StringBuilder param2 = new StringBuilder();
		for (HubCountry hubCountry : regionalFilterSaveRequest.getHubCountries()) {
			param2.append(TargetingUtil.fillRemainingString(hubCountry.getHub(), 2, StringUtils.SPACE));
			param2.append(TargetingUtil.fillRemainingString(hubCountry.getCountry(), 3, StringUtils.SPACE));
		}
		param2.append(TargetingUtil.addSpaceToProc(100));
		return param2.toString();
	}

	public String saveRegionalFiltersparam3(RegionalFilterSaveRequest regionalFilterSaveRequest) {
		StringBuilder param3 = new StringBuilder();
		if (CollectionUtils.isNotEmpty(regionalFilterSaveRequest.getCountryStates())) {
			for (CountryState countryState : regionalFilterSaveRequest.getCountryStates()) {
				param3.append(TargetingUtil.fillRemainingString(countryState.getCountry(), 3, StringUtils.SPACE));
				param3.append(TargetingUtil.fillRemainingString(countryState.getGeoCode(), 2, StringUtils.SPACE));
				param3.append(TargetingUtil.fillRemainingString(countryState.getStateCode(), 2, StringUtils.SPACE));
			}
		} else {
			param3.append(TargetingUtil.addSpaceToProc(7));
		}
		param3.append(TargetingUtil.addSpaceToProc(100));
		return param3.toString();
	}

	public String saveRegionalFiltersparam4(RegionalFilterSaveRequest regionalFilterSaveRequest) {
		StringBuilder param4 = new StringBuilder();
		if (CollectionUtils.isNotEmpty(regionalFilterSaveRequest.getZipCodes())) {
			for (RegionalZipPostalCode zip : regionalFilterSaveRequest.getZipCodes()) {
				param4.append(TargetingUtil.fillRemainingString(zip.getStartValue(), 6, StringUtils.SPACE));
				param4.append(TargetingUtil.fillRemainingString(zip.getEndValue(), 6, StringUtils.SPACE));
			}
		} else {
			param4.append(TargetingUtil.addSpaceToProc(12));
		}
		param4.append(TargetingUtil.addSpaceToProc(100));
		return param4.toString();
	}

	public CommonResponse saveRegionalFiltersResponse(Map<String, Object> responsesaveRegionalFilter)
			throws GCAMPException {
		String errorParam1 = (String) responsesaveRegionalFilter.get("OERR1");
		String errorParam2 = (String) responsesaveRegionalFilter.get("OERR2");
		log.info("FsaExpirationUpdateResponse procResponse of error-pram1::{}", errorParam1);
		log.info("FsaExpirationUpdateResponse procResponse of error-pram2::{}", errorParam2);
		return TargetingUtil.getCommonResponse(errorParam1);
	}

	private <T> String getListCount(List<T> hubCountryZipCodes) {
		if (CollectionUtils.isNotEmpty(hubCountryZipCodes)) {
			return String.valueOf(hubCountryZipCodes.size());
		}
		return String.valueOf(0);

	}

	public String regionalFiltersParam5(RegionalFiltersRequest regionalFiltersRequest) {
		StringBuilder param5 = new StringBuilder();
		if (CollectionUtils.isNotEmpty(regionalFiltersRequest.getSupplements())) {
			for (String supplement : regionalFiltersRequest.getSupplements()) {
				param5.append(supplement);
			}
		}
		return param5.toString();
	}

	public String saveRegionalFiltersparam5(RegionalFilterSaveRequest regionalFilterSaveRequest) {
		StringBuilder inputParam5 = new StringBuilder();
		if (CollectionUtils.isNotEmpty(regionalFilterSaveRequest.getSupplements())) {
			for (String supplement : regionalFilterSaveRequest.getSupplements()) {
				inputParam5.append(supplement);
			}
		}
		return inputParam5.toString();
	}

}
