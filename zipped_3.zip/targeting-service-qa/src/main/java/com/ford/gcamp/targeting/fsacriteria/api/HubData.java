package com.ford.gcamp.targeting.fsacriteria.api;

import java.util.List;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class HubData {

	@Size(min = 0, max = 2)
	@Pattern(regexp = "^[a-zA-Z\\*\\s\\d]{1,2}$")
	@Schema(example = "NA", description = "Hub Code")
	private String hubCode;


	@Size(min = 0, max = 30)
	@Pattern(regexp = "^[a-zA-Z\\d\\*\\s]$")
	@Schema(example = "NA", description = "Hub Code")
	private String label;

	@NotNull
	@Size(min = 0, max = 5)
	@Pattern(regexp = "^[a-zA-Z\\d\\*]*$")
	@Schema(example = "NR1", description = "Region of interest")
	private String roiCode;

	@NotNull
	@Size(min = 0, max = 30)
	@Pattern(regexp = "^[a-zA-Z\\d\\-\\s]*$")
	@Schema(example = "EUROPE - CENTRALISED MARKETS", description = "Region of interest Description")
	private String roiDesc;

	@Size(min = 0, max = 250, message = "Countries Children")
	private List<@Valid Countries> children;
}
