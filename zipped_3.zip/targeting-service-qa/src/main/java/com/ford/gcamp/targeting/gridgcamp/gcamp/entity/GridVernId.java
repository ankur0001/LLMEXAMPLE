package com.ford.gcamp.targeting.gridgcamp.gcamp.entity;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import jakarta.persistence.Table;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Embeddable
@Table(name="SGCPF59_GRID_VINRPT")
public class GridVernId implements Serializable {
	
	private static final long serialVersionUID = 1L;
	@Column(name = "GCPF59_GRID_YR_D")
	private int gridYearId;
	@Column(name = "GCPF59_GRID_SEQ_R")
	private int gridSequence;
	@Column(name = "GCPF59_GRID_IMPL_D")
	private int implementationId;
	@Column(name = "GCPF59_GRID_VERSION_R")
	private int version;
	@Column(name = "GCPF59_GRID_SUPPL_C")
	private String supplementId;
	
}
