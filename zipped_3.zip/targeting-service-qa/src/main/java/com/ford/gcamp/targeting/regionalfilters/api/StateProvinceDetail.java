package com.ford.gcamp.targeting.regionalfilters.api;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Builder
public class StateProvinceDetail {

	private String countryCode;
	private String countryDescription;
	private String geoCode;
	private String geoDescription;
	private String stateCode;
	private String stateDescription;
}
