package com.ford.gcamp.targeting.regionalfilters;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import com.ford.gcamp.targeting.regionalfilters.api.RegionalAuditReport;
@Component
public class RegionalAuditReportMapper implements RowMapper<RegionalAuditReport> {
	public static final String FSA_LAUNCHED_STATUS = "L";
	private String flag;
	private String fsaStatus;
	public RegionalAuditReportMapper(String flag, String fsaStatus) {
		this.flag = flag;
		this.fsaStatus = fsaStatus;
	}
	@Override
	public RegionalAuditReport mapRow(ResultSet resultSet, int rowNum) throws SQLException {
		RegionalAuditReport regionalAuditReportRequest =RegionalAuditReport.builder().build();
		if (("regional").equalsIgnoreCase(flag)) {
			regionalAuditReportRequest.setVehiclesTarget(resultSet.getString(3).trim());
			int vehicleFsaGeoCount = 0;
			if (FSA_LAUNCHED_STATUS.equalsIgnoreCase(fsaStatus.trim())) {
				vehicleFsaGeoCount = resultSet.getInt(2); 
				if (vehicleFsaGeoCount == 0) {
					vehicleFsaGeoCount = resultSet.getInt(1);
				}
			} else {
				vehicleFsaGeoCount = resultSet.getInt(1); 
			}
			regionalAuditReportRequest.setVehiclesWithFSAGeoParams(String.valueOf(vehicleFsaGeoCount));
			int exclude = resultSet.getInt(3) - vehicleFsaGeoCount;
			regionalAuditReportRequest.setExcludedVehicles(String.valueOf(exclude));
		}
		return regionalAuditReportRequest;
	}
}
