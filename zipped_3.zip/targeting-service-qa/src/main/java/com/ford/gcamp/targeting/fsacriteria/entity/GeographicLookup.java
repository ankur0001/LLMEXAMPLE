package com.ford.gcamp.targeting.fsacriteria.entity;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Entity
@Table(name = "SGCPA32_REG_GRPS")
public class GeographicLookup implements Serializable {

	private static final long serialVersionUID = 1L;

	
	@Id
	@Column(name = "GCPA32_REG_GRP_C")
	private String code;
	@Column(name = "GCPA32_REG_GRP_X")
	private String description;
	
}
