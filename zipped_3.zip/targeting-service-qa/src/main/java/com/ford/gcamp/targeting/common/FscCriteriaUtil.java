package com.ford.gcamp.targeting.common;


import java.util.*;




import com.ford.gcamp.targeting.common.api.LayoutBuffer;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.stereotype.Component;

import com.ford.gcamp.targeting.common.api.FscCriteriaRequest;
import com.ford.gcamp.targeting.manualaddvin.api.ManualAddVinsVO;

import com.ford.gcamp.targeting.frozenvin.api.FrozenVin;
import com.ford.gcamp.targeting.vin.api.FsaCriteriaVdmVO;
import com.ford.gcamp.targeting.vin.api.SerialUploadRequest;
import com.ford.gcamp.targeting.vin.api.UpdateVinSerialReq;

import lombok.extern.slf4j.Slf4j;



@Component
@Slf4j
public class FscCriteriaUtil {

	private static final Logger LOGGER = LoggerFactory.getLogger(FscCriteriaUtil.class);

	public String addSpaceToProc(int length) {
		StringBuilder sb = new StringBuilder();
		int maxLength = length;
		while (maxLength > 0) {
			sb.append(" ");
			maxLength--;
		}
		return sb.toString();
	}

	public String frozenParm(FrozenVin fscCriteriaRequest) {
		StringBuilder sbuil = new StringBuilder();
		String fsaType=fscCriteriaRequest.getOptRadio();
		String fsaNumber=fscCriteriaRequest.getFscNumber();
		if (("G").equals(fsaType)) {
			sbuil.append(fsaType);
			sbuil.append(TargetingUtil.fillRemainingString(fsaNumber,8,"0"));
			sbuil.append(addSpaceToProc(9));
		} else if (("L").equals(fsaType)) {
			sbuil.append(fsaType);
			sbuil.append(TargetingUtil.fillRemainingString(fsaNumber.toUpperCase(),10," "));
			sbuil.append(addSpaceToProc(9));
		}
		return sbuil.toString();
	}


	public String addZerosToProc(int length) {
		StringBuilder sb = new StringBuilder();
		int maxLength = length;
		while (maxLength > 0) {
			sb.append("0");
			maxLength--;
		}
		return sb.toString();
	}

	public String formInputParamFAG(String fscNumber, String optRadio) {
		StringBuilder sb = new StringBuilder();
		if (("G").equals(optRadio)) {
			sb.append(optRadio);
			sb.append(TargetingUtil.fillRemainingString(fscNumber,8,"0"));
			sb.append(addSpaceToProc(9));
		} else if (("L").equals(optRadio)) {
			sb.append(optRadio);
			sb.append(TargetingUtil.fillRemainingString(fscNumber.toUpperCase().toUpperCase(),10," "));
			sb.append(addSpaceToProc(9));
		}
		return sb.toString();
	}

	public String formInputParam2(String population, String cdsId) {
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.append(CommonConstants.FSA_SEARCH_GO_PARM);
		stringBuilder.append(population);
		if(cdsId!=null) {
			stringBuilder.append(TargetingUtil.fillRemainingString(cdsId.toUpperCase(),8," "));
		}
		stringBuilder.append(addSpaceToProc(989));
		return stringBuilder.toString();
	}

	public List<String> splitOutparamWithPipe(List<String> outputPAramList) {
		List<String> outPutFilterdList = new ArrayList<>();
		for (String string : outputPAramList) {
			String[] str = string.split("\\|");
			for (int i = 0; i < str.length; i++) {
				outPutFilterdList.add(str[i]);
			}

		}
		return outPutFilterdList;
	}

	public String fsaGoSerialParam(FscCriteriaRequest fscCriteriaRequest) {
		StringBuilder sb = new StringBuilder();
		String fsaType=fscCriteriaRequest.getOptRadio();
		String fsaNumber=fscCriteriaRequest.getFscNumber();
		if (("G").equals(fsaType)) {
			sb.append(fsaType);
			sb.append(TargetingUtil.fillRemainingString(fsaNumber,8,"0"));
			sb.append(addSpaceToProc(9));
		} else if (("L").equals(fsaType)) {
			sb.append(fsaType);
			sb.append(TargetingUtil.fillRemainingString(fsaNumber.toUpperCase(),10," "));
			sb.append(addSpaceToProc(9));
		}
		return sb.toString();
	}


	public String getSerialListParam(FscCriteriaRequest fscCriteriaRequest) {
		StringBuilder serialListParm = new StringBuilder();
		serialListParm.append("G");
		serialListParm.append(addSpaceToProc(8));
		serialListParm.append(fscCriteriaRequest.getPopulation());
		serialListParm.append(addSpaceToProc(713));

		return serialListParm.toString();
	}

	public String getUpdateSerialListParam(UpdateVinSerialReq updateSerialList) {
		StringBuilder updateVinList = new StringBuilder();
		//C0006250600VNAMBURU001AA TEST FOR SERIAL NUMBECHECKING                                                                                                                                                                                                                                AADI
		//
		updateVinList.append("C");
		updateVinList.append(TargetingUtil.fillRemainingString(updateSerialList.getFsaNumber(),8,"0"));
		updateVinList.append(updateSerialList.getVehiclePopUpCode());
		updateVinList.append(TargetingUtil.fillRemainingString(updateSerialList.getCdsId(),8," "));
		updateVinList.append(TargetingUtil.fillRemainingString(updateSerialList.getFolderId(),3,"0"));
		//vin grp code
		updateVinList.append(updateSerialList.getVinGrpCode());
		//vin grp description
		updateVinList.append(TargetingUtil.fillRemainingString(updateSerialList.getVinGrpDesc(),254," "));
		updateVinList.append(updateSerialList.getVinGrpCode());

		updateVinList.append(updateSerialList.getUpdatedField());
		updateVinList.append(updateSerialList.getFileType());

		updateVinList.append(addSpaceToProc(431));
		updateVinList.append(TargetingUtil.fillRemainingString(updateSerialList.getOtaIndicator(),1," "));
		updateVinList.append(updateSerialList.getFlag());
		updateVinList.append(TargetingUtil.fillRemainingString(updateSerialList.getFhmIndicator(),1," "));
		updateVinList.append(addSpaceToProc(8));

		return updateVinList.toString();
	}


	public String updateVinFsaGoParam(UpdateVinSerialReq updateSerialList) {

		StringBuilder sb = new StringBuilder();
		String fsaType=updateSerialList.getFsaType();
		String fsaNumber=updateSerialList.getFsaNumber();
		if (("G").equals(fsaType)) {
			sb.append(fsaType);
			sb.append(TargetingUtil.fillRemainingString(fsaNumber,8,"0"));
			sb.append(addSpaceToProc(9));
		} else if (("L").equals(fsaType)) {
			sb.append(fsaType);
			sb.append(TargetingUtil.fillRemainingString(fsaNumber.toUpperCase(),10," "));
			sb.append(addSpaceToProc(9));
		}
		return sb.toString();

	}

	public String uploadSerialInpuParm(SerialUploadRequest serialUploadRequest) {
		StringBuilder updateVinList = new StringBuilder();

		String BATCH_CODE=null;
		String vinGrpFlag="";
		String labelChangeFlag="";
		if(("I").equals(serialUploadRequest.getFileType())) {
			BATCH_CODE="011";
			vinGrpFlag="Y";
			labelChangeFlag="I";
		}else if(("E").equals(serialUploadRequest.getFileType())) {
			BATCH_CODE="011";
			vinGrpFlag="N";
			labelChangeFlag=" ";
			serialUploadRequest.setGrpCode("  ");
			serialUploadRequest.setGrpDescription("");

		}else if(("F").equals(serialUploadRequest.getFileType())) {
			BATCH_CODE="009";
			vinGrpFlag="N";
			labelChangeFlag=" ";
			serialUploadRequest.setGrpCode("  ");
			serialUploadRequest.setGrpDescription("");
		}

		updateVinList.append("A");
		updateVinList.append(TargetingUtil.fillRemainingString(serialUploadRequest.getFsaNumber(),8,"0"));
		updateVinList.append(serialUploadRequest.getPopulation());
		updateVinList.append(TargetingUtil.fillRemainingString(serialUploadRequest.getCdsId(),8," "));
		updateVinList.append("   ");
		updateVinList.append(serialUploadRequest.getGrpCode());
		updateVinList.append(TargetingUtil.fillRemainingString(serialUploadRequest.getGrpDescription(),254," "));
		updateVinList.append("  ");
		updateVinList.append(labelChangeFlag);
		updateVinList.append(serialUploadRequest.getFileType());
		updateVinList.append(addSpaceToProc(36));
		updateVinList.append(TargetingUtil.fillRemainingString(serialUploadRequest.getFilePath(), 75, " "));
		updateVinList.append(vinGrpFlag);
		updateVinList.append(" ");
		updateVinList.append(TargetingUtil.fillRemainingString(serialUploadRequest.getSerialSource(), 8, " "));
		updateVinList.append(addSpaceToProc(26));
		updateVinList.append("N");
		updateVinList.append(" ");
		updateVinList.append(TargetingUtil.fillRemainingString(serialUploadRequest.getSerialReason(), 254, " "));
		updateVinList.append(" ");
		updateVinList.append("   ");
		updateVinList.append(addSpaceToProc(14));
		updateVinList.append("USA");
		updateVinList.append(BATCH_CODE);
		updateVinList.append(serialUploadRequest.getComponentType());
		updateVinList.append(addSpaceToProc(12));

		return updateVinList.toString();
	}

	public String uploadVDMNonVDMParm(FsaCriteriaVdmVO fsaCriteriaVdm) {
		StringBuilder updateVinList = new StringBuilder();
		String labelCharge=null;

		if(("N").equals(fsaCriteriaVdm.getVinSelectionOption())) {
			labelCharge=" ";
			fsaCriteriaVdm.setFileType("N");
			fsaCriteriaVdm.setGroupCode("  ");
			fsaCriteriaVdm.setReasonOfVins(fsaCriteriaVdm.getSourceForReason());
			fsaCriteriaVdm.setSourceForReason("");
		}else if(("V").equals(fsaCriteriaVdm.getVinSelectionOption())&&("I").equals(fsaCriteriaVdm.getFileType())) {
			labelCharge="I";

		}else if(("V").equals(fsaCriteriaVdm.getVinSelectionOption())&&("E").equals(fsaCriteriaVdm.getFileType())) {
			labelCharge="B";
		}else {
			labelCharge="F";
		}


		String vinGrpF="";
		String ingProdDate="";
		String ingCrtFlag="";
		if(("V").equals(fsaCriteriaVdm.getVinSelectionOption())) {
			ingProdDate="N";
			ingCrtFlag="N";
		}else if(("N").equals(fsaCriteriaVdm.getVinSelectionOption())) {
			ingProdDate=" ";
			ingCrtFlag=" ";
			vinGrpF=" ";
		}
		if(("I").equals(fsaCriteriaVdm.getFileType())) {
			vinGrpF="Y";
		}else if(("E").equals(fsaCriteriaVdm.getFileType()) ||("F").equals(fsaCriteriaVdm.getFileType())) {
			vinGrpF="N";
			fsaCriteriaVdm.setGroupCode("  ");
		}
		updateVinList.append("A");
		updateVinList.append(TargetingUtil.fillRemainingString(fsaCriteriaVdm.getFsaNumber(),8,"0"));
		updateVinList.append(fsaCriteriaVdm.getPopulation());
		updateVinList.append(TargetingUtil.fillRemainingString(fsaCriteriaVdm.getCdsId(),8," "));
		//folderID 22
		updateVinList.append(addSpaceToProc(3));
		//vin grp code 23
		updateVinList.append(TargetingUtil.fillRemainingString(fsaCriteriaVdm.getGroupCode(),2,StringUtils.SPACE));
		//vin grp description
		updateVinList.append(TargetingUtil.fillRemainingString(fsaCriteriaVdm.getGroupDescription(),254," "));
		//25+254+2=281
		updateVinList.append("  ");

		updateVinList.append(labelCharge);
		updateVinList.append(fsaCriteriaVdm.getFileType());
		//2+36+281=319
		updateVinList.append(addSpaceToProc(36));
		updateVinList.append(TargetingUtil.fillRemainingString(fsaCriteriaVdm.getFilePath(), 75, " "));
		//vingrp flag3
		updateVinList.append(vinGrpF);
		//ing prod date19+75+2=396
		updateVinList.append(ingProdDate);
		//source of serial
		updateVinList.append(TargetingUtil.fillRemainingString(fsaCriteriaVdm.getSourceForReason(), 8, " "));
		//fldr mnt not required for serial upload
		updateVinList.append(addSpaceToProc(26));
		//IGN-CRIT-F
		updateVinList.append(ingCrtFlag);
		//8+26+396+2=432
		updateVinList.append(ingProdDate);
		//432+254=686
		updateVinList.append(TargetingUtil.fillRemainingString(fsaCriteriaVdm.getReasonOfVins(), 254, " "));

		updateVinList.append(" ");
		updateVinList.append("   ");
		//18+686=704
		updateVinList.append(addSpaceToProc(14));

		updateVinList.append(fsaCriteriaVdm.getCountryCode());
		//704+6
		updateVinList.append(fsaCriteriaVdm.getBatchCode());
		//706+4
		updateVinList.append(TargetingUtil.fillRemainingString(fsaCriteriaVdm.getEventCode(), 3, " "));
		//713+12=725
		updateVinList.append(addSpaceToProc(1));
		updateVinList.append(StringUtils.isBlank(fsaCriteriaVdm.getOtaIndicator()) ? addSpaceToProc(1)
				: StringUtils.trimToEmpty(fsaCriteriaVdm.getOtaIndicator()));
		updateVinList.append(" ");
		updateVinList.append(StringUtils.isBlank(fsaCriteriaVdm.getFhmIndicator()) ? addSpaceToProc(1)
				: StringUtils.trimToEmpty(fsaCriteriaVdm.getFhmIndicator()));
		updateVinList.append(addSpaceToProc(8));
		LOGGER.info("length update vinList input is {}:",updateVinList.toString().length());
		LOGGER.info("update vinList input is {}:",updateVinList);

		return updateVinList.toString();
	}

	public String updateVinInputParam1(SerialUploadRequest serialVo) {

		StringBuilder sb = new StringBuilder();
		String fsaType=serialVo.getFsaType();
		String fsaNumber=serialVo.getFsaNumber();
		if (("G").equals(fsaType)) {
			sb.append(fsaType);
			sb.append(TargetingUtil.fillRemainingString(fsaNumber,8,"0"));
			sb.append(addSpaceToProc(9));
		} else if (("L").equals(fsaType)) {
			sb.append(fsaType);
			sb.append(TargetingUtil.fillRemainingString(fsaNumber.toUpperCase(),10," "));
			sb.append(addSpaceToProc(9));
		}
		return sb.toString();

	}

	public String updateVinParam1(FsaCriteriaVdmVO vo) {


		StringBuilder sb = new StringBuilder();
		String fsaType=vo.getFsaType();
		String fsaNumber=vo.getFsaNumber();
		if (("G").equals(fsaType)) {
			sb.append(fsaType);
			sb.append(TargetingUtil.fillRemainingString(fsaNumber,8,"0"));
			sb.append(addSpaceToProc(9));
		} else if (("L").equals(fsaType)) {
			sb.append(fsaType);
			sb.append(TargetingUtil.fillRemainingString(fsaNumber.toUpperCase(),10," "));
			sb.append(addSpaceToProc(9));
		}
		return sb.toString();


	}
	public String fsaManualVinsGoParam(ManualAddVinsVO manualVinsVo) {

		StringBuilder sb = new StringBuilder();
		String fsaType=manualVinsVo.getFsaType();
		String fsaNumber=manualVinsVo.getFsaNumber();
		if (("G").equals(fsaType)) {
			sb.append(fsaType);
			sb.append(TargetingUtil.fillRemainingString(fsaNumber,8,"0"));
			sb.append(addSpaceToProc(9));
		} else if (("L").equals(fsaType)) {
			sb.append(fsaType);
			sb.append(TargetingUtil.fillRemainingString(fsaNumber.toUpperCase(),10," "));
			sb.append(addSpaceToProc(9));
		}
		log.info("fsa go param {}",sb.toString());
		return sb.toString();

	}

	public String getManulVinInputParam2(ManualAddVinsVO manualVinsVo) {
		StringBuilder manulVins = new StringBuilder();
		StringBuilder builtedString = new StringBuilder();
		String noOfVins=manualVinsVo.getVinNumbers();

		String[] noOfVinsArray = noOfVins.split(",");
		int vinSelectedCount=0;

		for (int i = 0; i < noOfVinsArray.length; i++) {
			if(noOfVinsArray[i].length()>0) {
				builtedString.append(noOfVinsArray[i]);
				vinSelectedCount++;
			}
		}
		String vinsSelected = builtedString.toString();

		String vinSelectedCount1 = String.valueOf(vinSelectedCount);

		manulVins.append(TargetingUtil.fillRemainingString(vinSelectedCount1.toUpperCase(),2,"0"));
		manulVins.append(vinsSelected);
		log.info("manual add vin param2 {}",manulVins.toString());
		return manulVins.toString();
	}

	public String getSerialListParamHistory(FscCriteriaRequest fscCriteriaRequest) {
		StringBuilder serialListParm = new StringBuilder();
		serialListParm.append("G");
		serialListParm.append(addSpaceToProc(8));
		serialListParm.append(fscCriteriaRequest.getPopulation());
		serialListParm.append(addSpaceToProc(701));
		serialListParm.append("G");
		serialListParm.append(addSpaceToProc(11));
		return serialListParm.toString();
	}

    public String batchInputManualAddVins(ManualAddVinsVO manualVinsVo) {
        StringBuilder manulVins = new StringBuilder();
        LayoutBuffer layout2 = new LayoutBuffer(4);
        LayoutBuffer layout3 = new LayoutBuffer(3);

        // 1. VIN Number count and FSA Type
        layout2.addField(LayoutBuffer.FIELDTYPE_PIC9, 2);
        layout2.addField(LayoutBuffer.FIELDTYPE_PICX, 2);

        List<String> myList = new ArrayList<>(Arrays.asList(manualVinsVo.getVinNumbers().split(",", -1)));
        int count = (int) myList.stream()
                .filter(vinNo -> vinNo.length() != 0)
                .count();

        layout2.setString(0, String.valueOf(count));
        layout2.setString(1, String.valueOf(manualVinsVo.getFsaType()));

        // 2. Process VINs
        StringBuilder builtedString = new StringBuilder();
        String noOfVins = manualVinsVo.getVinNumbers();
        String[] noOfVinsArray = noOfVins.split(",");
        for (int i = 0; i < noOfVinsArray.length; i++) {
            if (noOfVinsArray[i].length() > 0) {
                builtedString.append(noOfVinsArray[i]);
            }
        }
        String vinsSelected = builtedString.toString();

        // 3. Process Segments and VIN Groups (The Fixed Part)
        StringBuilder input1 = new StringBuilder();
        int segmentVINGroupCount = 0;

        String segmentsInput = manualVinsVo.getSelectedSegmentsAndVinGrps();
        if (StringUtils.isNotBlank(segmentsInput)) {
            // First, split by comma to get each "Segment|Group" pair
            String[] pairs = segmentsInput.split(",");

            for (String pair : pairs) {
                if (StringUtils.isBlank(pair)) continue;

                // Second, split each pair by the pipe
                String[] parts = pair.split("\\|");
                if (parts.length == 2) {
                    segmentVINGroupCount++;
                    LayoutBuffer layout1 = new LayoutBuffer(10);
                    layout1.addField(LayoutBuffer.FIELDTYPE_PIC9, 5); // Segment
                    layout1.addField(LayoutBuffer.FIELDTYPE_PIC9, 5); // VIN Group

                    // Trim to ensure no stray characters or commas are passed
                    layout1.setString(0, parts[0].trim());
                    layout1.setString(1, parts[1].trim());
                    input1.append(layout1.toString());
                }
            }
        }

        String input3 = input1.toString();

        // 4. Set the Count of Segment/Group blocks
        layout3.addField(LayoutBuffer.FIELDTYPE_PIC9, 3);
        layout3.setString(0, String.valueOf(segmentVINGroupCount));

        // 5. Padding for VINs (Mainframe expects 25 slots of 17 chars)
        LayoutBuffer layout4 = new LayoutBuffer((25 - count) * 17);

        // 6. Assemble final string
        manulVins.append(layout2);
        manulVins.append(manualVinsVo.getIncludeFronzenVin());
        manulVins.append(vinsSelected);
        manulVins.append(layout4);
        manulVins.append(layout3);
        manulVins.append(input3);

        log.info("manulVins Batch Job input param values: {}", manulVins);
        return manulVins.toString();
    }

	public String batchInputManualAddVinss(ManualAddVinsVO manualVinsVo) {
		StringBuilder manulVins = new StringBuilder();
		LayoutBuffer layout2 = new LayoutBuffer(4);
		LayoutBuffer layout3 = new LayoutBuffer(3);
		// VIN Number count
		layout2.addField(LayoutBuffer.FIELDTYPE_PIC9, 2);
		// FSA Type
		layout2.addField(LayoutBuffer.FIELDTYPE_PICX, 2);
		List<String> myList = new ArrayList<>(Arrays.asList(manualVinsVo.getVinNumbers().split(",", -1)));
		int count = (int) myList.stream()
				.filter(vinNo -> vinNo.length() != 0)
				.count();
		layout2.setString(0, String.valueOf(count));
		layout2.setString(1, String.valueOf(manualVinsVo.getFsaType()));

		StringBuilder builtedString = new StringBuilder();
		String noOfVins=manualVinsVo.getVinNumbers();
		String[] noOfVinsArray = noOfVins.split(",");
		for (int i = 0; i < noOfVinsArray.length; i++) {
			if(noOfVinsArray[i].length()>0) {
				builtedString.append(noOfVinsArray[i]);
			}
		}
		String vinsSelected = builtedString.toString();

		String fsaType = manualVinsVo.getFsaType();
		String includeFronzenVin = manualVinsVo.getIncludeFronzenVin();
		StringTokenizer token1 = new StringTokenizer(manualVinsVo.getSelectedSegmentsAndVinGrps());

		LayoutBuffer layout1 = null;
		StringBuilder input1 = new StringBuilder();
		String input3 = "";
		int segmentVINGroupCount = 0;
		while (token1.hasMoreTokens()) {
			String eachRowData1 = token1.nextToken();
			StringTokenizer rowToken1 = new StringTokenizer(eachRowData1, "|");
			segmentVINGroupCount++;
			while (rowToken1.hasMoreElements()) {
				layout1 = new LayoutBuffer(10);
				layout1.addField(LayoutBuffer.FIELDTYPE_PIC9, 5);
				layout1.addField(LayoutBuffer.FIELDTYPE_PIC9, 5);
				layout1.setString(0, rowToken1.nextToken());
				layout1.setString(1, rowToken1.nextToken());
				input3 = input1.append(layout1).toString();
			}
		}
		layout3.addField(LayoutBuffer.FIELDTYPE_PIC9, 3);
		layout3.setString(0, String.valueOf(segmentVINGroupCount));

		LayoutBuffer layout4 = new LayoutBuffer((25 - count) * 17);

		manulVins.append(layout2);
		manulVins.append(includeFronzenVin);
		manulVins.append(vinsSelected);
		manulVins.append(layout4);
		manulVins.append(layout3);
		manulVins.append(input3);

		log.info("manulVins Batch Job input param values{}",manulVins);
		return manulVins.toString();
	}

}
