package com.ford.gcamp.targeting.fsacriteria.api;

import java.util.List;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Size;
import org.springframework.stereotype.Component;

import com.ford.gcamp.targeting.common.api.ResponseStatusDTO;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Component
@EqualsAndHashCode(callSuper=false)
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class DynamicQueryResponse extends ResponseStatusDTO{
	@Size(min = 0, max = 1000, message = "modelYear List")
	private List<@Valid ModelYearList> modelYear;

	@Size(min = 0, max = 1000, message = "vehicleTypeList")
	private List<@Valid VehicleTypeList> vehicleTypeList;

	@Size(min = 0, max = 1000, message = "assemblyPlantList")
	private List<@Valid AssemblyPlantList> assemblyPlantList;

	@Size(min = 0, max = 1000, message = "wersValue")
	private List<@Valid WersValuesList> wersValue;

	@Size(min = 0, max = 1000, message = "vehicleBrandLists")
	private List<@Valid VehicleBrandList> vehicleBrandLists;

	@Size(min = 0, max = 1000, message = "attributeGroupingLists")
	private List<@Valid AttributeGroupingList> attributeGroupingLists;

	@Size(min = 0, max = 1000, message = "gcpFilterList")
	private List<@Valid GCPFilterList> gcpFilterList;
		
	
	
	/**
	 * @param modelYear
	 * @param wersList
	 * @param vehicleTypeList
	 * @param vehicleBrandLists
	 * @param gcpFilterList
	 * @param attributeGroupingLists
	 */
	
	
	}
