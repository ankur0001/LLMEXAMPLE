package com.ford.gcamp.targeting.fsacriteria.api;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class FsaCriteriaFilterFields {
	
	private String filterCode;
	private String filterDesc;
	private String filterGroup;
	private String filterGroupName;
	
	
	public FsaCriteriaFilterFields(String filterCode, String filterDesc) {
		super();
		this.filterCode = filterCode;
		this.filterDesc = filterDesc;
	}
	
	
	
	public FsaCriteriaFilterFields(String filterCode, String filterDesc, String filterGroup) {
		super();
		this.filterCode = filterCode;
		this.filterDesc = filterDesc;
		this.filterGroup = filterGroup;
	}


	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("FsaCriteriaFilterFields [filterCode=");
		builder.append(filterCode);
		builder.append(", filterDesc=");
		builder.append(filterDesc);
		builder.append(", filterGroup=");
		builder.append(filterGroup);
		builder.append(", filterGroupName=");
		builder.append(filterGroupName);
		builder.append("]");
		return builder.toString();
	}
	
	
	

}
