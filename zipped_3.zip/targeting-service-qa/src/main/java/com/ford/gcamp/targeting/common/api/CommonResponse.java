package com.ford.gcamp.targeting.common.api;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.SuperBuilder;

@Getter
@Setter
@SuperBuilder(toBuilder = true)
@NoArgsConstructor
@AllArgsConstructor
public class CommonResponse {

    @Size(min = 0, max = 30)
    @Pattern(regexp = "^[A-Za-z\\s]*$")
    @Schema(types={"string","null"},example = "SUCCESS", description = "Status of the response")
    private String status;

    @Size(min = 0, max = 50)
    @Schema(types={"string","null"},example = "200", description = "Status Code")
    @Pattern(regexp = "^[A-Za-z\\d\\s_.,'()\"]*$")
    private String statusCode;

    @Size(min = 0, max = 200)
    @Schema(types={"string","null"},example = "Success", description = "Status Description")
    @Pattern(regexp = "^[\\s\\S]*$")
    private String statusDescription;

}
