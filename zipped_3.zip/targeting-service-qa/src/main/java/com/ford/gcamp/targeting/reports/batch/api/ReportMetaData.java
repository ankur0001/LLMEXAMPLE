package com.ford.gcamp.targeting.reports.batch.api;

import java.io.Serializable;
import java.util.List;

import java.util.Arrays;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ReportMetaData implements Serializable {
   
    private static final long serialVersionUID = 1L;
    
    private String processIndicator;
   
    private int rptId;
    private String rptCode;
    private String reportDesc;
    private String agencyCode;
    private String rptFormat;
    private String dateFrom;
    private String filler;
    private String reqById;
    private String reqTimeStamp;
    private String periodEndingDate;
    private String finalRptFlag;
    private String hubCode;
    private String hubDescription;
    private String countryCode;
    private String langCode;
    private String localFSANum;
    private String suppCode;
    private String roiCode;
    private String jobQue;
    private String globalFSANum;
    private String globalFSANumDesc;
    private String launchFromDate;
    @Setter(AccessLevel.NONE)
    @Getter(AccessLevel.NONE)
    private byte[] blobData;
    private List<String> rptAttributesList;
    private String actionType;
    private String emailSubject;
    private String emailBody;
    private List<String> distEmailList;
    private int processId;

    private String errorCode;
    private String emailCode;
    private String distListFlag;


    private String distributionList;
    private int jobQueue;
    private String reportId;
    private String batchCode;
    private String processComplete;
    private boolean isRecordsFound;

    
    private String blobId;
    private int emailCount = 0;
    
	public byte[] getBlobData() {
		if (blobData != null) {
			return Arrays.copyOf(this.blobData, this.blobData.length);
		} else {
			return Arrays.copyOf(new byte[1], 1);
		}
	}
    
	public void setBlobData(byte[] blobData) {
		if (blobData != null) {
			this.blobData = Arrays.copyOf(blobData, blobData.length);
		} else {
			this.blobData = null;
		}
	}
}
