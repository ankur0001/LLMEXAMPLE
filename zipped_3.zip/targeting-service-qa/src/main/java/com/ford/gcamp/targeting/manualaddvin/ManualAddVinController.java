package com.ford.gcamp.targeting.manualaddvin;

import com.ford.cloudnative.base.api.StandardErrorResponse;
import com.ford.gcamp.targeting.common.api.CommonErrorResponse;
import com.ford.gcamp.targeting.common.api.RoiCountryResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import jakarta.validation.Valid;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.WebRequest;

import com.ford.gcamp.targeting.common.api.FscCriteriaRequest;
import com.ford.gcamp.targeting.core.exception.GCAMPException;
import com.ford.gcamp.targeting.logging.LogExecutionTime;
import com.ford.gcamp.targeting.manualaddvin.api.ManualAddVinsVO;
import com.ford.gcamp.targeting.manualaddvin.api.ManualUploadResponse;

@RestController
@RequestMapping("/api/v1/targeting/manualaddvin")
@Validated
public class ManualAddVinController {

	ManualAddVinService manualAddVinService;

	public ManualAddVinController(ManualAddVinService manualAddVinService) {
		this.manualAddVinService = manualAddVinService;
	}

	@PreAuthorize("@authorizeService.isAuthorized('GCAMP:manuallyAddVinToFsa:ManuallyAddVinGo','execute')")
	@Operation(summary = "Query Manual Upload Data",security = {
			@SecurityRequirement(name = "ADFS"),
			@SecurityRequirement(name = "AzureAD")
	})
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Query Manual Upload data request fetched successfully",
					content = @Content(mediaType = "application/problem+json",schema = @Schema(implementation = RoiCountryResponse.class))),
			@ApiResponse(responseCode = "default", description = "All Errors", content = @Content(schema = @Schema(implementation = StandardErrorResponse.class)))
	})
	@PostMapping(value = "/queryManualUploadData")
	@LogExecutionTime
	public ResponseEntity<ManualUploadResponse> queryManualUpload(
			@RequestBody @Valid final FscCriteriaRequest fscCriteriaRequest) throws GCAMPException {
		ManualUploadResponse manualUploadResp = manualAddVinService.queryManulLoad(fscCriteriaRequest);
		return ResponseEntity.ok(manualUploadResp);

	}

	@PreAuthorize("@authorizeService.isAuthorized('GCAMP:manuallyAddVinToFsa:AddVin','execute')")
	@Operation(summary = "Add Manual Vins",security = {
			@SecurityRequirement(name = "ADFS"),
			@SecurityRequirement(name = "AzureAD")
	})
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Add Manual Vins data request fetched successfully",
					content = @Content(mediaType = "application/problem+json",schema = @Schema(implementation = RoiCountryResponse.class))),
			@ApiResponse(responseCode = "412", description = "Precondition Failed", content = @Content(schema = @Schema(implementation = CommonErrorResponse.class))),
			@ApiResponse(responseCode = "default", description = "All Errors", content = @Content(schema = @Schema(implementation = StandardErrorResponse.class)))
	})
	@PostMapping(value = "/addManualVins")
	@LogExecutionTime
	public ResponseEntity<ManualUploadResponse> addVinsManual(@RequestBody @Valid final ManualAddVinsVO manualVinsVo)
			throws GCAMPException {
		ManualUploadResponse manualUploadResp = manualAddVinService.addVinsManually(manualVinsVo);
		return ResponseEntity.ok(manualUploadResp);

	}

	@ExceptionHandler({ AccessDeniedException.class })
	public ResponseEntity<Object> handleAccessDeniedException(Exception ex, WebRequest request) {
		if (ex.getMessage().toLowerCase().indexOf("access is denied") > -1) {
			return new ResponseEntity<>("You are not Authorized by APS to access the Resource", new HttpHeaders(),
					HttpStatus.FORBIDDEN);
		}
		return new ResponseEntity<>(ex.getMessage(), new HttpHeaders(), HttpStatus.INTERNAL_SERVER_ERROR);
	}
}
