package com.ford.gcamp.targeting.gridgcamp.gcamp.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Embeddable
@Table(name="SGCPG12_DSTLST_DTL")
public class DistributionDetailId {

    @Column(name = "GCPG11_DIST_LIST_D")
    private int distributionList;

    @Column(name = "GCPG12_CDS_ID_C")
    private String cdsid;

}
