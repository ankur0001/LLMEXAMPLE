package com.ford.gcamp.targeting.properties;

import org.springframework.boot.context.properties.ConfigurationProperties;

import lombok.Getter;
import lombok.Setter;

@ConfigurationProperties(prefix = "fsa.criteria")
@Getter
@Setter
public class FsaCriteriaConfiguration {
	
	private String modifyActionFlag;
	private String saveActionFlag;
	private String modelFilterCode;
	private String brandFilterCode;
	private String vehLineFilterCode;
	private String assemblyPlantFilterCode;
	private String productionFilterCode;
	private String wersFilterCode;
	private String vinRangeFilterCode;
	private String warrantyFilterCode;
	private String traceabilityFilterCode;
	private String traceabilityAttrCode;
	private String traceabilityEngineAttrDesc;
	private String traceabilityTransmisionAttrDesc;
	private String brands;
	
		
}
