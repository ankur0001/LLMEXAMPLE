package com.ford.gcamp.targeting.fsacriteria.api;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class FSACriteriaSessionData {

	private String fsaNumber;
	private String inquiry;
	private String compliance;
	private String hub;
	private String gloablFsa;
	private String date;
	
}
