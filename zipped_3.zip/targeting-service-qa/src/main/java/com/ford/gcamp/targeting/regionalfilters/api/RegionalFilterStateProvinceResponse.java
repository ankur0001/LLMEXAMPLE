package com.ford.gcamp.targeting.regionalfilters.api;

import java.util.List;

import com.ford.gcamp.targeting.common.api.CommonResponse;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.SuperBuilder;

@Getter
@Setter
@SuperBuilder(toBuilder = true)
@AllArgsConstructor
@NoArgsConstructor
public class RegionalFilterStateProvinceResponse extends CommonResponse {
	@Size(min = 0, max = 50, message = "Countries")
	private List<@Valid StateProvCountry> country;
}
