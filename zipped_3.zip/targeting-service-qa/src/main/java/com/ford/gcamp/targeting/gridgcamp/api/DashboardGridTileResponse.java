package com.ford.gcamp.targeting.gridgcamp.api;

import java.util.List;

import com.ford.gcamp.targeting.common.api.CommonResponse;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class DashboardGridTileResponse extends CommonResponse {

	@Size(min = 0, max = 1000, message = "List of Grid UnAssigned Verns")
	private List<@Valid DashboardGridTile> gridUnAssignedVerns;

}
