package com.ford.gcamp.targeting.gridgcamp.grid.entity;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class LocalFSAId implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private int globalFSANumber;
	private String hubCode;
}
