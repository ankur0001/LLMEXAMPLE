package com.ford.gcamp.targeting.gridgcamp.grid.api;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.ford.gcamp.targeting.gridgcamp.gcamp.api.GridBasicVernInfo;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@JsonIgnoreProperties
public class GridVernCount extends GridBasicVernInfo {

	private String localFSANumber;
	private String localFSAInitHub;
	private String frcApprovalDate;
	private String fsaTitle;
	private String globalFsaType;
	private String vernExtractFilePath;
	private String vernExtractFileName;
	private String vernExceptionFilePath;
	private String vernExceptionFileName;
	// This field is required only for Local FSA Create/Delete Communication to GRID
	private List<String> regions;
	private String action;
	private String comment;
	private String actionDate;
	private String vinFileName;
	private List<VehicleCountRegion> vernCount;
        @JsonProperty("isTandem")
	private boolean tandemFlag;
	private String expirationDate;
	private String key;
	private String timestamp;
}
