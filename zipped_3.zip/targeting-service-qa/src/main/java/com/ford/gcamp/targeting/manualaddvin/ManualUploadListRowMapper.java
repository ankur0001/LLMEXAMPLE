package com.ford.gcamp.targeting.manualaddvin;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.commons.lang3.StringUtils;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import com.ford.gcamp.targeting.manualaddvin.api.ManualUploadList;

@Component
public class ManualUploadListRowMapper implements RowMapper<ManualUploadList> {
	@Override
	public ManualUploadList mapRow(ResultSet rs, int rowNum) throws SQLException {
		return ManualUploadList.builder()
				.segmentNum(StringUtils.trimToEmpty(rs.getString(1)))
				.vinGrpSeqNum(StringUtils.trimToEmpty(rs.getString(2)))
				.vinGrpLablCode(StringUtils.trimToEmpty(rs.getString(3)))
				.vinGrpDesc(StringUtils.trimToEmpty(rs.getString(4)))
				.vinCount(StringUtils.trimToEmpty(rs.getString(5)))
				.build();
	}
}
