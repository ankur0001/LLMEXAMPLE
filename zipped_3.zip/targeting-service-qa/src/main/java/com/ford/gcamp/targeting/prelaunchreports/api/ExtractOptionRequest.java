package com.ford.gcamp.targeting.prelaunchreports.api;

import io.swagger.v3.oas.annotations.extensions.Extension;
import io.swagger.v3.oas.annotations.extensions.ExtensionProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ExtractOptionRequest {
	@Schema(example= "S" , description = "process Flag")
	@Size(min = 0, max = 1)
	@Pattern(regexp ="^[A-Za-z]$")
	private String processFlag;

	@NotNull
	@Size(min = 5, max = 6)
	@Pattern(regexp = "^\\d{2}[A-Za-z\\d]{2}\\d{1}\\d*$")
	@Schema(type="string", description = "FSA number",minLength=5,maxLength = 6, extensions = @Extension(properties = @ExtensionProperty(name = "x-42c-sample", value = "65569")))
	private String fsaNumber;

	@NotNull
	@Schema(example = "G", description = "fsaType")
	@Size(min = 0, max = 1)
	@Pattern(regexp = "^[A-Za-z]$", message = "FSA Type")
	private String fsaType;

	@Size(min = 0, max = 8)
	@Pattern(regexp = "^[a-zA-Z\\d\\-]*$")
	@Schema(example = "TDHARTI", description = "CDSID")
	private String cdsId;

	@Size(min = 0, max = 2)
	@Pattern(regexp ="^[A-Za-z\\d\\s\\*]*$", message = "population Code")
	@Schema(example = "AA", description = "Population")
	private String population;

	@Size(min = 0, max = 99)
	@Pattern(regexp = "^[a-zA-Z\\d\\s\\*]*$")
	@Schema(example = "T21T22T23T24T25T26T27T28T29T30T31T33T32T34IAD", description = "report checked")
	private String reportChecked;

	@Size(min = 0, max = 2)
	@Pattern(regexp = "^[a-zA-Z\\*]*$")
	@Schema(example = "NA", description = "Hub code")
	private String hubCode;

	@Size(min = 0, max = 3)
	@Pattern(regexp = "^[a-zA-Z\\*\\d\\s]*$")
	@Schema(example = "CAN", description = "CountryCode")
	private String countryCode;

	@Min(0)
	@Max(99)
	@Schema(example = "15", description = "report code")
	private int reportCount;

	@Min(0)
	@Max(99)
	@Schema(example = "15", description = "wers code count")
	private int wersCodeCount;

	@Size(min = 0, max = 40)
	@Pattern(regexp = "^[a-zA-Z\\d\\*\\,]*$")
	@Schema(example = "23,35,36", description = "CountryCode")
	private String wersCodeSelected;


	@Schema(example= "Y" , description = "email Submit Ind")
	@Size(min = 0, max = 1)
	@Pattern(regexp ="^[A-Za-z]$")
	private String emailSubmitInd;

	@Schema(example= "Y" , description = "serial Num Ind")
	@Size(min = 0, max = 1)
	@Pattern(regexp ="^[A-Za-z]$")
	private String serialNumInd;

	@Schema(example= "Y" , description = "navis Indicator")
	@Size(min = 0, max = 1)
	@Pattern(regexp ="^[A-Za-z]$")
	private String navisIndicator;

	@Schema(example= "Y" , description = "regional filter Indicator")
	@Size(min = 0, max = 1)
	@Pattern(regexp ="^[A-Za-z]$")
	private String regionalFilter;

	@Schema(example= "Y" , description = "Tera data Indicator")
	@Size(min = 0, max = 1)
	@Pattern(regexp ="^[A-Za-z]$")
	private String loadTeraDataInd;

	private boolean fsaRequest;
}
