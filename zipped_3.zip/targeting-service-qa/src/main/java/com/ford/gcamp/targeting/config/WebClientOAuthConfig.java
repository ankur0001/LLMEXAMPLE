package com.ford.gcamp.targeting.config;

import io.netty.handler.logging.LogLevel;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.security.oauth2.client.AuthorizedClientServiceReactiveOAuth2AuthorizedClientManager;
import org.springframework.security.oauth2.client.ClientCredentialsReactiveOAuth2AuthorizedClientProvider;
import org.springframework.security.oauth2.client.InMemoryReactiveOAuth2AuthorizedClientService;
import org.springframework.security.oauth2.client.endpoint.WebClientReactiveClientCredentialsTokenResponseClient;
import org.springframework.security.oauth2.client.registration.ClientRegistration;
import org.springframework.security.oauth2.client.registration.InMemoryReactiveClientRegistrationRepository;
import org.springframework.security.oauth2.client.web.reactive.function.client.ServerOAuth2AuthorizedClientExchangeFilterFunction;
import org.springframework.security.oauth2.core.AuthorizationGrantType;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.netty.http.client.HttpClient;
import reactor.netty.transport.ProxyProvider;
import reactor.netty.transport.logging.AdvancedByteBufFormat;

@Slf4j
public abstract class WebClientOAuthConfig {

    protected final String clientId;
    protected final String clientSecret;
    protected final String tokenUri;
    protected final String scope;
    protected final String registrationId;
    protected final WebClient.Builder webClientBuilder;
    private final String proxyHost;
    private final int proxyPort;

    protected WebClientOAuthConfig(
            String clientId,
            String clientSecret,
            String tokenUri,
            String scope,
            String registrationId,
            WebClient.Builder webClientBuilder,
            String proxyHost,
            int proxyPort
    ) {
        this.clientId = clientId;
        this.clientSecret = clientSecret;
        this.tokenUri = tokenUri;
        this.scope = scope;
        this.registrationId = registrationId;
        this.webClientBuilder = webClientBuilder;
        this.proxyHost = proxyHost;
        this.proxyPort = proxyPort;
    }

    protected ClientRegistration getClientRegistration() {
        return ClientRegistration.withRegistrationId(registrationId)
                .tokenUri(tokenUri)
                .clientId(clientId)
                .clientSecret(clientSecret)
                .scope(scope)
                .authorizationGrantType(AuthorizationGrantType.CLIENT_CREDENTIALS)
                .build();
    }

    protected WebClient buildWebClientWithProxy() {
        HttpClient httpClient = HttpClient.create()
                .proxy(proxy -> proxy
                        .type(ProxyProvider.Proxy.HTTP)
                        .host(proxyHost)
                        .port(proxyPort))
                .wiretap(
                        "reactor.netty.http.client.HttpClient",
                        LogLevel.DEBUG,
                        AdvancedByteBufFormat.TEXTUAL);

        ServerOAuth2AuthorizedClientExchangeFilterFunction oauth =
                new ServerOAuth2AuthorizedClientExchangeFilterFunction(getAuthorizedClientManager());
        oauth.setDefaultClientRegistrationId(registrationId);

        return webClientBuilder
                .clientConnector(new ReactorClientHttpConnector(httpClient))
                .filter(oauth)
                .build();
    }

    private AuthorizedClientServiceReactiveOAuth2AuthorizedClientManager getAuthorizedClientManager() {
        InMemoryReactiveClientRegistrationRepository clientRegistrationRepository =
                new InMemoryReactiveClientRegistrationRepository(getClientRegistration());

        InMemoryReactiveOAuth2AuthorizedClientService clientService =
                new InMemoryReactiveOAuth2AuthorizedClientService(clientRegistrationRepository);

        AuthorizedClientServiceReactiveOAuth2AuthorizedClientManager authorizedClientManager =
                new AuthorizedClientServiceReactiveOAuth2AuthorizedClientManager(
                        clientRegistrationRepository, clientService);

        ClientCredentialsReactiveOAuth2AuthorizedClientProvider authorizedClientProvider =
                new ClientCredentialsReactiveOAuth2AuthorizedClientProvider();

        WebClientReactiveClientCredentialsTokenResponseClient webTokenClient =
                new WebClientReactiveClientCredentialsTokenResponseClient();

        // Key fix: proxy is set on the token-fetching WebClient so token requests also go through proxy
        webTokenClient.setWebClient(WebClient.builder()
                .clientConnector(
                        new ReactorClientHttpConnector(HttpClient.create()
                                .proxy(proxy -> proxy
                                        .type(ProxyProvider.Proxy.HTTP)
                                        .host(proxyHost)
                                        .port(proxyPort))))
                .build());

        authorizedClientProvider.setAccessTokenResponseClient(webTokenClient);
        authorizedClientManager.setAuthorizedClientProvider(authorizedClientProvider);

        return authorizedClientManager;
    }
}
