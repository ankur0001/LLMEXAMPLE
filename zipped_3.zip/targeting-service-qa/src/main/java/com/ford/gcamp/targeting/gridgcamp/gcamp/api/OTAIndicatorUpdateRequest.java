package com.ford.gcamp.targeting.gridgcamp.gcamp.api;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@JsonIgnoreProperties(ignoreUnknown = true)
public class OTAIndicatorUpdateRequest extends GridBasicVernInfo {

	@Schema(description = "Indicates if OTA (Over-The-Air) updates are enabled",
			example = "false")
	private boolean otaIndicator;
	
	@Size(min = 0, max = 500)
	private List<@Valid VehicleCriteria> vehicleCritiera;

}
