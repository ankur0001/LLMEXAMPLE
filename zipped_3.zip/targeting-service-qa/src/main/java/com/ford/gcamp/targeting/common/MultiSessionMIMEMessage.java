package com.ford.gcamp.targeting.common;


import java.io.InputStream;

import jakarta.mail.Folder;
import jakarta.mail.MessagingException;
import jakarta.mail.Session;
import jakarta.mail.internet.InternetHeaders;
import jakarta.mail.internet.MimeMessage;

public class MultiSessionMIMEMessage extends MimeMessage {

	/**
	 * Constructor for MultiSessionMIMEMessage
	 */
	public MultiSessionMIMEMessage(Session arg0) {
		super(arg0);
	}

	/**
	 * Constructor for MultiSessionMIMEMessage
	 */
	public MultiSessionMIMEMessage(Session arg0, InputStream arg1)
		throws MessagingException {
		super(arg0, arg1);
	}

	/**
	 * Constructor for MultiSessionMIMEMessage
	 */
	protected MultiSessionMIMEMessage(Folder arg0, int arg1) {
		super(arg0, arg1);
	}

	/**
	 * Constructor for MultiSessionMIMEMessage
	 */
	protected MultiSessionMIMEMessage(Folder arg0, InputStream arg1, int arg2)
		throws MessagingException {
		super(arg0, arg1, arg2);
	}

	/**
	 * Constructor for MultiSessionMIMEMessage
	 */
	protected MultiSessionMIMEMessage(
		Folder arg0,
		InternetHeaders arg1,
		byte[] arg2,
		int arg3)
		throws MessagingException {
		super(arg0, arg1, arg2, arg3);
	}

	public void setSession(Session newSession){
		session = newSession;
	}
}

