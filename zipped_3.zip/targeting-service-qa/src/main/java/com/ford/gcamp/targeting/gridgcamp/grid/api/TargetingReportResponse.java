package com.ford.gcamp.targeting.gridgcamp.grid.api;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class TargetingReportResponse {

    private String targetingFileName;

    private String exceptionFileName;

    private String vernNumber;

    private Integer totalCount;

    private String updatedTimestamp;

    private String uploadedBy;

    private String actionFlag;

    private String action;
}
