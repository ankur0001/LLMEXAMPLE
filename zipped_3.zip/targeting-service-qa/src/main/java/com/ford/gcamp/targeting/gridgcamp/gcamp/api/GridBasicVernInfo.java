package com.ford.gcamp.targeting.gridgcamp.gcamp.api;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.*;
import lombok.experimental.SuperBuilder;

@Data
@Schema(types = {"object","null"})
@JsonIgnoreProperties(ignoreUnknown = true)
@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
public class GridBasicVernInfo {


	@Min(0)
	@Max(Integer.MAX_VALUE)
	@Schema(example = "24",description = "gridYearId")
	private int gridYearId;


	@Min(0)
	@Max(Integer.MAX_VALUE)
	@Schema(example = "725",description = "gridSequence")
	private int gridSequence;


	@Min(0)
	@Max(Integer.MAX_VALUE)
	@Schema(example = "3",description = "implementationId")
	private int implementationId;


	@Min(0)
	@Max(Integer.MAX_VALUE)
	@Schema(example = "1",description = "version")
	private int version;

	@Schema(example = "00",description = "supplementId")
	@Size(min = 0, max = 2, message = "length 1-2")
	@Pattern(regexp ="^|[A-Za-z\\d\\s]*$", message = "Supplement Code")
	private String supplementId;


	@Size(min = 0, max = 40, message = "Max length 40")
	@Pattern(regexp ="^|[A-Za-z\\d\\-\\s]*$")
	@Schema(example = "24-725-3-V1-S0", description = "vernNumber", minLength = 0, maxLength = 40)
	private String vernNumber;


	@Schema(example = "20458",description = "globalFSANumber")
	@Min(0)
	@Max(99999999)
	private int globalFSANumber;

	@Schema(example = "Y", description = "fsaAssignedFlag", minLength = 0, maxLength = 1)
	@Size(min = 0, max = 1, message = "Value must either Y or N")
	@Pattern(regexp ="^|[A-Za-z\\s]*$", message = "FSA Assigned Flag")
	private String fsaAssignedFlag;

	@Schema(example="T", description = "vernStatus", minLength = 0, maxLength = 30)
	@Size(min = 0, max = 30, message = "Max length 30")
	@Pattern(regexp ="^|[A-Za-z\\s]*$", message = "Vern Status")
	private String vernStatus;

	@Schema(example = "tdharti", description = "requester", minLength = 0, maxLength = 8)
	@Size(min = 0, max = 8, message = "Max length 8")
	@Pattern(regexp ="^|[A-Za-z\\d\\s]*$", message = "Requester CDSId")
	private String requester;

	@Schema(example = "tdharti", description = "updateId", minLength = 0, maxLength = 8)
	@Size(min = 0, max = 8, message = "Max length 8")
	@Pattern(regexp ="^|[A-Za-z\\d\\s]*$", message = "Update CDSId")
	private String updateId;

	@Schema(example="Y", description = "frcApprovedFlag", minLength = 0, maxLength = 1)
	@Size(min = 0, max = 1, message = "Max length 1")
	@Pattern(regexp ="^|[A-Z\\s]*$", message = "FRC Approved Flag")
	private String frcApprovedFlag;
	
}
