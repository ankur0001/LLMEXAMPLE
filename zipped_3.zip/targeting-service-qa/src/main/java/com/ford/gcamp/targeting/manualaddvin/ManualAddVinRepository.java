package com.ford.gcamp.targeting.manualaddvin;

import java.util.Map;


import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import com.ford.gcamp.targeting.common.CommonConstants;
import com.ford.gcamp.targeting.core.exception.GCAMPException;


import lombok.extern.slf4j.Slf4j;

@Repository
@Slf4j
public class ManualAddVinRepository {
	@Value("${DB_OWNER}")
	private String ownerId;
	private JdbcTemplate jdbcTemplate;
	private ManualUploadListRowMapper manualUploadListRowMapper;

	

	public ManualAddVinRepository(JdbcTemplate jdbcTemplate, ManualUploadListRowMapper manualUploadListRowMapper) {
		this.jdbcTemplate = jdbcTemplate;
		this.manualUploadListRowMapper = manualUploadListRowMapper;
	}

	MapSqlParameterSource createSqlParameterSource(String inputParamKey1, String inputParamVal1, String inputParamKey2,
												   String inputParamVal2) {
		return new MapSqlParameterSource().addValue(inputParamKey1, inputParamVal1).addValue(inputParamKey2,
				inputParamVal2);
	}

	MapSqlParameterSource createSqlParameterSource(String inputParamKey1, String inputParamVal1, String inputParamKey2,
												   String inputParamVal2, String inputParamKey3, String inputParamVal3) {
		return new MapSqlParameterSource().addValue(inputParamKey1, inputParamVal1)
				.addValue(inputParamKey2, inputParamVal2).addValue(inputParamKey3, inputParamVal3);
	}

	SimpleJdbcCall creatSimpleJdbcCall() {
		return new SimpleJdbcCall(jdbcTemplate).withSchemaName(CommonConstants.FSA_SCHEMA_NAME)
				.withProcedureName(CommonConstants.MANUAL_UPLOAD);
	}

	public Map<String, Object> queryManualUpload(String inputParam1, String inputParam2, String inputParam3)
			throws GCAMPException {
		try {
			SimpleJdbcCall simpleJdbcCall = creatSimpleJdbcCall();
			SqlParameterSource sqlParameterSource = createSqlParameterSource(CommonConstants.INPUT_PARM1, inputParam1,
					CommonConstants.INPUT_PARM2, inputParam2, CommonConstants.INPUT_PARM3, inputParam3);
			simpleJdbcCall.returningResultSet("segments", manualUploadListRowMapper);
			simpleJdbcCall.returningResultSet("segmentZero", manualUploadListRowMapper);

			return simpleJdbcCall.execute(sqlParameterSource);
		} catch (Exception e) {
			throw new GCAMPException(CommonConstants.EXCEPTION_OCCURED, e);
		}
	}

	public Map<String, Object> checkVinExistence(String inputParam1, String inputParam2) throws GCAMPException {
		Map<String, Object> manualVinExistence = null;
		try {
			SimpleJdbcCall simpleJdbcCall = creatSimpleJdbcCall();
			SqlParameterSource sqlParameterSource = createSqlParameterSource(CommonConstants.INPUT_PARM1, inputParam1,
					CommonConstants.INPUT_PARM2, inputParam2, CommonConstants.INPUT_PARM3, StringUtils.EMPTY);
			manualVinExistence = simpleJdbcCall.execute(sqlParameterSource);
		} catch (Exception e) {
			throw new GCAMPException(CommonConstants.EXCEPTION_OCCURED + " - checkVinExistence() :", e);
		}
		return manualVinExistence;
	}
}
