package com.ford.gcamp.targeting.reports.batch;

import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.ford.gcamp.targeting.reports.batch.common.ReportGenerationUtil;
import org.apache.commons.lang3.StringUtils;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.stereotype.Component;

import com.ford.gcamp.targeting.common.TargetingUtil;
import com.ford.gcamp.targeting.reports.batch.api.ReportMetaData;
import com.ford.gcamp.targeting.reports.batch.common.ReportCodeConstants;
import com.ford.gcamp.targeting.reports.batch.common.ReportConstants;

import lombok.extern.slf4j.Slf4j;

@Component
@StepScope
@Slf4j
public class TargetingReportPreparedStatementSetter implements PreparedStatementSetter {

	@Value("#{jobParameters['reportMetaData']}")
	private String reportMetaDataString;

	private ReportMetaData reportMetaData;

	private String reportCode;

	@Value("#{stepExecution}")
	private StepExecution stepExecution;

	@Override
	public void setValues(PreparedStatement ps) throws SQLException {

		reportMetaData = ReportGenerationUtil.getReportMetaDataObject(reportMetaDataString);

		String inputParm;
		setReportCode();
		if (ReportCodeConstants.IAD.equalsIgnoreCase(reportCode) || ReportCodeConstants.EXCEPTION_REPORTS.contains(reportCode)) {
			inputParm = setExceptionReportValues();
		} else {
			StringBuilder builder = new StringBuilder();
			builder.append(StringUtils.rightPad(reportMetaData.getBatchCode(), 3, StringUtils.SPACE));
			builder.append(reportMetaData.getReportId());
			builder.append(reportMetaData.getJobQue());
			builder.append(StringUtils.startsWithIgnoreCase(this.reportCode, "W") ? ReportCodeConstants.WERS_SQL_ID
					: ReportCodeConstants.REPORT_CODE_SQL_ID_MAP.get(this.reportCode));
			builder.append(
					StringUtils.startsWithIgnoreCase(this.reportCode, "W") ? this.reportCode.substring(1) : "0001");
			if (ReportConstants.ALL_POPULATION.equalsIgnoreCase(reportMetaData.getSuppCode())) {
				builder.append(reportMetaData.getGlobalFSANum());
			}
			builder.append(TargetingUtil.addSpaceToProc(2));
			inputParm = builder.toString();
			log.info("PARAM ONE to read data for Supplement {} for Report Id: {} and Report Code: {} is {}",
					reportMetaData.getSuppCode(), reportMetaData.getReportId(), this.reportCode, inputParm);
		}
		ps.setString(1, inputParm);
	}

	public void setReportCode() {
		String[] codeDescription = StringUtils.split(this.stepExecution.getStepName(), ":");
		reportCode = codeDescription[0];
	}

	private String setExceptionReportValues() {
		StringBuilder builder = new StringBuilder();
		builder.append(StringUtils.rightPad(reportMetaData.getBatchCode(), 3, StringUtils.SPACE));
		builder.append(reportMetaData.getReportId());
		builder.append(reportMetaData.getRptCode());
		builder.append(reportMetaData.getJobQue());
		builder.append(getSqlId());
		builder.append(TargetingUtil.addSpaceToProc(5));
		log.info("PARAM ONE to SP {} for Report Id: {} and Report Code: {} is {}",
				ReportConstants.EXCEPTION_REPORT_STORE_PROC, reportMetaData.getReportId(), this.reportCode,
				builder.toString());
		return builder.toString();
	}
	
	private String getSqlId() {
		if(StringUtils.length(reportCode) > 3 &&  "B".equalsIgnoreCase(reportCode.substring(reportCode.length() - 1))) {
			return "B";
		}
		return "A";
	}

}
