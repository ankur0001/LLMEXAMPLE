package com.ford.gcamp.targeting.fsacriteria;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ford.gcamp.targeting.common.CommonConstants;
import com.ford.gcamp.targeting.fsacriteria.api.LoadVehAttValDTO;
import com.ford.gcamp.targeting.fsacriteria.api.VehicleAttriGrpReq;

@Component
public class FSADBStoreProcVehAttUtil {
	@Autowired
	private LoadVehAttValDTO vehicleAttributeResponse;

	public LoadVehAttValDTO callStoreProcedure(Map<String, Object> map) {

		List<VehicleAttriGrpReq> listVehAtt = new ArrayList<>();
		@SuppressWarnings("unchecked")
		List<Map<String, Object>> vehicleData = (List<Map<String, Object>>) map.get("#result-set-1");
		if (vehicleData != null) {
			for (Map<String, Object> map1 : vehicleData) {
				VehicleAttriGrpReq vehicleAtt = new VehicleAttriGrpReq();
				vehicleAtt.setVehicleFltrVal((int) map1.get("GCPD02_FILTER_C"));
				vehicleAtt.setVehicleFltrDesc(((String) map1.get("GCPD02_FILTER_X")).trim());

				listVehAtt.add(vehicleAtt);

			}
		}  

		vehicleAttributeResponse.setListVehAtt(listVehAtt);
		if (vehicleAttributeResponse.getListVehAtt() != null) {
			vehicleAttributeResponse.setStatus(CommonConstants.SUCCESS);
			vehicleAttributeResponse.setStatusCode(CommonConstants.SUCCESS_CODE);
		} else {
			vehicleAttributeResponse.setStatus(CommonConstants.FAILURE);
			vehicleAttributeResponse.setStatusCode(CommonConstants.FAILURE_CODE);
		}

		return vehicleAttributeResponse;
	}

}
