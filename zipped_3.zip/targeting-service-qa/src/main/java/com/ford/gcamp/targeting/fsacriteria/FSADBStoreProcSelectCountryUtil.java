package com.ford.gcamp.targeting.fsacriteria;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ford.gcamp.targeting.fsacriteria.api.LoadSelectCounValDTO;
import com.ford.gcamp.targeting.fsacriteria.api.Countries;
import com.ford.gcamp.targeting.fsacriteria.api.HubData;



@Component
public class FSADBStoreProcSelectCountryUtil {
	@Autowired
	private LoadSelectCounValDTO loadSelectCounValResponse;

	public LoadSelectCounValDTO callStoreProcedure(Map<String, Object> map) {
		Map<String, List<HubData>> response = new HashMap<>();
		
		@SuppressWarnings("unchecked")
		List<Map<String, Object>> data = (List<Map<String, Object>>) map.get("#result-set-1");
		for (Map<String, Object> map1 : data) {
			String hubCode = (String) map1.get("GCPE10_HUB_C");
			if(response.containsKey(hubCode)) {
				List<HubData> hubList = response.get(hubCode);
				HubData hubDataResponse = new HubData();
				List<Countries> children = new ArrayList<>();
				Countries countries = new Countries();
				countries.setCountryCode((String) map1.get("COUNTRY_ISO3_C"));
				countries.setLabel(((String) map1.get("COUNTRY_NAME_X")).toUpperCase());
				children.add(countries);
				hubDataResponse.setChildren(children);
				hubList.add(hubDataResponse);
			} else {
				List<HubData> hubList = new ArrayList<>();
				HubData hubDataResponse = new HubData();
				hubDataResponse.setHubCode((String) map1.get("GCPE10_HUB_C"));
				hubDataResponse.setLabel(((String) map1.get("GCPE10_HUB_DESC_X")).toUpperCase());
				hubDataResponse.setRoiCode((String) map1.get("GCPE11_ROI_C"));
				hubDataResponse.setRoiDesc((String) map1.get("GCPE11_ROI_DESC_X"));
				List<Countries> children = new ArrayList<>();
				Countries countries = new Countries();
				countries.setCountryCode((String) map1.get("COUNTRY_ISO3_C"));
				countries.setLabel((String) map1.get("COUNTRY_NAME_X"));
				children.add(countries);
				hubDataResponse.setChildren(children);
				hubList.add(hubDataResponse);
				response.put(hubCode, hubList);
			}
			
		}
		HubData hubDataNew;
		List<HubData> hubList;
		List<HubData> finalhubList = new ArrayList<>();
		for (Map.Entry<String,List<HubData>> mapElement : response.entrySet()) { 
            hubDataNew = new HubData();
            List<Countries> children = new ArrayList<>();
            // Add some bonus marks 
            // to all the students and print it 
            hubList = mapElement.getValue(); 
  
            for(HubData hubdata:hubList){
            	if(hubdata.getHubCode()!=null && hubdata.getLabel()!=null){
            		hubDataNew.setHubCode(hubdata.getHubCode());
            		hubDataNew.setLabel(hubdata.getLabel());
            		hubDataNew.setRoiCode(hubdata.getRoiCode());
            		hubDataNew.setRoiDesc(hubdata.getRoiDesc());
            	}
            	for(Countries countries:hubdata.getChildren()){
            		Countries countriesnew = new Countries();
            		countriesnew.setCountryCode(countries.getCountryCode());
            		countriesnew.setLabel(countries.getLabel());
    				children.add(countriesnew);
            	}
            	
            }
            hubDataNew.setChildren(children);
            finalhubList.add(hubDataNew);
        } 
		
		loadSelectCounValResponse.setListHubData(finalhubList);
		return loadSelectCounValResponse;
	}

	

}
