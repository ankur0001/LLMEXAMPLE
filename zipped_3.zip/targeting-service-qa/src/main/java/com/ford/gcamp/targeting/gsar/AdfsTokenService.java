package com.ford.gcamp.targeting.gsar;

import java.util.LinkedHashMap;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.hc.client5.http.classic.HttpClient;
import org.apache.hc.client5.http.impl.classic.HttpClientBuilder;
import org.apache.hc.client5.http.impl.classic.HttpClients;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import com.ford.gcamp.targeting.gsar.api.StopShipRepair;


@Service
public class AdfsTokenService {

	private static final String APPLICATION_URLENCODED = "application/x-www-form-urlencoded";
	private static final String APPLICATION_JSON = "application/json";
	public static final String GRANT_TYPE = "grant_type";
	public static final String CLIENT_ID = "client_id";
	public static final String CLIENT_SRT = "client_secret";
	public static final String RESOURCE = "resource";
	public static final String CLIENT_CRDNTILS = "client_credentials";

	@Value("${gsar.adfs.clientId}")
	private String adfsClientId;

	@Value("${GSAR_ADFS_CLIENT_SECRET}")
	private String adfsclientsrt;

	@Value("${spring.security.oauth2.client.provider.client-adfs4.token-uri}")
	private String adfsTokenURL;

	@Value("${gsar.adfs.resourceurn}")
	private String adfsResourceUrn;

	public String getAccessToken() {
		HttpHeaders httpHeaders = getHttpHeaders(APPLICATION_JSON, APPLICATION_URLENCODED);
		HttpEntity<Object> requestEntity = new HttpEntity<>(getAccessTokenRequest(), httpHeaders);
		RestTemplate restTemplate = new RestTemplate();
		ResponseEntity<Object> responseEntity = restTemplate.exchange(adfsTokenURL, HttpMethod.POST, requestEntity,
				Object.class);
		LinkedHashMap<Object,String> responseBody = (LinkedHashMap) responseEntity.getBody();
		if (responseBody != null && !responseBody.isEmpty()) {
			return  responseBody.get("access_token");
		} else {
			return StringUtils.EMPTY;
		}

	}

	private MultiValueMap<String, String> getAccessTokenRequest() {
		MultiValueMap<String, String> map = new LinkedMultiValueMap<>();
		map.add(GRANT_TYPE, CLIENT_CRDNTILS);
		map.add(CLIENT_ID, adfsClientId);
		map.add(CLIENT_SRT, adfsclientsrt);
		map.add(RESOURCE, adfsResourceUrn);
		return map;
	}

	public HttpHeaders getHttpHeaders(String acceptHeader, String contentTypeHeader) {
		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.add(HttpHeaders.ACCEPT, acceptHeader);
		httpHeaders.add(HttpHeaders.CONTENT_TYPE, contentTypeHeader);
		return httpHeaders;
	}

	public RestTemplate createRestTemplate() {
		RestTemplate restTemplateWithProxy = new RestTemplate();
		HttpClientBuilder clientBuilder = HttpClients.custom();

		clientBuilder.useSystemProperties();

		HttpClient client = clientBuilder.build();

		HttpComponentsClientHttpRequestFactory factory = new HttpComponentsClientHttpRequestFactory();
		factory.setHttpClient(client);

		restTemplateWithProxy.setRequestFactory(factory);
		return restTemplateWithProxy;

	}

	public ResponseEntity<List<StopShipRepair>> invokeGsarAPI(String gsarRequestJson, String gsarApi) {
		RestTemplate restTemplateWithProxy = createRestTemplate();
		HttpEntity<Object> requestEntity = new HttpEntity<>(gsarRequestJson, addHeaders());
		return restTemplateWithProxy.exchange(gsarApi, HttpMethod.GET, requestEntity, new ParameterizedTypeReference<List<StopShipRepair>>() {
		});
	}

	private HttpHeaders addHeaders() {
		HttpHeaders headers = new HttpHeaders();
		headers.add(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
		headers.add(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON_VALUE);
		String adfsToken = getAccessToken();
		String accessToken = "Bearer" + StringUtils.SPACE + adfsToken;
		headers.add(HttpHeaders.AUTHORIZATION, accessToken);
		return headers;
	}


	public void setAdfsTokenURL(String adfsTokenURL) {
		this.adfsTokenURL = adfsTokenURL;
	}

}
