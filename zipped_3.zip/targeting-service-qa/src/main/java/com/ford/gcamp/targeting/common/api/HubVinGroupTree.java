package com.ford.gcamp.targeting.common.api;

import java.util.List;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class HubVinGroupTree {
	@Size(min = 0, max = 2)
	@Pattern(regexp = "^[a-zA-Z\\*\\s]*$")
	@Schema(example = "NA", description = "Hub code")
	private String hubCode;

	@Pattern(regexp = "^[a-zA-Z\\s&]*$")
	@Size(min=0, max =30)
	@Schema(example = "FORD NORTH AMERICA", description = "Hub code")
	private String label;

	@Size(min = 0, max = 250, message = "Children List")
	private List<@Valid VinGroup> children;
}
