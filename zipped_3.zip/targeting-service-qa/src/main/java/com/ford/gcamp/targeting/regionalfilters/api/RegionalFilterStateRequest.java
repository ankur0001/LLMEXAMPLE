package com.ford.gcamp.targeting.regionalfilters.api;

import java.util.List;

import com.ford.gcamp.targeting.common.api.GenericLookup;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Builder
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class RegionalFilterStateRequest {
	@Size(min = 0, max = 500, message = "Countries")
	private List<@Valid GenericLookup> countries;
}