package com.ford.gcamp.targeting.gsar;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import com.ford.gcamp.targeting.config.WebClientAdConfiguration;
import com.ford.gcamp.targeting.gridgcamp.gcamp.IncludeExcludeRepository;
import com.ford.gcamp.targeting.gsar.api.*;
import com.ford.gcamp.targeting.properties.ConfigProperties;
import com.ford.gcamp.targeting.vin.VinListsService;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.joda.time.LocalDate;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.MultipartBodyBuilder;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.stereotype.Service;

import com.ford.gcamp.targeting.common.BatchTrigger;
import com.ford.gcamp.targeting.common.CommonConstants;
import com.ford.gcamp.targeting.common.FTPSession;
import com.ford.gcamp.targeting.common.TargetingUtil;
import com.ford.gcamp.targeting.common.api.BatchJobData;
import com.ford.gcamp.targeting.common.api.CommonResponse;
import com.ford.gcamp.targeting.core.exception.GCAMPException;
import com.ford.gcamp.targeting.gsar.entity.GcampSnapEntity;
import com.ford.gcamp.targeting.logging.LogExecutionTime;
import com.ford.gcamp.targeting.prelaunchreports.api.ReportsResponse;
import com.ford.gcamp.targeting.vin.FSAVinListsUtil;
import com.ford.gcamp.targeting.vin.VinListsRepository;
import com.ford.gcamp.targeting.vin.api.VinListResponseDTO;

import lombok.extern.slf4j.Slf4j;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

@Service
@Slf4j
public class GsarService {
    private VinListsRepository vinListsRepository;
    private FSAVinListsUtil vinListsUtil;

    private GsarMapper gsarMapper;
    private GcampReportRepo gcampReportRepo;
    private WebClient webClient;
    private WebClientAdConfiguration webClientAdConfiguration;
    private ConfigProperties configProperties;
    private VinListsService vinListService;

    private IncludeExcludeRepository includeExcludeRepository;
    @Autowired
    private FTPSession ftp;
    @Autowired
    private BatchJobData job;
    @Autowired
    private BatchTrigger trigger;
    @Autowired
    private AdfsTokenService adfsTokenService;
    @Value("${gsar.report.size.limit}")
    private int gsarReportSize;
    @Value("${gsar.stopship.endpoint}")
    private String gsarStopShipEndpoint;
    @Value("${gsar.stopship.ftp.dataset}")
    private String gsarStopShipFtpDataSet;

    @Value("${spring.security.oauth2.client.registration.client-fsaservice-azure-ad.scope}")
    private  String scope;

    public static final String FSA = "fsa";

    public static final String GSAR = "GSAR_";
    public static final String ERROR_WHILE_UPLOAD_VIN = "Error while add vinlist and Upload file in GCS in Targeting";


    @Autowired
    public GsarService(GsarMapper gsarMapper,
            FSAVinListsUtil vinListsUtil, VinListsRepository vinListsRepository,
            GcampReportRepo gcampReportRepo, @Qualifier("fsaServiceWebClient") WebClient webClient, WebClientAdConfiguration webClientAdConfiguration,
            ConfigProperties configProperties, VinListsService vinListService, IncludeExcludeRepository includeExcludeRepository) {
        this.gsarMapper = gsarMapper;
        this.vinListsUtil = vinListsUtil;
        this.vinListsRepository = vinListsRepository;
        this.gcampReportRepo = gcampReportRepo;
        this.webClient = webClient;
        this.webClientAdConfiguration = webClientAdConfiguration;
        this.configProperties = configProperties;
        this.vinListService = vinListService;
        this.includeExcludeRepository = includeExcludeRepository;
    }

    public GsarSearchResponse searchGsarReports(GsarSearchRequest gsarSearchRequest) {
        // GsarRepository dependency removed; returning empty/default response
        return gsarMapper.parseGsarDataResponseMap(List.of(), List.of());
    }

    @LogExecutionTime
    public CommonResponse fetchGsarReports(GsarSearchRequest gsarSearchRequest) {
        // GsarRepository dependency removed; returning default CommonResponse
        CommonResponse commonResponse = new CommonResponse();
        commonResponse.setStatus(CommonConstants.FAILURE);
        commonResponse.setStatusCode(CommonConstants.FAILURE_CODE);
        commonResponse.setStatusDescription("GSAR repository not available");
        return commonResponse;
    }

    public ViewReportsResponse viewReports(String userhub) {
        List<ViewReports> viewReports = gcampReportRepo.getGcampReport(userhub);
        return gsarMapper.parseViewReportsResponseMap(viewReports);
    }

    public int deletePurgedReports() {
        return gcampReportRepo.deletePurgeGcampReport();
    }

    public ByteArrayResource downloadVinDetails(Integer resultId, Long uniqueId, String userhub) {
        ReportsResponse reportData = gcampReportRepo.getDownloadVinDetails(resultId, uniqueId, userhub);
        return new ByteArrayResource(reportData.getByteArry());
    }

    public CommonResponse deleteVinGroup(Integer resultId, Long uniqueId, String userhub) {
        int deleteResponse = gcampReportRepo.deleteGcampReport(resultId, uniqueId, userhub);
        return setCommonResponse(deleteResponse, "Deletion failed", "Data Deleted Successfully");
    }

    public CommonResponse uploadGsarFile(GsarFileUploadRequest gsarFileUploadRequest) throws GCAMPException {
        CommonResponse response = new CommonResponse();
        String fileName;
        ByteArrayResource byteArray = downloadVinDetails(Integer.valueOf(gsarFileUploadRequest.getResultId()),
                Long.valueOf(gsarFileUploadRequest.getUniqueId()), gsarFileUploadRequest.getUserHub());
        MultipartFile gsarVinMultipart ;
        if (!configProperties.isParallelProcessingFlag()){
            //GSAR File name upload format - Folder ID will be appended in FSA Service (GSAR File name sample - 25602939_001.txt)
            fileName = gsarFileUploadRequest.getUniqueId()+gsarFileUploadRequest.getResultId();
            gsarVinMultipart  = new MockMultipartFile("file", fileName, ".txt", byteArray.getByteArray());
            log.info("Parallel processing flag is enabled for add gsar vin list and upload file on GCS, request : {}", gsarFileUploadRequest);
            // Convert ByteArrayResource to byte array
            //setFilePath - to save the file name in DB - sample file name - GSAR_25603222.txt - in FSA Service save GCPD08_FLDR_PATH_X in SGCPD08_INCL_EXCL
            gsarFileUploadRequest.setFilePath(GSAR + gsarFileUploadRequest.getUniqueId().concat(gsarFileUploadRequest.getResultId())+".txt");
            Optional<IncludeExcludeEntity> existingEntry = includeExcludeRepository.findTopByIncludeExcludeIdGlobalFsaNumberAndFolderPath(
                    gsarFileUploadRequest.getFsaNumber(),
                    gsarFileUploadRequest.getFilePath()
            );
            //if already entry created based on GSAR ID, throws GSAR_DUPLICATE_FSA_DESC - check is to confirm one GSAR ID mapped only once for an FSA
            if(existingEntry.isPresent()){
                log.info("Entry already present for the FSA with same GSAR ID.");
                response.setStatus(CommonConstants.FAILURE);
                response.setStatusCode(CommonConstants.FAILURE_CODE);
                response.setStatusDescription(CommonConstants.GSAR_DUPLICATE_FSA_DESC);
            } else {
                log.info("New entry for GSAR ID.");
                response = callFsaServiceAddVinList(gsarFileUploadRequest, gsarVinMultipart);
            }
        }else {
            String batchCode = getBatchCode(gsarFileUploadRequest.getFileType());
            log.info("store proc and batch detials for add::{}", batchCode);
            String param1 = gsarMapper.addInputParam1(gsarFileUploadRequest);
            String param2 = gsarMapper.addInputParam2(gsarFileUploadRequest, batchCode);
            log.info("inout params ::{},{}", param1, param2);
            // Step1: Insert data into database
            Map<String, Object> addVinResponse = gcampReportRepo.uploadGsarFile(param1, param2);
            String errorParam = (String) addVinResponse.get(CommonConstants.ERROR_PARM);
            log.info("errorParam response ,{}", errorParam);
            response = TargetingUtil.getCommonResponse(errorParam);

            if (response.getStatusCode().equals(CommonConstants.FAILURE_CODE)
                    && response.getStatusDescription().contains(CommonConstants.GSAR_DUPLICATE_FSA_CODE)) {
                response.setStatusCode(CommonConstants.FAILURE_CODE_401);
                response.setStatusDescription(CommonConstants.GSAR_DUPLICATE_FSA_DESC);
            } else if (response.getStatus().equals(CommonConstants.SUCCESS)) {
                String outParam3 = addVinResponse.get("OUTPUT_PARM3").toString();
                log.info("OUTPUT_PARM3 {}", outParam3);
                String jobName = outParam3.substring(45, 53);
                String jobId = outParam3.substring(53, 63);
                String folderId = outParam3.substring(63, 66);
                String dataSet = "/ftadv:P=UNIX/__/" + outParam3.substring(0, 45).trim();
                log.info("output param3 {}, jobName {}, dateset {}", outParam3, jobName, dataSet);

                // Step2 : GCS Upload
                fileName = gsarFileUploadRequest.getUniqueId() + gsarFileUploadRequest.getResultId() + "_" + folderId
                        + ".txt";
                log.info("fileName::{} ", fileName);
                gsarVinMultipart  = new MockMultipartFile("file", fileName, ".txt", byteArray.getByteArray());
                vinListService.uploadFileToGcs(fileName, gsarVinMultipart);
                // Step3 : FTP upload
                try (InputStream inputStream = IOUtils.toInputStream(
                        new String(byteArray.getByteArray(), StandardCharsets.UTF_8), StandardCharsets.UTF_8.name())) {
                    ftp.uploadFile("", dataSet, inputStream);
                } catch (IOException e) {
                    throw new GCAMPException(CommonConstants.FILE_UPLOAD_EXCEPTION, e);
                }

                job.setBatchCode(batchCode);
                job.setCdsId(gsarFileUploadRequest.getCdsId());
                job.setGlobalFSANo(Integer.parseInt(gsarFileUploadRequest.getFsaNumber()));
                job.setHubCode(TargetingUtil.addSpaceToProc(2));
                job.setSupplement(gsarFileUploadRequest.getPopulation());
                job.setParameters(TargetingUtil.addZerosToProc(3));
                job.setJobName(jobName);
                trigger.submitJob(job);
                log.info("Triggering Vin Batch - End {}", jobId);
                response.setStatusDescription(
                        CommonConstants.JOB_COMPLETION_MSG + jobId + CommonConstants.BATCH_CODE_MSG + batchCode + ".");
                gcampReportRepo.updateGcampReport(gsarFileUploadRequest);
                response.setStatusDescription(CommonConstants.GSAR_UPLOAD_SUCCESS);
            }
        }
        return response;
    }

    public CommonResponse callFsaServiceAddVinList(GsarFileUploadRequest gsarFileUploadRequest, MultipartFile gsarVinMultipart){
        CommonResponse response = new CommonResponse();
        String resp = addGsarVinList(gsarFileUploadRequest, gsarVinMultipart);
        if(resp != null && !resp.isEmpty() && resp.contains("Vin List Uploaded Successfully")) {
            gcampReportRepo.updateGcampReport(gsarFileUploadRequest);
            response.setStatus(CommonConstants.SUCCESS);
            response.setStatusCode(CommonConstants.SUCCESS_CODE);
            response.setStatusDescription(resp);
            return response;
        } else {
            response.setStatus(CommonConstants.FAILURE);
            response.setStatusCode(CommonConstants.FAILURE_CODE);
            response.setStatusDescription(resp);
            return response;
        }
    }

    public String getBatchCode(String fileType){
        String batchCode = StringUtils.EMPTY;
        if (CommonConstants.FLAG_F.equalsIgnoreCase(fileType)) {
            batchCode = "005";
        } else if (CommonConstants.FLAG_I.equalsIgnoreCase(fileType)
                || CommonConstants.FLAG_E.equalsIgnoreCase(fileType)) {
            batchCode = "007";
        }
        return batchCode;
    }

    public String addGsarVinList(GsarFileUploadRequest gsarFileUploadRequest, MultipartFile vinFile) {
        gsarFileUploadRequest.setOtaIndicator("N");
        gsarFileUploadRequest.setFhmIndicator("N");
        String responseString;
        try {
            MultipartBodyBuilder builder = new MultipartBodyBuilder();
            builder.part("fsaCriteriaVdm", gsarFileUploadRequest);
            builder.part("vinFile", vinFile.getResource());

            responseString = webClient.post()
                    .uri("/api/v1/vinList/add")
                    .contentType(MediaType.MULTIPART_FORM_DATA)
                    .header("Authorization", "Bearer " + webClientAdConfiguration.getAccessToken(scope, FSA))
                    .body(BodyInserters.fromMultipartData(builder.build()))
                    .exchangeToMono(clientResponse -> {
                        if (clientResponse.statusCode().isError()) {
                            return clientResponse.bodyToMono(String.class)
                                    .flatMap(errorMessage -> {
                                        JSONObject json = new JSONObject(errorMessage);
                                        String messages = json.getJSONObject("error").getJSONArray("messages").join(", ");
                                        log.error("Error while add gsar vin list. FSA Service returned status code: {}, error message: {}",
                                                clientResponse.statusCode(), messages);
                                        return Mono.just(messages.replace("\"", ""));
                                    });
                        } else {
                            return clientResponse.bodyToMono(String.class);
                        }
                    })
                    .block();
            log.info("Response from FSA Service to Add the GSAR Vin List : {}", responseString);
        } catch (Exception e) {
            log.error(ERROR_WHILE_UPLOAD_VIN, e);
            return ERROR_WHILE_UPLOAD_VIN;
        }
        return responseString;
    }

    public VinListResponseDTO getGsarHistory(FscCriteriaRequestForGsar fscCriteriaRequest) {
        String fsaGoParm = gsarMapper.fsaGoSerialParamForGsar(fscCriteriaRequest);
        String inPutParm = gsarMapper.getSerialListParamHistory(fscCriteriaRequest);
        log.info(CommonConstants.PARAM_LENGTH_TEXT, fsaGoParm.length(), inPutParm.length());
        Map<String, Object> vinListListResponse = vinListsRepository.getVinLists(fsaGoParm, inPutParm);
        log.info(CommonConstants.SP_RESPONSE_TEXT, vinListListResponse);
        return vinListsUtil.getVinLists(vinListListResponse);
    }

    public void getGsarStopShipRepairDetails() throws GCAMPException {
        String todayDate = LocalDate.now().minusDays(1).toString();
        getGsarStopShipRepairDetails(todayDate, todayDate);
    }

    public StopShipRepairResponse getGsarStopShipRepairDetails(String startDate, String endDate) throws GCAMPException {
        StringBuilder endPointUrl = new StringBuilder();
        endPointUrl.append(gsarStopShipEndpoint);
        endPointUrl.append("?startDate=");
        endPointUrl.append(startDate);
        endPointUrl.append("&endDate=");
        endPointUrl.append(endDate);
        ResponseEntity<List<StopShipRepair>> responseEntity = adfsTokenService.invokeGsarAPI(StringUtils.EMPTY, endPointUrl.toString());
        //Upload VIN and Status to MF for Force Complete
        uploadStopShipRepairDetails(responseEntity.getBody());
        StopShipRepairResponse stopShipRepairResponse = new StopShipRepairResponse();
        TargetingUtil.getResponseStatus(null, stopShipRepairResponse);
        stopShipRepairResponse.setStopShipRepairDetails(responseEntity.getBody());
        return stopShipRepairResponse;
    }

    private void uploadStopShipRepairDetails(List<StopShipRepair> stopShipRepairDetails) throws GCAMPException {
        if (CollectionUtils.isNotEmpty(stopShipRepairDetails)) {
            StringBuilder stopShipRepairs = new StringBuilder();
            stopShipRepairDetails.forEach(stopShipRepair -> stopShipRepairs
                    .append(TargetingUtil.fillRemainingString(stopShipRepair.getFsaId(), 10, StringUtils.SPACE))
                    .append(TargetingUtil.fillRemainingString(stopShipRepair.getVin(), 17, StringUtils.SPACE))
                    .append(GsarConstants.STOP_SHIP_REPAIR_STATUS.get(stopShipRepair.getStatus()))
                    .append(TargetingUtil.fillRemainingString(stopShipRepair.getStopShipCampId(), 10,
                            StringUtils.SPACE))
                    .append(TargetingUtil.fillRemainingString(stopShipRepair.getStopShipNum(), 15, StringUtils.SPACE))
                    .append(StringUtils.LF));

            try (InputStream inputStream = new ByteArrayInputStream(
                    stopShipRepairs.toString().getBytes(StandardCharsets.UTF_8))) {
                ftp.uploadFile(StringUtils.EMPTY, GsarConstants.MF_FTP_CONFIG + gsarStopShipFtpDataSet, inputStream);
                log.info("GSAR Stop Ship Repair VIN with Status uploaded to MF successfully. Total VINs uploaded: {}", stopShipRepairDetails.size());
            } catch (Exception e) {
                throw new GCAMPException("Error in uploading Stop Ship Repair Details to Mainframe: ", e);
            }
        }
    }

    private CommonResponse setCommonResponse(int response, String failureDescription, String successDescription) {
        CommonResponse commonResponse = new CommonResponse();
        if (response > 0) {
            commonResponse.setStatus(CommonConstants.SUCCESS);
            commonResponse.setStatusCode(CommonConstants.SUCCESS_CODE);
            commonResponse.setStatusDescription(successDescription);
        } else {
            commonResponse.setStatus(CommonConstants.FAILURE);
            commonResponse.setStatusCode(CommonConstants.FAILURE_CODE);
            commonResponse.setStatusDescription(failureDescription);
        }
        return commonResponse;
    }

}
