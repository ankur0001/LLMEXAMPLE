package com.ford.gcamp.targeting.multiauth;

import lombok.*;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.util.StringUtils;

import java.util.Collections;
import java.util.List;

/**
 * Configuration properties for the decode multi auth JwtDecoder
 */
@ConfigurationProperties(prefix = "decode.multi-auth")
@Getter
@Setter
public class MultiAuthConfigurationProperties {
    /**
     * Configuration for ADFS
     */
    private ADFS adfs;
    /**
     * Configuration for EntraID
     */
    private EntraID entraId;
    /**
     * Whether to enable the Multiauth JWT Decoder
     */
    private boolean enabled;

    /**
     * Configuration values for ADFS
     */
    @Getter
    @Setter
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class ADFS {
        /**
         * ADFS environment to use, either QA or PROD.
         */
        @Builder.Default
        private ADFSEnvironment env = ADFSEnvironment.QA;

        /**
         * List of allowed audiences for ADFS tokens.
         */
        @Builder.Default
        private List<String> audiences = Collections.emptyList();

        /**
         * Roles to add to granted authorities when receiving an ADFS token.
         * Should be set to match roles expected by the application's security filter, and configured for EntraID in the API Catalog.
         */
        @Builder.Default
        private List<String> roleOverrides = Collections.emptyList();

        /**
         * Scopes to add to granted authorities when receiving an ADFS token.
         * Should be set to match scopes expected by the application's security filter, and configured for EntraID in the API Catalog or Azure Portal.
         * This is only necessary if the application uses scope-based security, generally for browser clients.
         */
        @Builder.Default
        private List<String> scopeOverrides = Collections.emptyList();

        /**
         * Issuer URI override for ADFS. If not set, will use default based on environment.
         */
        private String issuerUri;

        /**
         * JWK Set URI override for ADFS. If not set, will use default based on environment.
         */
        private String jwkSetUri;

        /**
         * Get calculated issuer URI.
         * If issuer URI is unset, provides the correct issuer URI for the configured environment
         *
         * @return Issuer URI for ADFS
         */
        public String getIssuerUri() {
            if (StringUtils.hasText(issuerUri)) {
                return this.issuerUri;
            }
            return switch (this.env) {
                case DEV -> "https://corpqa.sts.ford.com/adfs/services/trust";
                case QA -> "https://corpqa.sts.ford.com/adfs/services/trust";
                case PROD -> "https://corp.sts.ford.com/adfs/services/trust";
            };
        }

        /**
         * Get calculated JWK set URI.
         * If JWK set URI is unset, provides the correct JWK set URI for the configured environment
         *
         * @return JWK set URI for ADFS
         */
        public String getJwkSetUri() {
            if (StringUtils.hasText(jwkSetUri)) {
                return this.jwkSetUri;
            }
            return switch (this.env) {
                case DEV -> "https://corpqa.sts.ford.com/adfs/discovery/keys";
                case QA -> "https://corpqa.sts.ford.com/adfs/discovery/keys";
                case PROD -> "https://corp.sts.ford.com/adfs/discovery/keys";
            };
        }
    }

    /**
     * Configuration values for Entra ID
     */
    @Getter
    @Setter
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class EntraID {
        /**
         * Entra ID issuer version to use, either V1 or V2. For any APIs with roles configured in the API Catalog, use V2.
         */
        @Builder.Default
        private EntraIDIssuerVersion version = EntraIDIssuerVersion.V2;

        /**
         * List of allowed audiences for Entra ID tokens. For V2 tokens, this will be the bare Application (client) ID.
         * For V1 tokens, this will be the Application ID URI, typically in the format api://{client-id-guid}.
         */
        @Builder.Default
        private List<String> audiences = Collections.emptyList();

        /**
         * Entra tenant ID. Default is Ford's "azureford" tenant ID.
         */
        @Builder.Default
        private String tenantId = "c990bb7a-51f4-439b-bd36-9c07fb1041c0";

        /**
         * Proxy host to use when calling Entra ID APIs. Default is Ford GCP proxy. Set to internet.ford.com if running locally.
         */
        @Builder.Default
        private String proxyHost = "internet.gcp.ford.com";

        /**
         * Proxy port to use when calling Entra ID APIs.
         */
        @Builder.Default
        private Integer proxyPort = 83;

        /**
         * Issuer URI override for ADFS. If not set, will use default based on tenant and issuer version.
         */
        private String issuerUri;

        /**
         * JWK Set URI override for ADFS. If not set, will use default based on tenant.
         */
        private String jwkSetUri;

        /**
         * Get calculated issuer URI.
         * If issuer URI is unset, provides the correct issuer URI for the configured tenant and issuer version
         * @return Issuer URI for Entra ID
         */
        public String getIssuerUri() {
            if (StringUtils.hasText(issuerUri)) {
                return this.issuerUri;
            }
            return switch (this.version) {
                case V1 -> "https://sts.windows.net/" + this.tenantId + "/";
                case V2 -> "https://login.microsoftonline.com/" + this.tenantId + "/v2.0";
            };
        }

        /**
         * Get calculated JWK set URI.
         * If JWK set URI is unset, provides the correct JWK set URI for the configured tenant
         * @return JWK set URI for Entra ID
         */
        public String getJwkSetUri() {
            if (StringUtils.hasText(jwkSetUri)) {
                return this.jwkSetUri;
            }
            return "https://login.microsoftonline.com/" + this.tenantId + "/discovery/v2.0/keys";
        }
    }

    /**
     * On-prem ADFS environment
     */
    public enum ADFSEnvironment {
        /**
         * QA ADFS environment
         */
        DEV,
        /**
         * QA ADFS environment
         */
        QA,
        /**
         * Prod ADFS environment
         */
        PROD,
    }

    /**
     * Issuer version for Entra ID.
     * For Entra ID app registrations configured through the API Catalog, this will always be V2.
     */
    public enum EntraIDIssuerVersion {
        /**
         * V1 issuer (i.e. sts.windows.net)
         */
        V1,
        /**
         * V2 issuer (i.e. login.microsoftonline.com)
         */
        V2,
    }
}
