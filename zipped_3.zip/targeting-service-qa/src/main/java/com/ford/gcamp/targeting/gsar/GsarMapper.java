package com.ford.gcamp.targeting.gsar;

import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import com.ford.gcamp.targeting.gsar.api.*;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import com.ford.gcamp.targeting.common.CommonConstants;
import com.ford.gcamp.targeting.common.TargetingUtil;
import com.ford.gcamp.targeting.common.api.FscCriteriaRequest;
import com.ford.gcamp.targeting.gsar.entity.GcampDataEntity;
import com.ford.gcamp.targeting.gsar.entity.GcampSnapEntity;

import lombok.extern.slf4j.Slf4j;

@Component 
@Slf4j
public class GsarMapper {
	public GsarSearchResponse parseGsarDataResponseMap(List<GcampSnapEntity> response,
			List<ViewReports> gcampData) {
		GsarSearchResponse gsarSearchResponse = new GsarSearchResponse();
		List<GsarReports> gsarReports = new ArrayList<>();
		List<Integer> gcampReportIds = getGsarFetchStatus(gcampData);
		if (CollectionUtils.isNotEmpty(response)) { 
			for (GcampSnapEntity gcampSnapEntity : response) {
				GsarReports gsarReport = new GsarReports();
				gsarReport.setUniqueId(gcampSnapEntity.getUniqueId());
				gsarReport.setUserId(String.valueOf(gcampSnapEntity.getUserId()));
				gsarReport.setResultId(String.valueOf(gcampSnapEntity.getResultId()));
				gsarReport.setResId(String.valueOf(gcampSnapEntity.getResId()))	;
				gsarReport.setDescription(String.valueOf(gcampSnapEntity.getReqName()));
				gsarReport.setOption(String.valueOf(gcampSnapEntity.getRptSel()));
				gsarReport.setCriteria(String.valueOf(gcampSnapEntity.getRptCrt()));
				gsarReport.setCount(String.valueOf(gcampSnapEntity.getRowCount()));
				gsarReport.setRunDate(gcampSnapEntity.getRunDate());
				gsarReport.setFetchStatus(gcampReportIds.contains(gcampSnapEntity.getResultId()));
				gsarReports.add(gsarReport);
			}
		}
		gsarSearchResponse.setGsarReports(gsarReports);
		gsarSearchResponse.setStatus(CommonConstants.SUCCESS);
		gsarSearchResponse.setStatusCode(CommonConstants.SUCCESS_CODE);
		gsarSearchResponse.setStatusDescription(CommonConstants.SUCCESS_DESCRIPTION);
		return gsarSearchResponse;
	}

	public List<Integer> getGsarFetchStatus(List<ViewReports> gcampData) {
		List<Integer> gcampResultId = new ArrayList<>();
		if (CollectionUtils.isNotEmpty(gcampData)) {
			gcampResultId = gcampData.stream().map(ViewReports:: getResultId).collect(Collectors.toList());
		}
		return gcampResultId;
	}

	public GcampDataResponse parseGcampDataResponseMap(List<GcampDataEntity> resposne) {
		GcampDataResponse gcampDataResponse = null;
		List<VinList> vinList = new ArrayList<>();
		VinList vins;
		if (CollectionUtils.isNotEmpty(resposne)) {
			for (GcampDataEntity map : resposne) {
				vins = VinList.builder().vinCode(String.valueOf(map.getVinGrpCode())).build();
				vinList.add(vins);
				gcampDataResponse = GcampDataResponse.builder().modelYear(String.valueOf(map.getModelYear()))
						.reportId(String.valueOf(map.getResultId())).vinList(vinList).build();
			}
		}
		return gcampDataResponse;
	}

	public ViewReportsResponse parseViewReportsResponseMap(List<ViewReports> viewReports) {
		ViewReportsResponse viewReportsResponse = new ViewReportsResponse();
		
		if (CollectionUtils.isNotEmpty(viewReports)) { 
			for (ViewReports report : viewReports) {
				if(report.getCreatedDate() != null) {
					long daysRemainingToPurge = checkPurgingData(report.getUploadFlag(), report.getCreatedDate());
					String rptOpt = getRptOptDesc(report.getOption());
					if (daysRemainingToPurge >=0) {
						String purgeDate = LocalDate.now().plusDays(daysRemainingToPurge).format(DateTimeFormatter.ofPattern("dd/MMM/yyyy"));
						report.setWarningMessage("This report is going to delete from system on " + purgeDate
								+ " since it's not been used against any FSA");
						report.setShowWarning(true);
					} else {
						report.setWarningMessage(StringUtils.EMPTY);
						report.setShowWarning(false);
					}
					report.setRunDate(report.getRunDate());
					report.setOption(rptOpt);
				}
				

			}
		}
		viewReportsResponse.setViewReports(viewReports);
		viewReportsResponse.setStatus(CommonConstants.SUCCESS);
		viewReportsResponse.setStatusCode(CommonConstants.SUCCESS_CODE);
		viewReportsResponse.setStatusDescription(CommonConstants.SUCCESS_DESCRIPTION);
		return viewReportsResponse;
	}
	
	public String getReportOptionCode(GcampSnapEntity gsarReports) {
		return getRptOptCode(gsarReports);
	}
	
	public String addInputParam1(GsarFileUploadRequest gsarFileUploadRequest) {
		StringBuilder fsaGoParm1 = new StringBuilder();
		String fsaType = gsarFileUploadRequest.getFsaType();
		String fsaNumber = gsarFileUploadRequest.getFsaNumber();
		if (("G").equals(fsaType)) {
			fsaGoParm1.append(fsaType);
			fsaGoParm1.append(String.format("%08d", Integer.parseInt(fsaNumber)));
			fsaGoParm1.append(TargetingUtil.addSpaceToProc(9));
		} else if (("L").equals(fsaType)) {
			fsaGoParm1.append(fsaType);
			fsaGoParm1.append(StringUtils.rightPad(fsaNumber.toUpperCase(), 10, StringUtils.SPACE));
			fsaGoParm1.append(TargetingUtil.addSpaceToProc(9));
		}
		return fsaGoParm1.toString();
	}

	public String addInputParam2(GsarFileUploadRequest gsarFileUploadRequest, String batchCode) {
		StringBuilder addParam2 = new StringBuilder();
		String labelCharge;
		String vinGrpF=StringUtils.EMPTY;
		String ingProdDate=StringUtils.EMPTY;
		String ingCrtFlag=StringUtils.EMPTY;
		if (CommonConstants.FLAG_I.equalsIgnoreCase(gsarFileUploadRequest.getFileType())) {
			labelCharge = "I";
		} else if (CommonConstants.FLAG_E.equalsIgnoreCase(gsarFileUploadRequest.getFileType())) {
			labelCharge = "B";
		} else {
			labelCharge = "F";
		}
		if (("V").equals(gsarFileUploadRequest.getVinSelectionOption())) {
			ingProdDate = "N";
			ingCrtFlag = "N";
		} else if (("N").equals(gsarFileUploadRequest.getVinSelectionOption())) {
			ingProdDate = " ";
			ingCrtFlag = " ";
			vinGrpF = " ";
		}
		if (CommonConstants.FLAG_I.equalsIgnoreCase(gsarFileUploadRequest.getFileType())) {
			vinGrpF = "Y";
		} else if (CommonConstants.FLAG_E.equalsIgnoreCase(gsarFileUploadRequest.getFileType())
				|| CommonConstants.FLAG_F.equalsIgnoreCase(gsarFileUploadRequest.getFileType())) {
			vinGrpF = "N";
		}
		addParam2.append(CommonConstants.ADD);
		addParam2.append(TargetingUtil.fillFsaTypeValue(gsarFileUploadRequest.getFsaNumber(), 8, gsarFileUploadRequest.getFsaType()));
		addParam2.append(gsarFileUploadRequest.getPopulation());
		addParam2.append(StringUtils.rightPad(gsarFileUploadRequest.getCdsId().toUpperCase(), 8, StringUtils.SPACE));
		addParam2.append(TargetingUtil.addZerosToProc(3));
		if(CommonConstants.FLAG_I.equalsIgnoreCase(gsarFileUploadRequest.getFileType())) {
			addParam2.append(gsarFileUploadRequest.getGroupCode());
			addParam2.append(TargetingUtil.fillRemainingString(gsarFileUploadRequest.getGroupDescription(),254," "));
		} else {
			addParam2.append(TargetingUtil.addSpaceToProc(2));
			addParam2.append(TargetingUtil.addSpaceToProc(254));
		}
		
		addParam2.append(TargetingUtil.addSpaceToProc(2));
		addParam2.append(labelCharge);
		addParam2.append(gsarFileUploadRequest.getFileType());
		addParam2.append(TargetingUtil.addSpaceToProc(36));
		addParam2.append(StringUtils.rightPad(gsarFileUploadRequest.getUniqueId()+gsarFileUploadRequest.getResultId()+".txt", 75, StringUtils.SPACE));
		addParam2.append(vinGrpF);// VIN-GROUP-F
		addParam2.append(ingProdDate);// IGN-PROD-DATE-F
		addParam2.append(StringUtils.rightPad(gsarFileUploadRequest.getSourceForReason(), 8, StringUtils.SPACE));
		addParam2.append(TargetingUtil.addSpaceToProc(26));
		addParam2.append(ingCrtFlag);// IGN-CRIT-F
		addParam2.append(ingProdDate);// IGN-VHLN-F
		addParam2.append(StringUtils.rightPad(gsarFileUploadRequest.getReasonOfVins(), 254, StringUtils.SPACE));
		addParam2.append(TargetingUtil.addSpaceToProc(18));
		addParam2.append(gsarFileUploadRequest.getCountryCode());
		addParam2.append(batchCode);
		if(CommonConstants.FLAG_F.equalsIgnoreCase(gsarFileUploadRequest.getFileType())) {
			addParam2.append(StringUtils.rightPad(gsarFileUploadRequest.getEventCode(), 3, StringUtils.SPACE));
		} else {
			addParam2.append(TargetingUtil.addSpaceToProc(3));
		}
		
		// Adding flag value=G for GSAR File Upload
		addParam2.append(CommonConstants.FLAG_G);	
		addParam2.append(TargetingUtil.addSpaceToProc(11));
		log.info("inoaram 2 is {} ", addParam2.toString().length());
		log.info("inoaram 2 is {} ", addParam2);
		return addParam2.toString();
	}
	
	public String getSerialListParamHistory(FscCriteriaRequestForGsar fscCriteriaRequest) {
		StringBuilder serialListParm = new StringBuilder();
		serialListParm.append(CommonConstants.FLAG_G);
		serialListParm.append(TargetingUtil.addSpaceToProc(8));
		serialListParm.append(fscCriteriaRequest.getPopulation());
		serialListParm.append(TargetingUtil.addSpaceToProc(701));
		serialListParm.append(CommonConstants.FLAG_G);
		serialListParm.append(TargetingUtil.addSpaceToProc(11));
		return serialListParm.toString();
	}
	
	private long checkPurgingData(String uploadFlag, Date createdDate) {
		LocalDate reportCreatedDate = createdDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
		LocalDate currentDate = LocalDate.now();
		long numberOfDays = ChronoUnit.DAYS.between(reportCreatedDate, currentDate);
		if (StringUtils.equalsIgnoreCase(uploadFlag, "N") && numberOfDays < 180 && numberOfDays >= 175) {
			return (180-numberOfDays);
		} else {
			return -1L;
		}
	}
	
	
	private String getRptOptCode(GcampSnapEntity gsarReports) {
		String rptOption = gsarReports.getRptSel();
		if(StringUtils.equalsIgnoreCase(rptOption, CommonConstants.INCLUDE_REPORT_OPTION)) {
			return "I";
		} else if(StringUtils.equalsIgnoreCase(rptOption, CommonConstants.EXLUDE_REPORT_OPTION)) {
			return "E";
		} else if(StringUtils.equalsIgnoreCase(rptOption, CommonConstants.FORCE_COMPLETE_REPORT_OPTION)) {
			return "F";
		}
		return StringUtils.EMPTY;
	}
	
	private String getRptOptDesc(String rptOption) {
		if(StringUtils.equalsIgnoreCase(rptOption, "I")) {
			return CommonConstants.INCLUDE_REPORT_OPTION;
		} else if(StringUtils.equalsIgnoreCase(rptOption, "E")) {
			return CommonConstants.EXLUDE_REPORT_OPTION;
		} else if(StringUtils.equalsIgnoreCase(rptOption, "F")) {
			return CommonConstants.FORCE_COMPLETE_REPORT_OPTION;
		}
		return StringUtils.EMPTY;
	}

	public String fsaGoSerialParamForGsar(FscCriteriaRequestForGsar fscCriteriaRequest) {
		StringBuilder sb = new StringBuilder();
		String fsaType=fscCriteriaRequest.getOptRadio();
		String fsaNumber=fscCriteriaRequest.getFscNumber();
		if (("G").equals(fsaType)) {
			sb.append(fsaType);
			sb.append(TargetingUtil.fillRemainingString(fsaNumber,8,"0"));
			sb.append(addSpaceToProcForGsar(9));
		} else if (("L").equals(fsaType)) {
			sb.append(fsaType);
			sb.append(TargetingUtil.fillRemainingString(fsaNumber.toUpperCase(),10," "));
			sb.append(addSpaceToProcForGsar(9));
		}
		return sb.toString();
	}

	public String addSpaceToProcForGsar(int length) {
		StringBuilder sb = new StringBuilder();
		int maxLength = length;
		while (maxLength > 0) {
			sb.append(" ");
			maxLength--;
		}
		return sb.toString();
	}
}
