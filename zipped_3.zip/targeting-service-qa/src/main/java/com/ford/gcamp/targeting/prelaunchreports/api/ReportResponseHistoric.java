package com.ford.gcamp.targeting.prelaunchreports.api;


import com.ford.gcamp.targeting.common.api.CommonResponse;
import lombok.Getter;
import lombok.Setter;

import java.io.InputStream;

@Setter
@Getter
public class ReportResponseHistoric extends CommonResponse {

    private String reportId;
    private String requestedBy;
    private String reportFormatCode;
    private InputStream reportContentStream;
}
