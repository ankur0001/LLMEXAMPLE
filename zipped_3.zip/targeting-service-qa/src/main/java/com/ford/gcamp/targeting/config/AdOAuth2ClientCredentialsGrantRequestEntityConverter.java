package com.ford.gcamp.targeting.config;

import org.springframework.http.RequestEntity;
import org.springframework.security.oauth2.client.endpoint.OAuth2ClientCredentialsGrantRequest;
import org.springframework.security.oauth2.client.endpoint.OAuth2ClientCredentialsGrantRequestEntityConverter;
import org.springframework.util.MultiValueMap;

public class AdOAuth2ClientCredentialsGrantRequestEntityConverter
		extends OAuth2ClientCredentialsGrantRequestEntityConverter {

	private final String resource;

	public AdOAuth2ClientCredentialsGrantRequestEntityConverter(String resource) {
		this.resource = resource;
	}

	@Override
	@SuppressWarnings("unchecked")
	public RequestEntity<?> convert(OAuth2ClientCredentialsGrantRequest clientCredentialsGrantRequest) {
		RequestEntity<?> requestEntity = super.convert(clientCredentialsGrantRequest);
		if(null != requestEntity) {
			MultiValueMap<String, String> formParameters = (MultiValueMap<String, String>) requestEntity.getBody();
			if(null != formParameters) {
				formParameters.add("resource", this.resource);
			}
		}
		return requestEntity;
	}
}
