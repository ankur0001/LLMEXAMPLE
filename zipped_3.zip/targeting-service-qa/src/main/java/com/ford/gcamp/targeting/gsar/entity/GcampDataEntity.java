package com.ford.gcamp.targeting.gsar.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "GCAMP_DATA", schema = "APP_SERVER")
public class GcampDataEntity {
	
	@Id
	@Column(name = "RESULT_ID")
	Integer resultId;
	
	@Column(name = "U_ID")
	Long uniqueId;

	@Column(name = "MDL_YR")
	String modelYear;
	
	@Column(name = "VIN_CD")
	String vinGrpCode;


}
