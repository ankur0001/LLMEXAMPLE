package com.ford.gcamp.targeting.gridgcamp.gcamp.entity;

import java.sql.Timestamp;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

import org.hibernate.annotations.NotFound;
import org.hibernate.annotations.NotFoundAction;
import org.hibernate.annotations.UpdateTimestamp;

import com.ford.gcamp.targeting.gridgcamp.grid.entity.HubLookupData;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Entity
@Table(name = "SGCPA15_GLOBAL_FSA")
@JsonIgnoreProperties(ignoreUnknown = true)
public class FSAData {

	@Id
	@Column(name = "GCPA15_GLOBL_FSA_R")
	private int globalFSANumber;
	@Column(name = "GCPA15_FSACRT_ID_C", updatable = false)
	private String createBy;
	@Column(name = "GCPA11_FSA_TYPE_C")
	private String fsaType;
	@Column(name = "GCPA15_FSAUPD_ID_C")
	private String updateId;
	@Setter(AccessLevel.NONE)
	@Getter(AccessLevel.NONE)
	@Column(name = "GCPA15_FSAUPDATE_S")
	@UpdateTimestamp
	private Timestamp updateTimeStamp;

	@Column(name = "GCPA15_GLOBL_FSA_X")
	private String globalFSADescription;
	@Column(name = "GCPE10_OR_HUB_C")
	private String hubCode;
	@Column(name = "GCPA15_FRC_DECN_Y")
	private String frcDecisionDate;
	
	@JoinColumn(name = "GCPE10_OR_HUB_C", referencedColumnName = "GCPE10_HUB_C", insertable = false, updatable = false)
	@OneToOne
	@NotFound(action = NotFoundAction.IGNORE)
	private HubLookupData hub;
	
	@Column(name = "GCPA15_OTA_F")
	private String otaFlag;
	

}
