package com.ford.gcamp.targeting.common;


import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class LDAPModel {
    @Size(min = 0, max = 8)
    @Pattern(regexp = "^[a-zA-Z\\d\\-]*$")
    @Schema(example = "TDHARTI", description = "userId")
    private String userId;

    @Size(min = 0, max = 100)
    @Pattern(regexp = "^(|[a-zA-Z\\s])*$")
    @Schema(example = "Dharti", description = "First Name")
    private String firstName;

    @Size(min = 0, max = 100)
    @Pattern(regexp = "^(|[a-zA-Z\\s])*$")
    @Schema(example = "Thakker", description = "Last Name")
    private String lastName;


    @Size(min = 0, max = 17)
    @Pattern(regexp = "^[a-zA-Z0-9\\-\\@\\.]*$")
    @Schema(example = "tdharti@ford.com", description = "email Address")
    private String email;

    @Size(min = 0, max = 100)
    @Pattern(regexp = "^(|[a-zA-Z\\s\\,\\(\\)\\.])*$")
    @Schema(example = "Dharti, Thakker (T.)", description = "email Address")
    private String fordDisplayName;

    @Size(min = 0, max = 20)
    @Pattern(regexp = "^[a-zA-Z\\d\\s]*$")
    @Schema(example = "IT FCSD", description = "Department")
    private String department;

    @Size(min = 0, max = 3)
    @Pattern(regexp = "^[a-zA-Z]*$")
    @Schema(example = "USA", description = "Country Code")
    private String country;
}
