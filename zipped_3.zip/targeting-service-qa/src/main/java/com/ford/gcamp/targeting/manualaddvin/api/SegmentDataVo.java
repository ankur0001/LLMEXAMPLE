package com.ford.gcamp.targeting.manualaddvin.api;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class SegmentDataVo {

	private String segmentNumber;
	private String segmentDescription;
	private String launchedStatus;
	
}
