package com.ford.gcamp.targeting.fsacriteria.api;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class FsaGlobalSearchList {

	@Size(min = 0, max = 10)
	@Pattern(regexp = "^[a-zA-Z\\d\\s]*$")
	@Schema(example = "15543", description = "global FSA number")
	private String globalFsaNumber;


	@Size(min = 0, max = 10)
	@Pattern(regexp = "^[a-zA-Z\\d\\s]*$")
	@Schema(example = "15S01", description = "Local FSA number")
	private String localFsaNumber;


	@Schema(example = "Testing" , description = "globalfsaDesc")
	@Size(min = 0, max = 254)
	@Pattern(regexp ="^[A-Za-z\\d\\s\\.\\,\\_\\-]*$")
	private String globalfsaDesc;

	@Schema(example = "testing" , description = "localFsaDesc")
	@Size(min = 0, max = 254)
	@Pattern(regexp ="^[A-Za-z\\d\\s\\.\\,\\_\\-]*$")
	private String localFsaDesc;


	@Size(min = 0, max = 2)
	@Pattern(regexp = "^[A-Z\\*\\s]{1,2}$")
	@Schema(example = "NA", description = "Hub Code")
	private String hubName;


	@Size(min=0 , max = 12)
	@Pattern(regexp = "^[a-zA-Z\\d\\-]*$")
	@Schema(example = "31-Dec-9999", description = "local FSA Crt Year")
	private String localFsaCrtYr;
	
}
