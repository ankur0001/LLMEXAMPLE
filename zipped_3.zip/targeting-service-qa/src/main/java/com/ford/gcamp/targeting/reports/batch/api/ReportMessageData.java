package com.ford.gcamp.targeting.reports.batch.api;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@Setter
@Getter
public class ReportMessageData implements Serializable {

    private static final long serialVersionUID = 1L;
    private String reportId;
    private String oracleURL;
    private String metaString;
    private String userId;
}
