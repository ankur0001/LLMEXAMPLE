package com.ford.gcamp.targeting.fsacriteria.api;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class FsaCriteriaError {
	
	private String errorInd;
	private String errorFlag;
	private String errorCode;
	private String errorMessage;
	
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("FsaCriteriaError [errorInd=");
		builder.append(errorInd);
		builder.append(", errorFlag=");
		builder.append(errorFlag);
		builder.append(", errorCode=");
		builder.append(errorCode);
		builder.append(", errorMessage=");
		builder.append(errorMessage);
		builder.append("]");
		return builder.toString();
	}
	
	

}
