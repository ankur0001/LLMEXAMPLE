package com.ford.gcamp.targeting.fsacriteria;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ford.gcamp.targeting.common.CommonConstants;
import com.ford.gcamp.targeting.fsacriteria.api.FsaGlobalSearchDTO;
import com.ford.gcamp.targeting.fsacriteria.api.FsaGlobalSearchList;


@Component
public class FsaGlobalSearchUtil {
	
	@Autowired
	private FsaGlobalSearchDTO fsaGlobalSearchDTO;

	public FsaGlobalSearchDTO callGlobalSearchStorProc(Map<String, Object> map, String fsaType) {
		
		List<FsaGlobalSearchList> globalSearchlist = new ArrayList<>();
		
		@SuppressWarnings("unchecked")
		List<Map<String, Object>> searchList = (List<Map<String, Object>>) map.get("#result-set-1");
		if (searchList!=null && !searchList.isEmpty()) {
			for (Map<String, Object> map1 : searchList) {
				FsaGlobalSearchList fsGlobList = new FsaGlobalSearchList();
				if("G".equals(fsaType)) {
				fsGlobList.setGlobalFsaNumber((String.valueOf(map1.get("GCPA15_GLOBL_FSA_R"))));
				fsGlobList.setGlobalfsaDesc(((String) map1.get("GCPA15_GLOBL_FSA_X")).trim());
				}else if("L".equals(fsaType)) {
					fsGlobList.setLocalFsaNumber((String.valueOf(map1.get("GCPA16_LOCAL_FSA_R"))));
					fsGlobList.setGlobalFsaNumber((String.valueOf(map1.get("GCPA15_GLOBL_FSA_R"))));
					fsGlobList.setLocalFsaDesc(String.valueOf(map1.get("GCPA16_LOCAL_FSA_X")).trim());
					fsGlobList.setHubName(String.valueOf(map1.get("GCPE10_HUB_C")));
					fsGlobList.setLocalFsaCrtYr(String.valueOf(map1.get("GCPA16_LOCFSACRT_Y")));
				}
				globalSearchlist.add(fsGlobList);

			}
			fsaGlobalSearchDTO.setStatus(CommonConstants.SUCCESS_CODE);
			fsaGlobalSearchDTO.setStatusCode(CommonConstants.SUCCESS);
			fsaGlobalSearchDTO.setStatusDescription(CommonConstants.SUCCESS_DESC);
		}else {
			fsaGlobalSearchDTO.setStatusDescription(CommonConstants.FSA_SEARCH_FAILURE);
		}
		fsaGlobalSearchDTO.setFsaGlobalList(globalSearchlist);
		
		return fsaGlobalSearchDTO;
	}

}
