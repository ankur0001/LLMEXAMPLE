package com.ford.gcamp.targeting.prelaunchreports.api;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class DownloadReportRequest {
	@Size(min = 0, max = 999999999)
	@Pattern(regexp = "^[\\d]*$")
	@Schema(example = "86866", description = "Report Id")
	private String reportId;

	@Size(min = 0, max = 999999)
	@Pattern(regexp = "^[a-zA-Z\\d]*$")
	@Schema(example = "T03", description = "Report Code")
	private String reportCode;

	@Size(min = 0, max = 999999)
	@Pattern(regexp = "^[a-zA-Z\\d]*$")
	@Schema(example = "HG", description = "Agency Code")
	private String agencyCode;

	@Size(min = 0, max = 3)
	@Pattern(regexp = "^[a-zA-Z\\d]*$")
	@Schema(example = "XLS", description = "Report Format")
	private String reportFormat;

	@Size(min = 0, max = 999999999)
	@Pattern(regexp = "^[a-zA-Z\\d]*$")
	@Schema(example = "25", description = "Report Code")
	private String jobQueueId;

	@Size(min = 0, max = 9999)
	@Pattern(regexp = "^[a-zA-Z\\d]*$")
	@Schema(example = "T03", description = "Report Code")
	private String batchCode;

	@Size(min = 0, max = 999999999)
	@Pattern(regexp = "^[a-zA-Z\\d]*$")
	@Schema(example = "25", description = "Blob Id")
	private String blobId;
	
}
