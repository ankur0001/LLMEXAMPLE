package com.ford.gcamp.targeting.fsacriteria.api;

import java.util.List;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CountryData {
	@NotNull
	@Size(min = 0, max = 3)
	@Pattern(regexp = "^[a-zA-Z\\*\\s]*$")
	@Schema(example = "CAN", description = "CountryCode")
	private String countryCode;

	@Size(min = 0, max = 100)
	@Pattern(regexp = "^[a-zA-Z\\-\\s\\&\\(\\)\\.]*$")
	@Schema(example = "CANADA", description = "Country Description")
	private String label;

	@Size(min = 0, max = 250, message = "States")
	private List<@Valid StateProvince> children;
}
