package com.ford.gcamp.targeting.reports.batch.api;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class EngineCode extends GenericReportData {

    /**
     * Contains the hub description
     */
    private String hub;

    /**
     * Contains the local FSA
     */
    private String localFSA;

    /**
     * Contains the ROI description
     */
    private String roi;

    /**
     * Contains the Counry name
     */
    private String country;

    /**
     * Contains the engine code
     */
    private String code;

    /**
     * Contains the engine desc
     */
    private String engineDesc;

    /**
     * Contains the model year
     */
    private String modelYear;

    /**
     * Contains the count for a particular set of keys.
     */
    private int count;

}
