package com.ford.gcamp.targeting.common.api;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;
@Getter
@Setter
public class GlobalFSAPopupData implements Serializable{
	
	private static final long serialVersionUID = 1L;
	String popupString = "";

	
}
