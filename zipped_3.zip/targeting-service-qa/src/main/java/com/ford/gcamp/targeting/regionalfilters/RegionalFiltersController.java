package com.ford.gcamp.targeting.regionalfilters;

import com.ford.cloudnative.base.api.StandardErrorResponse;
import com.ford.gcamp.targeting.common.api.*;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.extensions.Extension;
import io.swagger.v3.oas.annotations.extensions.ExtensionProperty;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import org.apache.commons.lang3.StringUtils;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.ford.gcamp.targeting.core.exception.GCAMPException;
import com.ford.gcamp.targeting.logging.LogExecutionTime;
import com.ford.gcamp.targeting.regionalfilters.api.ProcessMigVehRequest;
import com.ford.gcamp.targeting.regionalfilters.api.RegionalFilterSaveRequest;
import com.ford.gcamp.targeting.regionalfilters.api.RegionalFilterStateProvinceResponse;
import com.ford.gcamp.targeting.regionalfilters.api.RegionalFilterStateRequest;
import com.ford.gcamp.targeting.regionalfilters.api.RegionalFiltersGoResponse;
import com.ford.gcamp.targeting.regionalfilters.api.RegionalAuditReportResponse;
import org.springframework.web.bind.annotation.PathVariable;
import com.ford.gcamp.targeting.regionalfilters.api.RegionalFiltersRequest;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping(path = "/api/v1/targeting/regionalfilters")
@Validated
public class RegionalFiltersController {
	private RegionalFiltersService regionalFiltersService;

	public RegionalFiltersController(RegionalFiltersService regionalFiltersService) {
		this.regionalFiltersService = regionalFiltersService;
	}

	@PreAuthorize("@authorizeService.isAuthorized('GCAMP:regionalFilters:executeGo','execute')")
	@Operation(summary = "Search for regional filters",security={
			@SecurityRequirement(name = "ADFS"),
			@SecurityRequirement(name = "AzureAD")
	})
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = " Search data request fetched successfully",
					content = @Content(mediaType = "application/problem+json",schema = @Schema(implementation = RegionalFiltersGoResponse.class))),
			@ApiResponse(responseCode = "412", description = "Precondition Failed", content = @Content(schema = @Schema(implementation = CommonErrorResponse.class))),
			@ApiResponse(responseCode = "default", description = "All Errors", content = @Content(schema = @Schema(implementation = StandardErrorResponse.class)))
	})
	@PostMapping("/search")
	@LogExecutionTime
	public ResponseEntity<RegionalFiltersGoResponse> regionalFilterSearch(
			@RequestBody @Valid final FSACommonGoRequest fsaGoRequest) throws GCAMPException {
		RegionalFiltersGoResponse response = regionalFiltersService.commonSearch(fsaGoRequest);
		return ResponseEntity.ok(response);
	}

	@PreAuthorize("@authorizeService.isAuthorized('GCAMP:regionalCountry:selectCountries','execute')")
	@Operation(summary = "Country load for regional filters",security = {
			@SecurityRequirement(name = "ADFS"),
			@SecurityRequirement(name = "AzureAD")
	})
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Load Country data request fetched successfully",
					content = @Content(mediaType = "application/problem+json",schema = @Schema(implementation = RoiCountryResponse.class))),
			@ApiResponse(responseCode = "412", description = "Precondition Failed", content = @Content(schema = @Schema(implementation = CommonErrorResponse.class))),
			@ApiResponse(responseCode = "default", description = "All Errors", content = @Content(schema = @Schema(implementation = StandardErrorResponse.class)))
	})
	@PostMapping(value = "/country/load")
	public ResponseEntity<RoiCountryResponse> loadCountry(@RequestBody @Valid FSACommonGoRequest fsaGoRequest)
			throws GCAMPException {
		RoiCountryResponse countryResponse = regionalFiltersService.loadCountry(fsaGoRequest, StringUtils.EMPTY);
		return ResponseEntity.ok(countryResponse);
	}

	@PreAuthorize("@authorizeService.isAuthorized('GCAMP:regionalStateProv:selectStatesProvinces','execute')")
	@Operation(summary = "State Province load for regional filters",security = {
			@SecurityRequirement(name = "ADFS"),
			@SecurityRequirement(name = "AzureAD")
	})
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "state province request fetched successfully",
					content = @Content(mediaType = "application/problem+json",schema = @Schema(implementation = RegionalFilterStateProvinceResponse.class))),
			@ApiResponse(responseCode = "412", description = "Precondition Failed", content = @Content(schema = @Schema(implementation = CommonErrorResponse.class))),
			@ApiResponse(responseCode = "default", description = "All Errors", content = @Content(schema = @Schema(implementation = StandardErrorResponse.class)))
	})
	@PostMapping(value = "/stateprovince/load")
	public ResponseEntity<RegionalFilterStateProvinceResponse> getStatesProvinces(
			@RequestBody @Valid  final RegionalFilterStateRequest regionalFilterStateRequest) throws GCAMPException {
		RegionalFilterStateProvinceResponse regionalFilterStateProvinceResponse = regionalFiltersService
				.getStatesProvinces(regionalFilterStateRequest);
		return ResponseEntity.ok(regionalFilterStateProvinceResponse);
	}

	@PreAuthorize("@authorizeService.isAuthorized('GCAMP:regionalFilters:executeInsert','execute')")
	@Operation(summary = "Save for regional filters",security = {
			@SecurityRequirement(name = "ADFS"),
			@SecurityRequirement(name = "AzureAD")
	})
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Query Manual Upload data request fetched successfully",
					content = @Content(mediaType = "application/problem+json",schema = @Schema(implementation = CommonResponse.class))),
			@ApiResponse(responseCode = "412", description = "Precondition Failed", content = @Content(schema = @Schema(implementation = CommonErrorResponse.class))),
			@ApiResponse(responseCode = "default", description = "All Errors", content = @Content(schema = @Schema(implementation = StandardErrorResponse.class)))
	})
	@PostMapping(value = "/save")
	public ResponseEntity<CommonResponse> saveRegionalFilters(
			@RequestBody @Valid final RegionalFilterSaveRequest regionalFilterSaveRequest) throws GCAMPException {
		CommonResponse regionalFilterStateProvinceResponse = regionalFiltersService
				.saveRegionalFilters(regionalFilterSaveRequest);
		return ResponseEntity.ok(regionalFilterStateProvinceResponse);
	}

	@PreAuthorize("@authorizeService.isAuthorized('GCAMP:regionalFilters:executeDelete','execute')")
	@Operation(summary = "Delete for regional filters",security = {
			@SecurityRequirement(name = "ADFS"),
			@SecurityRequirement(name = "AzureAD")
	})
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Delete request fetched successfully",
					content = @Content(mediaType = "application/problem+json",schema = @Schema(implementation = CommonResponse.class))),
			@ApiResponse(responseCode = "412", description = "Precondition Failed", content = @Content(schema = @Schema(implementation = CommonErrorResponse.class))),
			@ApiResponse(responseCode = "default", description = "All Errors", content = @Content(schema = @Schema(implementation = StandardErrorResponse.class)))
	})
	@PostMapping("/delete")
	public ResponseEntity<CommonResponse> deleteRegionalFilters(@RequestBody @Valid final RegionalFiltersRequest deleteRequest)
			throws GCAMPException {
		CommonResponse deleteResponse = regionalFiltersService.deleteRegionalFilters(deleteRequest);
		return ResponseEntity.ok(deleteResponse);
	}

	@PreAuthorize("@authorizeService.isAuthorized('GCAMP:regionalFilters:processMigratedVeh','execute')")
	@Operation(summary = "Process Migrated Vehicles for regional filters",security = {
			@SecurityRequirement(name = "ADFS"),
			@SecurityRequirement(name = "AzureAD")
	})
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Query Manual Upload data request fetched successfully",
					content = @Content(mediaType = "application/problem+json",schema = @Schema(implementation = CommonResponse.class))),
			@ApiResponse(responseCode = "412", description = "Precondition Failed", content = @Content(schema = @Schema(implementation = CommonErrorResponse.class))),
			@ApiResponse(responseCode = "default", description = "All Errors", content = @Content(schema = @Schema(implementation = StandardErrorResponse.class)))
	})
	@PostMapping("/processmigratedveh")
    public ResponseEntity<CommonJobResponse> submitProcessMigratedVehicle(
            @RequestBody @Valid
            @io.swagger.v3.oas.annotations.parameters.RequestBody(
                    content = @Content(
                            schema = @Schema(implementation = ProcessMigVehRequest.class),
                            extensions = {@Extension(properties = {
                                    @ExtensionProperty(name = "x-42c-sample", value = """
                                            {
                                            "hub":"NA",
                                            "fsaNumber":"21201",
                                            "country":"USA",
                                            "cdsId":"PDHANAS9"
                                            }
                                            """)
                            })}
                    )
            )
			ProcessMigVehRequest processMigVeh) throws GCAMPException {
		CommonJobResponse jobResponse = regionalFiltersService.processMigratedVehicle(processMigVeh);
		return ResponseEntity.ok(jobResponse);

	}

	@PreAuthorize("@authorizeService.isAuthorized('GCAMP:regionalauditreport','execute')")
	@Operation(summary = "Save for regional filters",security = {
			@SecurityRequirement(name = "ADFS"),
			@SecurityRequirement(name = "AzureAD")
	})
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Query Manual Upload data request fetched successfully",
					content = @Content(mediaType = "application/problem+json",schema = @Schema(implementation = RegionalAuditReportResponse.class))),
			@ApiResponse(responseCode = "400", description = "Bad Request, missing required fields"),
			@ApiResponse(responseCode = "401", description = "Unauthorized"),
			@ApiResponse(responseCode = "403", description = "Forbidden"),
			@ApiResponse(responseCode = "404", description = "Not Found"),
			@ApiResponse(responseCode = "405", description = "Invalid Method type"),
			@ApiResponse(responseCode = "412", description = "Precondition Failed", content = @Content(schema = @Schema(implementation = CommonErrorResponse.class))),
			@ApiResponse(responseCode = "415", description = "Unsupported Media Type"),
			@ApiResponse(responseCode = "428", description = "Bad Request, missing required fields"),
			@ApiResponse(responseCode = "429", description = "Too many bad request"),
			@ApiResponse(responseCode = "500", description = "Internal Server Error"),
			@ApiResponse(responseCode = "default", description = "All Errors", content = @Content(schema = @Schema(implementation = StandardErrorResponse.class)))
	})
	@GetMapping(value = "regionalReport/{fsaNumber}/{flag}/{supplement}")
	public ResponseEntity<RegionalAuditReportResponse> getRegionalAuditReport(
			@PathVariable ("fsaNumber") @Valid  @NotNull  @Min(0) @Max(99999999) @Schema(type = "integer",example = "15543", description = "FSA number")
			int fsaNumber,
			@PathVariable("flag") @Valid @NotNull
	        @Size(min = 1, max = 8)
	        @Pattern(regexp = "^[a-zA-Z]*$")
	        @Schema(example = "regional", description = "Flag")  String flag,
			@PathVariable("supplement")  @Valid @NotNull
			@Size( max = 2)
			@Pattern(regexp = "^[a-zA-Z\\d\\s]*$")
			@Schema(example = "AA", description = "Supplement Code")  String supplement) {
		RegionalAuditReportResponse reportResponse = regionalFiltersService.getRegionalAuditReport(String.valueOf(fsaNumber), flag,
				supplement);
		return ResponseEntity.ok(reportResponse);
	}
	
	@PreAuthorize("@authorizeService.isAuthorized('GCAMP:regionalFilters:executeGo','execute')")
	@PostMapping("/supplements")
	@Operation(summary = "Process Migrated Vehicles for regional filters",security = {
			@SecurityRequirement(name = "ADFS"),
			@SecurityRequirement(name = "AzureAD")
	})
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Supplements data request fetched successfully",
					content = @Content(mediaType = "application/problem+json",schema = @Schema(implementation = GenericLookupResponse.class))),
			@ApiResponse(responseCode = "412", description = "Precondition Failed", content = @Content(schema = @Schema(implementation = CommonErrorResponse.class))),
			@ApiResponse(responseCode = "default", description = "All Errors", content = @Content(schema = @Schema(implementation = StandardErrorResponse.class)))
	})
	public ResponseEntity<GenericLookupResponse> getSupplements(@RequestBody @Valid FSACommonGoRequest fsaGoRequest) throws GCAMPException {
		GenericLookupResponse supplementResponse = regionalFiltersService.getSupplements(fsaGoRequest);
		return ResponseEntity.ok(supplementResponse);
	}
	
	

}
