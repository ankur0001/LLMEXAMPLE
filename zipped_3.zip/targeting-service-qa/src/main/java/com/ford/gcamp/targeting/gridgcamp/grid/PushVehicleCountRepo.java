package com.ford.gcamp.targeting.gridgcamp.grid;


import com.ford.gcamp.targeting.common.CommonConstants;
import com.ford.gcamp.targeting.core.exception.GCAMPException;
import com.ford.gcamp.targeting.gridgcamp.grid.api.GridVernCount;
import com.ford.gcamp.targeting.vin.S3Service;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import java.util.Map;

@Repository
@Slf4j
public class PushVehicleCountRepo {
    private JdbcTemplate jdbcTemplate;

    @Autowired
    S3Service s3Service;
    @Value("${DB_OWNER}")
    private String ownerId;
    @Value("${db2.uncommit.read}")
    private String uncommitRead;

    @Autowired
    public PushVehicleCountRepo(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }
    MapSqlParameterSource createSqlParameterSource(String inputParamKey1, String inputParamVal1, String inputParamKey2, String inputParamVal2) {
        return new MapSqlParameterSource().addValue(inputParamKey1,inputParamVal1)
                .addValue(inputParamKey2, inputParamVal2);

    }

    SimpleJdbcCall createSimpleJdbcCall(String schemaName, String procedureName) {
        return new SimpleJdbcCall(jdbcTemplate).withSchemaName(schemaName).withProcedureName(procedureName);
    }

    public Map<String, Object> insertData(String inputParam1, String inputParam2, GridVernCount gridVernCount) throws GCAMPException {
        Map<String, Object> claimInfoResponse = null;
        SimpleJdbcCall simpleJdbcCall = null;
        try {
            simpleJdbcCall = createSimpleJdbcCall(CommonConstants.FSA_SCHEMA_NAME,
                    CommonConstants.AUDIT_DATA);
            SqlParameterSource sqlParameterSource = createSqlParameterSource(CommonConstants.INPUT_PARM1, inputParam1,CommonConstants.INPUT_PARM2, inputParam2);
            log.info("input of recall info api{}", sqlParameterSource);
            claimInfoResponse = simpleJdbcCall.execute(sqlParameterSource);
            log.info("response of recall info api {}", claimInfoResponse);

        } catch (Exception e) {
            log.error(CommonConstants.DB_EXCEPTION, e);
            throw new GCAMPException(CommonConstants.DB_EXCEPTION, e);
        }
        checkforErrorMessage(claimInfoResponse,gridVernCount);
        return claimInfoResponse;
    }
    private void checkforErrorMessage(Map<String, Object> output,GridVernCount gridVernCount)  {
        String errorParam = (String) output.get("ERROR_PARM1");

        String statusInd = StringUtils.isNotBlank(errorParam) ? errorParam.substring(9, 10) : "N";
        if (statusInd != null && "Y".equalsIgnoreCase(statusInd)) {
            s3Service.deleteFile(gridVernCount.getKey());

        }
    }

}
