package com.ford.gcamp.targeting;

import static org.springframework.security.config.Customizer.withDefaults;
import static org.springframework.security.oauth2.jwt.JwtClaimNames.AUD;

import com.ford.gcamp.targeting.config.CountryRestrictionFilter;
import com.ford.gcamp.targeting.multiauth.OverrideableJwtRolesAndScopesConverter;
import com.ford.gcamp.targeting.user.UserService;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.actuate.autoconfigure.security.servlet.EndpointRequest;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.oauth2.core.OAuth2Error;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.security.oauth2.jwt.JwtValidationException;
import org.springframework.security.oauth2.server.resource.web.authentication.BearerTokenAuthenticationFilter;
import org.springframework.security.web.DefaultSecurityFilterChain;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

@Configuration
@EnableWebSecurity
@EnableMethodSecurity
@Slf4j
public class WebSecurityConfiguration {

    WebSecurityConfiguration() {
        // Default public constructor
    }

    /*****************************************************************************************************************
     * Other - Basic/Public
     *****************************************************************************************************************/

    @Configuration
    @Order(10)
    public static class ResourceServerSecurityConfiguration {

        // @Value("#{'${audience-id}'.split(',')}")
        List<String> audience;

        public static final String READ_ROLE = "read";
        private final JwtDecoder multiAuthJwtDecoder;

        @Value("${cors.allowed-origins}")
        private List<String> allowedOrigins;

        @Value("${cors.allowed-headers}")
        private List<String> allowedHeaders;

        @Value("${cors.allowed-methods}")
        private List<String> allowedMethods;

        @Value("${cors.allowed-path-pattern}")
        private String allowedPathPattern;

        @Autowired UserService userService;

        @Value("${RESTRICTED_COUNTRIES}")
        private String restrictedCountries;

        @Bean
        public CountryRestrictionFilter countryRestrictionFilter() {
            return new CountryRestrictionFilter(userService, restrictedCountries);
        }

        @Autowired
        public ResourceServerSecurityConfiguration(JwtDecoder multiAuthJwtDecoder) {
            this.multiAuthJwtDecoder = multiAuthJwtDecoder;
        }

        @Bean
        protected DefaultSecurityFilterChain configure(
                HttpSecurity http, OverrideableJwtRolesAndScopesConverter converter)
                throws Exception {
            log.info("Inside ResourceServerSecurityConfiguration configure");
            //         JwtDecoder newJwtDecoder = wrapJwtDecoderWithAudienceCheck(this.jwtDecoder,
            // audience);

            http.cors(withDefaults())
                    .securityMatcher("/api/**")
                    .csrf(AbstractHttpConfigurer::disable)
                    .authorizeHttpRequests(
                            authorizeHttpRequest -> {
                                authorizeHttpRequest
                                        .requestMatchers(
                                                "/swagger-ui/**",
                                                "/swagger-*",
                                                "/swagger-resources/**",
                                                "/webjars/**",
                                                "/v3/api-docs",
                                                "/v3/api-docs/**")
                                        .permitAll();
                                authorizeHttpRequest.requestMatchers("/csrf").permitAll();
                                authorizeHttpRequest.requestMatchers("/h2-console").permitAll();
                                authorizeHttpRequest
                                        .requestMatchers("/api/v1/targeting/**")
                                        .authenticated();
                                authorizeHttpRequest
                                        .requestMatchers(
                                                EndpointRequest.to("info", "health", "refresh"))
                                        .permitAll();
                                authorizeHttpRequest.anyRequest().authenticated();
                            })
                    .sessionManagement(
                            smc -> smc.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
                    .oauth2ResourceServer(
                            oauth ->
                                    oauth.jwt(
                                            jwt ->
                                                    jwt.decoder(multiAuthJwtDecoder)
                                                            .jwtAuthenticationConverter(
                                                                    converter)));
            http.addFilterAfter(countryRestrictionFilter(), BearerTokenAuthenticationFilter.class);
            return http.build();
        }

        @Bean
        CorsConfigurationSource corsConfigurationSource() {
            log.info("Applying Cors Filter");
            CorsConfiguration config = new CorsConfiguration();
            config.setAllowCredentials(true);
            config.setAllowedOrigins(allowedOrigins);
            config.setAllowedHeaders(allowedHeaders);
            config.setAllowedMethods(allowedMethods);
            UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
            source.registerCorsConfiguration(allowedPathPattern, config);
            log.debug("CORS Filter configured successfully");
            return source;
        }
    }

    static JwtDecoder wrapJwtDecoderWithAudienceCheck(
            JwtDecoder jwtDecoder, List<String> audience) {
        return token -> {
            Jwt jwt = jwtDecoder.decode(token);
            Optional<String> optional =
                    jwt.getClaimAsStringList(AUD).stream()
                            .filter(
                                    e ->
                                            (audience.stream()
                                                            .filter(value -> value.equals(e))
                                                            .findAny())
                                                    .isPresent())
                            .findAny();
            if (Boolean.TRUE.equals(jwt.getClaims().containsKey(AUD)) && !optional.isPresent()) {
                throw new JwtValidationException(
                        "Audience field does not match: " + audience,
                        Arrays.asList(new OAuth2Error("invalid_aud")));
            }
            return jwt;
        };
    }
}
