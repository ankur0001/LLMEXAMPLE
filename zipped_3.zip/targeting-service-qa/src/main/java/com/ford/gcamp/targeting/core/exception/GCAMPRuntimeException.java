package com.ford.gcamp.targeting.core.exception;

import org.springframework.http.HttpStatus;

import com.ford.gcamp.targeting.common.CommonConstants;
import com.ford.gcamp.targeting.common.api.CommonErrorResponse;

public class GCAMPRuntimeException extends RuntimeException {

	private static final long serialVersionUID = -8720789619363341078L;

	private final CommonErrorResponse responseStatus;

	public GCAMPRuntimeException(String message) {
		super(message);
		responseStatus = new CommonErrorResponse(CommonConstants.FAILURE, HttpStatus.PRECONDITION_FAILED.toString(),
				message);
	}

	public CommonErrorResponse getResponseStatus() {
		return responseStatus;
	}

}
