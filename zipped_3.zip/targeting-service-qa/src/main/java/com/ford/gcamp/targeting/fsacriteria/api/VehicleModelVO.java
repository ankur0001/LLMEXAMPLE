package com.ford.gcamp.targeting.fsacriteria.api;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class VehicleModelVO extends FsaVehicleCommonVO {

	@Size(min = 0, max = 10)
	@Pattern(regexp = "^|[a-zA-Z\\d\\-\\s]*$")
	@Schema(example = " ", description = "filterCode")
	private String modelFilterCode;

	@Size(min = 0, max = 10)
	@Pattern(regexp = "^|[a-zA-Z\\d\\-\\s]*$")
	@Schema(example = " ", description = "filterCode")
	private String modelCode;

	@Size(min = 0, max = 250)
	@Pattern(regexp = "^|[a-zA-Z\\d\\-\\s]*$")
	@Schema(example = " ", description = "filterCode")
	private String modelDesc;
	
}
