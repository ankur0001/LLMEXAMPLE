package com.ford.gcamp.targeting.gridgcamp.api;

import com.ford.gcamp.targeting.common.api.CommonResponse;

import jakarta.validation.constraints.Size;
import jakarta.validation.Valid;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class DashboardGridTileCountResponse  extends CommonResponse {

  @Valid
	private DashboardGridCount dashboardGridCount;
}
