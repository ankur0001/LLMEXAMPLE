package com.ford.gcamp.targeting.reports.batch.exception;

import java.util.Map;

import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.repeat.RepeatContext;
import org.springframework.batch.repeat.exception.ExceptionHandler;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.ford.gcamp.targeting.reports.batch.ReportEmailSender;
import com.ford.gcamp.targeting.reports.batch.api.ReportMetaData;
import com.ford.gcamp.targeting.reports.batch.common.ReportGenerationUtil;
import com.ford.gcamp.targeting.reports.batch.common.ReportStandardConstants;

import lombok.extern.slf4j.Slf4j;

@Component
@StepScope
@Slf4j
public class ReportExceptionHandler implements ExceptionHandler {

	@Value("#{jobParameters['reportMetaData']}")
	private String reportMetaDataString;

	private ReportMetaData reportMetaData;

	private ReportEmailSender reportEmailSender;

	private Map<String, SXSSFWorkbook> workbookMap;

	public ReportExceptionHandler(ReportEmailSender reportEmailSender, Map<String, SXSSFWorkbook> workbookMap) {
		super();
		this.reportEmailSender = reportEmailSender;
		this.workbookMap = workbookMap;
	}

	@Override
	public void handleException(RepeatContext context, Throwable exception) throws Throwable {

		reportMetaData = ReportGenerationUtil.getReportMetaDataObject(reportMetaDataString);

		log.error("There is an error in processing the report", exception.getCause());

		reportMetaData.setActionType(ReportStandardConstants.ERROR);

		reportEmailSender.processError(reportMetaData);

		reportMetaData.setBlobData(null);
		
		// Remove Workbook stored for T20 Report Code when exception occurs for T20 Step
		String key = ReportGenerationUtil.getWorkbookMapKey(reportMetaData);
		if (workbookMap.containsKey(key)) {
			workbookMap.remove(key);
		}

		throw exception;

	}

}
