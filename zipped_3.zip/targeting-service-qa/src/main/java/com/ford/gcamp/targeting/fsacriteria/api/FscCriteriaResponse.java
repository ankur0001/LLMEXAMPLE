package com.ford.gcamp.targeting.fsacriteria.api;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


    @Getter
    @Setter
	@NoArgsConstructor
	@AllArgsConstructor
	public class FscCriteriaResponse {
		private FSACriteriaSessionData outPutFSA01;
		private List<FSAGlobalData> outPutFSA02;
		private List<VINGrpCriteriaVO> vinGrpCriteriaVOs;
	}

