package com.ford.gcamp.targeting.gsar.api;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Builder
public class VinList {
	@Size(min = 0, max = 17)
	@Pattern(regexp = "^[a-zA-Z\\d]*$")
	@Schema(example = "1FTYR10U56PA26613", description = "vinCode")
	private String vinCode;
}
