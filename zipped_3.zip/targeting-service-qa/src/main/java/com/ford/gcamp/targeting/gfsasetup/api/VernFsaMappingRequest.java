package com.ford.gcamp.targeting.gfsasetup.api;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class VernFsaMappingRequest {

    private boolean fsaTypeChanged;

    @NotNull
    @Size(max = 2)
    @Pattern(regexp = "^[a-zA-Z\\d]*$")
    @Schema(example = "SC", description = "Safety Compliance")
    private String selectedGlobalFsaType;

    @Size(max = 8)
    @Pattern(regexp = "^[a-zA-Z\\d\\-]*$")
    @Schema(example = "TDHARTI", description = "updateId")
    private String updateId;

    @Min(0)
    @Max(Integer.MAX_VALUE)
    @Schema(example = "24",description = "gridYearId")
    private int gridYearId;

    @Min(0)
    @Max(Integer.MAX_VALUE)
    @Schema(example = "725",description = "gridSequence")
    private int gridSequence;

    @Min(0)
    @Max(Integer.MAX_VALUE)
    @Schema(example = "3",description = "implementationId")
    private int implementationId;

    @Min(0)
    @Max(Integer.MAX_VALUE)
    @Schema(example = "1",description = "version")
    private int version;

    @Schema(example = "00",description = "supplementId")
    @Size(max = 2, message = "length 1-2")
    @Pattern(regexp ="^|[A-Za-z\\d\\s]*$", message = "Supplement Code")
    private String supplementId;

    @Size(max = 40, message = "Max length 40")
    @Pattern(regexp ="^|[A-Za-z\\d\\-\\s]*$")
    @Schema(example = "24-725-3-V1-S0", description = "vernNumber")
    private String vernNumber;

    @Schema(example = "20458",description = "globalFSANumber")
    @Min(0)
    @Max(99999999)
    private int globalFSANumber;

    @Schema(example = "WM" , description = "modifyFsaType")
    @Size(max = 2)
    @Pattern(regexp ="^[A-Za-z\\d]*$")
    private String modifyFsaType;

    @Size(max = 20)
    @Pattern(regexp = "^|[a-zA-Z\\d\\-\\s]*$")
    @Schema(example = "05-Jun-2024", description = "FRC Decision Date")
    private String frcDecisionDate;

    private boolean frcDecisionDateChanged;
}
