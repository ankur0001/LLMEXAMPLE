package com.ford.gcamp.targeting.prelaunchreports;

import java.util.List;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class ReportsSelection {
	@Size(min = 0, max = 10)
	@Pattern(regexp = "^[\\d]*$")
	@Schema(example = "00", description = "report Count")
	private String reportCount;

	@Size(min = 0, max = 300, message = "Report List")
	private List<String> reportList;

	@Size(min = 0, max = 3)
	@Pattern(regexp = "^[a-zA-Z\\*\\s\\d]*$")
	@Schema(example = "CAN", description = "Country")
	private String country;

	@Size(min = 0, max = 1)
	@Pattern(regexp = "^[a-zA-Z]$")
	@Schema(example = "Y", description = "fsaLoadDataExists")
	private String fsaLoadDataExists;

	@Size(min = 0, max = 10)
	@Pattern(regexp = "^[a-zA-Z\\d]$")
	@Schema(example = "45", description = "wersreportCount")
	private String wersreportCount;

	@Size(min = 0, max = 300, message = "Wers Report List")
	private List<String> wersReportList;
}
