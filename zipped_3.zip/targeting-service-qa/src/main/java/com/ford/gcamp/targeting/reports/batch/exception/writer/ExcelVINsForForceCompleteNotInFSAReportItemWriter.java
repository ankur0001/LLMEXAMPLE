
package com.ford.gcamp.targeting.reports.batch.exception.writer;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import com.ford.gcamp.targeting.reports.batch.common.ReportGenerationUtil;
import org.apache.commons.collections4.ListUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.xssf.streaming.SXSSFSheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.item.Chunk;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.ford.gcamp.targeting.reports.batch.api.ExcelConfig;
import com.ford.gcamp.targeting.reports.batch.api.ReportMetaData;
import com.ford.gcamp.targeting.reports.batch.common.ReportCodeConstants;
import com.ford.gcamp.targeting.reports.batch.exception.GCAMPReportException;
import com.ford.gcamp.targeting.reports.batch.exception.api.TargetingExceptionReport;
import com.ford.gcamp.targeting.reports.batch.writer.GCAMPXSSFReportWriter;

@Component(ReportCodeConstants.T03 + "itemWriter")
@StepScope
public class ExcelVINsForForceCompleteNotInFSAReportItemWriter extends GCAMPXSSFReportWriter
		implements ItemWriter<TargetingExceptionReport> {

	private static final String VINS_FOR_FORCE_COMPLETE_NOT_IN_FSA = "VINs not in FSA";

	private List<TargetingExceptionReport> vinsForForceCompleteNotInFSAList;

	@Value("#{jobParameters['reportMetaData']}")
	private String reportMetaDataString;

	private ReportMetaData rptData;

	@Value("${exception.report.xlsx.maxrecords}")
	private int xlsxMaxRecords;

	@Override
	public void write(Chunk<? extends TargetingExceptionReport> items) throws Exception {
		rptData = ReportGenerationUtil.getReportMetaDataObject(reportMetaDataString);
		vinsForForceCompleteNotInFSAList = new ArrayList<>(items.getItems());
		this.createReport(rptData);
	}

	@Override
	public void createWorksheet(SXSSFWorkbook hssfWorkbook, ReportMetaData metaData) throws GCAMPReportException {

		initializeWorkbook(hssfWorkbook);

		List<List<TargetingExceptionReport>> vinsForForceCompleteNotInFSAs = ListUtils.partition(
				vinsForForceCompleteNotInFSAList,
				xlsxMaxRecords);
		List<ExcelConfig> vinsForForceCompleteNotInFSAConfigList = loadConfigFile(ReportCodeConstants.T03,
				metaData.getSuppCode());
		int index = 1;
		for (List<TargetingExceptionReport> vinsForForceCompleteNotInFSA : vinsForForceCompleteNotInFSAs) {

			SXSSFSheet sheet = hssfWorkbook
					.createSheet(vinsForForceCompleteNotInFSAList.size() > xlsxMaxRecords
							? VINS_FOR_FORCE_COMPLETE_NOT_IN_FSA + StringUtils.SPACE + index
							: VINS_FOR_FORCE_COMPLETE_NOT_IN_FSA);

			try {

				createProfile(sheet, metaData, "VINs Force Complete not in FSA");

				setColumnWidth(sheet, vinsForForceCompleteNotInFSAConfigList);

				setColumnHeader(sheet, vinsForForceCompleteNotInFSAConfigList);

				setRowData(sheet, vinsForForceCompleteNotInFSAConfigList, vinsForForceCompleteNotInFSA);

			} catch (Exception e) {
				throw new GCAMPReportException("Error in processing VINs For Force Complete not in FSA report ", e);
			}
			index++;
		}

	}

	public void setXlsxMaxRecords(int xlsxMaxRecords) {
		this.xlsxMaxRecords = xlsxMaxRecords;
	}

	public void setReportData(ReportMetaData metadata) {
		this.rptData = metadata;
	}

}
