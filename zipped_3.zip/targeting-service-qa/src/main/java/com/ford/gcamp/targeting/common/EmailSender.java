package com.ford.gcamp.targeting.common;

import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Component;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class EmailSender {

	@Value("${from-email-address}")
	private String fromEmailAddress;

	private JavaMailSender javaMailSender;

	@Autowired
	public EmailSender(JavaMailSender javaMailSender) {
		this.javaMailSender = javaMailSender;
	}

	public void sendMailToUsers(String[] toEmailAddresses, String[] ccEmailAddresses, String fromAddr, String subject,
			String body, boolean isHtmlBody) {
		try {
			MimeMessage message = javaMailSender.createMimeMessage();
			MimeMessageHelper helper = new MimeMessageHelper(message, true);

			if (StringUtils.isNotBlank(fromAddr)) {
				helper.setFrom(fromAddr);
			} else {
				helper.setFrom(fromEmailAddress);
			}

			helper.setTo(toEmailAddresses);
			if (StringUtils.isNoneBlank(ccEmailAddresses)) {
				helper.setCc(ccEmailAddresses);
			}
			helper.setSubject(subject);
			if(isHtmlBody) {
				helper.setText(body, isHtmlBody);
			} else {
				message.setContent(body, "text/plain");
				message.saveChanges();
			}
			javaMailSender.send(helper.getMimeMessage());
		} catch (MessagingException ex) {
			log.error("Error while sending email ", ex);
		}
	}

	
}
