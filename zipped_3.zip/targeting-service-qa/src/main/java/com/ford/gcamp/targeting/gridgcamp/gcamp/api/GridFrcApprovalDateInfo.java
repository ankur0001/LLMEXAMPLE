package com.ford.gcamp.targeting.gridgcamp.gcamp.api;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class GridFrcApprovalDateInfo {

	@NotNull
	@NotBlank(message = "FRC Approval Date is mandatory")
	@Schema(example = "2021-10-25")
	@Size(min = 10, max = 10, message = "length 1-10")
	private String frcApprovalDate;

	@Schema(example = "C")
	@Size(min = 0, max = 1, message = "length 1")
	@Pattern(regexp ="^[A-Za-z\\d]*$", message = "FSA Type")
	private String fsaType;


	@Schema(description = "supplementId")
	@Size(min = 1, max = 2, message = "length 1-2")
	@Pattern(regexp ="^[A-Za-z\\d]*$", message = "Supplement Code")
	private String supplementId;


	@Schema(description = "globalFSANumber")
	@Min(0)
	@Max(99999999)
	private int globalFSANumber;

	@Schema(description = "updateId")
	@Size(min = 0, max = 8, message = "Max length 8")
	@Pattern(regexp ="^[A-Za-z\\d]*$", message = "Update CDSId")
	private String updateId;
}
