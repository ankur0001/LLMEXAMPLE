package com.ford.gcamp.targeting.reports.batch;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import com.ford.gcamp.targeting.common.TargetingUtil;
import com.ford.gcamp.targeting.core.exception.GCAMPException;
import com.ford.gcamp.targeting.reports.batch.api.ReportMessageData;
import com.ford.gcamp.targeting.reports.batch.common.ReportConstants;
import com.ford.gcamp.targeting.reports.batch.exception.GCAMPReportException;
import com.ford.gcamp.targeting.reports.batch.mapper.ReportMessageDataMapper;

import lombok.extern.slf4j.Slf4j;

@Repository
@Slf4j
public class TargetingReportRepo {

	private String inputParam1;

	@Value("${DB_OWNER}")
	private String ownerId;
	@Value("${db2.uncommit.read}")
	private String withUR;

	private JdbcTemplate jdbcTemplate;

	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

	public TargetingReportRepo(JdbcTemplate jdbcTemplate, NamedParameterJdbcTemplate namedParameterJdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
		this.namedParameterJdbcTemplate = namedParameterJdbcTemplate;
	}

	@SuppressWarnings("unchecked")
	public List<ReportMessageData> getBMPCompletedJobs() throws GCAMPException {
		String procedureName = ReportConstants.COMPLETED_JOBS_STORE_PROC;
		StringBuilder builder = new StringBuilder();
		builder.append(ReportConstants.BMP_FLAG);
		builder.append(TargetingUtil.addSpaceToProc(5));
		builder.append(TargetingUtil.addZerosToProc(18));
		builder.append(TargetingUtil.addSpaceToProc(19));
		builder.append(TargetingUtil.addZerosToProc(5));
		builder.append(TargetingUtil.addSpaceToProc(12));
		inputParam1 = builder.toString();
		log.info("The INPUT PARM for {} is {}", procedureName, inputParam1);
		return (List<ReportMessageData>) this.executeProcedure(procedureName);
	}

	private Object executeProcedure(String procedureName) throws GCAMPException {

		Map<String, Object> outputMap;
		SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withSchemaName("SYSPROC")
				.withProcedureName(procedureName).returningResultSet("joblist", new ReportMessageDataMapper());

		// Set Input Parameters
		SqlParameterSource sqlParameterSource = new MapSqlParameterSource().addValue("INPUT_PARM1", inputParam1);

		// execute the procedure
		try {
			outputMap = simpleJdbcCall.execute(sqlParameterSource);
		} catch (Exception e) {
			throw new GCAMPException("Error in executing procedure: ", e);
		}

		return outputMap.get("joblist");

	}

	public List<String> getReportCodes(String reportId, String reportCode) throws GCAMPReportException {
		MapSqlParameterSource inQueryParams = new MapSqlParameterSource();

		StringBuilder sql = new StringBuilder();
		sql.append("SELECT DISTINCT F02.GCPF04_REPORT_C ");
		sql.append(ReportConstants.FROM_KEYWORD);
		sql.append(ownerId);
		sql.append("SGCPF02_RPTCHILD F02, ");
		sql.append(ownerId);
		sql.append("SGCPF04_REPORT F04 ");
		sql.append(" WHERE   ");
		sql.append(" F02.GCPF01_REPORT_ID_D=");
		sql.append(ReportConstants.REPORT_ID);
		sql.append(ReportConstants.AND_KEYWORD);
		sql.append(" F02.GCPF04_REPORT_C NOT IN  (");
		sql.append(":reportCode");
		sql.append(",'");
		sql.append("IAD");
		sql.append("')");
		sql.append(ReportConstants.AND_KEYWORD);
		sql.append(" F04.GCPF04_REPORT_C = F02.GCPF04_REPORT_C ");
		sql.append(ReportConstants.AND_KEYWORD);
		sql.append(" F04.GCPF04_RPT_GROUP_C = 'TR' ");
		sql.append(" ORDER BY F02.GCPF04_REPORT_C ");
		sql.append(withUR);

		inQueryParams.addValue("reportCode", reportCode).addValue("reportId", Integer.parseInt(reportId));

		log.info("The SQL is {}", sql);

		return namedParameterJdbcTemplate.query(sql.toString(), inQueryParams, new RowMapper<String>() {
			public String mapRow(ResultSet rs, int rowNum) throws SQLException {
				return StringUtils.trimToEmpty(rs.getString(1));
			}
		});

	}

	public String getWERSDescription(String wersCode) {
		MapSqlParameterSource inQueryParams = new MapSqlParameterSource();

		StringBuilder sql = new StringBuilder();
		sql.append("SELECT GCPD02_FILTER_X ");
		sql.append(ReportConstants.FROM_KEYWORD);
		sql.append(ownerId);
		sql.append("SGCPD02_FILTER ");
		sql.append(" WHERE  ");
		sql.append(" GCPD02_FILTER_C = :wersCode ");
		sql.append(withUR);

		inQueryParams.addValue("wersCode", wersCode);

		return namedParameterJdbcTemplate.queryForObject(sql.toString(), inQueryParams, String.class);

	}

}
