package com.ford.gcamp.targeting.fsacriteria.entity;


import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.IdClass;
import jakarta.persistence.Table;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Entity
@IdClass(HubRoiLookupId.class)
@Table(name = "SGCPE11_HUB_ROI")
public class HubRoiLookup implements Serializable {

	private static final long serialVersionUID = 1L;
	@Id
	@Column(name = "GCPE11_ROI_C")
	private String roiCode;
	@Id
	@Column(name = "GCPE10_HUB_C")
	private String hubCode;

	@Column(name = "GCPE11_ROI_DESC_X")
	private String roiDescription;

}
