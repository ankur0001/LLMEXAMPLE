package com.ford.gcamp.targeting.common.api;


import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class SuppPopulationVo {
	@NotNull
	@Size(min = 2, max = 2)
	@Pattern(regexp = "^[a-zA-Z\\d]*$")
	@Schema(example = "AA", description = "Population")
	private String supCode;

	@Size(min = 0, max = 100)
	@Pattern(regexp = "^[a-zA-Z\\d\\-\\s]*$")
	@Schema(example = "AA-aa", description = "Population Description")
	private String supDesc;

	@NotNull
	@Size(min=1, max =1)
	@Pattern(regexp = "^[a-zA-Z]")
	@Schema(example = "C", description = "FSA Number status")
	private String fsaStatus;
	
}
