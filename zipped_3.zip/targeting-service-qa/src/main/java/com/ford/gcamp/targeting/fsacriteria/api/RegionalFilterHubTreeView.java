package com.ford.gcamp.targeting.fsacriteria.api;

import java.util.List;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Builder
public class RegionalFilterHubTreeView {
    @NotNull
	@Size(min = 1, max = 2)
	@Pattern(regexp = "^[A-Z\\*\\s]{1,2}$")
	@Schema(example = "NA", description = "Hub Code")
	private String hubCode;

	@Pattern(regexp = "^[a-zA-Z\\s&]*$")
	@Size(min=0, max =30)
	@Schema(example = "FORD NORTH AMERICA", description = "Hub code")
	private String label;

	@Size(min = 0, max = 500)
	private List<@Valid RegionalFilterRoiTreeView> children;
}
