package com.ford.gcamp.targeting.fsacriteria.entity;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.IdClass;
import jakarta.persistence.Table;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Entity
@IdClass(StateProvinceId.class)
@Table(name = "SDPMA02_STPR")
public class StateProvinceLookup implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name = "STPR_STATE_C")
	private String stateCode;
	
	@Id
	@Column(name = "COUNTRY_ISO3_C")
	private String countryCode;
	
	@Column(name = "STPR_NAME_X")
	private String description;
	
}
