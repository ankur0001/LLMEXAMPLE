package com.ford.gcamp.targeting.fsacriteria.api;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.ford.gcamp.targeting.gridgcamp.gcamp.api.VinAttachment;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.SuperBuilder;

import java.util.List;

@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
@ToString
@JsonIgnoreProperties(ignoreUnknown = true)
public class FsaVinCriteriaRequest{

    private boolean automationFlag;
    private boolean criteriaFlag;
    private List<FsaCriteriaSaveParam> fsaCriteriaRequestList;
}
