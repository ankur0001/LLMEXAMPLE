package com.ford.gcamp.targeting.fsacriteria.api;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class BrandVO extends FsaVehicleCommonVO {

	@Size(min = 0, max = 10)
	@Pattern(regexp = "^|[a-zA-Z\\d\\s]*$")
	@Schema(example = "000000002", description = "brandFilterCode")
	private String brandFilterCode;

	@Size(min = 0, max = 2)
	@Pattern(regexp = "^|[a-zA-Z\\d\\s]*$")
	@Schema(example = "F", description = "brandFilterCode")
	private String brandCode;

	@Size(min = 0, max = 250)
	@Pattern(regexp = "^|[a-zA-Z\\d\\s().,\\-\\_]*$")
	@Schema(example = "FORD", description = "brandFilterCode")
	private String brandName;
	
	
}
