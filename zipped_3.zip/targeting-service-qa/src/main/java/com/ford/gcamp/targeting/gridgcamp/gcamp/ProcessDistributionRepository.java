package com.ford.gcamp.targeting.gridgcamp.gcamp;

import com.ford.gcamp.targeting.gridgcamp.gcamp.entity.ProcessDistributionMapEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ProcessDistributionRepository extends JpaRepository<ProcessDistributionMapEntity, Integer> {

    ProcessDistributionMapEntity findByHubAndDistributionProcessEntitiesProcessInfo(String hub, String processInfo);

}
