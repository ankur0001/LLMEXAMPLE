package com.ford.gcamp.targeting.prelaunchreports;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class Distributions {

	private String distListId;
	private String processCode;
	private String countryCode;
	private String defaultFlag;
	private String countryName;
	private String distListName;
	private String processDesc;
}
