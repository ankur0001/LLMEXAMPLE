package com.ford.gcamp.targeting.gridgcamp.gcamp;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.ford.gcamp.targeting.gridgcamp.gcamp.entity.GridVernData;
import com.ford.gcamp.targeting.gridgcamp.gcamp.entity.GridVernId;

@Repository
public interface GridGCampRepository extends JpaRepository<GridVernData, GridVernId>, JpaSpecificationExecutor<GridVernData> {

	public List<GridVernData> findByInitiatingHub(String hubCode);

	public List<GridVernData> findByGlobalFSANumberOrderByGridVernIdVersionDesc(int globalFsaNumber);

	@Query(value = "select grid from GridVernData grid where grid.gridVernId.gridYearId =?1 and grid.gridVernId.gridSequence = ?2 and grid.gridVernId.implementationId = ?3")
	public List<GridVernData> findByGridVernId(int gridYearId, int gridSequence, int implementationId);

	@Query(value = "select grid from GridVernData grid where grid.initiatingHub in (?1) and grid.globalFSANumber = 0 and "
			+ "grid.gridVernId.version = (select MAX(grid2.gridVernId.version) from GridVernData grid2 where grid2.gridVernId.gridYearId = grid.gridVernId.gridYearId "
			+ "and grid2.gridVernId.gridSequence = grid.gridVernId.gridSequence and grid2.gridVernId.implementationId = grid.gridVernId.implementationId) "
			+ "order by grid.requestDate desc")
	public List<GridVernData> findByHub(List<String> hubCodes);

	@Query(value = "select grid from GridVernData grid where grid.globalFSANumber =?1 and grid.gridVernId.supplementId = ?2 and grid.initiatingHub in (?3) order by grid.gridVernId.version desc")
	public List<GridVernData> findByGlobalFSANumberAndSupplementCode(int globalFSANumber, String supplementCode,
			List<String> hubCodes);

	@Query(value = "select grid from GridVernData grid where grid.globalFSANumber =?1 and grid.gridVernId.supplementId = ?2 order by grid.gridVernId.version desc")
	public List<GridVernData> findByGlobalFSANumberAndSupplementCode(int globalFSANumber, String supplementCode);

	@Query(value = "select grid from GridVernData grid where grid.initiatingHub in (?1) and grid.globalFSANumber =?2 and grid.gridVernId.supplementId !='00' and grid.fsaAssignedFlag = 'N' "
			+ "and grid.gridVernId.version = (select MAX(grid2.gridVernId.version) from GridVernData grid2 where grid.initiatingHub = grid2.initiatingHub and grid.globalFSANumber = grid2.globalFSANumber and grid2.gridVernId.supplementId = grid.gridVernId.supplementId) "
			+ "order by  grid.gridVernId.supplementId desc")
	public List<GridVernData> findGridVernInfoSupplements(List<String> hubCodes, int globalFSANumber);

	@Query(value = "select grid from GridVernData grid where grid.globalFSANumber =?1 and grid.gridVernId.supplementId = ?2 and grid.fsaAssignedFlag = 'Y'")
	public GridVernData getAssignedGridVernInfoBySupplement(int globalFSANumber, String supplementCode);

	@Query(value = "select grid from GridVernData grid where grid.globalFSANumber =?1 and grid.gridVernId.supplementId !='00' and grid.fsaAssignedFlag = 'Y'")
	public List<GridVernData> getAssignedGridVernInfoByFSANumber(int globalFSANumber);

	@Query(value = "select grid from GridVernData grid where grid.vernStatusDesc != '' or grid.vfdRequestStatus = 'PROCESSED'")
	public List<GridVernData> getAssignedGridVernInfoByStatus();

	public List<GridVernData> findByVfdRequestStatus(String vfdRequestStatus);

	public Optional<GridVernData> findByGridVernIdAndIsTandem(GridVernId gridVernId, String tandemFlag);

	Optional<GridVernData> findByGlobalFSANumberAndGridVernId_SupplementIdAndFsaAssignedFlag(int globalFsaNumber, String supplementId, String fsaAssignedFlag);
}
