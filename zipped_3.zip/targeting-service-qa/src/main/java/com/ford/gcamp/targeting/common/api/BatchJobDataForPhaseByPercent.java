package com.ford.gcamp.targeting.common.api;

import org.springframework.stereotype.Component;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Component
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class BatchJobDataForPhaseByPercent {

    @SuppressWarnings("unused")
    private static final long serialVersionUID = -4639041037014306027L;
    private String batchCode;
    private int globalFSANo;
    private String localFSANo;
    private String hubCode;
    private String countryCode;
    private String cdsId;
    private String emailIndicator;
    // All segments
    private int segment = 9999;
    private String supplement;
    private String parameters;
    private int jobId;
    private String jobName;
    // for all jobs except for project A it will be Q
    private String jobStatus = "";
    private String fileName;
    private String requestTime;
    private String folderId = "999";
    private String vin;
    private String assignCode;

    //input params 2 for phase by percent screen
    private String supplementCounts;
    private String brandCounts;
    private String vehicleLineCounts;
    private String modelYearsCounts;
    private String stateCounts;
    private String countryCounts;
    private String states;
    private String brands;
    private String vehicleLines;
    private String modelYears;

    private static final int INPUT_LENGTH1 = 100;
    private static final int INPUT_LENGTH2 = 32000;




    public String getInputString1() {

        LayoutBuffer layout = new LayoutBuffer(INPUT_LENGTH1);

        layout.addField(LayoutBuffer.FIELDTYPE_PICX, 3);
        layout.addField(LayoutBuffer.FIELDTYPE_PIC9, 8);
        layout.addField(LayoutBuffer.FIELDTYPE_PICX, 10);
        layout.addField(LayoutBuffer.FIELDTYPE_PICX, 2);
        layout.addField(LayoutBuffer.FIELDTYPE_PICX, 3);
        layout.addField(LayoutBuffer.FIELDTYPE_PICX, 8);
        addPicXOnefield(layout);
        layout.addField(LayoutBuffer.FIELDTYPE_PIC9, 5);
        layout.addField(LayoutBuffer.FIELDTYPE_PICX, 2);
        addPicXOnefield(layout);
        addPicXOnefield(layout);
        layout.addField(LayoutBuffer.FIELDTYPE_PIC9, 2);
        addPicXOnefield(layout);
        addPicXOnefield(layout);
        layout.addField(LayoutBuffer.FIELDTYPE_PIC9, 3);
        layout.addField(LayoutBuffer.FIELDTYPE_PICX, 17);
        layout.addField(LayoutBuffer.FIELDTYPE_PICX, 32);

        layout.setString(0, this.getBatchCode());
        layout.setString(1, Integer.toString(this.getGlobalFSANo()));
        layout.setString(2, this.getLocalFSANo());
        layout.setString(3, this.getHubCode());
        layout.setString(4, this.getCountryCode());
        layout.setString(5, this.getCdsId());
        layout.setString(6, this.getEmailIndicator());
        layout.setString(7, Integer.toString(this.getSegment()));
        layout.setString(8, this.getSupplement());
        // batch group blank rt now
        layout.setString(9, " ");
        // job status "" in most "Q" for project-A CTS queued jobs
        layout.setString(10, this.getJobStatus());
        layout.setString(11, "");
        layout.setString(12, "");
        layout.setString(13, this.getAssignCode());
        layout.setString(14, this.getFolderId());
        layout.setString(15, this.getVin());
        layout.setString(16, "");

        return layout.toString();
    }

    private void addPicXOnefield(LayoutBuffer layout) {
        layout.addField(LayoutBuffer.FIELDTYPE_PICX, 1);

    }

    public String getInputString2() {

        LayoutBuffer layout = new LayoutBuffer(INPUT_LENGTH2);

        layout.addField(LayoutBuffer.FIELDTYPE_PICX,4);
        layout.addField(LayoutBuffer.FIELDTYPE_PICX,2);
        layout.addField(LayoutBuffer.FIELDTYPE_PIC9, 3);
        layout.addField(LayoutBuffer.FIELDTYPE_PICX,202);
        layout.addField(LayoutBuffer.FIELDTYPE_PIC9, 3);
        layout.addField(LayoutBuffer.FIELDTYPE_PICX, 600);
        layout.addField(LayoutBuffer.FIELDTYPE_PIC9, 3);
        layout.addField(LayoutBuffer.FIELDTYPE_PICX, 400);
        layout.addField(LayoutBuffer.FIELDTYPE_PIC9, 2);
        layout.addField(LayoutBuffer.FIELDTYPE_PICX, 15);
        layout.addField(LayoutBuffer.FIELDTYPE_PIC9, 2);
        layout.addField(LayoutBuffer.FIELDTYPE_PICX, 90);
        layout.addField(LayoutBuffer.FIELDTYPE_PIC9, 3);
        layout.addField(LayoutBuffer.FIELDTYPE_PICX, 400);
        layout.addField(LayoutBuffer.FIELDTYPE_PICX, 30268);
        int remainingLength = INPUT_LENGTH2 - 1737;
        layout.addField(LayoutBuffer.FIELDTYPE_PICX, remainingLength);

        layout.setString(0, this.getParameters());
        layout.setString(1, this.getHubCode());
        layout.setString(2, this.getSupplementCounts());
        layout.setString(3, this.getSupplement());
        layout.setString(4, this.getCountryCounts());
        layout.setString(5, this.getCountryCode());
        layout.setString(6, this.getStateCounts());
        layout.setString(7, this.getStates());
        layout.setString(8, this.getBrandCounts());
        layout.setString(9, this.getBrands());
        layout.setString(10, this.getVehicleLineCounts());
        layout.setString(11, this.getVehicleLines());
        layout.setString(12, this.getModelYearsCounts());
        layout.setString(13, this.getModelYears());
        return layout.toString();
    }

}