package com.ford.gcamp.targeting.common.api;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class FSANumberVO implements java.io.Serializable {


	private static final long serialVersionUID = 1L;
	
  private String fsaNumber = "";
  private String fsaDescription = ""; 
  private GenericLookup hub = new GenericLookup();
  private String fsaFormatType = ""; 
  private String fsaStatus = "";

  public void setString(String str, int size) {

      LayoutBuffer layoutBuffer = new LayoutBuffer(size);

      //FSA Number
      layoutBuffer.addField(LayoutBuffer.FIELDTYPE_PICX, 10);

      //FSA Format Type
      layoutBuffer.addField(LayoutBuffer.FIELDTYPE_PICX, 1);

      //Hub Code
      layoutBuffer.addField(LayoutBuffer.FIELDTYPE_PICX, 2);

      //Hub Description
      layoutBuffer.addField(LayoutBuffer.FIELDTYPE_PICX, 30);

      //FSA Description
      layoutBuffer.addField(LayoutBuffer.FIELDTYPE_PICX, 254);

      //FSA Status
      layoutBuffer.addField(LayoutBuffer.FIELDTYPE_PICX, 1);

      //Filler
      layoutBuffer.addField(LayoutBuffer.FIELDTYPE_PICX, size - FSAInfoVO.LOCAL_FSA_LAYOUT_SIZE + 2);

      layoutBuffer.fromString(str);

      this.setFsaNumber(layoutBuffer.getString(0));
      this.setFsaFormatType(layoutBuffer.getString(1));
      this.setHub(
          new GenericLookup(layoutBuffer.getString(2), layoutBuffer.getString(3)));
      this.setFsaDescription(layoutBuffer.getString(4));
      this.setFsaStatus(layoutBuffer.getString(5));
  }

  public String toString() {

      return "\n\n\nFSA="
          + this.getFsaNumber()
          + "\nIND="
          + this.getFsaFormatType()
          + "\nHUB="
          + this.hub.getCode()
          + "\nDESC="
          + this.hub.getDescription()
          + "\nFSADESC="
          + this.getFsaDescription()
          + "\nFSAStatus="
          + this.getFsaStatus();
  }
	

}