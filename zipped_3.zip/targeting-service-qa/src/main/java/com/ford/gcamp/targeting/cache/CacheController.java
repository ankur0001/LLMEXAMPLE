package com.ford.gcamp.targeting.cache;


import com.ford.cloudnative.base.api.StandardErrorResponse;
import com.ford.gcamp.targeting.common.api.CommonErrorResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping(path = "/api/v1/targeting/cache")
@Validated
public class CacheController {

	@Autowired
	private CachingService cachingService;


	@Operation(summary = "Clear All Cache", security = {
			@SecurityRequirement(name = "ADFS"),
			@SecurityRequirement(name = "AzureAD")
	})
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Clearing Cache request processed successfully"),
			@ApiResponse(responseCode = "400", description = "Bad Request, missing required fields"),
			@ApiResponse(responseCode = "401", description = "Unauthorized"),
			@ApiResponse(responseCode = "403", description = "Forbidden"),
			@ApiResponse(responseCode = "404", description = "Not Found"),
			@ApiResponse(responseCode = "405", description = "Invalid Method type"),
			@ApiResponse(responseCode = "412", description = "Precondition Failed", content = @Content(schema = @Schema(implementation = CommonErrorResponse.class))),
			@ApiResponse(responseCode = "415", description = "Unsupported Media Type"),
			@ApiResponse(responseCode = "428", description = "Bad Request, missing required fields"),
			@ApiResponse(responseCode = "429", description = "Too many bad request"),
			@ApiResponse(responseCode = "500", description = "Internal Server Error"),
			@ApiResponse(responseCode = "412", description = "Precondition Failed", content = @Content(schema = @Schema(implementation = CommonErrorResponse.class))),
			@ApiResponse(responseCode = "default", description = "All Errors", content = @Content(schema = @Schema(implementation = StandardErrorResponse.class)))
	})
	@GetMapping(value = "/clearAllCache")
	public void clearAllCaches() {
		cachingService.evictAllCache();
	}


	@Operation(summary = "Clear Particular Cache" , security = {
			@SecurityRequirement(name = "ADFS"),
			@SecurityRequirement(name = "AzureAD")
	})
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Cache request processed successfully"),
			@ApiResponse(responseCode = "400", description = "Bad Request, missing required fields"),
			@ApiResponse(responseCode = "401", description = "Unauthorized"),
			@ApiResponse(responseCode = "403", description = "Forbidden"),
			@ApiResponse(responseCode = "404", description = "Not Found"),
			@ApiResponse(responseCode = "405", description = "Invalid Method type"),
			@ApiResponse(responseCode = "412", description = "Precondition Failed", content = @Content(schema = @Schema(implementation = CommonErrorResponse.class))),
			@ApiResponse(responseCode = "415", description = "Unsupported Media Type"),
			@ApiResponse(responseCode = "428", description = "Bad Request, missing required fields"),
			@ApiResponse(responseCode = "429", description = "Too many bad request"),
			@ApiResponse(responseCode = "500", description = "Internal Server Error"),
			@ApiResponse(responseCode = "412", description = "Precondition Failed", content = @Content(schema = @Schema(implementation = CommonErrorResponse.class))),
			@ApiResponse(responseCode = "default", description = "All Errors", content = @Content(schema = @Schema(implementation = StandardErrorResponse.class)))
	})
		@GetMapping(value = "/clearCache/{cacheName}")
	public void clearSingleCache(@PathVariable("cacheName") @Valid @NotNull @Size(min=1, max=30) @Pattern(regexp = "^[A-Za-z\\s]*$") @Schema(example = "getFscFormDetails", description = "Cacheable data") String cacheName) {
		cachingService.evictSingleCache(cacheName);
	}


	@Operation(summary = "Refresh FSA Criteria", security = {
			@SecurityRequirement(name = "ADFS"),
			@SecurityRequirement(name = "AzureAD")
	})
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Cache request processed successfully"),
			@ApiResponse(responseCode = "400", description = "Bad Request, missing required fields"),
			@ApiResponse(responseCode = "401", description = "Unauthorized"),
			@ApiResponse(responseCode = "403", description = "Forbidden"),
			@ApiResponse(responseCode = "404", description = "Not Found"),
			@ApiResponse(responseCode = "405", description = "Invalid Method type"),
			@ApiResponse(responseCode = "412", description = "Precondition Failed", content = @Content(schema = @Schema(implementation = CommonErrorResponse.class))),
			@ApiResponse(responseCode = "415", description = "Unsupported Media Type"),
			@ApiResponse(responseCode = "428", description = "Bad Request, missing required fields"),
			@ApiResponse(responseCode = "429", description = "Too many bad request"),
			@ApiResponse(responseCode = "500", description = "Internal Server Error"),
			@ApiResponse(responseCode = "412", description = "Precondition Failed", content = @Content(schema = @Schema(implementation = CommonErrorResponse.class))),
			@ApiResponse(responseCode = "default", description = "All Errors", content = @Content(schema = @Schema(implementation = StandardErrorResponse.class)))
	})
	@GetMapping(value = "/refreshFsaCriteria")
	public void loadFsaCriteria() {
		cachingService.refreshFsaCriteria();
	}
}
