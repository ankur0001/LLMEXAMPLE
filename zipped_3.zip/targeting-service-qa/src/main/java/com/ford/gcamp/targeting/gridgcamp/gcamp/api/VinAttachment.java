package com.ford.gcamp.targeting.gridgcamp.gcamp.api;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;

import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class VinAttachment {


	@Schema(description = "type")
	@Size(min = 1, max = 15, message = "Max length 15")
	@Pattern(regexp ="^[A-Za-z\\s]*$", message = "Type Value invalid")
	private String type;


	@Schema(description = "filePath")
	@Size(min = 1, max = 250, message = "length 50")
	@Pattern(regexp ="^[A-Za-z\\d\\s,.#_\\-/{}()]*$", message = "File Path invalid")
	private String filePath;


	@Schema(description = "fileName")
	@Size(min = 5, max = 250, message = "length 50")
	@Pattern(regexp ="^[A-Za-z\\d\\s,.#_\\-()]*$", message = "File Name invalid")
	private String fileName;


	@Schema(description = "action",minLength = 0,maxLength = 10)
	@Size(min = 0, max = 10, message = "length 10")
	@Pattern(regexp ="^[A-Za-z]*$", message = "Action value invalid")
	private String action;


	@Schema(description = "deletedVernNumber",minLength = 0,maxLength = 20)
	@Size(min = 0, max = 20, message = "length 20")
	@Pattern(regexp ="^|([A-Za-z0-9-]*$)", message = "Delete Vern number invalid")
	private String deletedVernNumber;


	@Schema(description = "addedVernNumber",minLength = 0,maxLength = 20)
	@Size(min = 0, max = 20, message = "length 20")
	@Pattern(regexp ="^[A-Za-z0-9-]*$", message = "Added vern number invalid")
	private String addedVernNumber;


	@Min(0)
	@Max(Integer.MAX_VALUE)
	private int vinCount;
}
