package com.ford.gcamp.targeting.fsacriteria.api;

import java.util.List;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import org.springframework.stereotype.Component;

import lombok.Getter;
import lombok.Setter;

@Component
@Getter
@Setter
public class LoadSelectCounValDTO {
	@Size(min = 0, max = 250, message = "List Hub data")
	private List<@Valid HubData> listHubData;

	public LoadSelectCounValDTO() {

	}
	
	public LoadSelectCounValDTO(List<HubData> listHubData) throws UnsupportedOperationException{
		//A public constructor - Sonar fix
	}

	
}
