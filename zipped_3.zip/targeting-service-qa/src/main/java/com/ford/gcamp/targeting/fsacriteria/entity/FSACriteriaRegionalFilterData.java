package com.ford.gcamp.targeting.fsacriteria.entity;

import java.sql.Timestamp;
import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.NotFound;
import org.hibernate.annotations.NotFoundAction;
import org.hibernate.annotations.UpdateTimestamp;
import com.ford.gcamp.targeting.gridgcamp.grid.entity.CountryLookupData;
import com.ford.gcamp.targeting.gridgcamp.grid.entity.HubLookupData;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Entity
@Builder
@Table(name = "SGCPD24_SLCN_ROI_CNTRY")
@NoArgsConstructor
@AllArgsConstructor
public class FSACriteriaRegionalFilterData {
	@EmbeddedId
	private RegionalFilterId regionalFilterId;

	@Column(name = "GCPE10_HUB_C")
	private String hubCode;

	@Column(name = "GCPE11_ROI_C")
	private String roiCode;

	@Column(name = "COUNTRY_ISO3_C")
	private String countryCode;

	@Column(name = "GCPA32_REG_GRP_C")
	private String geographicCode;

	@Column(name = "STPR_STATE_C")
	private String stateCode;

	@Column(name = "GCPD24_UPDATE_ID_C")
	private String updateId;
	@Setter(AccessLevel.NONE)
	@Getter(AccessLevel.NONE)
	@Column(name = "GCPD24_UPDATE_S")
	@UpdateTimestamp
	private Timestamp updateDate;

	@JoinColumn(name = "GCPE10_HUB_C", insertable = false, updatable = false)
	@OneToOne
	@NotFound(action = NotFoundAction.IGNORE)
	private HubLookupData hub;

	@JoinColumn(name = "GCPE11_ROI_C", referencedColumnName = "GCPE11_ROI_C", insertable = false, updatable = false)
	@JoinColumn(name = "GCPE10_HUB_C", referencedColumnName = "GCPE10_HUB_C", insertable = false, updatable = false)
	@OneToOne
	@NotFound(action = NotFoundAction.IGNORE)
	private HubRoiLookup roi;

	@JoinColumn(name = "COUNTRY_ISO3_C", insertable = false, updatable = false)
	@OneToOne
	@NotFound(action = NotFoundAction.IGNORE)
	private CountryLookupData country;

	@JoinColumn(name = "GCPA32_REG_GRP_C", insertable = false, updatable = false)
	@OneToOne
	@NotFound(action = NotFoundAction.IGNORE)
	private GeographicLookup geoGraphichData;

	@JoinColumn(name = "COUNTRY_ISO3_C", referencedColumnName = "COUNTRY_ISO3_C", insertable = false, updatable = false)
	@JoinColumn(name = "STPR_STATE_C", referencedColumnName = "STPR_STATE_C", insertable = false, updatable = false)
	@OneToOne
	@NotFound(action = NotFoundAction.IGNORE)
	private StateProvinceLookup stateProvinceData;

	@JoinColumn(name = "GCPA15_GLOBL_FSA_R", referencedColumnName = "GCPA15_GLOBL_FSA_R", insertable = false, updatable = false)
	@JoinColumn(name = "GCPD22_VINGP_LBL_C", referencedColumnName = "GCPD22_VINGP_LBL_C", insertable = false, updatable = false)
	@OneToOne
	@NotFound(action = NotFoundAction.IGNORE)
	private VinGroupLookup vinGroupLookup;

}
