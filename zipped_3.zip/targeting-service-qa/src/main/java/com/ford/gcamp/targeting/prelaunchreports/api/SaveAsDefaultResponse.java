package com.ford.gcamp.targeting.prelaunchreports.api;

import com.ford.gcamp.targeting.common.api.CommonResponse;
import com.ford.gcamp.targeting.prelaunchreports.ReportsSelection;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@EqualsAndHashCode(callSuper=false)
public class SaveAsDefaultResponse extends CommonResponse{

	private ReportsSelection reportSelection;
}
