package com.ford.gcamp.targeting.gfsasetup.api;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class GfsaType {
	@NotNull
	@Size(min = 0, max = 2)
	@Pattern(regexp = "^[a-zA-Z\\d]*$")
	@Schema(example = "SC", description = "code")
	private String code;

	@NotNull
	@Size(min = 0, max = 30)
	@Pattern(regexp = "^[a-zA-Z\\d\\s\\-\\(\\)]*$")
	@Schema(example = "SAFETY COMPLIANCE", description = "label")
	private String label;

	@NotNull
	@Size(min = 0, max = 1)
	@Pattern(regexp = "^[a-zA-Z\\d]$")
	@Schema(example = "P", description = "Fsa Dependency Type")
	private String fsaDependencyType;
}
