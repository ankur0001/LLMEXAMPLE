package com.ford.gcamp.targeting.common.api;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class VinGroupDetail {


	@Size(min = 0, max = 2)
	@Pattern(regexp = "^[A-Za-z\\d\\s\\*]*$")
	@Schema(example = "**", description = "Vin Group Code")
	private String vinGroupCode;

	@Size(min = 0, max = 254)
	@Pattern(regexp = "^[a-zA-Z\\d\\s&().,\\-\\_\\&*']*$")
	@Schema(example = "label", description = "Country Description")
	private String label;

	@Min(0)
	@Max(99999999)
	@Schema(example = "78", description = "Count")
	private int count;
}
