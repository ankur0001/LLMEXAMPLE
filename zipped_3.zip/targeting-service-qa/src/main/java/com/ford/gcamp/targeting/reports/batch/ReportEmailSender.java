package com.ford.gcamp.targeting.reports.batch;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.ford.gcamp.targeting.common.EmailSender;
import com.ford.gcamp.targeting.common.LDAPModel;
import com.ford.gcamp.targeting.core.exception.GCAMPException;
import com.ford.gcamp.targeting.reports.batch.api.ReportMetaData;
import com.ford.gcamp.targeting.reports.batch.common.ReportConstants;
import com.ford.gcamp.targeting.reports.batch.common.ReportStandardConstants;
import com.ford.gcamp.targeting.reports.batch.exception.GCAMPReportDB2Exception;
import com.ford.gcamp.targeting.reports.batch.exception.GCAMPReportException;
import com.ford.gcamp.targeting.user.UserService;
import com.nimbusds.oauth2.sdk.util.CollectionUtils;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class ReportEmailSender {

	private ReportEmailRepo reportEmailRepo;

	private UserService userService;

	@Value("${report.url}")
	private String reportUrl;

	@Value("${system.email.address}")
	private String systemEmail;
	
	private EmailSender sender;
	
	private List<Integer> errorEmailSentList = new ArrayList<>();

	public ReportEmailSender(ReportEmailRepo reportEmailRepo, UserService userService, EmailSender sender) {
		super();
		this.reportEmailRepo = reportEmailRepo;
		this.userService = userService;
		this.sender = sender;
	}

	public void checkIfEmailCanBeSent(ReportMetaData reportMetaData) {
		reportMetaData.setActionType(ReportStandardConstants.RETRIEVE);
		try {
			getEmailData(reportMetaData);
			String str = getErrorEmailCount(reportMetaData.getRptId());
			if (str.length() > 0 && !ReportConstants.ALL_POPULATION.equalsIgnoreCase(reportMetaData.getSuppCode())) {
				log.info("Preparing to send error email for FSA number {}", reportMetaData.getGlobalFSANum());
				sendErrorEmail(reportMetaData, str);
			}
			int goodCount = getGoodMailCount(reportMetaData.getRptId());
			reportMetaData.setEmailCount(goodCount);
			if (goodCount > 0 && ReportConstants.ALL_POPULATION.equalsIgnoreCase(reportMetaData.getSuppCode())) {
				updateReportCompletionFlag(reportMetaData);
			} else if (goodCount > 0 && StringUtils.isNotBlank(reportMetaData.getEmailSubject())) {
				log.info("Preparing to send good email for FSA number {}", reportMetaData.getGlobalFSANum());
				sendGoodEmail(reportMetaData);
			}

		} catch (Exception e) {
			log.error("Error in sending email ", e);
		}

	}

	public void sendGoodEmail(ReportMetaData metaData) throws GCAMPReportException {
		StringBuilder subject = new StringBuilder();
		StringBuilder appendUrl = new StringBuilder();
		StringBuilder actualLinkUrl = new StringBuilder();
		StringBuilder targetUrl = new StringBuilder();
		StringBuilder bodyURL = new StringBuilder();
		String urlString;

		String userCDSID = metaData.getReqById();
		Optional<LDAPModel> ldap = userService.getByCDSId(userCDSID);

		StringBuilder submittedBy = new StringBuilder(ReportConstants.SUBMITTED_BY);

		if ("SFI".equalsIgnoreCase(metaData.getRptCode())) {
			submittedBy.append(ReportConstants.REPORT_SERVICE);
		} else if (ldap.isPresent()) {
			log.info("Report Submitted By {}", userCDSID);
			submittedBy.append(ldap.get().getFordDisplayName());
		}

		String[] cc = new String[1];
		if (StringUtils.isNotBlank(userCDSID)) {
			cc[0] = userCDSID.concat(ReportConstants.FORD_EMAIL_DOMAIN);
		} else {
			cc[0] = systemEmail;
		}

		final String PASTE_LINK_TEXT = "</a><br>If you have difficulty getting to the above link, Please paste the following link in your browser<br>";
		String emailSubject = StringUtils.isNotBlank(metaData.getEmailSubject()) ? metaData.getEmailSubject()
				: "YOUR REPORT IS READY";
		String emailBody = StringUtils.isNotBlank(metaData.getEmailBody()) ? metaData.getEmailBody()
				: "YOUR REPORT IS READY";
		String reportGroup = reportEmailRepo.getReportGroup(metaData.getRptCode());
		if ("TR".equalsIgnoreCase(reportGroup) || "TE".equalsIgnoreCase(reportGroup)
				|| "TU".equalsIgnoreCase(reportGroup)) {
			subject.append("FSA ").append(Integer.parseInt(metaData.getGlobalFSANum())).append(" ")
					.append(emailSubject);
			targetUrl.append("<HTML><BODY><p>").append(emailBody).append(" For Global FSA Number: ")
					.append(Integer.parseInt(metaData.getGlobalFSANum())).append(" Supplement Code: ")
					.append(metaData.getSuppCode());
			targetUrl.append(" <a href= '");
			actualLinkUrl.append(getReportDownloadLink(metaData));
			targetUrl.append(actualLinkUrl.toString()).append("'> Click here ").append(PASTE_LINK_TEXT)
					.append(actualLinkUrl.toString()).append("<br>").append("</p></BODY></HTML>");
			urlString = targetUrl.toString();
			
			log.info("The Good Email Subject {}", emailSubject);

		} else {
			subject.append(emailSubject);
			actualLinkUrl.append("&agencyCode=");
			appendUrl.append("&agencyCode=");
			if (StringUtils.isNotBlank(metaData.getAgencyCode())) {
				actualLinkUrl.append(metaData.getAgencyCode());
				appendUrl.append(metaData.getAgencyCode());
			} else {
				actualLinkUrl.append("");
				appendUrl.append("");
			}
			appendUrl.append("'> Click here").append(PASTE_LINK_TEXT).append(actualLinkUrl.toString()).append("</p>");

			appendUrl.append("</BODY>");
			appendUrl.append("</HTML>");

			urlString = bodyURL.toString() + appendUrl.toString();

		}
		updateReportCompletionFlag(metaData);
		try {
			if (reportEmailRepo.doesNavisFetchSuccessful(metaData.getJobQueue())) {
				log.info("NAVIS fetch successful for FSA: {}", metaData.getGlobalFSANum());
				urlString += ReportConstants.NAVIS_FETCH_SUCCESS_MSG;
			}
			urlString += submittedBy.toString();
			sender.sendMailToUsers(getEmailIdsFromDL(metaData), cc, systemEmail, subject.toString(), urlString, true);
		} catch (Exception e) {
			throw new GCAMPReportException("There is an error in sending success email", e);
		}
	
	}
	
	private void updateReportCompletionFlag(ReportMetaData metaData) throws GCAMPReportException {
		metaData.setActionType(ReportStandardConstants.MODIFY);
		try {
			reportEmailRepo.updateEmailData(metaData);
			log.info("Report Completion Flag updated for FSA Number {} and Report Id {} ", metaData.getGlobalFSANum(),
					metaData.getRptId());
		} catch (GCAMPException e) {
			throw new GCAMPReportException("There is an error in updating report completion flag", e);
		}
	}

	private String getReportDownloadLink(ReportMetaData metaData) {
		StringBuilder actualLinkUrl = new StringBuilder();
		actualLinkUrl.append(reportUrl);
		actualLinkUrl.append("targeting-report?");
		actualLinkUrl.append("fsaNumber=");
		actualLinkUrl.append(Integer.parseInt(metaData.getGlobalFSANum()));
		actualLinkUrl.append("&fsaType=G");
		actualLinkUrl.append("&population=");
		actualLinkUrl.append(metaData.getSuppCode());
		return actualLinkUrl.toString();

	}

	public void sendErrorEmail(ReportMetaData metaData, String str) throws GCAMPReportException {

		String userCDSID = metaData.getReqById();
		Optional<LDAPModel> ldap = userService.getByCDSId(userCDSID);

		String from = systemEmail;
		StringBuilder submittedBy = new StringBuilder(ReportConstants.SUBMITTED_BY);

		if ("SFI".equalsIgnoreCase(metaData.getRptCode())) {
			submittedBy.append(ReportConstants.REPORT_SERVICE);
		} else if (ldap.isPresent()) {
			submittedBy.append(ldap.get().getFordDisplayName());
		}

		String[] cc = new String[1];
		if (StringUtils.isNotBlank(userCDSID)) {
			cc[0] = userCDSID + ReportConstants.FORD_EMAIL_DOMAIN;
		} else {
			cc[0] = from;
		}

		StringBuilder body = new StringBuilder();
		body.append(ReportStandardConstants.ERROR_BODY).append("<br>" + str + "</br>");
		StringBuilder subject = new StringBuilder();
		subject.append("For FSA ").append(Integer.parseInt(metaData.getGlobalFSANum())).append(StringUtils.SPACE)
				.append(ReportStandardConstants.ERROR_SUBJECT);
		try {
			body.append(submittedBy);
			if (CollectionUtils.isNotEmpty(errorEmailSentList) && !errorEmailSentList.contains(metaData.getRptId())) {
				errorEmailSentList.add(metaData.getRptId());
				sender.sendMailToUsers(getEmailIdsFromDL(metaData), cc, from, subject.toString(), body.toString(), true);
			}
		} catch (Exception e) {
			throw new GCAMPReportException("There is an error in sending job failure email ", e);
		}
	}

	private String[] getEmailIdsFromDL(ReportMetaData metaData) {

		List<String> emailList = new ArrayList<>();

		String[] emailIds = StringUtils.split(metaData.getDistributionList(), ReportStandardConstants.SEMI_COLON);

		boolean reqIdExists = false;

		if (emailIds != null) {
			for (String emailId : emailIds) {

				reqIdExists = StringUtils.trim(emailId).equalsIgnoreCase(metaData.getReqById());

				emailList.add(StringUtils.trim(emailId) + ReportConstants.FORD_EMAIL_DOMAIN);
			}
		}

		if (!reqIdExists) {
			emailList.add(metaData.getReqById() + ReportConstants.FORD_EMAIL_DOMAIN);
		}
		metaData.setDistEmailList(emailList);

		return emailList.stream().toArray(String[]::new);
	}

	public void getEmailData(ReportMetaData reportMetaData) throws GCAMPException {
		reportEmailRepo.getEmailData(reportMetaData);
	}

	public String getErrorEmailCount(int reportId) throws GCAMPReportDB2Exception {
		return reportEmailRepo.getErrorEmailCount(reportId);
	}

	public int getGoodMailCount(int reportId) throws GCAMPReportDB2Exception {
		return reportEmailRepo.getGoodMailCount(reportId);
	}

	public void processError(ReportMetaData reportMetaData) throws GCAMPException {
		reportEmailRepo.processError(reportMetaData);
	}
}
