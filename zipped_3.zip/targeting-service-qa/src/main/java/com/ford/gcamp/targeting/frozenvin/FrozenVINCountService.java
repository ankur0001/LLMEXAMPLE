package com.ford.gcamp.targeting.frozenvin;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ford.gcamp.targeting.common.BatchTrigger;
import com.ford.gcamp.targeting.common.FscCriteriaUtil;
import com.ford.gcamp.targeting.common.api.BatchJobData;
import com.ford.gcamp.targeting.core.exception.GCampBatchTriggerException;
import com.ford.gcamp.targeting.frozenvin.api.FrozenVINCountRequest;
import com.ford.gcamp.targeting.frozenvin.api.FrozenVINCountResponse;
import com.ford.gcamp.targeting.frozenvin.api.FrozenVinHistResponse;
import com.ford.gcamp.targeting.frozenvin.api.FrozenVinResponseDTO;
import com.ford.gcamp.targeting.frozenvin.api.FrozenVin;

@Service
public class FrozenVINCountService {

	private static final Logger LOGGER = LoggerFactory.getLogger(FrozenVINCountService.class);
	
	@Autowired
	private BatchTrigger batch;
	
	@Autowired
	FscCriteriaUtil fscCriteriaUtil;
	
	@Autowired
	FrozenVinCountRepository frozenVinRepository;
	
	@Autowired
	FrozenVinStorProc frozenStore;
	
	public FrozenVinResponseDTO getFrozenVinList(FrozenVin frozenVin) {
		return frozenVinRepository.getFSaHubDetails(frozenVin);
	}

	public FrozenVinHistResponse getFrozenHistory(FrozenVin fsaCriteria) {
		String fsaGoParm = fscCriteriaUtil.frozenParm(fsaCriteria);
		String filterFlag=fsaCriteria.getFilterBy();
		LOGGER.info("job Pojo::{}", fsaGoParm);
		Map<String, Object> frozenMap = frozenVinRepository.frozenHistoryData(fsaGoParm);
		return frozenStore.getHistoryOfFrozen(frozenMap,filterFlag);

	}
	public FrozenVINCountResponse freezeUnfreeze(FrozenVINCountRequest frozenVINCountRequest) throws GCampBatchTriggerException {
		int jobId = 0;
		FrozenVINCountResponse frozenVIMCountResponse = new FrozenVINCountResponse();
		if(frozenVINCountRequest != null ) {
			jobId = freezeUnfreezeVINCount(frozenVINCountRequest);
			frozenVIMCountResponse.setJobId(jobId);
			frozenVIMCountResponse.setResponseCode("success");
			frozenVIMCountResponse.setResponseMsg("Your Job has been successfully submitted with Job Id "+jobId+" for the Batch Code "+frozenVINCountRequest.getBatchCode()+".");
		} else {
			frozenVIMCountResponse.setJobId(jobId);
			frozenVIMCountResponse.setResponseCode("error");
			frozenVIMCountResponse.setResponseMsg("ERROR = INPUT VALUE OBJECTS ARE NULL");
		}
		return frozenVIMCountResponse;
	}
	
	private int freezeUnfreezeVINCount(FrozenVINCountRequest frozenVINCountRequest) throws GCampBatchTriggerException {
		 	
			int jobId =0;
			String supplement = null;
			if("".equals(frozenVINCountRequest.getSupplementCode().trim())) {
				supplement = "00";
			}else {
				supplement = frozenVINCountRequest.getSupplementCode().trim();
			}
			BatchJobData job = new 	BatchJobData();
			job.setBatchCode("0"+frozenVINCountRequest.getBatchCode());
				
			if("G".equalsIgnoreCase(frozenVINCountRequest.getFsaType())) {
				job.setGlobalFSANo(Integer.parseInt(frozenVINCountRequest.getFsaNumber()));
			}else {
				job.setGlobalFSANo(frozenVINCountRequest.getLocalFsaNumber());
			}
			
			job.setSupplement(supplement);
			job.setCdsId(frozenVINCountRequest.getCdsId());				
			job.setParameters(frozenVINCountRequest.getBatchParameter());
			LOGGER.info("Frozen Count Batch Code : {}", job.getBatchCode());
			jobId = batch.submitJob(job);
			return jobId;
	}

}
