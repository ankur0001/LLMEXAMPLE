package com.ford.gcamp.targeting.config;


import io.swagger.v3.oas.models.Components;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.security.OAuthFlow;
import io.swagger.v3.oas.models.security.OAuthFlows;
import io.swagger.v3.oas.models.security.Scopes;
import io.swagger.v3.oas.models.security.SecurityScheme;
import org.springdoc.core.customizers.OpenApiCustomizer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.core.env.Environment;

@Configuration
public class OpenApiConfig {
    @Autowired
    Environment environment;

    @Value("${aps.auth-url}")
    private String AZURE_TOKEN_URL;

    @Value("${spring.security.oauth2.client.provider.client-adfs4.token-uri}")
    private String ADFS_TOKEN_URL;

    private String ADFS_AUTHORIZATION_URL = "https://adfs.ford.com/adfs/oauth2/authorize/";

    @Bean
    @Primary
    public OpenAPI apiInfo() {
        return new OpenAPI()
                .info(new Info()
                        .title(environment.getProperty("cn.app.swagger.display.title"))
                        .description(environment.getProperty("cn.app.swagger.display.description"))
                        .contact(new Contact()
                                .name(environment.getProperty("cn.app.swagger.display.contact-name"))
                                .email(environment.getProperty("cn.app.swagger.display.contact-email"))
                        )
                        .version(environment.getProperty("cn.app.swagger.display.version"))
                )                    .components(new Components()
                        .addSecuritySchemes("AzureAD",
                                new SecurityScheme().
                                        type(SecurityScheme.Type.OAUTH2)
                                        .description("AzureAD")
                                        .flows(new OAuthFlows()
                                                .clientCredentials(new OAuthFlow()
                                                        //  .authorizationUrl(AZURE_AUTHORIZATION_URL)
                                                        .tokenUrl(AZURE_TOKEN_URL)
                                                        .scopes(new Scopes())
                                                )))
                        .addSecuritySchemes("ADFS",
                                new SecurityScheme().
                                        type(SecurityScheme.Type.OAUTH2)
                                        .description("ADFS")
                                        .flows(new OAuthFlows()
                                                .authorizationCode(new OAuthFlow()
                                                        .authorizationUrl(ADFS_AUTHORIZATION_URL)
                                                        .tokenUrl(ADFS_TOKEN_URL)
                                                        .scopes(new Scopes())))));

    }

    @Bean
    public OpenApiCustomizer openApiCustomiser() {
        return openApi -> openApi.getComponents().getSchemas().values().forEach(s -> s.setAdditionalProperties(false));
    }

}