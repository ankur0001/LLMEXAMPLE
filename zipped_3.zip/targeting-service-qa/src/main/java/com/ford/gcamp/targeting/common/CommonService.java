package com.ford.gcamp.targeting.common;

import java.util.List;
import java.util.Map;
import org.springframework.web.util.HtmlUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import com.ford.gcamp.targeting.common.api.CommonResponse;
import com.ford.gcamp.targeting.common.api.FSACommonGoRequest;
import com.ford.gcamp.targeting.common.api.FSAInfoVO;
import com.ford.gcamp.targeting.common.api.GenericLookup;
import com.ford.gcamp.targeting.common.api.GenericLookupResponse;
import com.ford.gcamp.targeting.common.api.RoiCountryResponse;
import com.ford.gcamp.targeting.core.exception.GCAMPException;
import com.ford.gcamp.targeting.properties.HubCountryProperties;
import com.ford.gcamp.targeting.properties.HubPropertiesResponse;
import com.ford.gcamp.targeting.regionalfilters.RegionalFiltersMapper;

@Service
public class CommonService {

	private CommonRepository commonRepository;
	private RegionalFiltersMapper regionalFiltersMapper;
	private HubCountryProperties properties;

	public CommonService(CommonRepository commonRepository, RegionalFiltersMapper regionalFiltersMapper,
			HubCountryProperties properties) {
		this.commonRepository = commonRepository;
		this.regionalFiltersMapper = regionalFiltersMapper;
		this.properties = properties;
	}

	public RoiCountryResponse loadCountry(String hubCode) throws GCAMPException {

		String roiCountryparam1 = TargetingUtil.addSpaceToProc(20);
		String roiCountryparam2 = "2";
		String roiCountryparam3 = StringUtils.SPACE;
		Map<String, Object> responseMap = commonRepository.loadCountry(roiCountryparam1, roiCountryparam2,
				roiCountryparam3);
		return regionalFiltersMapper.parseCountryResponseMap(responseMap, hubCode);

	}

	public GenericLookupResponse getSupplements(String globalFsaNumber) {
		GenericLookupResponse supplementResponse = new GenericLookupResponse();
		List<GenericLookup> supplements = commonRepository.getSupplements(globalFsaNumber);
		supplementResponse.setValues(supplements);
		return supplementResponse;
	}

	public HubPropertiesResponse getHubFromPropertyFile(String hubKey) {
		HubPropertiesResponse response = new HubPropertiesResponse();
		String hubFromPropertyFile = properties.getHub().get(hubKey);
		response.setHub(hubFromPropertyFile);
		return response;
	}

	public GenericLookupResponse getCountries(String hubCode) {
		GenericLookupResponse countryResponse = new GenericLookupResponse();
		List<GenericLookup> countries = commonRepository.getCountries(HtmlUtils.htmlEscape(hubCode));
		countryResponse.setStatus(CommonConstants.SUCCESS);
		countryResponse.setStatusCode(CommonConstants.SUCCESS_CODE);
		countryResponse.setStatusDescription(CommonConstants.SUCCESS);
		countryResponse.setValues(countries);
		return countryResponse;
	}
	
// Fsa Overlap and Tandem Feature
	public FSAInfoVO getFsaInfo(FSACommonGoRequest fsaCommonGoRequest) throws GCAMPException {
		FSAInfoVO fsaInfo = new FSAInfoVO();
		CommonResponse response = new CommonResponse();
		
		Map<String, Object> fsaCommonGoResponseMap = commonRepository.getFsaInfo(fsaCommonGoRequest);
		TargetingUtil.getResponseStatus((String) fsaCommonGoResponseMap.get(CommonConstants.OUTPUT_ERR1), response);
		String outputFsaGoParm1 = (String) fsaCommonGoResponseMap.get(CommonConstants.OUTPUT_PARM1);
		String outputFsaGoParm2 = (String) fsaCommonGoResponseMap.get(CommonConstants.OUTPUT_PARM2);
		fsaInfo.setString(outputFsaGoParm1, outputFsaGoParm2);
		return fsaInfo;
	}

}
