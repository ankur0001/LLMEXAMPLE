package com.ford.gcamp.targeting.manualaddvin.api;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class ManuallyAddVINsValidateVO {
	
	private String vinNumber= null;	
	private String vinFlag= null;	

}