package com.ford.gcamp.targeting.reports.batch.exception;

public class GCAMPReportException extends Exception {

	private static final long serialVersionUID = 1L;

	/**
	 * Constructor for GCampReportException
	 */
	public GCAMPReportException() {
		super();
	}

	/**
	 * Constructor for GCampReportException
	 */
	public GCAMPReportException(String msg) {
		super(msg);
	}

	/**
	 * Constructor for GCampReportException
	 */
	public GCAMPReportException(Throwable rootCause) {
		super(rootCause);
	}

	/**
	 * Constructor for GCampReportException
	 */
	public GCAMPReportException(String msg, Throwable rootCause) {
		super(msg, rootCause);
	}

}
