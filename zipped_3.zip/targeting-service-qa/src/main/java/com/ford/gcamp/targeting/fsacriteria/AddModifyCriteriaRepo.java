package com.ford.gcamp.targeting.fsacriteria;

import java.util.List;
import java.util.Map;

import com.ford.gcamp.targeting.common.Hubs;
import com.ford.gcamp.targeting.common.api.FSATypes;
import com.ford.gcamp.targeting.common.api.FscCriteriaRequest;
import com.ford.gcamp.targeting.fsacriteria.api.DeleteFsaInfoReq;
import com.ford.gcamp.targeting.fsacriteria.api.FsaCriteriaParamRequest;
import com.ford.gcamp.targeting.fsacriteria.api.FsaGlobalSearchDTO;
import com.ford.gcamp.targeting.fsacriteria.api.FscCriteriaResponseGoDTO;
import com.ford.gcamp.targeting.fsacriteria.api.LoadFsaResponseDTO;
import com.ford.gcamp.targeting.fsacriteria.api.LoadSelectCounValDTO;
import com.ford.gcamp.targeting.fsacriteria.api.LoadStateProvinceDTO;
import com.ford.gcamp.targeting.fsacriteria.api.LoadVehAttValDTO;
import com.ford.gcamp.targeting.vin.api.ExistingVinGrpList;


public interface AddModifyCriteriaRepo {

	public LoadFsaResponseDTO loadFscCriteriaDetails();
	public FscCriteriaResponseGoDTO getFscSearchList(FscCriteriaRequest fscCriteriaRequest);
	public LoadVehAttValDTO loadDynamicQueryDetailsForVehAtt(String inputModelValue);
	public FscCriteriaResponseGoDTO saveFscSearchListDesc(FsaCriteriaParamRequest fsaCriteriaParam);
	public FscCriteriaResponseGoDTO copyFscSearchListDesc(FsaCriteriaParamRequest fsaCriteriaParam);
	public LoadStateProvinceDTO loadDynamicQueryDetailsForStateProv(String inputModelValue, int multiSelectionLength,
			String attributeSelected);
	public LoadSelectCounValDTO loadDynamicQueryDetailsForSelectCountry(FscCriteriaRequest fscCriteriaRequest);
	public FsaGlobalSearchDTO globalFsaSearchDetails(String dynamicQueryInutParam, String fsaType);
	public Map<String, Object> deleteFscSearchListDesc(FsaCriteriaParamRequest fsaCriteriaParam);
	public Map<String, Object> deleteAllFsaInfo(String inuputParam, DeleteFsaInfoReq deleteFsaInfoReq);
	public List<Hubs> getHubCodes();
	public List<FSATypes> getFsaTypes();
	public Map<String, Object> checkBlocker(String deleteInputParam);
	public List<ExistingVinGrpList> checkVinExistence(String fsaNumber, List<String> vinGrpCodes);
}
