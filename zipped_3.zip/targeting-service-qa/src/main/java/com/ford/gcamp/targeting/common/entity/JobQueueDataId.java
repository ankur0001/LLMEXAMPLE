package com.ford.gcamp.targeting.common.entity;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class JobQueueDataId implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String batchCode;
	private Integer jobQueueId;
}
