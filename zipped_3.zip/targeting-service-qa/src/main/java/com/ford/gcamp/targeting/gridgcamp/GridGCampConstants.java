package com.ford.gcamp.targeting.gridgcamp;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public class GridGCampConstants {

	public static final String SEQUENCE_NUMBER = "sequnceNumber";
	public static final String FILTER_GROUP_CODE = "filterGroupCode";
	public static final String FILTER_GROUP_DESCRIPTION = "filterGroupDesccription";
	public static final String OPERATOR = "operator";
	public static final String ATTRIBUTE_CODE = "attributeCode";
	public static final String ATTRIBUTE_DESCRIPTION = "attributeDescription";
	public static final String VALUE_FROM = "valueFrom";
	public static final String VALUE_TO = "valueTo";
	
	public static final int WERS_FILTER_CODE = 48;
	public static final int VEHICLE_CODE_FILTER_CODE = 1085;
	public static final int CUSTOMER_STATE_CODE_FILTER_CODE = 19;
	public static final int PRODUCTION_DATE_FILTER_CODE = 16;
	public static final int BODYSTYLE_FILTER_CODE = 46;
	public static final int ENGINEE_FILTER_CODE = 49;
	public static final int TRANSMISSION_FILTER_CODE = 52;
	
	public static final String GRID_VERN_ID_VERSION = "gridVernId.version";
	public static final String GRID_VERN_ID = "gridVernId";
	
	public static final String TRANSIENT = "Transient";
	public static final String OFFICIAL = "Official";
	public static final String LAUNCHED = "Launched";
	
	public static final String CREATE_GLOBAL_FSA = "C";
	public static final String UPDATE_GLOBAL_FSA_WITH_NEW_VERSION = "U";
	public static final String SEND_VERN_COUNT_ON_EXTRACT = "E";
	public static final String VEHICLE_CONFIRMATION = "O";
	
	public static final String FSA_DELETED = "FSA_DELETED";
	public static final String FSA_CONFIRMED = "FSA_CONFIRMED";
	public static final String FSA_INQUIRY = "FSA_INQUIRY";
	public static final String FSA_LAUNCHED = "FSA_LAUNCHED";
	public static final String FRC_DATE_UPDATED = "FRC_DATE_UPDATED";
	public static final String FSA_TYPE_UPDATED = "FSA_TYPE_UPDATED";
	public static final String GCAMP_FSA_TYPE_UPDATED = "GCAMP_FSA_TYPE_UPDATED";
	public static final String LOCAL_FSA_CREATED = "LOCAL_FSA_CREATED";
	public static final String LOCAL_FSA_DELETED = "LOCAL_FSA_DELETED";
	public static final String VIN_FILE_PROCESSED = "VIN_FILE_PROCESSED";
	public static final String REFRESH_SOLD_UNSOLD_COUNT = "REFRESH_SOLD_UNSOLD_COUNT";
	
	public static final String SOLD_UNSOLD_GRID_CDSID = "GRID";
	
	public static final String DASHBOARD_GRID_TILE_NEW_VERN_REMARKS ="VERN is not associated with any FSA";
	public static final String DASHBOARD_GRID_TILE_NEW_ORIG_VERN_REMARKS ="FSA is not associated with updated VERN";
	public static final String DASHBOARD_GRID_TILE_NEW_SUPPL_VERN_REMARKS ="Supplement is not associated with updated VERN";
	
	public static final String GRID_VFD_REQ_RECEIVED = "RECEIVED";
	public static final String GRID_VFD_REQ_PENDING = "PENDING";
	public static final String GRID_VFD_REQ_PROCESSED = "PROCESSED";
	public static final String GRID_VFD_REQ_COMPLETED = "COMPLETED";
	public static final String GRID_VFD_REQ_FAILED = "FAILED";
	
	

	public static final Map<Integer, String> VEHICLE_CRITERIA_PROPERTIES_MAP;
	static {
		Map<Integer, String> vehicleCriteriaPropertiesMap = new HashMap<>();
		vehicleCriteriaPropertiesMap.put(44, "modelYear");
		vehicleCriteriaPropertiesMap.put(2, "brand");
		vehicleCriteriaPropertiesMap.put(43, "vehicleLine");
		vehicleCriteriaPropertiesMap.put(1, "plant");
		VEHICLE_CRITERIA_PROPERTIES_MAP = Collections.unmodifiableMap(vehicleCriteriaPropertiesMap);
	}

	private GridGCampConstants() {

	}
}
