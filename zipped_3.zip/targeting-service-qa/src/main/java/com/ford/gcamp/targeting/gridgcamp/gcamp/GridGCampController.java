package com.ford.gcamp.targeting.gridgcamp.gcamp;

import com.ford.cloudnative.base.api.StandardErrorResponse;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;

import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.Operation;
import org.apache.commons.lang3.StringUtils;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.ford.gcamp.targeting.common.CommonConstants;
import com.ford.gcamp.targeting.common.api.CommonResponse;
import com.ford.gcamp.targeting.core.exception.GCAMPException;
import com.ford.gcamp.targeting.core.exception.ResourceNotFoundException;
import com.ford.gcamp.targeting.gridgcamp.GridGCampConstants;
import com.ford.gcamp.targeting.gridgcamp.gcamp.api.GridBasicVernInfo;
import com.ford.gcamp.targeting.gridgcamp.gcamp.api.GridFrcApprovalData;
import com.ford.gcamp.targeting.gridgcamp.gcamp.api.GridFrcApprovalDateInfo;
import com.ford.gcamp.targeting.gridgcamp.gcamp.api.GridOTAUpdateResponse;
import com.ford.gcamp.targeting.gridgcamp.gcamp.api.GridVernInfo;
import com.ford.gcamp.targeting.gridgcamp.gcamp.api.GridVernInfoExistsResponse;
import com.ford.gcamp.targeting.gridgcamp.gcamp.api.GridVernResponse;
import com.ford.gcamp.targeting.gridgcamp.gcamp.api.GridVfdRequest;
import com.ford.gcamp.targeting.gridgcamp.gcamp.api.OTAIndicatorUpdateRequest;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping(path = "/api/v1/targeting/gridgcamp")
@Slf4j
@Validated
public class GridGCampController {

    private GridGCampService gridService;

    private GridGCampVernInfoService gridGCampVernInfoService;

    public GridGCampController(GridGCampService gridService, GridGCampVernInfoService gridGCampVernInfoService) {
        super();
        this.gridService = gridService;
        this.gridGCampVernInfoService = gridGCampVernInfoService;
    }

    @Operation(summary = "Insert GRID data into GCAMP", description = "Adding GRID data into GCAMP database", security = {
			@SecurityRequirement(name = "ADFS"),
			@SecurityRequirement(name = "AzureAD")
	})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "GRID updated successfully", content = {
                    @Content(mediaType = "application/problem+json", schema = @Schema(implementation = CommonResponse.class))}),
            @ApiResponse(responseCode = "400", description = "Bad Request, missing required fields"),
            @ApiResponse(responseCode = "401", description = "Unauthorized"),
            @ApiResponse(responseCode = "403", description = "Forbidden"),
            @ApiResponse(responseCode = "404", description = "Not Found", content = @Content(schema = @Schema(implementation = CommonResponse.class))),
            @ApiResponse(responseCode = "405", description = "Invalid Method type"),
            @ApiResponse(responseCode = "406", description = "Invalid Response type"),
            @ApiResponse(responseCode = "412", description = "Precondition Failed", content = @Content(schema = @Schema(implementation = CommonResponse.class))),
            @ApiResponse(responseCode = "415", description = "Unsupported Media Type"),
            @ApiResponse(responseCode = "428", description = "Bad Request, missing required fields", content = @Content(array = @ArraySchema(schema = @Schema(implementation = CommonResponse.class)))),
            @ApiResponse(responseCode = "429", description = "Too many bad request"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")})
    @PostMapping
    public ResponseEntity<CommonResponse> insertGridVernData(@RequestBody @Valid GridVernInfo gridVernRequest)
            throws ResourceNotFoundException {
        CommonResponse response;
        try {
            response = gridService.saveGridVernData(gridVernRequest, true);
        } catch (Exception e) {
            log.error("Exception while saving the GRID details in GCAMP ", e);
            throw new ResourceNotFoundException("Error occurred while saving the GRID details in GCAMP");
        }
        return ResponseEntity.ok(response);
    }

    @Operation(summary = "Update GRID data into GCAMP", description = "Modify GRID data into GCAMP database", security = {
			@SecurityRequirement(name = "ADFS"),
			@SecurityRequirement(name = "AzureAD")
	})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "GRID updated successfully", content = {
                    @Content(mediaType = "application/problem+json", schema = @Schema(implementation = CommonResponse.class))}),
            @ApiResponse(responseCode = "400", description = "Bad Request, missing required fields"),
            @ApiResponse(responseCode = "401", description = "Unauthorized"),
            @ApiResponse(responseCode = "403", description = "Forbidden"),
            @ApiResponse(responseCode = "404", description = "Not Found", content = @Content(schema = @Schema(implementation = CommonResponse.class))),
            @ApiResponse(responseCode = "405", description = "Invalid Method type"),
            @ApiResponse(responseCode = "406", description = "Invalid Response type"),
            @ApiResponse(responseCode = "412", description = "Precondition Failed", content = @Content(schema = @Schema(implementation = CommonResponse.class))),
            @ApiResponse(responseCode = "415", description = "Unsupported Media Type"),
            @ApiResponse(responseCode = "428", description = "Bad Request, missing required fields", content = @Content(array = @ArraySchema(schema = @Schema(implementation = CommonResponse.class)))),
            @ApiResponse(responseCode = "429", description = "Too many bad request"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")})
    @PutMapping
    public ResponseEntity<CommonResponse> saveGridVernData(@RequestBody @Valid GridVernInfo gridVernRequest)
            throws ResourceNotFoundException {
        CommonResponse response;
        try {
            response = gridService.saveGridVernData(gridVernRequest, false);
        } catch (Exception e) {
            log.error("Exception while updating the GRID details in GCAMP ", e);
            throw new ResourceNotFoundException("Error occured while updating the GRID details in GCAMP");
        }
        return ResponseEntity.ok(response);
    }

    @Operation(summary = "Update FRC Approval data into GCAMP", description = "Save FRC Approval data into GCAMP database", security = {
			@SecurityRequirement(name = "ADFS"),
			@SecurityRequirement(name = "AzureAD")
	})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "GRID updated successfully", content = {
                    @Content(mediaType = "application/problem+json", schema = @Schema(implementation = CommonResponse.class))}),
            @ApiResponse(responseCode = "400", description = "Bad Request, missing required fields"),
            @ApiResponse(responseCode = "401", description = "Unauthorized"),
            @ApiResponse(responseCode = "403", description = "Forbidden"),
            @ApiResponse(responseCode = "404", description = "Not Found", content = @Content(schema = @Schema(implementation = CommonResponse.class))),
            @ApiResponse(responseCode = "405", description = "Invalid Method type"),
            @ApiResponse(responseCode = "406", description = "Invalid Response type"),
            @ApiResponse(responseCode = "412", description = "Precondition Failed", content = @Content(schema = @Schema(implementation = CommonResponse.class))),
            @ApiResponse(responseCode = "415", description = "Unsupported Media Type"),
            @ApiResponse(responseCode = "428", description = "Bad Request, missing required fields", content = @Content(array = @ArraySchema(schema = @Schema(implementation = CommonResponse.class)))),
            @ApiResponse(responseCode = "429", description = "Too many bad request"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")})
    @PutMapping(value = "/gridverninfo/frcapproval")
    public ResponseEntity<CommonResponse> saveFrcApprovalData(
            @RequestBody @Valid GridFrcApprovalData gridFrcApprovalData) throws ResourceNotFoundException {
        CommonResponse response = gridService.saveGridFrcApprovalData(gridFrcApprovalData);
        return ResponseEntity.ok(response);
    }

    @Operation(summary = "Update GRID Vern FRC Approval data into GCAMP", description = "Update GRID Vern FRC Approval data into GCAMP", security = {
			@SecurityRequirement(name = "ADFS"),
			@SecurityRequirement(name = "AzureAD")
	})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "GRID vern info hubcode updated successfully", content = {
                    @Content(mediaType = "application/problem+json", schema = @Schema(implementation = CommonResponse.class))}),
            @ApiResponse(responseCode = "400", description = "Bad Request, missing required fields"),
            @ApiResponse(responseCode = "401", description = "Unauthorized"),
            @ApiResponse(responseCode = "403", description = "Forbidden"),
            @ApiResponse(responseCode = "404", description = "Not Found", content = @Content(schema = @Schema(implementation = CommonResponse.class))),
            @ApiResponse(responseCode = "405", description = "Invalid Method type"),
            @ApiResponse(responseCode = "406", description = "Invalid Response type"),
            @ApiResponse(responseCode = "412", description = "Precondition Failed", content = @Content(schema = @Schema(implementation = CommonResponse.class))),
            @ApiResponse(responseCode = "415", description = "Unsupported Media Type"),
            @ApiResponse(responseCode = "428", description = "Bad Request, missing required fields", content = @Content(array = @ArraySchema(schema = @Schema(implementation = CommonResponse.class)))),
            @ApiResponse(responseCode = "429", description = "Too many bad request"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")})
    @PutMapping(value = {
            "/gridverninfo/frcapprovaldate"})
    public ResponseEntity<CommonResponse> updateGridVernFrcApprovalDate(
            @RequestBody @Valid GridFrcApprovalDateInfo gridFrcApprovalDateInfo) throws ResourceNotFoundException {
        CommonResponse response = gridService.updateGridVernInfo(gridFrcApprovalDateInfo);
        return ResponseEntity.ok(response);
    }

    @GetMapping(value = "/gridverninfo/hub/{hubCode}")
    @Operation(summary = "Update GRID Vern FRC Approval data into GCAMP", description = "Update GRID Vern FRC Approval data into GCAMP", security = {
			@SecurityRequirement(name = "ADFS"),
			@SecurityRequirement(name = "AzureAD")
	})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "GRID vern info hubcode updated successfully", content = {
                    @Content(mediaType = "application/json", schema = @Schema(implementation = GridVernResponse.class))}),
            @ApiResponse(responseCode = "default", description = "All Errors", content = @Content(schema = @Schema(implementation = StandardErrorResponse.class)))
    })
    public ResponseEntity<GridVernResponse> getGridVernDataByHubCode(
            @PathVariable @Size(min = 1, max = 2) @Schema(example = "NA", description = "Hub Code") @Pattern(regexp = "^[A-Za-z\\s\\*]*$") String hubCode) {
        GridVernResponse response = gridService.getGridVernDataByHubCode(hubCode);
        return ResponseEntity.ok(response);
    }

    @GetMapping(value = "/gridvern/fsa/{globalFSANumber}")
    @Operation(summary = "Get GRID Vern Data by FSA Number", security = {
			@SecurityRequirement(name = "ADFS"),
			@SecurityRequirement(name = "AzureAD")
	})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "GRID vern info hubcode updated successfully", content = {
                    @Content(mediaType = "application/problem+json", schema = @Schema(implementation = GridVernResponse.class))}),
            @ApiResponse(responseCode = "400", description = "Bad Request, missing required fields"),
            @ApiResponse(responseCode = "401", description = "Unauthorized"),
            @ApiResponse(responseCode = "403", description = "Forbidden"),
            @ApiResponse(responseCode = "404", description = "Not Found", content = @Content(schema = @Schema(implementation = CommonResponse.class))),
            @ApiResponse(responseCode = "406", description = "Invalid Response type"),
            @ApiResponse(responseCode = "405", description = "Invalid Method type"),
            @ApiResponse(responseCode = "412", description = "Precondition Failed", content = @Content(schema = @Schema(implementation = CommonResponse.class))),
            @ApiResponse(responseCode = "415", description = "Unsupported Media Type"),
            @ApiResponse(responseCode = "428", description = "Bad Request, missing required fields",content = @Content(array = @ArraySchema(schema = @Schema(implementation = CommonResponse.class)))),
            @ApiResponse(responseCode = "429", description = "Too many bad request"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error"),
            @ApiResponse(responseCode = "default", description = "All Errors", content = @Content(schema = @Schema(implementation = StandardErrorResponse.class)))
    })
    public ResponseEntity<GridVernResponse> getGridVernDataByFSANumber(
            @PathVariable @Min(0) @Max(99999999)
            @Schema(type = "integer", example = "15543", description = "globalFSANumber")
            int globalFSANumber) {
        GridVernResponse response = gridService.getGridVernDataByFSANumber(null, globalFSANumber, null);
        return ResponseEntity.ok(response);
    }

    @GetMapping(value = "/gridverninfo/fsa/{globalFSANumber}/{supplementCode}")
    @Operation(summary = "Get GRID Vern Data by FSA Number Supplement", security = {
			@SecurityRequirement(name = "ADFS"),
			@SecurityRequirement(name = "AzureAD")
	})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "GRID vern info hubcode updated successfully", content = {
                    @Content(mediaType = "application/problem+json", schema = @Schema(implementation = GridVernResponse.class))}),
            @ApiResponse(responseCode = "400", description = "Bad Request, missing required fields"),
            @ApiResponse(responseCode = "401", description = "Unauthorized"),
            @ApiResponse(responseCode = "403", description = "Forbidden"),
            @ApiResponse(responseCode = "404", description = "Not Found", content = @Content(schema = @Schema(implementation = CommonResponse.class))),
            @ApiResponse(responseCode = "406", description = "Invalid Response type"),
            @ApiResponse(responseCode = "405", description = "Invalid Method type"),
            @ApiResponse(responseCode = "412", description = "Precondition Failed", content = @Content(schema = @Schema(implementation = CommonResponse.class))),
            @ApiResponse(responseCode = "415", description = "Unsupported Media Type"),
            @ApiResponse(responseCode = "428", description = "Bad Request, missing required fields",content = @Content(array = @ArraySchema(schema = @Schema(implementation = CommonResponse.class)))),
            @ApiResponse(responseCode = "429", description = "Too many bad request"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error"),
            @ApiResponse(responseCode = "default", description = "All Errors", content = @Content(schema = @Schema(implementation = StandardErrorResponse.class)))
    })
    public ResponseEntity<GridVernResponse> getGridVernDataByFSANumberSuppl(
            @Schema(type = "integer", example = "15543", description = "globalFSANumber")
            @PathVariable @Min(0) @Max(99999999) int globalFSANumber,
            @Schema(example = "AA", description = "Supplement Code")
            @PathVariable @Size(min = 1, max = 2) @Pattern(regexp = "^[A-Za-z\\d]*$") String supplementCode) {
        GridVernResponse response = gridService.getGridVernDataByFSANumber(null, globalFSANumber, supplementCode);
        return ResponseEntity.ok(response);
    }

    @GetMapping(value = "/gridverninfo/supplements/{hubCode}/{globalFSANumber}")
    @Operation(summary = "Get Supplements Grid Vern Data by FSA Number", security = {
			@SecurityRequirement(name = "ADFS"),
			@SecurityRequirement(name = "AzureAD")
	})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "GRID vern info hubcode updated successfully", content = {
                    @Content(mediaType = "application/problem+json", schema = @Schema(implementation = GridVernResponse.class))}),
            @ApiResponse(responseCode = "400", description = "Bad Request, missing required fields"),
            @ApiResponse(responseCode = "401", description = "Unauthorized"),
            @ApiResponse(responseCode = "403", description = "Forbidden"),
            @ApiResponse(responseCode = "404", description = "Not Found", content = @Content(schema = @Schema(implementation = CommonResponse.class))),
            @ApiResponse(responseCode = "406", description = "Invalid Response type"),
            @ApiResponse(responseCode = "405", description = "Invalid Method type"),
            @ApiResponse(responseCode = "412", description = "Precondition Failed", content = @Content(schema = @Schema(implementation = CommonResponse.class))),
            @ApiResponse(responseCode = "415", description = "Unsupported Media Type"),
            @ApiResponse(responseCode = "428", description = "Bad Request, missing required fields",content = @Content(array = @ArraySchema(schema = @Schema(implementation = CommonResponse.class)))),
            @ApiResponse(responseCode = "429", description = "Too many bad request"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error"),
            @ApiResponse(responseCode = "default", description = "All Errors", content = @Content(schema = @Schema(implementation = StandardErrorResponse.class)))
    })
    public ResponseEntity<GridVernResponse> getSupplementsGridVernDataByFSANumber(
            @PathVariable @Size(min = 1, max = 2)
            @Schema(example = "NA", description = "Hub Code") @Pattern(regexp = "^[A-Za-z]*$") String hubCode,
            @Schema(type = "integer", example = "15543", description = "globalFSANumber")
            @PathVariable @Min(0) @Max(99999999) int globalFSANumber) {
        GridVernResponse response = gridService.getGridVernInfoSupplements(hubCode, globalFSANumber);
        return ResponseEntity.ok(response);
    }

    @GetMapping(value = "/gridverninfo/fsa/{hubCode}/{globalFSANumber}/{supplementCode}")
    @Operation(summary = "Get Grid Vern Data by FSA Number", security = {
			@SecurityRequirement(name = "ADFS"),
			@SecurityRequirement(name = "AzureAD")
	})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Submit VFD Request", content = {
                    @Content(mediaType = "application/json", schema = @Schema(implementation = GridVernResponse.class))}),
            @ApiResponse(responseCode = "400", description = "Bad Request, missing required fields"),
            @ApiResponse(responseCode = "401", description = "Unauthorized"),
            @ApiResponse(responseCode = "403", description = "Forbidden"),
            @ApiResponse(responseCode = "404", description = "Not Found", content = @Content(schema = @Schema(implementation = CommonResponse.class))),
            @ApiResponse(responseCode = "406", description = "Invalid Response type"),
            @ApiResponse(responseCode = "405", description = "Invalid Method type"),
            @ApiResponse(responseCode = "412", description = "Precondition Failed", content = @Content(schema = @Schema(implementation = CommonResponse.class))),
            @ApiResponse(responseCode = "415", description = "Unsupported Media Type"),
            @ApiResponse(responseCode = "428", description = "Bad Request, missing required fields",content = @Content(array = @ArraySchema(schema = @Schema(implementation = CommonResponse.class)))),
            @ApiResponse(responseCode = "429", description = "Too many bad request"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error"),
            @ApiResponse(responseCode = "default", description = "All Errors", content = @Content(schema = @Schema(implementation = StandardErrorResponse.class)))
    })
    public ResponseEntity<GridVernResponse> getGridVernDataByFSANumber(
            @PathVariable @NotNull @Size(min = 1, max = 2) @Schema(example = "NA", description = "Hub Code") @Pattern(regexp = "^[A-Za-z]*$") String hubCode,
            @Schema(type = "integer", example = "15543", description = "globalFSANumber")
            @PathVariable @Min(0) @Max(99999999) int globalFSANumber,
            @PathVariable @Size(min = 1, max = 2) @Schema(example = "AA", description = "Supplement Code") @Pattern(regexp = "^[A-Za-z\\d]*$") String supplementCode) {
        GridVernResponse response = gridService.getGridVernDataByFSANumber(hubCode, globalFSANumber, supplementCode);
        return ResponseEntity.ok(response);
    }

    @Operation(summary = "Update Global FSA number for the GRID vern", security = {
			@SecurityRequirement(name = "ADFS"),
			@SecurityRequirement(name = "AzureAD")
	})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Submit VFD Request", content = {
                    @Content(mediaType = "application/problem+json", schema = @Schema(implementation = CommonResponse.class))}),
            @ApiResponse(responseCode = "400", description = "Bad Request, missing required fields"),
            @ApiResponse(responseCode = "401", description = "Unauthorized"),
            @ApiResponse(responseCode = "403", description = "Forbidden"),
            @ApiResponse(responseCode = "404", description = "Not Found", content = @Content(schema = @Schema(implementation = CommonResponse.class))),
            @ApiResponse(responseCode = "405", description = "Invalid Method type"),
            @ApiResponse(responseCode = "406", description = "Invalid Response type"),
            @ApiResponse(responseCode = "412", description = "Precondition Failed", content = @Content(schema = @Schema(implementation = CommonResponse.class))),
            @ApiResponse(responseCode = "415", description = "Unsupported Media Type"),
            @ApiResponse(responseCode = "428", description = "Bad Request, missing required fields", content = @Content(array = @ArraySchema(schema = @Schema(implementation = CommonResponse.class)))),
            @ApiResponse(responseCode = "429", description = "Too many bad request"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")})
    @PostMapping(value = "/gridverninfo/fsa/assign")
    public ResponseEntity<CommonResponse> updateGlobalFSANumber(
            @RequestBody @Valid GridBasicVernInfo gridBasicVernInfo) {
        if (gridBasicVernInfo != null && checkMandatoryParam(gridBasicVernInfo)) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(CommonResponse.builder().status(CommonConstants.FAILURE)
                            .statusCode(String.valueOf(HttpStatus.NOT_FOUND.value()))
                            .statusDescription("Mandatory Param missing").build());
        }

        int response = gridService.updateGlobalFSANumber(gridBasicVernInfo,
                GridGCampConstants.UPDATE_GLOBAL_FSA_WITH_NEW_VERSION);
        if (response == -1) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(CommonResponse.builder().status(CommonConstants.FAILURE)
                            .statusCode(String.valueOf(HttpStatus.NOT_FOUND.value()))
                            .statusDescription("Grid Record not found").build());
        }
        return ResponseEntity
                .ok(CommonResponse.builder().status(CommonConstants.SUCCESS).statusCode(CommonConstants.SUCCESS_CODE)
                        .statusDescription(CommonConstants.UPDATE_SUCCESS_DESCRIPTION).build());
    }

    @GetMapping(value = "/gridverninfo/{globalFSANumber}/exists")
    @Operation(summary = "Check if Vern info exists for the GRID vern", description = "Update Global FSA number for the GRID vern", security = {
			@SecurityRequirement(name = "ADFS"),
			@SecurityRequirement(name = "AzureAD")
	})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Submit VFD Request", content = {
                    @Content(mediaType = "application/problem+json", schema = @Schema(implementation = GridVernInfoExistsResponse.class))}),
            @ApiResponse(responseCode = "400", description = "Bad Request, missing required fields"),
            @ApiResponse(responseCode = "401", description = "Unauthorized"),
            @ApiResponse(responseCode = "403", description = "Forbidden"),
            @ApiResponse(responseCode = "404", description = "Not Found", content = @Content(schema = @Schema(implementation = CommonResponse.class))),
            @ApiResponse(responseCode = "406", description = "Invalid Response type"),
            @ApiResponse(responseCode = "405", description = "Invalid Method type"),
            @ApiResponse(responseCode = "412", description = "Precondition Failed", content = @Content(schema = @Schema(implementation = CommonResponse.class))),
            @ApiResponse(responseCode = "415", description = "Unsupported Media Type"),
            @ApiResponse(responseCode = "428", description = "Bad Request, missing required fields",content = @Content(array = @ArraySchema(schema = @Schema(implementation = CommonResponse.class)))),
            @ApiResponse(responseCode = "429", description = "Too many bad request"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error"),
            @ApiResponse(responseCode = "default", description = "All Errors", content = @Content(schema = @Schema(implementation = StandardErrorResponse.class)))
    })
    public ResponseEntity<GridVernInfoExistsResponse> checkIfGridVernInfoExists(
            @Schema(type = "integer", example = "15543", description = "globalFSANumber")
            @PathVariable @Min(0) @Max(99999999) int globalFSANumber) {
        boolean exists = gridService.checkIfGridVernInfoExists(globalFSANumber, StringUtils.EMPTY);
        return ResponseEntity.ok(GridVernInfoExistsResponse.builder().vernInfoExists(exists).build());
    }

    @GetMapping(value = "/gridverninfo/{globalFSANumber}/{supplementCode}/exists")
    @Operation(summary = "Check if Vern info exists for the GRID vern", security = {
			@SecurityRequirement(name = "ADFS"),
			@SecurityRequirement(name = "AzureAD")
	})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Submit VFD Request", content = {
                    @Content(mediaType = "application/problem+json", schema = @Schema(implementation = GridVernInfoExistsResponse.class))}),
            @ApiResponse(responseCode = "400", description = "Bad Request, missing required fields"),
            @ApiResponse(responseCode = "401", description = "Unauthorized"),
            @ApiResponse(responseCode = "403", description = "Forbidden"),
            @ApiResponse(responseCode = "404", description = "Not Found", content = @Content(schema = @Schema(implementation = CommonResponse.class))),
            @ApiResponse(responseCode = "406", description = "Invalid Response type"),
            @ApiResponse(responseCode = "405", description = "Invalid Method type"),
            @ApiResponse(responseCode = "412", description = "Precondition Failed", content = @Content(schema = @Schema(implementation = CommonResponse.class))),
            @ApiResponse(responseCode = "415", description = "Unsupported Media Type"),
            @ApiResponse(responseCode = "428", description = "Bad Request, missing required fields",content = @Content(array = @ArraySchema(schema = @Schema(implementation = CommonResponse.class)))),
            @ApiResponse(responseCode = "429", description = "Too many bad request"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error"),
            @ApiResponse(responseCode = "default", description = "All Errors", content = @Content(schema = @Schema(implementation = StandardErrorResponse.class)))
    })
    public ResponseEntity<GridVernInfoExistsResponse> checkIfGridVernInfoExistsBySupplement(
            @Schema(type = "integer", example = "15543", description = "globalFSANumber")
            @PathVariable @Min(0) @Max(99999999) int globalFSANumber,
            @PathVariable @Size(min = 0, max = 2) @Schema(example = "AA", description = "Supplement Code") @Pattern(regexp = "^[A-Za-z0-9]*$") String supplementCode) {
        boolean exists = gridService.checkIfGridVernInfoExists(globalFSANumber, supplementCode);
        return ResponseEntity.ok(GridVernInfoExistsResponse.builder().vernInfoExists(exists).build());
    }

    @GetMapping(value = "/gridverninfo/latest/{globalFSANumber}/{supplementCode}/exists")
    @Operation(summary = "To check if latest grid Vern exists", description = "Update OTA Indicator for the GRID vern and Vehicle criteria", security = {
			@SecurityRequirement(name = "ADFS"),
			@SecurityRequirement(name = "AzureAD")
	})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Submit VFD Request", content = {
                    @Content(mediaType = "application/problem+json", schema = @Schema(implementation = GridVernInfoExistsResponse.class))}),
            @ApiResponse(responseCode = "400", description = "Bad Request, missing required fields"),
            @ApiResponse(responseCode = "401", description = "Unauthorized"),
            @ApiResponse(responseCode = "403", description = "Forbidden"),
            @ApiResponse(responseCode = "404", description = "Not Found", content = @Content(schema = @Schema(implementation = CommonResponse.class))),
            @ApiResponse(responseCode = "406", description = "Invalid Response type"),
            @ApiResponse(responseCode = "405", description = "Invalid Method type"),
            @ApiResponse(responseCode = "412", description = "Precondition Failed", content = @Content(schema = @Schema(implementation = CommonResponse.class))),
            @ApiResponse(responseCode = "415", description = "Unsupported Media Type"),
            @ApiResponse(responseCode = "428", description = "Bad Request, missing required fields",content = @Content(array = @ArraySchema(schema = @Schema(implementation = CommonResponse.class)))),
            @ApiResponse(responseCode = "429", description = "Too many bad request"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error"),
            @ApiResponse(responseCode = "default", description = "All Errors", content = @Content(schema = @Schema(implementation = StandardErrorResponse.class)))
    })
    public ResponseEntity<GridVernInfoExistsResponse> checkIfLatestGridVernExists(
            @Schema(type = "integer", example = "15543", description = "globalFSANumber")
            @PathVariable @Min(0) @Max(99999999) int globalFSANumber,
            @PathVariable @Size(min = 1, max = 2) @Schema(example = "AA", description = "Supplement Code") @Pattern(regexp = "^[A-Za-z0-9]*$") String supplementCode) {
        boolean exists = gridService.checkIfLatestGridVernExists(globalFSANumber, supplementCode);
        return ResponseEntity.ok(GridVernInfoExistsResponse.builder().vernInfoExists(exists).build());
    }

    @Operation(summary = "Send VERN status to GRID", description = "Send VERN status to GRID", security = {
			@SecurityRequirement(name = "ADFS"),
			@SecurityRequirement(name = "AzureAD")
	})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Vern Status send successfully to GRID"),
            @ApiResponse(responseCode = "400", description = "Bad Request, missing required fields"),
            @ApiResponse(responseCode = "401", description = "Unauthorized"),
            @ApiResponse(responseCode = "403", description = "Forbidden"),
            @ApiResponse(responseCode = "404", description = "Not Found"),
            @ApiResponse(responseCode = "405", description = "Invalid Method type"),
            @ApiResponse(responseCode = "406", description = "Invalid Response type"),
            @ApiResponse(responseCode = "415", description = "Unsupported Media Type"),
            @ApiResponse(responseCode = "428", description = "Bad Request, missing required fields", content = @Content(array = @ArraySchema(schema = @Schema(implementation = CommonResponse.class)))),
            @ApiResponse(responseCode = "429", description = "Too many bad request"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")})
    @GetMapping("/gridverninfo/vernstatus/send")
    @ResponseStatus(value = HttpStatus.NO_CONTENT)
    public void sendVernStatus() {
        gridService.sendVernStatusToGrid();
    }

    @Operation(summary = "VFD Request from GRID", description = "Submit VFD Report for GRID", security = {
			@SecurityRequirement(name = "ADFS"),
			@SecurityRequirement(name = "AzureAD")
	})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Submit VFD Request", content = {
                    @Content(mediaType = "application/problem+json", schema = @Schema(implementation = CommonResponse.class))}),
            @ApiResponse(responseCode = "400", description = "Bad Request, missing required fields"),
            @ApiResponse(responseCode = "401", description = "Unauthorized"),
            @ApiResponse(responseCode = "403", description = "Forbidden"),
            @ApiResponse(responseCode = "404", description = "Not Found", content = @Content(schema = @Schema(implementation = CommonResponse.class))),
            @ApiResponse(responseCode = "406", description = "Invalid Response type"),
            @ApiResponse(responseCode = "405", description = "Invalid Method type"),
            @ApiResponse(responseCode = "412", description = "Precondition Failed", content = @Content(schema = @Schema(implementation = CommonResponse.class))),
            @ApiResponse(responseCode = "415", description = "Unsupported Media Type"),
            @ApiResponse(responseCode = "428", description = "Bad Request, missing required fields", content = @Content(array = @ArraySchema(schema = @Schema(implementation = CommonResponse.class)))),
            @ApiResponse(responseCode = "429", description = "Too many bad request"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")})
    @PostMapping(value = "/vfd/report")
    public ResponseEntity<CommonResponse> submitVfdReport(@RequestBody @Valid GridVfdRequest gridVfdRequest)
            throws GCAMPException {
        gridVfdRequest.setVfdRequested(true);
        CommonResponse response = gridService.submitVfdReport(gridVfdRequest, GridGCampConstants.GRID_VFD_REQ_PENDING);
        return ResponseEntity.ok(response);
    }

    private boolean checkMandatoryParam(GridBasicVernInfo gridBasicVernInfo) {
        return (StringUtils.isBlank(gridBasicVernInfo.getSupplementId())
                || StringUtils.isBlank(gridBasicVernInfo.getFsaAssignedFlag()));

    }

    // Grid OTA update
    @Operation(summary = "Update OTA Indicator for the GRID vern and Vehicle criteria", description = "Update OTA Indicator for the GRID vern and Vehicle criteria", security = {
			@SecurityRequirement(name = "ADFS"),
			@SecurityRequirement(name = "AzureAD")
	})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Vern Records fetched successfully",
                    content = @Content(mediaType = "application/problem+json", schema = @Schema(implementation = GridOTAUpdateResponse.class))),
            @ApiResponse(responseCode = "400", description = "Bad Request, missing required fields"),
            @ApiResponse(responseCode = "401", description = "Unauthorized"),
            @ApiResponse(responseCode = "403", description = "Forbidden"),
            @ApiResponse(responseCode = "404", description = "Not Found", content = @Content(schema = @Schema(implementation = CommonResponse.class))),
            @ApiResponse(responseCode = "405", description = "Invalid Method type"),
            @ApiResponse(responseCode = "406", description = "Invalid Response type"),
            @ApiResponse(responseCode = "412", description = "Precondition Failed", content = @Content(schema = @Schema(implementation = CommonResponse.class))),
            @ApiResponse(responseCode = "415", description = "Unsupported Media Type"),
            @ApiResponse(responseCode = "428", description = "Bad Request, missing required fields", content = @Content(array = @ArraySchema(schema = @Schema(implementation = CommonResponse.class)))),
            @ApiResponse(responseCode = "429", description = "Too many bad request"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")})
    @PutMapping(value = "/gridverninfo/otaindicator/update")
    public ResponseEntity<GridOTAUpdateResponse> updateOTAIndicator(
            @RequestBody @Valid OTAIndicatorUpdateRequest gridOTAUpdateRequest) throws GCAMPException {

        GridOTAUpdateResponse response = gridService.updateOTAIndicator(gridOTAUpdateRequest);

        gridGCampVernInfoService.sendEmailOnOTAIndicatorUpdate(gridOTAUpdateRequest,
                response);
        return ResponseEntity.ok(response);

    }

}
