package com.ford.gcamp.targeting.gsar.api;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class GsarSearchRequest {


	@Size(min = 0, max = 8)
	@Pattern(regexp = "^[a-zA-Z\\d\\-]*$")
	@Schema(example = "EHAERI", description = "CDSID", minLength = 0, maxLength = 8)
	 private String cdsId;


	@Size(min = 0, max = 20)
	@Pattern(regexp = "^[0-9]*$")
	@Schema(example = "25603597", description = "reportId", minLength = 0, maxLength = 20)
	 private String reportId;

	@Size(min = 0, max = 20)
	@Pattern(regexp = "^[0-9]*$")
	@Schema(example = "7", description = "uniqueId", minLength = 0, maxLength = 20)
	 private String uniqueId;


	@Size(min = 0, max = 2)
	@Pattern(regexp = "^[a-zA-Z\\*\\s]*$")
	@Schema(example = "EU", description = "Hub code", minLength = 0, maxLength = 2)
	private String hubCode;
}
