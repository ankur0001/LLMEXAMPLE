package com.ford.gcamp.targeting.gridgcamp.grid.entity;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Entity
@Table(name = "SDPMA01_COUNTRY")
public class CountryLookupData implements Serializable {

	private static final long serialVersionUID = 1L;
	@Id
	@Column(name = "COUNTRY_ISO3_C")
	private String code;
	@Column(name = "COUNTRY_NAME_X")
	private String description;
}
