package com.ford.gcamp.targeting.manualaddvin.api;

import io.swagger.v3.oas.annotations.extensions.Extension;
import io.swagger.v3.oas.annotations.extensions.ExtensionProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ManualAddVinsVO {
	@NotNull
	@Size(min = 5, max = 6)
	@Pattern(regexp = "^\\d{2}[A-Za-z\\d]{2}\\d{1}\\d*$")
	@Schema(type="string", description = "FSA number",minLength=5,maxLength = 6, extensions = @Extension(properties = @ExtensionProperty(name = "x-42c-sample", value = "15311")))
	private String fsaNumber;

	@NotNull
	@Schema(example = "G", description = "fsaType")
	@Size(min = 1, max = 1)
	@Pattern(regexp = "^[A-Za-z]$", message = "FSA Type")
	private String fsaType;

	@Size(min = 0, max = 600)
	@Pattern(regexp = "^[a-zA-Z\\d\\,]*$")
	@Schema(example = "MAJUP3SF7FC138776,,,,,,,,,,,,,,,,,,,,,,,,", description = "Vin numbers")
	private String vinNumbers;

	@Size(min = 1, max = 8)
	@Pattern(regexp = "^[a-zA-Z\\d\\-]*$")
	@Schema(example = "TDHARTI", description = "CDSID")
	private String cdsId;

	@Size(min = 0, max = 1000)
	@Pattern(regexp = "^[a-zA-Z\\d\\|\\,]*$")
	@Schema(example = "17|1|,2|2|,99|1|", description = "segments and Vingroups combined")
	private String selectedSegmentsAndVinGrps;

	@Schema(example= "Y" , description = "Include Frozen Vin")
	@Size(min = 1, max = 1)
	@Pattern(regexp ="^[A-Za-z]*$")
	private String includeFronzenVin;



	@Schema(example= "Y" , description = "Batch In email")
	@Size(min = 1, max = 1)
	@Pattern(regexp ="^[A-Za-z]*$")
	private String batchInEmail;
	private boolean isLocalTest;


	@Size(min = 1, max = 2)
	@Pattern(regexp = "^[A-Za-z\\d\\s\\*]*$")
	@Schema(example = "**", description = "Vin Group Code")
	private String vinGroupCode;

	@Size(max = 254)
	@Pattern(regexp ="^|[A-Za-z\\d\\s_.,'()\"\\=\\<>\\#\\&/*\\-]*$")
	@Schema(example = "**", description = "Vin Group Description")
	private String vinGroupDescription;

	@Size(min = 1, max = 2)
	@Pattern(regexp = "^[A-Za-z\\d]*$")
	@Schema(example = "AA", description = "supplement code")
	private String supplementCode;


	@Size(min = 0, max = 5)
	@Pattern(regexp = "^[A-Za-z\\d]*$")
	@Schema(example = "8", description = "Segment number")
	private String segmentNumber;

	@Schema(example= "Y" , description = "is New Vin group added")
	@Size(min = 1, max = 1)
	@Pattern(regexp ="^[A-Za-z]*$")
	private String isNewVinGroupAdded;
}
