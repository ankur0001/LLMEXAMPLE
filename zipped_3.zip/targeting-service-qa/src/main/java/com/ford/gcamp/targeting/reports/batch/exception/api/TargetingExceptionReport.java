package com.ford.gcamp.targeting.reports.batch.exception.api;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Builder
public class TargetingExceptionReport {

	private String fileName;
	private String vin;
	private String reason;
	private String componentType;
	private String serialNumber;
	private String count;
	private String vinGroup;
	private String vinGroupDescription;
	private String timeStamp;
    private String activeException;
}
