package com.ford.gcamp.targeting.fsacriteria.api;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class VehicleAttriGrpReq {
	@NotNull
	@Size(min = 1, max = 5)
	@Pattern(regexp = "^[\\d]*$")
	@Schema(example="2471",description = "Vehicle Filter Value")
	private int vehicleFltrVal;

	@NotNull
	@Size(min = 1, max = 50)
	@Pattern(regexp = "^[a-zA-Z\\d\\(\\)\\s\\/\\-\\.\\,]*$")
	@Schema(example="ANGULAR TEST1",description = "Vehicle Filter Value Description")
	private String vehicleFltrDesc;
	public VehicleAttriGrpReq(int vehicleFltrVal, String vehicleFltrDesc) {
		super();
		this.vehicleFltrVal = vehicleFltrVal;
		this.vehicleFltrDesc = vehicleFltrDesc;
	}
	public VehicleAttriGrpReq() {

	}
	
}
