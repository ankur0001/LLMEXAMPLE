package com.ford.gcamp.targeting.properties;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;


@ConfigurationProperties(prefix = "config.toggle")
@Getter
@Setter
@NoArgsConstructor
public class ConfigProperties {

	private boolean createUsingVernService;
	private boolean slice5Flag;
	private boolean parallelProcessingFlag;
}
