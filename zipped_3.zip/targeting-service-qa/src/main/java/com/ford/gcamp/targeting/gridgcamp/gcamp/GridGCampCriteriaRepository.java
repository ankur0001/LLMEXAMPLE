package com.ford.gcamp.targeting.gridgcamp.gcamp;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ford.gcamp.targeting.gridgcamp.gcamp.entity.GridCriteriaData;
import com.ford.gcamp.targeting.gridgcamp.gcamp.entity.GridCriteriaId;

@Repository
public interface GridGCampCriteriaRepository extends JpaRepository<GridCriteriaData, GridCriteriaId> {

}
