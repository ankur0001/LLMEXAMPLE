package com.ford.gcamp.targeting.fsacriteria;

import java.util.List;

import com.ford.gcamp.targeting.fsacriteria.api.DynamicQueryMappingReq;
import com.ford.gcamp.targeting.fsacriteria.api.DynamicQueryResponse;
import com.ford.gcamp.targeting.fsacriteria.api.FsaFilterCriteriaResponse;

public interface FsaCriteriaFilterService {
	
	List<FsaFilterCriteriaResponse> getFsaBrandModelVehLinePlant();

	List<FsaFilterCriteriaResponse> getAllWersDetails();

	DynamicQueryResponse getFsaDetails(DynamicQueryMappingReq dynamicMappingRequest);

}
