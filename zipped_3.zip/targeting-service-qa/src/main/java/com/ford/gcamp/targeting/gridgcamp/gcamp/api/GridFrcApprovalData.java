package com.ford.gcamp.targeting.gridgcamp.gcamp.api;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;
import org.springframework.validation.annotation.Validated;

@Setter
@Getter
@Validated
@JsonIgnoreProperties
public class GridFrcApprovalData {



	@NotNull
	@NotBlank(message = "FSA Title is mandatory")
	@Schema(example = "FSA Brake Air Bag 2020, Launch")
	@Size(min = 1, max = 254, message = "length 1-254")
	@Pattern(regexp ="^[a-zA-Z\\d .\\-_,]*$", message = "FSA Title")
	private String fsaTitle;

	@NotNull
	@NotBlank(message = "FRC Approval Date is mandatory")
	@Schema(example = "2021-10-25")
	@Size(min = 10, max = 10, message = "length 1-10")
	private String frcApprovalDate;

	@Schema(description = "supplementId")
	@Size(min = 1, max = 2, message = "length 1-2")
	@Pattern(regexp ="^[A-Za-z\\d]*$", message = "Supplement Code")
	private String supplementId;

	@NotNull
	@NotBlank(message = "FSA Type is mandatory")
	@Schema(example = "C")
	@Size(min = 1, max = 1, message = "length 1")
	@Pattern(regexp ="^[A-Za-z\\d]*$", message = "FSA Type")
	private String fsaType;

	@Schema(description = "updateId")
	@Size(min = 0, max = 8, message = "Max length 8")
	@Pattern(regexp ="^[A-Za-z\\d]*$", message = "Update CDSId")
	private String updateId;


	@Schema(description = "globalFSANumber")
	@Min(0)
	@Max(99999999)
	private int globalFSANumber;
	
}
