package com.ford.gcamp.targeting.fsacriteria.api;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class FsaFilterCriteriaResponse {
	
	private int id;
	private String relatedId;
	private String modelCode;
	private String brandCode;
	private String brandDesc;
	private String vehLine;
	private String vehLineDesc;
	private String plant;
	private String plantDesc;
	private int wersCode;
	private String wersDesc;
	private String wersValue;
	private String wersValueDesc;
	private String filterCode;
	private String filterDesc;
	private String wersFamilyCode;
	
	
	public FsaFilterCriteriaResponse(int id, String relatedId, int wersCode, String wersDesc, String wersValue,
			String wersValueDesc) {
		super();
		this.id = id;
		this.relatedId = relatedId;
		this.wersCode = wersCode;
		this.wersDesc = wersDesc;
		this.wersValue = wersValue;
		this.wersValueDesc = wersValueDesc;
	}


	public FsaFilterCriteriaResponse(int wersCode, String wersDesc,String wersValue) {
		super();
		this.wersCode = wersCode;
		this.wersDesc = wersDesc;
		this.wersValue = wersValue;
	}



	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("FsaFilterCriteriaResponse [id=");
		builder.append(id);
		builder.append(", relatedId=");
		builder.append(relatedId);
		builder.append(", modelCode=");
		builder.append(modelCode);
		builder.append(", brandCode=");
		builder.append(brandCode);
		builder.append(", brandDesc=");
		builder.append(brandDesc);
		builder.append(", vehLine=");
		builder.append(vehLine);
		builder.append(", vehLineDesc=");
		builder.append(vehLineDesc);
		builder.append(", plant=");
		builder.append(plant);
		builder.append(", plantDesc=");
		builder.append(plantDesc);
		builder.append(", wersCode=");
		builder.append(wersCode);
		builder.append(", wersDesc=");
		builder.append(wersDesc);
		builder.append(", wersValue=");
		builder.append(wersValue);
		builder.append(", wersValueDesc=");
		builder.append(wersValueDesc);
		builder.append("]");
		return builder.toString();
	}
	
	
	
}
