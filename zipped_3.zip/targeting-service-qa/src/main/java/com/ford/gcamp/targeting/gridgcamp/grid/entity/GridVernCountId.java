package com.ford.gcamp.targeting.gridgcamp.grid.entity;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class GridVernCountId implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private int globalFSANumber;
	private String supplementCode;
	private String countryCode;
	private String hubCode;
	private String roiCode;
	private String brandCode;
	private String vehicleTypeCode;
	private String vehicleLineCode;
	private int modelYear;
	private String soldFlag;
	private int vehicleCount;
	
}
