package com.ford.gcamp.targeting.gfsasetup;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import com.ford.gcamp.targeting.common.CommonConstants;
import com.ford.gcamp.targeting.common.TargetingUtil;
import com.ford.gcamp.targeting.gfsasetup.api.FsaSetupCreateRequest;
import com.ford.gcamp.targeting.gfsasetup.api.GfsaType;

import lombok.extern.slf4j.Slf4j;

@Repository
@Slf4j
public class GlobalFSASetupDao {

	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	@Autowired
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

	@Value("${DB_OWNER}")
	private String ownerId;

	@Value("${db2.uncommit.read}")
	private String uncommitRead;

	public Map<String, Object> createGfsaSetup(FsaSetupCreateRequest fsaSetupCreateRequest) {
		SimpleJdbcCall simpleJdbcCall = null;
		StringBuilder builder = new StringBuilder();
		builder.append(TargetingUtil.fillRemainingString("", 8, CommonConstants.ZERO));
		builder.append(TargetingUtil.fillRemainingString("I", 1, StringUtils.SPACE));
		builder.append(TargetingUtil.fillRemainingString("", 1, StringUtils.SPACE));
		builder.append(TargetingUtil.fillRemainingString(fsaSetupCreateRequest.getCdsid().trim(), 8, StringUtils.SPACE));
		builder.append(TargetingUtil.fillRemainingString(fsaSetupCreateRequest.getSelectedGlobalFSAType(), 2, StringUtils.SPACE));
		builder.append(TargetingUtil.fillRemainingString(fsaSetupCreateRequest.getHub(), 2, StringUtils.SPACE));
		builder.append("I");
		builder.append(TargetingUtil.fillRemainingString(formatInputDate(fsaSetupCreateRequest.getFrcDecisionDate()),
				10, StringUtils.SPACE));
		builder.append(TargetingUtil.fillRemainingString(fsaSetupCreateRequest.getNumber14D(), 5, StringUtils.SPACE));
		builder.append(TargetingUtil.fillRemainingString(fsaSetupCreateRequest.getAuthor14D(), 8, StringUtils.SPACE));
		builder.append(
				TargetingUtil.fillRemainingString(formatInputDate(fsaSetupCreateRequest.getRelinquishDate()), 10, StringUtils.SPACE));
		builder.append(TargetingUtil.fillRemainingString(formatInputDate(fsaSetupCreateRequest.getGlobalLaunchDate()),
				10, StringUtils.SPACE));
		builder.append(TargetingUtil.fillRemainingString(fsaSetupCreateRequest.getFsaLaunchFlag(), 1, StringUtils.SPACE));
		builder.append(TargetingUtil.fillRemainingString(fsaSetupCreateRequest.getGlobalFSADesc(), 254, StringUtils.SPACE));
		if (ObjectUtils.isNotEmpty(fsaSetupCreateRequest.getGridBasicVernInfo())) {
			builder.append(
					TargetingUtil.fillRemainingString(
							Integer.toString(fsaSetupCreateRequest.getGridBasicVernInfo().getGridYearId()), 4,
							CommonConstants.ZERO));
			builder.append(
					TargetingUtil.fillRemainingString(
							Integer.toString(fsaSetupCreateRequest.getGridBasicVernInfo().getGridSequence()), 5,
							CommonConstants.ZERO));
			builder.append(
					TargetingUtil.fillRemainingString(
							Integer.toString(fsaSetupCreateRequest.getGridBasicVernInfo().getImplementationId()), 5,
							CommonConstants.ZERO));
			builder.append(
					TargetingUtil.fillRemainingString(
							String.valueOf(fsaSetupCreateRequest.getGridBasicVernInfo().getVersion()), 5,
							CommonConstants.ZERO));
			builder.append(
					TargetingUtil.fillRemainingString(fsaSetupCreateRequest.getGridBasicVernInfo().getSupplementId(), 2,
							StringUtils.SPACE));
		} else {
			builder.append(TargetingUtil.fillRemainingString(StringUtils.EMPTY, 21, StringUtils.SPACE));
		}
		builder.append(TargetingUtil.fillRemainingString(fsaSetupCreateRequest.getOtaIndicator(), 1, StringUtils.SPACE));
		
		log.info("builder={}", builder);

		simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withSchemaName(CommonConstants.FSA_SCHEMA_NAME)
				.withProcedureName(CommonConstants.GLOBAL_FSA_SETUP_PROC);

		SqlParameterSource sqlParameterSource = new MapSqlParameterSource().addValue("IPARM1", builder.toString())
				.addValue("IPARM2",
						TargetingUtil.fillRemainingString(fsaSetupCreateRequest.getGlobalFSARemarks(), 254, StringUtils.SPACE));

		return simpleJdbcCall.execute(sqlParameterSource);

	}

	public String formatInputDate(String strDate) {
		String newdate = "0001-01-01";
		String textDate = strDate;
		Date date = null;
		if (StringUtils.isNoneBlank(strDate)) {

			SimpleDateFormat sdfInput = new SimpleDateFormat("dd-MMM-yyyy");
			SimpleDateFormat sdfOutput = new SimpleDateFormat("yyyy-MM-dd");

			try {
				date = sdfInput.parse(textDate);
				newdate = sdfOutput.format(date);
			} catch (java.text.ParseException ex) {
				log.error("Parse of date failed.");
			}

		}
		return newdate;
	}

	public List<GfsaType> getGfsaTypes() {
		StringBuilder sql = new StringBuilder();
		sql.append("SELECT DISTINCT GCPA11_FSA_TYPE_C AS code, GCPA11_FSA_TYPE_X AS label, GCPA11_FSA_DPND_TYP_F  AS fsaDependencyType ");
		sql.append(" FROM  ");
		sql.append(ownerId);
		sql.append("SGCPA11_FSA_TYPE ");

		sql.append(" WHERE GCPA11_FROM_DATE_Y <= CURRENT DATE");
		sql.append(" AND GCPA11_TO_DATE_Y >= CURRENT DATE");
		sql.append(" ORDER BY GCPA11_FSA_TYPE_X ");
		sql.append(" " + uncommitRead);
		MapSqlParameterSource inQueryParams = new MapSqlParameterSource();
		return  namedParameterJdbcTemplate.query(sql.toString(), inQueryParams,
				new BeanPropertyRowMapper<GfsaType>(GfsaType.class));
	}

}
