package com.ford.gcamp.targeting.reports.batch.exception.api;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Builder
public class CDMReport {
	private String vin;
	private String currentCountry;
	private String responsibleCountry;
	private String dealer; 
}
