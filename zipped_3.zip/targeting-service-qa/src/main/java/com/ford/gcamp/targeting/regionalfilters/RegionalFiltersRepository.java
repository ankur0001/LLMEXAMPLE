package com.ford.gcamp.targeting.regionalfilters;

import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;
import org.springframework.web.util.HtmlUtils;
import lombok.extern.slf4j.Slf4j;
import com.ford.gcamp.targeting.common.CommonConstants;
import com.ford.gcamp.targeting.common.api.GenericLookup;
import com.ford.gcamp.targeting.core.exception.GCAMPException;
import java.util.HashMap;
import com.ford.gcamp.targeting.regionalfilters.api.RegionalAuditReport;

@Repository
@Slf4j
public class RegionalFiltersRepository {

	@Autowired
	private JdbcTemplate jdbcTemplate;
	@Value("${DB_OWNER}")
	private String ownerId;

	@Value("${db2.uncommit.read}")
	private String uncommitRead;
	@Autowired
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

	public Map<String, Object> commonSearch(String inputParam1, String inputParam2, String inputParam3)
			throws GCAMPException {

		try {
			SimpleJdbcCall simpleJdbcCall = creatSimpleJdbcCall(CommonConstants.FSA_SCHEMA_NAME,
					CommonConstants.REGIONAL_FILTER_GO);
			SqlParameterSource sqlParameterSource = createSqlParameterSource(CommonConstants.INPUT_PARM1, inputParam1,
					CommonConstants.INPUT_PARM2, inputParam2, CommonConstants.INPUT_PARM3, inputParam3);
			log.info("regional filter search input of proc info {}", sqlParameterSource);

			return simpleJdbcCall.execute(sqlParameterSource);

		} catch (Exception e) {
			throw new GCAMPException(CommonConstants.DB_EXCEPTION, e);
		}
	}

	public List<GenericLookup> getCountries() {
		StringBuilder sql = new StringBuilder();
		sql.append("SELECT DISTINCT COUNTRY_ISO3_C, COUNTRY_NAME_X ");
		sql.append(" FROM   ");
		sql.append(ownerId);
		sql.append("SDPMA01_COUNTRY ");
		sql.append(" ORDER BY COUNTRY_NAME_X ");
		sql.append(uncommitRead);
		SqlParameterSource parameters = new MapSqlParameterSource();
		return namedParameterJdbcTemplate.query(sql.toString(), parameters,
				(rs, rowNum) -> new GenericLookup(rs.getString("COUNTRY_ISO3_C").trim(),
						rs.getString("COUNTRY_NAME_X").trim()));
	}

	public Map<String, Object> getStatesProvinces(String inputParam1, String inputParam2) throws GCAMPException {

		try {
			SimpleJdbcCall simpleJdbcCall = creatSimpleJdbcCall();
			SqlParameterSource sqlParameterSource = createSqlParameterSource(CommonConstants.INPUT_PARM1, inputParam1,
					CommonConstants.INPUT_PARM2, inputParam2);
			log.info("input of state province {}", sqlParameterSource);
			return simpleJdbcCall.execute(sqlParameterSource);

		} catch (Exception e) {
			log.error(CommonConstants.EXCEPTION_OCCURED, e);
			throw new GCAMPException(CommonConstants.DB_EXCEPTION);
		}

	}

	public Map<String, Object> saveRegionalFilters(String inputParam1, String inputParam2, String inputParam3,
			String inputParam4, String inputParam5) throws GCAMPException {

		try {
			SimpleJdbcCall simpleJdbcCall = creatSimpleJdbcCall(CommonConstants.FSA_SCHEMA_NAME,
					CommonConstants.REGIONAL_FILTER_SAVE_STORE_PROC);
			SqlParameterSource sqlParameterSource = new MapSqlParameterSource()
					.addValue(CommonConstants.IPARM1, inputParam1).addValue(CommonConstants.IPARM2, inputParam2)
					.addValue(CommonConstants.IPARM3, inputParam3).addValue(CommonConstants.IPARM4, inputParam4)
					.addValue(CommonConstants.IPARM5, inputParam5);
			log.info("input of save regionalfilters {}", sqlParameterSource);
			return simpleJdbcCall.execute(sqlParameterSource);

		} catch (Exception e) {
			log.error(CommonConstants.EXCEPTION_OCCURED, e);
			throw new GCAMPException(CommonConstants.DB_EXCEPTION);
		}

	}

	SimpleJdbcCall creatSimpleJdbcCall() {
		return new SimpleJdbcCall(jdbcTemplate).withSchemaName(CommonConstants.FSA_SCHEMA_NAME)
				.withProcedureName(CommonConstants.REGIONAL_FILTER_STATE_PROVINCE_STORE_PROC)
				.returningResultSet("stateprovinces", new StateProvinceMapper());
	}

	MapSqlParameterSource createSqlParameterSource(String inputParamKey1, String inputParamVal1, String inputParamKey2,
			String inputParamVal2) {
		return new MapSqlParameterSource().addValue(inputParamKey1, inputParamVal1).addValue(inputParamKey2,
				inputParamVal2);

	}

	MapSqlParameterSource createSqlParameterSource(String inputParamKey1, String inputParamVal1, String inputParamKey2,
			String inputParamVal2, String inputParamKey3, String inputParamVal3) {
		return new MapSqlParameterSource().addValue(inputParamKey1, inputParamVal1)
				.addValue(inputParamKey2, inputParamVal2).addValue(inputParamKey3, inputParamVal3);

	}

	SimpleJdbcCall creatSimpleJdbcCall(String schemaName, String procedureName) {
		return new SimpleJdbcCall(jdbcTemplate).withSchemaName(schemaName).withProcedureName(procedureName);
	}

	public List<RegionalAuditReport> getRegionalAuditReport(String globalFSANum, String flag, String supplement) {
		StringBuilder query = new StringBuilder();
		query.append(
				"SELECT GCPA31_RGN_CNT_T AS regionCount, GCPA31_MIGRD_VIN_T AS migrationCount, GCPA31_T_VIN_CNT_T AS vinCount FROM ")
				.append(ownerId).append(" SGCPA31_REGN_PARMS ").append(" WHERE GCPA15_GLOBL_FSA_R= :globalFSANum ")
				.append(" AND GCPA09_SUPPL_C = :supplement ").append(uncommitRead);
		String fsaStatus = getFsaStatus(globalFSANum);
		Map<String, String> auditReportInputParamMap = new HashMap<>();
		auditReportInputParamMap.put("globalFSANum", globalFSANum);
		auditReportInputParamMap.put("supplement", supplement);
		SqlParameterSource parameters = new MapSqlParameterSource(auditReportInputParamMap);
		return namedParameterJdbcTemplate.query(query.toString(), parameters,
				new RegionalAuditReportMapper(flag, fsaStatus));
	}

	public String getFsaStatus(String globalFSANum) {
		String fsaStatus = "";
		StringBuilder sqlQuery = new StringBuilder();
		sqlQuery.append("SELECT GCPA07_FSA_STAT_C AS fsaStatus FROM ").append(ownerId).append(" SGCPA15_GLOBAL_FSA ")
				.append(" WHERE GCPA15_GLOBL_FSA_R= :globalFSANum ").append(uncommitRead);
		SqlParameterSource parameters = new MapSqlParameterSource().addValue("globalFSANum", globalFSANum);
		fsaStatus = namedParameterJdbcTemplate.queryForObject(sqlQuery.toString(), parameters, String.class);
		return fsaStatus;
	}

	public Map<String, Object> deleteRegionalFilters(String inputParam1, String inputParam2, String inputParam3,
			String inputParam4, String inputParam5) throws GCAMPException {

		try {
			SimpleJdbcCall simpleJdbcCall = creatSimpleJdbcCall(CommonConstants.FSA_SCHEMA_NAME,
					CommonConstants.REGIONAL_FILTERS_PROC);
			Map<String, String> inputParamMap = new HashMap<>();
			inputParamMap.put(CommonConstants.IPARM1, inputParam1);
			inputParamMap.put(CommonConstants.IPARM2, inputParam2);
			inputParamMap.put(CommonConstants.IPARM3, inputParam3);
			inputParamMap.put(CommonConstants.IPARM4, inputParam4);
			inputParamMap.put(CommonConstants.IPARM5, inputParam5);

			SqlParameterSource sqlParameterSource = createSqlParameterSource(inputParamMap);

			log.info("input of delete details info {}", sqlParameterSource);
			return simpleJdbcCall.execute(sqlParameterSource);

		} catch (Exception e) {
			log.error(CommonConstants.EXCEPTION_OCCURED, e);
			throw new GCAMPException(CommonConstants.DB_EXCEPTION, e);
		}

	}

	MapSqlParameterSource createSqlParameterSource(Map<String, String> inputParamMap) {
		return new MapSqlParameterSource().addValues(inputParamMap);
	}

	public Map<String, Object> loadCountry(String inputParam1, String inputParam2) throws GCAMPException {

		try {
			SimpleJdbcCall simpleJdbcCall = creatSimpleJdbcCall(CommonConstants.FSA_SCHEMA_NAME,
					CommonConstants.FSA_SELECT_COUNTRY);
			SqlParameterSource sqlParameterSource = createSqlParameterSource(CommonConstants.INPUT_PARM1, inputParam1,
					CommonConstants.INPUT_PARM2, inputParam2, CommonConstants.INPUT_PARM3, StringUtils.SPACE);
			log.info("input of proc info {}", sqlParameterSource);
			return simpleJdbcCall.execute(sqlParameterSource);

		} catch (Exception e) {
			log.error(CommonConstants.EXCEPTION_OCCURED, e);
			throw new GCAMPException(CommonConstants.DB_EXCEPTION, e);
		}

	}

	public List<GenericLookup> getExistingSupplements(String globalFsaNumber) {
		Map<String, Object> valueByKey = new HashMap<>();
		valueByKey.put("globalFsa", HtmlUtils.htmlEscape(globalFsaNumber));
		SqlParameterSource parameters = new MapSqlParameterSource(valueByKey);
		StringBuilder sql = new StringBuilder();
		sql.append("SELECT  PA30.GCPA09_SUPPL_C AS code ,PA09.GCPA09_SUPP_DESC_X  AS description");
		sql.append(" FROM ");
		sql.append(ownerId);
		sql.append("SGCPA30_REGN_FLT PA30 LEFT OUTER JOIN  ");
		sql.append(ownerId);
		sql.append("SGCPA09_FSA_SUPPL  PA09 ");
		sql.append(
				"  ON PA30.GCPA15_GLOBL_FSA_R  =  PA09.GCPA15_GLOBL_FSA_R  AND PA30.GCPA09_SUPPL_C =  PA09.GCPA09_SUPPL_C ");
		sql.append(" WHERE PA30.GCPA15_GLOBL_FSA_R = :globalFsa ");
		sql.append(" GROUP BY PA30.GCPA09_SUPPL_C ,PA09.GCPA09_SUPP_DESC_X ORDER BY PA30.GCPA09_SUPPL_C ");
		sql.append(uncommitRead);
		return namedParameterJdbcTemplate.query(sql.toString(), parameters,
				new BeanPropertyRowMapper<GenericLookup>(GenericLookup.class));
	}

	public List<GenericLookup> getSupplements(String fsaNumber) {
		Map<String, Object> valueByKey = new HashMap<>();
		valueByKey.put("globalFsaNumber", HtmlUtils.htmlEscape(fsaNumber));
		valueByKey.put("inquiryStatus", CommonConstants.FLAG_I);
		valueByKey.put("confirmedStatus", CommonConstants.FLAG_F);
		SqlParameterSource parameters = new MapSqlParameterSource(valueByKey);
		StringBuilder sql = new StringBuilder();
		sql.append("SELECT DISTINCT GCPA09_SUPPL_C AS code ,GCPA09_SUPP_DESC_X AS description ");
		sql.append(" FROM ");
		sql.append(ownerId);
		sql.append("SGCPA09_FSA_SUPPL ");
		sql.append(" WHERE GCPA15_GLOBL_FSA_R = :globalFsaNumber ");
		sql.append(" AND GCPA07_FSA_STAT_C IN ( :inquiryStatus , :confirmedStatus ) ");
		sql.append(" ORDER BY GCPA09_SUPPL_C ");
		sql.append(uncommitRead);
		return namedParameterJdbcTemplate.query(sql.toString(), parameters,
				new BeanPropertyRowMapper<GenericLookup>(GenericLookup.class));
	}

}
