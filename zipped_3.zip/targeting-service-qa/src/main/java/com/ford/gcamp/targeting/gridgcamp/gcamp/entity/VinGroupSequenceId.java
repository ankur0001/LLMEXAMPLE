package com.ford.gcamp.targeting.gridgcamp.gcamp.entity;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import jakarta.persistence.Table;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Builder
@Embeddable
@Table(name="SGCPB18_VINGRPSEQ")
public class VinGroupSequenceId implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	@Column(name = "GCPA15_GLOBL_FSA_R")
	private int globalFSANumber;
	
	@Column(name = "GCPD14_SEGMENT_R")
	private int segmentNumber;
	
	@Column(name = "GCPB18_VINGRPSEQ_R")
	private int vinGroupSequnceNumber;
	
}
