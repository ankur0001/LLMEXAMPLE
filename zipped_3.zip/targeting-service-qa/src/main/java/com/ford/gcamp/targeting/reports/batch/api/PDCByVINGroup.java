package com.ford.gcamp.targeting.reports.batch.api;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class PDCByVINGroup extends GenericReportData {
  	
    	private String country;
    		
    	private String pdcType;
    	
    	private String pdcCode;
    	
    	private String pdcDesc;
    	
    	private String vinGroup;
    	
    	private int count;
}

