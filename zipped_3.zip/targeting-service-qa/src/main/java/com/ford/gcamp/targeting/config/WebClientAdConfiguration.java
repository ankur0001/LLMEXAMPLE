package com.ford.gcamp.targeting.config;

import com.ford.gcamp.targeting.core.exception.GCAMPRuntimeException;
import com.microsoft.aad.msal4j.ClientCredentialFactory;
import com.microsoft.aad.msal4j.ClientCredentialParameters;
import com.microsoft.aad.msal4j.ConfidentialClientApplication;
import com.microsoft.aad.msal4j.IAuthenticationResult;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.HttpHeaders;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.MediaType;
import org.springframework.web.reactive.function.client.WebClient;

import java.net.InetSocketAddress;
import java.net.MalformedURLException;
import java.net.Proxy;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.Collections;
import java.util.Set;
import java.util.concurrent.ExecutionException;

@Configuration
@Slf4j
public class WebClientAdConfiguration {

    public static final String ERROR_IN_WEB_CLIENT_CALL = "Error in web client call: {} ";
    @Value("${fsa_url}")
    private String fsaServiceUrl;
    @Value("${spring.security.oauth2.client.registration.client-fsaservice-azure-ad.client-id}")
    private String clientId;
    @Value("${spring.security.oauth2.client.registration.client-fsaservice-azure-ad.client-secret}")
    private String clientSecret;
    @Value("${spring.security.oauth2.client.provider.client-fsaservice-azure-ad.token-uri}")
    private String uri;
    @Value("${azure.ad.auth.refresh.time.in.minutes}")
    private Long authRefreshTimeInMinutes;
    private String fsaAuthToken;
    private LocalDateTime fsaLastSuccessDT = null;
    private LocalDateTime vernLastSuccessDT = null;
    private LocalDateTime reportingLastSuccessDT = null;
    private String vernAuthToken;
    private String reportingAuthToken;

    @Value("${vern_url}")
    private String vernServiceUrl;

    @Value("${reporting_url}")
    private String reportingServiceUrl;

    @Bean("fsaServiceWebClient")
    WebClient fsaServiceAzureAdClient() {
        try {
            return generateFsaServiceAzureWebClient();
        } catch (Exception e) {
            throw new GCAMPRuntimeException(e.getMessage());
        }
    }

    @Bean("vernServiceWebClient")
    WebClient vernServiceAzureAdClient() {
        try {
            return generateVernServiceAzureWebClient();
        } catch (Exception e) {
            throw new GCAMPRuntimeException(e.getMessage());
        }
    }

    @Bean("reportingServiceWebClient")
    WebClient reportingServiceAzureAdClient() {
        try {
            return generateReportingServiceAzureWebClient();
        } catch (Exception e) {
            throw new GCAMPRuntimeException(e.getMessage());
        }
    }

    public WebClient generateFsaServiceAzureWebClient() {
        return WebClient.builder()
                .baseUrl(fsaServiceUrl)
                .defaultHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                .filter((request, next) -> next.exchange(request)
                        .doOnError(error -> log.error(ERROR_IN_WEB_CLIENT_CALL, error.getMessage(), error)))
                .build();
    }

    public WebClient generateVernServiceAzureWebClient() {
        return WebClient.builder()
                .baseUrl(vernServiceUrl)
                .defaultHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                .filter((request, next) -> next.exchange(request)
                        .doOnError(error -> log.error(ERROR_IN_WEB_CLIENT_CALL, error.getMessage(), error)))
                .build();
    }

    public WebClient generateReportingServiceAzureWebClient() {
        return WebClient.builder()
                .baseUrl(reportingServiceUrl)
                .defaultHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                .filter((request, next) -> next.exchange(request)
                        .doOnError(error -> log.error(ERROR_IN_WEB_CLIENT_CALL, error.getMessage(), error)))
                .build();
    }

    public IAuthenticationResult getiAuthenticationResult(String scope) throws MalformedURLException, InterruptedException, ExecutionException {

        Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress("internet.ford.com", 83));
        ConfidentialClientApplication app = ConfidentialClientApplication.builder(clientId, ClientCredentialFactory.createFromSecret(clientSecret))
                .proxy(proxy)
                .authority(uri + "/")
                .build();

        Set<String> scopes = Collections.singleton(scope);

        ClientCredentialParameters clientCredentialParameters = ClientCredentialParameters
                .builder(scopes)
                .build();

        return app.acquireToken(clientCredentialParameters).get();
    }

    public String getAccessToken(String scope, String serviceName) {
        try {
            if ("fsa".equals(serviceName)) {
                return getToken(scope, serviceName, fsaAuthToken, fsaLastSuccessDT);
            } else if ("vern".equals(serviceName)) {
                return getToken(scope, serviceName, vernAuthToken, vernLastSuccessDT);
            }else if ("reporting".equals(serviceName)) {
                return getToken(scope, serviceName, reportingAuthToken, reportingLastSuccessDT);
            }
        } catch (Exception e) {
            log.error("Error while getting access token from Azure AD", e);
        }
        return null;
    }

    private String getToken(String scope, String serviceName, String authToken, LocalDateTime lastSuccessDT) throws MalformedURLException, ExecutionException, InterruptedException {
        if (lastSuccessDT == null) {
            lastSuccessDT = LocalDateTime.now();
        }
        if (authToken == null || Duration.between(lastSuccessDT, LocalDateTime.now()).toMinutes() > authRefreshTimeInMinutes) {
            IAuthenticationResult result = getiAuthenticationResult(scope);
            authToken = result.accessToken();
            lastSuccessDT = LocalDateTime.now();
        }
        if ("fsa".equals(serviceName)) {
            fsaAuthToken = authToken;
            fsaLastSuccessDT = lastSuccessDT;
        } else if ("vern".equals(serviceName)) {
            vernAuthToken = authToken;
            vernLastSuccessDT = lastSuccessDT;
        }else if ("reporting".equals(serviceName)) {
            reportingAuthToken = authToken;
            reportingLastSuccessDT = lastSuccessDT;
        }
        return authToken;
    }
}
