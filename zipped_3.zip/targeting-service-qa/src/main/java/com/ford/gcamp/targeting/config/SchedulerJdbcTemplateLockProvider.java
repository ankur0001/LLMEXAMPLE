package com.ford.gcamp.targeting.config;

import net.javacrumbs.shedlock.support.StorageBasedLockProvider;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.transaction.PlatformTransactionManager;

import javax.sql.DataSource;
import java.util.TimeZone;

public class SchedulerJdbcTemplateLockProvider extends StorageBasedLockProvider {

    public SchedulerJdbcTemplateLockProvider(JdbcTemplate jdbcTemplate) {
        this(jdbcTemplate, (PlatformTransactionManager) null);
    }

    public SchedulerJdbcTemplateLockProvider(JdbcTemplate jdbcTemplate, PlatformTransactionManager transactionManager) {
        this(jdbcTemplate, transactionManager, "shedlock");
    }

    public SchedulerJdbcTemplateLockProvider(JdbcTemplate jdbcTemplate, String tableName) {
        this(jdbcTemplate, (PlatformTransactionManager) null, tableName);
    }

    public SchedulerJdbcTemplateLockProvider(DataSource dataSource) {
        this(new JdbcTemplate(dataSource));
    }

    public SchedulerJdbcTemplateLockProvider(DataSource dataSource, String tableName) {
        this(new JdbcTemplate(dataSource), tableName);
    }

    public SchedulerJdbcTemplateLockProvider(DataSource dataSource, String tableName, String columnName,
                                             String columnLockUntil, String columnLockedAt, String columnLockedBy) {
        this(Configuration.builder()
                .withJdbcTemplate(new JdbcTemplate(dataSource))
                .withTransactionManager(null)
                .withColumnName(columnName)
                .withColumnLockUntil(columnLockUntil)
                .withColumnLockAt(columnLockedAt)
                .withColumnLockedBy(columnLockedBy)
                .withTableName(tableName).build());
    }

    public SchedulerJdbcTemplateLockProvider(JdbcTemplate jdbcTemplate, PlatformTransactionManager transactionManager, String tableName) {
        this(Configuration.builder().withJdbcTemplate(jdbcTemplate).withTransactionManager(transactionManager).withTableName(tableName).build());
    }

    public SchedulerJdbcTemplateLockProvider(Configuration configuration) {
        super(new SchedulerJdbcTemplateStorageAccessor(configuration));
    }

    public static class Configuration {
        private final JdbcTemplate jdbcTemplate;
        private final PlatformTransactionManager transactionManager;
        private final String tableName;
        private final TimeZone timeZone;

        private final String columnName;
        private final String columnLockUntil;
        private final String columnLockedAt;
        private final String columnLockedBy;

        Configuration(ConfigurationParams configurationParams) {
            this.jdbcTemplate = configurationParams.getJdbcTemplate();
            this.transactionManager = configurationParams.getTransactionManager();
            this.tableName = configurationParams.getTableName();
            this.timeZone = configurationParams.getTimeZone();
            this.columnName = configurationParams.getColumnName();
            this.columnLockUntil = configurationParams.getColumnLockUntil();
            this.columnLockedAt = configurationParams.getColumnLockedAt();
            this.columnLockedBy = configurationParams.getColumnLockedBy();
        }

        public JdbcTemplate getJdbcTemplate() {
            return this.jdbcTemplate;
        }

        public PlatformTransactionManager getTransactionManager() {
            return this.transactionManager;
        }

        public String getTableName() {
            return this.tableName;
        }

        public TimeZone getTimeZone() {
            return this.timeZone;
        }

        public String getColumnName() {
            return columnName;
        }

        public String getColumnLockUntil() {
            return columnLockUntil;
        }

        public String getColumnLockedAt() {
            return columnLockedAt;
        }

        public String getColumnLockedBy() {
            return columnLockedBy;
        }

        public static Builder builder() {
            return new Builder();
        }

        public static class Builder {
            private JdbcTemplate jdbcTemplate;
            private PlatformTransactionManager transactionManager;
            private String tableName = "shedlock";
            private String columnName = "name";
            private String columnLockUntil = "lock_until";
            private String columnLockedAt = "locked_at";
            private String columnLockedBy = "locked_by";

            private TimeZone timeZone;

            public Builder() {
                //Default Method
            }

            public Builder withJdbcTemplate(JdbcTemplate jdbcTemplate) {
                this.jdbcTemplate = jdbcTemplate;
                return this;
            }

            public Builder withTransactionManager(PlatformTransactionManager transactionManager) {
                this.transactionManager = transactionManager;
                return this;
            }

            public Builder withTableName(String tableName) {
                this.tableName = tableName;
                return this;
            }

            public Builder withColumnName(String columnName) {
                this.columnName = columnName;
                return this;
            }

            public Builder withTimeZone(TimeZone timeZone) {
                this.timeZone = timeZone;
                return this;
            }

            public Builder withColumnLockUntil(String columnLockUntil) {
                this.columnLockUntil = columnLockUntil;
                return this;
            }

            public Builder withColumnLockAt(String columnLockAt) {
                this.columnLockedAt = columnLockAt;
                return this;
            }

            public Builder withColumnLockedBy(String columnLockedBy) {
                this.columnLockedBy = columnLockedBy;
                return this;
            }


            public Configuration build() {
                return new Configuration(
                        new ConfigurationParams(this.jdbcTemplate, this.transactionManager, this.tableName, this.timeZone, this.columnName, this.columnLockUntil, this.columnLockedAt, this.columnLockedBy));
            }
        }
    }
}