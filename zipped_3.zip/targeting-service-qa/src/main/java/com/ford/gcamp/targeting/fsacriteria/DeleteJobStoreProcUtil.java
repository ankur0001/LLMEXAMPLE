package com.ford.gcamp.targeting.fsacriteria;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.ford.gcamp.targeting.common.CommonConstants;
import com.ford.gcamp.targeting.fsacriteria.api.FsaDeleteResponseDTO;

@Component
public class DeleteJobStoreProcUtil {

	private static final Logger LOGGER = LoggerFactory.getLogger(DeleteJobStoreProcUtil.class);

	public FsaDeleteResponseDTO deleteFsaList(Map<String, Object> deleteListResponse) {
		FsaDeleteResponseDTO responseStatusDTO = new FsaDeleteResponseDTO();

		String errorParam = (String) deleteListResponse.get(CommonConstants.ERROR_PARM);
		LOGGER.info("deleteFsaList errorParam::{}", errorParam);
		String statusInd = errorParam.substring(9, 10);
		if (statusInd != null && "Y".equalsIgnoreCase(statusInd)) {
			String errorCode = errorParam.substring(37, 40);
			String errorDesc = errorParam.substring(40, 150);
			responseStatusDTO.setStatus(CommonConstants.FAILURE);
			responseStatusDTO.setStatusCode(CommonConstants.FAILURE_CODE);
			responseStatusDTO.setStatusDescription(errorCode + errorDesc);
		} else {
			String jobStatus = (String) deleteListResponse.get("OUTPUT_PARM1");
			String jobName = jobStatus.substring(90, 98);
			LOGGER.info("deleteFsaList jobName::{}", jobName);
			responseStatusDTO.setJobName(jobName);
			responseStatusDTO.setStatus(CommonConstants.SUCCESS);
			responseStatusDTO.setStatusCode(CommonConstants.SUCCESS_CODE);
			responseStatusDTO.setStatusDescription(CommonConstants.SUCCESS_DESC);
		}

		return responseStatusDTO;

	}

	public FsaDeleteResponseDTO globalFsaDelete(Map<String, Object> responseMap) {
		FsaDeleteResponseDTO responseStatusDTO = new FsaDeleteResponseDTO();
		String errorparamResponse = (String) responseMap.get(CommonConstants.ERROR_PARM);
		LOGGER.info("globalFsaDelete error param::{}", errorparamResponse);
		String statusInd = errorparamResponse.substring(9, 10);
		LOGGER.info("globalFsaDelete status indicator::{}", statusInd);
		if (statusInd != null && "Y".equalsIgnoreCase(statusInd)) {
			String errorCode = errorparamResponse.substring(37, 40);
			String errorDesc = errorparamResponse.substring(40, 150);
			responseStatusDTO.setStatus(CommonConstants.FAILURE);
			responseStatusDTO.setStatusCode(CommonConstants.FAILURE_CODE);
			responseStatusDTO.setStatusDescription(errorCode + errorDesc);

		} else {
			String outParmResponse = (String) responseMap.get("OUTPUT_PARM1");
			LOGGER.info("globalFsaDelete output param ::{}", outParmResponse);
			String jobName = outParmResponse.substring(90, 98);
			LOGGER.info("globalFsaDelete jobName ::{}", jobName);
			String statusMessage = outParmResponse.substring(10, 22) + outParmResponse.substring(50, 58);
			responseStatusDTO.setJobName(jobName);
			responseStatusDTO.setStatus(CommonConstants.SUCCESS);
			responseStatusDTO.setStatusCode(CommonConstants.SUCCESS_CODE);
			responseStatusDTO.setStatusDescription(statusMessage);
		}

		return responseStatusDTO;
	}

	public FsaDeleteResponseDTO blockerProcess(Map<String, Object> checkBlockerResponse) {
		FsaDeleteResponseDTO responseStatusDTO = new FsaDeleteResponseDTO();

		String errorParam = (String) checkBlockerResponse.get(CommonConstants.ERROR_PARM);
		LOGGER.info("deleteFsaList errorParam::{}", errorParam);
		String statusInd = errorParam.substring(9, 10);
		if (statusInd != null && "Y".equalsIgnoreCase(statusInd)) {
			String errorCode = errorParam.substring(37, 40);
			String errorDesc = null;
			if ("803".equalsIgnoreCase(errorCode)) {
				errorDesc = "Batch cannot run because some other blocking batch is running";
			} else {
				errorDesc = errorParam.substring(18, 36);
			}
			responseStatusDTO.setStatus(CommonConstants.FAILURE);
			responseStatusDTO.setStatusCode(CommonConstants.FAILURE_CODE);
			responseStatusDTO.setStatusDescription(errorCode + " " + errorDesc);
		} else {
			responseStatusDTO.setStatus(CommonConstants.SUCCESS);
			responseStatusDTO.setStatusCode(CommonConstants.SUCCESS_CODE);
			responseStatusDTO.setStatusDescription(CommonConstants.SUCCESS_DESC);
		}

		return responseStatusDTO;

	}

	public List<String> getVinGrpInData(String vinGrps) {

		String[] grp = vinGrps.split(",");
		return Arrays.asList(grp);
	}

}
