package com.ford.gcamp.targeting.fsacriteria;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ford.gcamp.targeting.fsacriteria.api.LoadStateProvinceDTO;
import com.ford.gcamp.targeting.common.CommonConstants;
import com.ford.gcamp.targeting.fsacriteria.api.CountryData;
import com.ford.gcamp.targeting.fsacriteria.api.StateProvince;

@Component
public class FSADBStoreProcStateprovUtil {

	@Autowired
	private LoadStateProvinceDTO loadStateProvinceResponse;
	
	public LoadStateProvinceDTO callStoreProcedure(Map<String, Object> map) {	
		List<String> uniqueState = new ArrayList<>();
		Map<String, List<CountryData>> response = new HashMap<>();
		@SuppressWarnings("unchecked")
		List<Map<String, Object>> data = (List<Map<String, Object>>) map.get("#result-set-1");
		for (Map<String, Object> map1 : data) {
			String countryCode = (String) map1.get("COUNTRY_ISO3_C");
			if (response.containsKey(countryCode)) {
				List<CountryData> countryList = response.get(countryCode);
				CountryData countryDataResponse = new CountryData();
				if (!uniqueState.contains(map1.get(CommonConstants.STPR_STATE_C))) {
					List<StateProvince> children = new ArrayList<>();
					StateProvince stateProvince = new StateProvince();
					uniqueState.add((String) map1.get(CommonConstants.STPR_STATE_C));
					stateProvince.setStateProCode((String) map1.get(CommonConstants.STPR_STATE_C));
					stateProvince.setLabel((String) map1.get("STPR_NAME_X"));
					children.add(stateProvince);
					countryDataResponse.setChildren(children);
					countryList.add(countryDataResponse);
				}
			} else {
				List<CountryData> countryList = new ArrayList<>();
				CountryData countryDataResponse = new CountryData();
				countryDataResponse.setCountryCode((String) map1.get("COUNTRY_ISO3_C"));
				countryDataResponse.setLabel((String) map1.get("COUNTRY_NAME_X"));
				List<StateProvince> children = new ArrayList<>();
				StateProvince stateProvince = new StateProvince();
				uniqueState.add((String) map1.get(CommonConstants.STPR_STATE_C));
				stateProvince.setStateProCode((String) map1.get(CommonConstants.STPR_STATE_C));
				stateProvince.setLabel((String) map1.get("STPR_NAME_X"));
				children.add(stateProvince);
				countryDataResponse.setChildren(children);
				countryList.add(countryDataResponse);
				response.put(countryCode, countryList);
			}

		}
		CountryData countryDataNew = null;
		List<CountryData> countryList = null;
		List<CountryData> finalcountryList = new ArrayList<>();
		for (Map.Entry<String,List<CountryData>> mapElement : response.entrySet()) {
			countryDataNew = new CountryData();
			List<StateProvince> children = new ArrayList<>();
			countryList = mapElement.getValue();
			setCountryData(countryList, countryDataNew, children);
			countryDataNew.setChildren(children);
			finalcountryList.add(countryDataNew);
		}

		loadStateProvinceResponse.setListCountryData(finalcountryList);
		return loadStateProvinceResponse;
	}

	private void setCountryData(List<CountryData> countryList, CountryData countryDataNew, List<StateProvince> children) {
		for (CountryData countrydata : countryList) {
			if (countrydata.getCountryCode() != null && countrydata.getLabel() != null) {
				countryDataNew.setCountryCode(countrydata.getCountryCode());
				countryDataNew.setLabel(countrydata.getLabel());
			}
			for (StateProvince stateProvince : countrydata.getChildren()) {
				StateProvince stateProvincenew = new StateProvince();
				stateProvincenew.setStateProCode(stateProvince.getStateProCode());
				stateProvincenew.setLabel(stateProvince.getLabel());
				children.add(stateProvincenew);
			}

		}
		
	}

}
