package com.ford.gcamp.targeting.common.api;

import java.util.List;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class FSATypesResponse extends ResponseStatusDTO{
	@Size(min = 0, max = 250, message = "FSA Type List")
	private List<@Valid FSATypes> fsaTypeList;
}
