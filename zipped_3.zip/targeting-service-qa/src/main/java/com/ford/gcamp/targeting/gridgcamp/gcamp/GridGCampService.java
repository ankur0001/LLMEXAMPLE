package com.ford.gcamp.targeting.gridgcamp.gcamp;

import com.ford.gcamp.targeting.common.CommonConstants;
import com.ford.gcamp.targeting.common.CommonRepository;
import com.ford.gcamp.targeting.common.TargetingUtil;
import com.ford.gcamp.targeting.common.api.CommonResponse;
import com.ford.gcamp.targeting.common.api.GenericLookup;
import com.ford.gcamp.targeting.config.WebClientAdConfiguration;
import com.ford.gcamp.targeting.core.exception.GCAMPException;
import com.ford.gcamp.targeting.core.exception.ResourceNotFoundException;
import com.ford.gcamp.targeting.fsacriteria.api.AttributeGroupingList;
import com.ford.gcamp.targeting.fsacriteria.api.LoadFsaResponseDTO;
import com.ford.gcamp.targeting.gfsasetup.api.FsaSetupCreateRequest;
import com.ford.gcamp.targeting.gfsasetup.api.FsaSetupCreateServiceResponse;
import com.ford.gcamp.targeting.gfsasetup.api.VernFsaMappingRequest;
import com.ford.gcamp.targeting.gridgcamp.GridGCampConstants;
import com.ford.gcamp.targeting.gridgcamp.gcamp.api.*;
import com.ford.gcamp.targeting.gridgcamp.gcamp.entity.*;
import com.ford.gcamp.targeting.gridgcamp.grid.GridVernCountService;
import com.ford.gcamp.targeting.properties.ConfigProperties;
import com.ford.gcamp.targeting.setupfsa.api.ModifySaveRequest;
import com.ford.gcamp.targeting.setupfsa.dependentfsa.DependentFsaRepository;
import com.ford.gcamp.targeting.setupfsa.dependentfsa.entity.DependentFsaData;
import com.ford.gcamp.targeting.setupfsa.dependentfsa.entity.DependentFsaId;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.json.JSONObject;
import org.modelmapper.ModelMapper;
import org.modelmapper.convention.MatchingStrategies;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.ExampleMatcher;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.util.*;
import java.util.stream.Collectors;

@Service
@Slf4j
public class GridGCampService {

	public static final String VERN = "vern";
	public static final String ERROR_WHILE_CALLING_VERN_SERVICE = "Error while calling vern service in Targeting";
	private static final String VERN_INFO_DOESN_T_EXISTS_MSG = "The VERN information doesn't exists in GCAMP";
	public static final String ERROR_WHILE_CREATING_VERN = "Error while calling create vern in GCAMP";
	private GridGCampRepository gridRespository;
	private GridGCampCriteriaRepository gridGcampCriteriaRepository;
	private GridGCampEntityMapper entityMapper;
	private GridGCampVernInfoService serviceHelper;

	private FSATypeRepository fsaTypeRepository;
	private SoftwareCriteriaRepository softwareCriteriaRepository;
	private WebClient webClient;
	private WebClientAdConfiguration webClientAdConfiguration;
	private final ConfigProperties configProperties;

	@Autowired
	private ProcessDistributionRepository processDistributionRepository;

	@Autowired
	private CommonRepository commonRepository;
	private GridVernCountService gridVernCountService;

	@Autowired
	private VehicleCriteriaSelectionRepository criteriaSelectionRepository;

	@Autowired
	private FSARepository fsaRepository;

	@Autowired
	private VinGroupSequenceRepository vinGroupSequenceRepository;

	@Autowired
	private DependentFsaRepository dependentFsaRepository;

	@Value("${spring.profiles.active}")
	private String activeProfile;

	@Value("${spring.security.oauth2.client.registration.client-vernservice-azure-ad.scope}")
	private String scope;

	private static final String GRID_UPDATE_NOTIFY = "GRID_UPDATE_NOTIFY";

	public GridGCampService(GridGCampRepository gridRespository,
							GridGCampCriteriaRepository gridGcampCriteriaRepository, GridGCampEntityMapper entityMapper,
							GridGCampVernInfoService serviceHelper, GridVernCountService gridVernCountService,
							FSATypeRepository fsaTypeRepository, SoftwareCriteriaRepository softwareCriteriaRepository,
							@Qualifier("vernServiceWebClient") WebClient webClient, WebClientAdConfiguration webClientAdConfiguration,
							ConfigProperties configProperties) {
		super();
		this.gridRespository = gridRespository;
		this.gridGcampCriteriaRepository = gridGcampCriteriaRepository;
		this.entityMapper = entityMapper;
		this.serviceHelper = serviceHelper;
		this.fsaTypeRepository = fsaTypeRepository;
		this.softwareCriteriaRepository = softwareCriteriaRepository;
		this.gridVernCountService = gridVernCountService;
		this.webClient = webClient;
		this.webClientAdConfiguration = webClientAdConfiguration;
		this.configProperties = configProperties;
	}

	public void setCommonRepository(CommonRepository commonRepository) {
		this.commonRepository = commonRepository;
	}

	/**
	 * Save the received GRID VERN Info in GCAMP
	 *
	 * @param gridVernRequest
	 * @param insert
	 * @return
	 * @throws GCAMPException
	 */
	@Transactional("jpaDb2TransactionManager")
	public CommonResponse saveGridVernData(GridVernInfo gridVernRequest, boolean insert)
			throws ResourceNotFoundException {
		log.info("Vern Info Request from GRID: {}", TargetingUtil.prettyPrintJSON(gridVernRequest));
		try {
			if (configProperties.isCreateUsingVernService()) {
				log.info("Vern Info Request from GRID LDAP Commented");
				if (insert) {
					gridVernRequest.setHubCoordinatorIds(processDistributionRepository.findByHubAndDistributionProcessEntitiesProcessInfo(gridVernRequest.getInitiatingHub().substring(0, 2), GRID_UPDATE_NOTIFY)
							.getDistributionDetailEntities().stream().map(e -> e.getDetailId().getCdsid().trim()).toList());
				}
				createVernService(gridVernRequest, insert);

			} else {

				ModelMapper modelMapper = new ModelMapper();
				// Map GRID VERN information
				gridVernRequest.setSupplementId(TargetingUtil.fillWithZeros(gridVernRequest.getSupplementId(), 2));
				gridVernRequest.setInitiatingHub(StringUtils.length(gridVernRequest.getInitiatingHub()) > 2
						? gridVernRequest.getInitiatingHub().substring(0, 2)
						: gridVernRequest.getInitiatingHub());
				if (StringUtils.isBlank(gridVernRequest.getFrcApprovalDate())) {
					gridVernRequest.setFrcApprovalDate(CommonConstants.INVALID_DATE);
				}
				GridVernId vernCompositeId = modelMapper.map(gridVernRequest, GridVernId.class);
				GridVernData gridVernData = modelMapper.map(gridVernRequest, GridVernData.class);
				gridVernData.setGridVernId(vernCompositeId);
				gridVernData.setGlobalFsaType(CommonConstants.NOT_APPROVED);
				gridVernData.setRequester(StringUtils.upperCase(gridVernData.getRequester()));
				gridVernData.setRequesterDept(serviceHelper.getRequesterDeptFromLdap(gridVernRequest.getRequester()));
				gridVernData.setUpdateId(StringUtils.upperCase(gridVernRequest.getRequester()));
				gridVernData.setConcernDescription(StringUtils.trimToEmpty(gridVernRequest.getConcernDescription()));
				gridVernData.setSpecialRequest(StringUtils.trimToEmpty(gridVernRequest.getSpecialRequest()));
				gridVernData
						.setVinListFileDetails(entityMapper.convertVinAttachmentsToString(gridVernRequest.getVinAttachment()));
				gridVernData.setOtaFlag(gridVernRequest.isOtaIndicator() ? CommonConstants.FLAG_Y : CommonConstants.FLAG_N);
				//For Tandem FSA Mapping from GRID
				gridVernData.setIsTandem(gridVernRequest.isTandem() ? CommonConstants.FLAG_Y: CommonConstants.FLAG_N);
				setTandemFsaDetails(gridVernRequest, gridVernData);

				log.info("OTA indicator at VERN level {}", gridVernData.getOtaFlag());
				log.info("Tandem FLAG {}", gridVernData.getIsTandem());

				// Transform GRID Vehicle Criteria and Software Criteria
				List<GridCriteriaData> gcampVehicleCriteria = new ArrayList<>();
				List<SoftwareCriteriaData> gcampSoftwareCriteria = new ArrayList<>();
				entityMapper.transformGridVehicleCriteria(gridVernRequest, gcampVehicleCriteria, gcampSoftwareCriteria);
				setVfdReportRequestAttributes(gridVernRequest.isVfdRequested(), gridVernRequest.getWersAttributes(),
						gridVernData, GridGCampConstants.GRID_VFD_REQ_RECEIVED);

				log.info("The Vehicle Criteria List size {}", gcampVehicleCriteria.size());
				try {
					Optional<GridVernData> existingGridVernData = gridRespository.findById(vernCompositeId);
					if ((!existingGridVernData.isPresent() && insert) || (existingGridVernData.isPresent() && !insert
							&& existingGridVernData.get().getGlobalFSANumber() == 0)) {
						gridRespository.save(gridVernData);
						gridGcampCriteriaRepository.saveAll(gcampVehicleCriteria);
						softwareCriteriaRepository.saveAll(gcampSoftwareCriteria);
					} else if (existingGridVernData.isPresent() && !insert
							&& existingGridVernData.get().getGlobalFSANumber() != 0) {
						throw new ResourceNotFoundException(
								"The VERN information can't be updated in GCAMP since Global FSA Number "
										+ existingGridVernData.get().getGlobalFSANumber()
										+ " has already been assigned. Please send a new version of this VERN");
					} else if (existingGridVernData.isPresent()) {
						throw new ResourceNotFoundException("The VERN information already exists in GCAMP");
					} else {
						throw new ResourceNotFoundException(VERN_INFO_DOESN_T_EXISTS_MSG);
					}
				} catch (ResourceNotFoundException e) {
					log.error("Exception while saving the GRID details in GCAMP ", e);
					throw new ResourceNotFoundException("Error occured while saving the GRID details in GCAMP");
				}

				if (insert)
					serviceHelper.sendEmailOnNewVERNInfo(gridVernRequest);

			}
			return CommonResponse.builder().status(CommonConstants.SUCCESS).statusCode(CommonConstants.SUCCESS_CODE)
					.statusDescription(CommonConstants.SUBMIT_SUCCESS_DESCRIPTION).build();
		} catch (Exception e) {
			log.error("EXCEPTION WHILE CREATING THE GRID DETAILS IN GCAMP ", e);
			throw new ResourceNotFoundException(ERROR_WHILE_CREATING_VERN);
		}
	}

	public GridVernData createVernService(GridVernInfo gridVernRequest,boolean insertFlag) throws ResourceNotFoundException {
		try {
			log.info("Vern Request targeting to vern service : {}", TargetingUtil.prettyPrintJSON(gridVernRequest));
			GridVernData gridVernData =  (insertFlag ? webClient.post() : webClient.put())
					.uri(insertFlag?"/api/v1/createvern":"/api/v1/updatevern")
					.contentType(MediaType.APPLICATION_JSON)
					.header("Authorization", "Bearer " + webClientAdConfiguration.getAccessToken(scope, VERN))
					.body(Mono.just(gridVernRequest), GridVernInfo.class)
					.retrieve()
					.onStatus(HttpStatusCode::isError, clientResponse -> {
						log.error("Error while calling create vern service in GCAMP - returned status code: {} ", clientResponse.statusCode());
						return Mono.error(new ResourceNotFoundException(clientResponse.statusCode() + " Error while creating Vern"));
					})
					.bodyToMono(GridVernData.class)
					.block();
			if (insertFlag && "0".equalsIgnoreCase(gridVernRequest.getSupplementId())){
				gridVernCountService.sendAssignedVernInfoToGrid(gridVernData, GridGCampConstants.CREATE_GLOBAL_FSA);
			}
			return gridVernData;
		} catch (Exception e) {
			log.error(ERROR_WHILE_CREATING_VERN, e.getMessage());
			throw new ResourceNotFoundException(e.getMessage());
		}
	}


	private void setTandemFsaDetails(GridVernInfo gridVernRequest, GridVernData gridVernData) {
		if (gridVernRequest.isTandem() && ObjectUtils.isNotEmpty(gridVernRequest.getFsaTypes())) {
			gridVernData.setOriginalFsas(StringUtils.isNotEmpty(gridVernRequest.getFsaTypes().getOriginalFsas()) ? gridVernRequest.getFsaTypes().getOriginalFsas() : StringUtils.EMPTY);
			gridVernData.setSupplementFsas(StringUtils.isNotEmpty(gridVernRequest.getFsaTypes().getSupplementFsas()) ? gridVernRequest.getFsaTypes().getSupplementFsas() : StringUtils.EMPTY);
			gridVernData.setGlobalFsas(StringUtils.isNotEmpty(gridVernRequest.getFsaTypes().getGlobalFsas()) ? gridVernRequest.getFsaTypes().getGlobalFsas() : StringUtils.EMPTY);
		}
	}

	private FSAMappingTypes getFsaTypes(GridVernData gridVernData) {
		return FSAMappingTypes.builder()
				.originalFsas(gridVernData.getOriginalFsas())
				.globalFsas(gridVernData.getGlobalFsas())
				.supplementFsas(gridVernData.getSupplementFsas())
				.build();
	}

	@Transactional("jpaDb2TransactionManager")
	public CommonResponse saveGridFrcApprovalData(GridFrcApprovalData gridFrcApprovalData)
			throws ResourceNotFoundException {
		GridVernData gridVernData = gridRespository.getAssignedGridVernInfoBySupplement(
				gridFrcApprovalData.getGlobalFSANumber(),
				TargetingUtil.fillWithZeros(gridFrcApprovalData.getSupplementId(), 2));
		if (gridVernData != null) {
			gridVernData.setGlobalFsaType(gridFrcApprovalData.getFsaType());
			gridVernData.setFsaTitle(gridFrcApprovalData.getFsaTitle());
			gridVernData.setFrcApprovalDate(gridFrcApprovalData.getFrcApprovalDate());
			gridVernData.setUpdateId(gridFrcApprovalData.getUpdateId());
			gridVernData.setFrcApprovedFlag(CommonConstants.FLAG_Y);
			gridRespository.save(gridVernData);
			serviceHelper.updateFrcApprovalData(gridVernData);
			return CommonResponse.builder().status(CommonConstants.SUCCESS).statusCode(CommonConstants.SUCCESS_CODE)
					.statusDescription(CommonConstants.SUBMIT_SUCCESS_DESCRIPTION).build();
		} else {
			throw new ResourceNotFoundException(VERN_INFO_DOESN_T_EXISTS_MSG);
		}
	}

	/**
	 * This method is called when FSA needs to be assigned to Grid VERN Info and
	 * send details to GRID
	 *
	 * @param gridBasicVernInfo
	 * @param actionFlag
	 * @throws GCAMPException
	 */
	@Transactional("jpaDb2TransactionManager")
	public int updateGlobalFSANumber(GridBasicVernInfo gridBasicVernInfo, String actionFlag) {
		ModelMapper modelMapper = new ModelMapper();
		GridVernId gridVernId = modelMapper.map(gridBasicVernInfo, GridVernId.class);
		List<GridVernData> gridVernInfoData = gridRespository.findByGridVernId(gridVernId.getGridYearId(),
				gridVernId.getGridSequence(), gridVernId.getImplementationId());
		if (CollectionUtils.isNotEmpty(gridVernInfoData)) {
			gridVernInfoData.forEach(grid -> {
				grid.setGlobalFSANumber(gridBasicVernInfo.getGlobalFSANumber());
				if (grid.getGridVernId().getSupplementId().equalsIgnoreCase(gridBasicVernInfo.getSupplementId())) {
					grid.setFsaAssignedFlag(
							gridBasicVernInfo.getVersion() == grid.getGridVernId().getVersion() ? CommonConstants.FLAG_Y
									: CommonConstants.FLAG_N);
				}
			});
			gridRespository.saveAll(gridVernInfoData);
		} else {
			return -1;
		}
		GridVernData gridVernData = getAssignedGridVernInfoBySupplement(gridBasicVernInfo.getGlobalFSANumber(),
				gridBasicVernInfo.getSupplementId());
		if (gridVernData == null) {
			return -1;
		}
		gridVernCountService.sendAssignedVernInfoToGrid(gridVernData, actionFlag);
		return 1;

	}

	@Transactional("jpaDb2TransactionManager")
	public void updateNewTandemFSAMappingfromGRID(FsaSetupCreateRequest fsaSetupCreateRequest, int tandemGlobalFSANumber) {
		ModelMapper modelMapper = new ModelMapper();
		GridVernId gridVernId = modelMapper.map(fsaSetupCreateRequest.getGridBasicVernInfo(), GridVernId.class);
		Optional<GridVernData> gridVernData = gridRespository.findByGridVernIdAndIsTandem(gridVernId, fsaSetupCreateRequest.getTandemFlag());
		if (gridVernData.isPresent()) {
			log.info("GRID Vern Data for Tandem: {}", gridVernData);
			List<String> primaryFSAList = new ArrayList<>();
			if (StringUtils.isNotEmpty(gridVernData.get().getOriginalFsas())) {
				String[] str = gridVernData.get().getOriginalFsas().split(",");
				Collections.addAll(primaryFSAList, str);
			}
			if (CollectionUtils.isNotEmpty(primaryFSAList)) {
				List<DependentFsaData> dependentFsaDataList = new ArrayList<>();
				primaryFSAList.forEach(fsa -> {
					DependentFsaId dependentFsaId = DependentFsaId.builder().primaryGlobalFsa(Integer.parseInt(fsa.trim()))
							.dependentGlobalFsa(tandemGlobalFSANumber).categoryCode(CommonConstants.FLAG_T).build();
					dependentFsaDataList.add(DependentFsaData.builder().dependentFsaId(dependentFsaId).updateId(fsaSetupCreateRequest.getCdsid()).batchUpdateId(fsaSetupCreateRequest.getCdsid()).build());
				});
				dependentFsaRepository.saveAll(dependentFsaDataList);
			}
		} else {
			log.info("Error in Creating Tandem FSA {}", VERN_INFO_DOESN_T_EXISTS_MSG);
		}

	}

	@Transactional("jpaDb2TransactionManager")
	public void updateGlobalFSAType(int globalFSANumber, String fsaTypeCode, String updateId) {
		GridVernData gridVernData = getAssignedGridVernInfoBySupplement(globalFSANumber, CommonConstants.TWO_ZEROS);
		if (gridVernData != null && gridVernData.getGlobalFSANumber() != 0) {
			FSATypeLookupData fsaType = fsaTypeRepository.findFirstByCode(fsaTypeCode);
			String gridFSATypeCode = CommonConstants.NOT_APPROVED.equalsIgnoreCase(fsaType.getCode())
					? fsaType.getCode()
					: StringUtils.trimToEmpty(fsaType.getGridCode());
			if (StringUtils.isNotBlank(gridFSATypeCode)) {
				gridVernData.setGlobalFsaType(gridFSATypeCode);
				gridVernData.setUpdateId(updateId);
				gridRespository.save(gridVernData);
			}
		}
	}

	/**
	 * This method is called when click on Confirm Population in View Targeting
	 * Reports Screen and send details to GRID
	 *
	 * @param globalFSANumber
	 * @param supplementCode
	 */
	@Transactional("jpaDb2TransactionManager")
	public void updateGridVernInfoOfficialVersion(int globalFSANumber, String supplementCode) {
		GridVernData gridVernData = getAssignedGridVernInfoBySupplement(globalFSANumber, supplementCode);
		if (gridVernData != null && gridVernData.getGlobalFSANumber() != 0) {
			gridVernData.setVernStatus(CommonConstants.FLAG_O);
			gridRespository.save(gridVernData);
			gridVernCountService.sendAssignedVernInfoToGrid(gridVernData, GridGCampConstants.VEHICLE_CONFIRMATION);
		}
	}

	/**
	 * This method is called from GRID to update FRC approval date or FSA Type after
	 * the FSA is assigned to GRID VERN Info
	 *
	 * @param globalFSANumber
	 * @param supplementCode
	 * @throws GCAMPException
	 */
	@Transactional("jpaDb2TransactionManager")
	public CommonResponse updateGridVernInfo(GridFrcApprovalDateInfo gridFrcApprovalData)
			throws ResourceNotFoundException {
		log.info("FRC Approval Date Update Request from GRID: {}", TargetingUtil.prettyPrintJSON(gridFrcApprovalData));
		GridVernData gridVernData = getAssignedGridVernInfoBySupplement(gridFrcApprovalData.getGlobalFSANumber(),
				TargetingUtil.fillWithZeros(gridFrcApprovalData.getSupplementId(), 2));
		if (gridVernData != null && gridVernData.getGlobalFSANumber() != 0) {
			gridVernData.setUpdateId(StringUtils.trimToEmpty(gridFrcApprovalData.getUpdateId()).toUpperCase());
			updateGridVernInfoField(gridFrcApprovalData, gridVernData);
			gridRespository.save(gridVernData);
			return CommonResponse.builder().status(CommonConstants.SUCCESS).statusCode(CommonConstants.SUCCESS_CODE)
					.statusDescription(CommonConstants.UPDATE_SUCCESS_DESCRIPTION).build();
		}
		throw new ResourceNotFoundException(
				"The GRID Vern Info doesn't exists in GCAMP for a given FSA Number and Supplement Id");
	}

	private void updateGridVernInfoField(GridFrcApprovalDateInfo gridFrcApprovalData, GridVernData gridVernData) {
		if (StringUtils.isNotBlank(gridFrcApprovalData.getFrcApprovalDate())) {
			gridVernData.setFrcApprovalDate(gridFrcApprovalData.getFrcApprovalDate());
			gridVernData.setVernStatusDesc(GridGCampConstants.FRC_DATE_UPDATED);
		} else if (StringUtils.isNotBlank(gridFrcApprovalData.getFsaType())) {
			gridVernData.setGlobalFsaType(gridFrcApprovalData.getFsaType());
			gridVernData.setVernStatusDesc(GridGCampConstants.FSA_TYPE_UPDATED);
		}
	}

	@Transactional("jpaDb2TransactionManager")
	public void saveGridVernData(GridVernData gridVernData) {
		gridRespository.save(gridVernData);
	}

	/**
	 * This method is to get GRID VERN Info to be displayed in GCAMP Screens except
	 * Create Global FSA Setup based on hubCode, globalFSANumber and supplementCode
	 *
	 * @param hubCode
	 * @param globalFSANumber
	 * @param supplementCode
	 * @return
	 */
	public GridVernResponse getGridVernDataByFSANumber(String hubCode, int globalFSANumber, String supplementCode) {
		List<GridVernData> gridVernData;
		if (StringUtils.isNotBlank(supplementCode) && StringUtils.isNotBlank(hubCode)) {
			gridVernData = gridRespository.findByGlobalFSANumberAndSupplementCode(globalFSANumber, supplementCode,
					serviceHelper.getHub(hubCode));
		} else if (StringUtils.isNotBlank(supplementCode)) {
			gridVernData = gridRespository.findByGlobalFSANumberAndSupplementCode(globalFSANumber, supplementCode);
		} else {
			gridVernData = gridRespository.findByGlobalFSANumberOrderByGridVernIdVersionDesc(globalFSANumber);
		}
		return transformGridVernData(gridVernData);
	}

	/**
	 * This method is to get GRID VERN Info to be displayed in Create Global FSA
	 * Setup based on user hubCode and FSA number is 0
	 *
	 * @param hubCode
	 * @return
	 */
	public GridVernResponse getGridVernDataByHubCode(String hubCode) {
		List<GridVernData> gridVernData = gridRespository.findByHub(serviceHelper.getHub(hubCode));
		return transformGridVernData(gridVernData);
	}

	/**
	 * Transform the GRID VERN Info data from the stored format to display format in
	 * screens
	 *
	 * @param gridVernData
	 * @return
	 */
	private GridVernResponse transformGridVernData(List<GridVernData> gridVernData) {
		GridVernResponse gridVernResponse = new GridVernResponse();
		List<GridVernInfo> gridVernInfoList = new ArrayList<>();
		LoadFsaResponseDTO fsaCriteriaLookupData = serviceHelper.getFSACriteriaLookupData();
		List<Integer> attrFilterGroupCodes = fsaCriteriaLookupData.getAttributeGroupingLists().stream()
				.map(AttributeGroupingList::getGcpFilterGRPC).toList();
		List<Integer> vehicleAttrFilterCodes = commonRepository.getFilterCodesByFilterGroup(attrFilterGroupCodes);
		gridVernData.forEach(gcampGridVernData -> {
			ModelMapper modelMapper = new ModelMapper();
			modelMapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STRICT);
			GridVernInfo gridVernInfo = modelMapper.map(gcampGridVernData, GridVernInfo.class);

			gridVernInfo.setOtaIndicator(CommonConstants.FLAG_Y.equalsIgnoreCase(gcampGridVernData.getOtaFlag()));
			//For Tandem FSA
			gridVernInfo.setTandem(CommonConstants.FLAG_Y.equalsIgnoreCase(gcampGridVernData.getIsTandem()));
			if (CommonConstants.FLAG_Y.equalsIgnoreCase(gcampGridVernData.getIsTandem())){
				gridVernInfo.setFsaTypes(getFsaTypes(gcampGridVernData));
			}

			gridVernInfo.setRequesterName(serviceHelper.getRequesterNameFromLdap(gridVernInfo.getRequester()));
			gridVernInfo.setConcernDescription(gcampGridVernData.getConcernDescription());
			if (StringUtils.isNotBlank(gcampGridVernData.getGlobalFsaType())) {
				FSATypeLookupData fsaTypeResponse = gcampGridVernData.getGlobalFsaType().length() > 1
						? fsaTypeRepository.findFirstByCode(gcampGridVernData.getGlobalFsaType())
						: fsaTypeRepository.findFirstByGridCode(gcampGridVernData.getGlobalFsaType());
				gridVernInfo.setFsaTypeResponse(GenericLookup.builder().code(fsaTypeResponse.getCode())
						.description(StringUtils.trimToEmpty(fsaTypeResponse.getDescription())).build());
			}
			if (CommonConstants.INVALID_DATE.equalsIgnoreCase(gridVernInfo.getFrcApprovalDate())) {
				gridVernInfo.setFrcApprovalDate(StringUtils.EMPTY);
			}
			modelMapper.map(gcampGridVernData.getGridVernId(), gridVernInfo);
			gridVernInfo.setVinAttachment(
					entityMapper.convertStringToVinAttachments(gcampGridVernData.getVinListFileDetails()));
			Example<GridCriteriaData> criteriaExample = serviceHelper
					.constructCriteriaExample(gcampGridVernData.getGridVernId());
			List<GridCriteriaData> gridCriteria = gridGcampCriteriaRepository.findAll(criteriaExample);

			log.info("The length of grid criteria retrieved from database {}", gridCriteria.size());
			Example<SoftwareCriteriaData> swCriteriaExample = serviceHelper
					.constructSwCriteriaExample(gcampGridVernData.getGridVernId());
			List<SoftwareCriteriaData> softwareCriteria = softwareCriteriaRepository.findAll(swCriteriaExample);
			log.info("The length of software criteria retrieved from database {}", softwareCriteria.size());
			List<VehicleCriteria> vehicleCriteria = entityMapper.transformGridCriteria(gridCriteria, softwareCriteria,
					fsaCriteriaLookupData, vehicleAttrFilterCodes);
			gridVernInfo.setVehicleCritiera(vehicleCriteria);
			gridVernInfoList.add(gridVernInfo);

		});
		gridVernResponse.setGridVernData(gridVernInfoList);
		gridVernResponse.setStatus(CommonConstants.SUCCESS);
		gridVernResponse.setStatusCode(CommonConstants.SUCCESS_CODE);
		gridVernResponse.setStatusDescription(CommonConstants.SUCCESS_DESCRIPTION);
		return gridVernResponse;
	}

	public GridVernData getAssignedGridVernInfoBySupplement(int globalFSANumber, String supplementCode) {
		return gridRespository.getAssignedGridVernInfoBySupplement(globalFSANumber, supplementCode);
	}

	public List<GridBasicVernInfo> getAssignedBasicGridVernInfoAll(int globalFSANumber) {
		List<GridVernData> gridVernData = gridRespository.getAssignedGridVernInfoByFSANumber(globalFSANumber);
		List<GridBasicVernInfo> gridBasicVerns = new ArrayList<>();
		if (CollectionUtils.isNotEmpty(gridVernData)) {
			gridVernData.forEach(gcampGridVernData -> {
				ModelMapper modelMapper = new ModelMapper();
				modelMapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STRICT);
				GridBasicVernInfo gridBasicVernInfo = modelMapper.map(gcampGridVernData, GridBasicVernInfo.class);
				modelMapper.map(gcampGridVernData.getGridVernId(), gridBasicVernInfo);
				gridBasicVerns.add(gridBasicVernInfo);
			});
		}
		return gridBasicVerns;
	}

	public GridVernResponse getGridVernInfoSupplements(String hubCode, int globalFSANumber) {
		List<GridVernData> gridVernData = gridRespository.findGridVernInfoSupplements(serviceHelper.getHub(hubCode),
				globalFSANumber);
		return transformGridVernData(gridVernData);
	}

	public boolean checkIfGridVernInfoExists(int globalFSANumber) {
		return checkIfGridVernInfoExists(globalFSANumber, StringUtils.EMPTY);
	}

	public boolean checkIfGridVernInfoExists(int globalFSANumber, String supplmentCode) {
		Example<GridVernData> example = serviceHelper.constructGridVernInfoExample(globalFSANumber, supplmentCode,
				CommonConstants.FLAG_Y);
		return gridRespository.exists(example);
	}

	public boolean checkIfLatestGridVernExists(int globalFSANumber, String supplmentCode) {
		Example<GridVernData> latestVernExample = serviceHelper.constructGridVernInfoExample(globalFSANumber,
				supplmentCode, CommonConstants.FLAG_Y);
		Optional<GridVernData> assignedGridVernData = gridRespository.findOne(latestVernExample);
		if (assignedGridVernData.isPresent()) {
			ExampleMatcher vernExistsMatcher = ExampleMatcher.matching()
					.withIgnorePaths(GridGCampConstants.GRID_VERN_ID_VERSION, "globalFSANumber");
			GridVernData gridVernData = new GridVernData();
			gridVernData.setGridVernId(assignedGridVernData.get().getGridVernId());
			gridVernData.setFsaAssignedFlag(CommonConstants.FLAG_N);
			latestVernExample = Example.of(gridVernData, vernExistsMatcher);
			List<GridVernData> availableGirdVernData = gridRespository.findAll(latestVernExample,
					Sort.by(Sort.Direction.DESC, GridGCampConstants.GRID_VERN_ID_VERSION));
			if (CollectionUtils.isNotEmpty(availableGirdVernData)) {
				return availableGirdVernData.get(0).getGridVernId().getVersion() > assignedGridVernData.get()
						.getGridVernId().getVersion();
			}

		}
		return false;
	}

	/**
	 * Invoked by TargetingScheduler to send FSA updates to GRID
	 */
	@Transactional("jpaDb2TransactionManager")
	public void sendVernStatusToGrid() {
		if ("dev".equalsIgnoreCase(activeProfile) || "qa".equalsIgnoreCase(activeProfile)
				|| "prod".equalsIgnoreCase(activeProfile)) {
			List<GridVernData> gridVernData = gridRespository.getAssignedGridVernInfoByStatus();
			if (CollectionUtils.isNotEmpty(gridVernData)) {
				processVernStatusDescription(gridVernData);
			}
		}
	}

	private void processVernStatusDescription(List<GridVernData> gridVernData) {
		gridVernData.forEach(vernData -> {
			String vernStatus = StringUtils.trimToEmpty(vernData.getVernStatusDesc());
			switch (vernStatus) {
				case GridGCampConstants.FSA_DELETED:
					gridVernCountService.sendDeletedFSAInfoToGrid(vernData);
					unAssignGridVernInfo(vernData);
					break;
				case GridGCampConstants.FRC_DATE_UPDATED:
					serviceHelper.sendFRCApprovalDateReceivedEmail(vernData);
					updateVernStatusDescEmpty(vernData);
					break;
				case GridGCampConstants.FSA_TYPE_UPDATED:
					serviceHelper.updateGlobalFSAType(vernData);
					updateVernStatusDescEmpty(vernData);
					break;
				case GridGCampConstants.GCAMP_FSA_TYPE_UPDATED:
					gridVernCountService.sendFSATypeToGrid(vernData);
					updateVernStatusDescEmpty(vernData);
					break;
				case GridGCampConstants.FSA_CONFIRMED:
					updateVfdRequestStatusIfReceived(vernData);
					sendAssignedVernToGrid(vernData);
					break;
				case GridGCampConstants.FSA_INQUIRY:
					sendAssignedVernToGrid(vernData);
					break;
				case GridGCampConstants.FSA_LAUNCHED:
					sendAssignedVernToGrid(vernData);
					break;
				case GridGCampConstants.VIN_FILE_PROCESSED:
					String[] vinFileStatusArr = StringUtils.split(StringUtils.trimToEmpty(vernData.getVinFileStatus()),
							"|");
					List<String> vinFiles = Arrays.asList(vinFileStatusArr);
					vinFiles.forEach(vinFile -> {
						String action = vinFile.substring(0, vinFile.indexOf("_")).toLowerCase();
						String vinFileName = StringUtils.trimToEmpty(vinFile.substring(vinFile.indexOf("_") + 1));
						gridVernCountService.sendVinFileProcessedStatus(vernData, vinFileName, action);
					});
					vernData.setVinFileStatus(StringUtils.EMPTY);
					updateVernStatusDescEmpty(vernData);
					break;
				case GridGCampConstants.REFRESH_SOLD_UNSOLD_COUNT:
					if (configProperties.isParallelProcessingFlag()) {
						gridVernCountService.sendAssignedVernInfoToGrid(vernData, GridGCampConstants.SEND_VERN_COUNT_ON_EXTRACT);
					}
					updateVfdRequestStatusIfReceived(vernData);
					updateVernStatusDescEmpty(vernData);
					break;
				default:
					processLocalFSAChanges(vernData, vernStatus);
			}
			if (GridGCampConstants.GRID_VFD_REQ_PROCESSED
					.equalsIgnoreCase(StringUtils.trimToEmpty(vernData.getVfdRequestStatus()))) {
				sendVfdReportToGrid(vernData);
				gridRespository.save(vernData);
			}
		});
	}

	private void sendAssignedVernToGrid(GridVernData vernData) {
		gridVernCountService.sendAssignedVernInfoToGrid(vernData,
				CommonConstants.FLAG_T.equalsIgnoreCase(vernData.getVernStatus())
						? GridGCampConstants.UPDATE_GLOBAL_FSA_WITH_NEW_VERSION
						: vernData.getVernStatus());
		updateVernStatusDescEmpty(vernData);
	}

	private void processLocalFSAChanges(GridVernData vernData, String vernStatus) {
		boolean localFSACreated = vernStatus.contains(GridGCampConstants.LOCAL_FSA_CREATED);
		boolean localFSADeleted = vernStatus.contains(GridGCampConstants.LOCAL_FSA_DELETED);
		if (localFSACreated || localFSADeleted) {
			String hub = localFSACreated
					? vernStatus.replaceAll(GridGCampConstants.LOCAL_FSA_CREATED, StringUtils.EMPTY)
					: vernStatus.replaceAll(GridGCampConstants.LOCAL_FSA_DELETED, StringUtils.EMPTY);
			String[] regions = StringUtils.split(StringUtils.chop(hub), "_");
			List<String> gridRegions = Arrays.asList(regions);
			gridRegions.replaceAll(region -> serviceHelper.getGridRegion(region));
			gridVernCountService.sendLocalFSAChangesToGrid(vernData, gridRegions,
					localFSACreated ? CommonConstants.FLAG_C : CommonConstants.DELETE);
			updateVernStatusDescEmpty(vernData);
		} else {
			updateVernStatusDescEmpty(vernData);
		}
	}

	private void updateVernStatusDescEmpty(GridVernData vernData) {
		log.info("VERN Status before emptying: {}", vernData.getVernStatusDesc());
		vernData.setVernStatusDesc(StringUtils.EMPTY);
		gridRespository.save(vernData);
	}

	private void updateVfdRequestStatusIfReceived(GridVernData vernData) {
		//Update Received VFD Request to Pending to start the VFD Request Process automatically
		if (GridGCampConstants.GRID_VFD_REQ_RECEIVED
				.equalsIgnoreCase(StringUtils.trimToEmpty(vernData.getVfdRequestStatus()))) {
			vernData.setVfdRequestStatus(GridGCampConstants.GRID_VFD_REQ_PENDING);
		}
	}

	private void unAssignGridVernInfo(GridVernData vernData) {
		List<GridVernData> gridVernInfoData = gridRespository.findByGlobalFSANumberAndSupplementCode(
				vernData.getGlobalFSANumber(), vernData.getGridVernId().getSupplementId());
		gridVernInfoData.forEach(grid -> {
			if (CommonConstants.TWO_ZEROS.equalsIgnoreCase(grid.getGridVernId().getSupplementId())) {
				grid.setGlobalFSANumber(0);
			}
			grid.setFsaAssignedFlag(CommonConstants.FLAG_N);
			grid.setVernStatus(CommonConstants.FLAG_T);
			grid.setVernStatusDesc(StringUtils.EMPTY);
			grid.setUpdateId(vernData.getUpdateId());
		});
		gridRespository.saveAll(gridVernInfoData);
	}

	public void setActiveProfile(String activeProfile) {
		this.activeProfile = activeProfile;
	}

    @Transactional("jpaDb2TransactionManager")
    public CommonResponse submitVfdReport(GridVfdRequest gridVfdRequest, String vfdRequestStatus)
            throws ResourceNotFoundException {
        log.info("VFD Report Request from GRID for FSA : {} : {} ", gridVfdRequest.getGlobalFSANumber(), gridVfdRequest.isVfdRequested()   );
        GridVernData gridVernData = gridRespository.getAssignedGridVernInfoBySupplement(
                gridVfdRequest.getGlobalFSANumber(), TargetingUtil.fillWithZeros(gridVfdRequest.getSupplementId(), 2));
        if (gridVernData != null) {
            log.info("VFD Report GridVernInfo : reportId: {}, gridVernId: {}, VFDRequestStatus: {}", gridVernData.getReportId(), gridVernData.getGridVernId(), gridVernData.getVfdRequestStatus());
            setVfdReportRequestAttributes(gridVfdRequest.isVfdRequested(), gridVfdRequest.getWersAttributes(),
                    gridVernData, vfdRequestStatus);
            gridRespository.save(gridVernData);
            log.info("VFD Report Submitted Successfully for the reportId: {} and gridVernId: {}", gridVernData.getReportId(), gridVernData.getGridVernId());
            return CommonResponse.builder().status(CommonConstants.SUCCESS).statusCode(CommonConstants.SUCCESS_CODE)
                    .statusDescription(CommonConstants.SUBMIT_SUCCESS_DESCRIPTION).build();
        } else {
            log.error("No VERN Info found for FSA: {}", gridVfdRequest.getGlobalFSANumber());
            throw new ResourceNotFoundException("There is no VERN present for given FSA Number and Supplement");
        }
    }

    private void setVfdReportRequestAttributes(boolean vfdRequested, List<GenericLookup> wersAttributes,
            GridVernData gridVernData, String vfdRequestStatus) {
        if (vfdRequested) {
            log.info("VFD requested. Preparing WERS codes from {} selected attributes", CollectionUtils.size(wersAttributes));
            List<String> wersCodes = wersAttributes.stream().map(GenericLookup::getCode).toList();
            gridVernData.setWersCodes(String.join("|", wersCodes));
            gridVernData.setVfdReportDataset(StringUtils.EMPTY);
            gridVernData.setVfdRequestStatus(vfdRequestStatus);
        }
    }

	@Transactional("jpaDb2TransactionManager")
	public void sendVfdReportToGrid(GridVernData gridData) {
		try {
			GridVfdResponse vfdResponse = serviceHelper.uploadVfdReportToS3(gridData);
			log.info("VFD Report Response sent to GRID: {}", TargetingUtil.prettyPrintJSON(vfdResponse));
			CommonResponse gridResponse = gridVernCountService.sendVfdReportResponseToGrid(vfdResponse);
			if (gridResponse != null && CommonConstants.SUCCESS_CODE.equals(gridResponse.getStatusCode())) {
				log.info("VFD Report Response Sent Successfully to GRID");
				gridData.setVfdRequestStatus(GridGCampConstants.GRID_VFD_REQ_COMPLETED);
			} else {
				gridData.setVfdRequestStatus(GridGCampConstants.GRID_VFD_REQ_FAILED);
			}
		} catch (Exception ex) {
			log.error("Error in sending VFD Report Response to GRID", ex);
			gridData.setVfdRequestStatus(GridGCampConstants.GRID_VFD_REQ_FAILED);
		}
	}

	@Transactional("jpaDb2TransactionManager")
	public GridOTAUpdateResponse updateOTAIndicator(@Valid OTAIndicatorUpdateRequest gridOTAUpdateRequest)
			throws GCAMPException {
		log.info("Vern Info Request from GRID: {}", TargetingUtil.prettyPrintJSON(gridOTAUpdateRequest));
		return CollectionUtils.isEmpty(gridOTAUpdateRequest.getVehicleCritiera())
				? updateOTAIndicatorForExistingVern(gridOTAUpdateRequest)
				: updateOTAIndicatorForVehicleLine(gridOTAUpdateRequest);
	}

	public GridOTAUpdateResponse updateOTAIndicatorForExistingVern(
			@Valid OTAIndicatorUpdateRequest gridOTAUpdateRequest) throws GCAMPException {

		ModelMapper modelMapper = new ModelMapper();
		GridVernId gridVernId = modelMapper.map(gridOTAUpdateRequest, GridVernId.class);
		Optional<GridVernData> gridVernData = gridRespository.findById(gridVernId);

		if (gridVernData.isPresent()) {
			GridOTAUpdateResponse gridOTAUpdateResponse = new GridOTAUpdateResponse();
			String otaIndicator = gridOTAUpdateRequest.isOtaIndicator() ? CommonConstants.FLAG_Y
					: CommonConstants.FLAG_N;
			if (gridVernData.get().getOtaFlag().equalsIgnoreCase(otaIndicator)) {
				throw new GCAMPException("The given VERN is already marked as "
						+ (gridOTAUpdateRequest.isOtaIndicator() ? "OTA" : "NON OTA"));
			}
			gridVernData.get().setOtaFlag(otaIndicator);
			gridVernData.get().setRequester(gridOTAUpdateRequest.getRequester());
			gridRespository.save(gridVernData.get());

			log.info("OTA Update at VERN is success at Grid VERN table: {}", gridVernData.get().getGlobalFSANumber());

			// Update A15 table only if FSA is tagged to the VERN
			if (gridOTAUpdateRequest.getGlobalFSANumber() > 0) {
				Optional<FSAData> fsaData = fsaRepository.findById(gridOTAUpdateRequest.getGlobalFSANumber());

				if (fsaData.isPresent()) {
					fsaData.get().setOtaFlag(otaIndicator);
					fsaData.get().setUpdateId(gridOTAUpdateRequest.getRequester());
					fsaRepository.save(fsaData.get());
					log.info("OTA Update to FSA table: {}", fsaData.get().getGlobalFSANumber());
				}
			}
			setSuccessResponse(gridOTAUpdateResponse);

			return gridOTAUpdateResponse;

		} else {
			throw new GCAMPException(VERN_INFO_DOESN_T_EXISTS_MSG);
		}

	}

	public GridOTAUpdateResponse updateOTAIndicatorForVehicleLine(@Valid OTAIndicatorUpdateRequest otaUpdateRequest)
			throws GCAMPException {
		GridOTAUpdateResponse gridOTAUpdateResponse = new GridOTAUpdateResponse();
		Set<String> failedVehicleLines = new HashSet<>();
		List<OTAEmailVehicleLineInfo> emailVehicleLineInfo = new ArrayList<>();

		try {
			otaUpdateRequest.getVehicleCritiera().stream().forEach(vernVehicleCriteria -> {

				OTAEmailVehicleLineInfo vehicleLineEmailInfo = new OTAEmailVehicleLineInfo();
				GridVehicleCriteria vehicleLines = vernVehicleCriteria.getVehicleLine();

				vehicleLines.getValue().stream().forEach(vehicle -> {
					// update OTA to the vehicle Line
					updateGridVernCriteria(otaUpdateRequest, vernVehicleCriteria.isOtaIndicator(),
							StringUtils.trimToEmpty(vehicle.getCode()));

					List<VehicleCriteriaSelectionData> vehicleCriterias = criteriaSelectionRepository
							.findAllByGlobalFSANumberAndFilterCodeAndVehicleAttributeValue(
									otaUpdateRequest.getGlobalFSANumber(), 43,
									StringUtils.trimToEmpty(vehicle.getCode()));

					if (CollectionUtils.isNotEmpty(vehicleCriterias)) {
						if (vehicleCriterias.size() > 1) {
							failedVehicleLines.add(vehicle.getCodeAndDescription());
							log.info(
									"Automatic OTA Update failed as multiple Vin Groups are created for the vehicle line {}",
									vehicle.getCodeAndDescription());
						} else {
							updateOTAIndicatorToVinGroup(otaUpdateRequest, vehicleCriterias, vernVehicleCriteria,
									vehicleLineEmailInfo);
							vehicleLineEmailInfo.setVehicleLine(vehicle.getDescription());
							emailVehicleLineInfo.add(vehicleLineEmailInfo);

						}

					}
				});

			});
		} catch (Exception e) {
			throw new GCAMPException("Error while updating OTA Indocator");
		}
		setSuccessResponse(gridOTAUpdateResponse);
		gridOTAUpdateResponse.setEmailVehicleLineInfo(emailVehicleLineInfo);
		gridOTAUpdateResponse.setUpdateFiledvehicleLines(failedVehicleLines.stream().toList());
		return gridOTAUpdateResponse;
	}

	private void setVehicleEmailInfo(VehicleCriteria vernVehicleCriteria, OTAEmailVehicleLineInfo vehicleLineEmailInfo,
									 String previousOTAIndicator) {
		vehicleLineEmailInfo.setBrands(vernVehicleCriteria.getBrand().getValue().stream()
				.map(GenericLookup::getDescription).collect(Collectors.joining(",")));
		vehicleLineEmailInfo.setModelYears(vernVehicleCriteria.getModelYear().getValue().stream()
				.map(GenericLookup::getCode).collect(Collectors.joining(",")));
		vehicleLineEmailInfo.setUpdatedOTAFlag(
				vernVehicleCriteria.isOtaIndicator() ? CommonConstants.FLAG_Y : CommonConstants.FLAG_N);

		vehicleLineEmailInfo.setPreviousOTAFlag(previousOTAIndicator);

	}

	private void updateOTAIndicatorToVinGroup(OTAIndicatorUpdateRequest otaUpdateRequest,
											  List<VehicleCriteriaSelectionData> vehicleCriterias, VehicleCriteria vernVehicleCriteria,
											  OTAEmailVehicleLineInfo vehicleLineEmailInfo) {
		VehicleCriteriaSelectionData vehicleCriteriaData = vehicleCriterias.get(0);
		Optional<VinGroupSequenceData> vinGroupSequenceData = vinGroupSequenceRepository.findById(
				VinGroupSequenceId.builder().globalFSANumber(otaUpdateRequest.getGlobalFSANumber()).segmentNumber(0)
						.vinGroupSequnceNumber(vehicleCriteriaData.getVinGroupSequenceNuber()).build());

		if (vinGroupSequenceData.isPresent()) {
			String previousOTAIndicator = vinGroupSequenceData.get().getOtaFlag();
			String otaIndicator = vernVehicleCriteria.isOtaIndicator() ? CommonConstants.FLAG_Y
					: CommonConstants.FLAG_N;
			vinGroupSequenceData.get().setOtaFlag(otaIndicator);
			vinGroupSequenceData.get().setUpdateId(otaUpdateRequest.getRequester());
			vinGroupSequenceRepository.save(vinGroupSequenceData.get());
			log.info("Automatic OTA Update is completed for the Vin Group ",
					vinGroupSequenceData.get().getVinGroupLabel());

			updateVERNAndGlobalFSATables(otaUpdateRequest);


			setVehicleEmailInfo(vernVehicleCriteria, vehicleLineEmailInfo, previousOTAIndicator);
		}
	}

	private void updateVERNAndGlobalFSATables(OTAIndicatorUpdateRequest otaUpdateRequest) {
		Optional<FSAData> fsaData = fsaRepository.findById(otaUpdateRequest.getGlobalFSANumber());

		if (fsaData.isPresent() && CommonConstants.FLAG_Y.equalsIgnoreCase(fsaData.get().getOtaFlag())) {
			log.info("Update Global FSA Table OTA Indicator to N {} ", fsaData.get().getGlobalFSANumber());
			fsaData.get().setOtaFlag(CommonConstants.FLAG_N);
			fsaData.get().setUpdateId(otaUpdateRequest.getRequester());
			fsaRepository.save(fsaData.get());
		}

		ModelMapper modelMapper = new ModelMapper();
		GridVernId gridVernId = modelMapper.map(otaUpdateRequest, GridVernId.class);
		Optional<GridVernData> gridVernData = gridRespository.findById(gridVernId);
		if (gridVernData.isPresent() && CommonConstants.FLAG_Y.equalsIgnoreCase(gridVernData.get().getOtaFlag())) {
			gridVernData.get().setOtaFlag(CommonConstants.FLAG_N);
			gridVernData.get().setRequester(otaUpdateRequest.getRequester());
			gridRespository.save(gridVernData.get());
		}

	}

	private void setSuccessResponse(GridOTAUpdateResponse gridOTAUpdateResponse) {
		gridOTAUpdateResponse.setStatus(CommonConstants.SUCCESS);
		gridOTAUpdateResponse.setStatusCode(CommonConstants.SUCCESS_CODE);
		gridOTAUpdateResponse.setStatusDescription(CommonConstants.OTA_UPDATE_SUCCESS);

	}

	private void updateGridVernCriteria(@Valid OTAIndicatorUpdateRequest otaUpdateRequest, boolean otaIndicator,
										String vehicleLineCode) {

		Example<GridCriteriaData> criteriaExample = serviceHelper.constructOTACriteriaExample(otaUpdateRequest);
		List<GridCriteriaData> gridVernCriterias = gridGcampCriteriaRepository.findAll(criteriaExample);

		Optional<GridCriteriaData> attributeCriteriaCodes = gridVernCriterias.stream()
				.filter(criteria -> criteria.getAttributeCode().equalsIgnoreCase(vehicleLineCode)
						&& criteria.getFilterCode() == 43)
				.findFirst();
		if (attributeCriteriaCodes.isPresent()) {
			String otaFlag = otaIndicator ? CommonConstants.FLAG_Y : CommonConstants.FLAG_N;
			List<GridCriteriaData> vinGroupCriteria = gridVernCriterias.stream()
					.filter(vehicleCriteriaAttribute -> vehicleCriteriaAttribute.getGridCriteriaId()
							.getCriteriaNumber() == (attributeCriteriaCodes.get().getGridCriteriaId()
							.getCriteriaNumber()))
					.toList();

			vinGroupCriteria.stream().forEach(criteria -> criteria.setCriteriaOTAIndicator(otaFlag));
			gridGcampCriteriaRepository.saveAll(vinGroupCriteria);
			log.info(" OTA Update is completed for the vehicle criteria for the request {} ",
					otaUpdateRequest.getVernNumber());
		}

	}

	public void updateVfdReportRequestStatus(GridVernId gridVernId, String vfdRequestStatus) {
		Optional<GridVernData> gridVernData = gridRespository.findById(gridVernId);
		if (gridVernData.isPresent()) {
			gridVernData.get().setVfdRequestStatus(vfdRequestStatus);
			gridRespository.save(gridVernData.get());
		}
	}

	public GridVernData updateMappingToVern(VernFsaMappingRequest commonCallVernRequest) throws ResourceNotFoundException {
		try {
			GridVernData gridVernData = webClient.patch()
					.uri("/api/v1/updatevern")
					.contentType(MediaType.APPLICATION_JSON)
					.header("Authorization", "Bearer " + webClientAdConfiguration.getAccessToken(scope, VERN))
					.body(Mono.just(commonCallVernRequest), VernFsaMappingRequest.class)
					.exchangeToMono(clientResponse -> {
						if (clientResponse.statusCode().isError()) {
							return clientResponse.bodyToMono(String.class)
									.flatMap(errorMessage -> {
										JSONObject json = new JSONObject(errorMessage);
										String messages = json.getJSONObject("error").getJSONArray("messages").join(", ");
										log.error("Error while calling update Vern Service from Create Fsa in Targeting returned status code: {}, error message: {}",
												clientResponse.statusCode(), messages);
										return Mono.error(new ResourceNotFoundException(clientResponse.statusCode() + " Error while creating Global Fsa"));

									});
						} else {
							return clientResponse.bodyToMono(GridVernData.class);
						}
					})
					.block();
			return gridVernData;
		} catch (Exception e) {
			log.error(ERROR_WHILE_CALLING_VERN_SERVICE, e);
			throw new ResourceNotFoundException(ERROR_WHILE_CALLING_VERN_SERVICE);
		}
	}

	public void invokeInfoToGrid(GridVernData gridVernData, String message){
		gridVernCountService.sendAssignedVernInfoToGrid(gridVernData, message);
	}

	public void updateNewTandemFsaMappingFromGridUsingVernService(GridVernData gridVernData, FsaSetupCreateRequest fsaSetupCreateRequest, int globalFsaNumber) {
		log.info("GRID Vern Data for Tandem: {}", gridVernData);
		List<String> primaryFSAList = new ArrayList<>();
		if (StringUtils.isNotEmpty(gridVernData.getOriginalFsas())) {
			String[] str = gridVernData.getOriginalFsas().split(",");
			Collections.addAll(primaryFSAList, str);
		}
		if (CollectionUtils.isNotEmpty(primaryFSAList)) {
			List<DependentFsaData> dependentFsaDataList = new ArrayList<>();
			primaryFSAList.forEach(fsa -> {
				DependentFsaId dependentFsaId = DependentFsaId.builder().primaryGlobalFsa(Integer.parseInt(fsa.trim()))
						.dependentGlobalFsa(globalFsaNumber).categoryCode(CommonConstants.FLAG_T).build();
				dependentFsaDataList.add(DependentFsaData.builder().dependentFsaId(dependentFsaId).updateId(fsaSetupCreateRequest.getCdsid()).batchUpdateId(fsaSetupCreateRequest.getCdsid()).build());
			});
			dependentFsaRepository.saveAll(dependentFsaDataList);
		}
	}

}
