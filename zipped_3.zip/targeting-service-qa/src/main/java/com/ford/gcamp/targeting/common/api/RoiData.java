package com.ford.gcamp.targeting.common.api;

import java.util.List;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class RoiData {

	@Size(min = 0, max = 5)
	@Pattern(regexp = "^[a-zA-Z\\d\\*]*$")
	@Schema(example = "NR1", description = "Region of interest")
	private String roiCode;

	@Size(min = 0, max = 30)
	@Pattern(regexp = "^[a-zA-Z\\-\\s]*$")
	@Schema(example = "FORD - NORTH AMERICA", description = "ROI Description")
	private String label;

	@Size(min = 0, max = 250, message = "Country List")
	private List<@Valid Country> children;
}
