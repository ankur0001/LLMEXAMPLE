package com.ford.gcamp.targeting.regionalfilters.api;

import jakarta.validation.constraints.Size;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Builder
public class RegionalAuditReport {
	@Size(min = 0, max = 500, message = "vehiclesTarget List")
	private String vehiclesTarget;
	@Size(min = 0, max = 500, message = "vehiclesWithFSAGeoParams List")
	private String vehiclesWithFSAGeoParams;
	@Size(min = 0, max = 500, message = "excludedVehicles List")
	private String excludedVehicles;
}
