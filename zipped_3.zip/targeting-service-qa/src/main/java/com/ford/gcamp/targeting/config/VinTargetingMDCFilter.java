package com.ford.gcamp.targeting.config;

import java.util.UUID;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import org.slf4j.MDC;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

@Component
public class VinTargetingMDCFilter extends OncePerRequestFilter {


	@Override
    protected void doFilterInternal(final HttpServletRequest request, final HttpServletResponse response, final FilterChain chain)
        throws java.io.IOException, ServletException {
        try {
            String token = UUID.randomUUID().toString().toUpperCase().replace("-", "");
            MDC.put("transactionId", token);
            chain.doFilter(request, response);
        } finally {
            MDC.remove("transactionId");
        }
    }

}
