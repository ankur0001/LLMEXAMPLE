package com.ford.gcamp.targeting.gridgcamp.gcamp.api;

import java.util.List;
import com.ford.gcamp.targeting.common.api.CommonResponse;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class GridOTAUpdateResponse extends CommonResponse {
	@Size(min = 0, max = 250, message = "updateFiledvehicleLines list")
	private List<@Valid String> updateFiledvehicleLines;
	@Size(min = 0, max = 250, message = "emailVehicleLineInfo list")
	private List<@Valid OTAEmailVehicleLineInfo> emailVehicleLineInfo;
	
	

}
