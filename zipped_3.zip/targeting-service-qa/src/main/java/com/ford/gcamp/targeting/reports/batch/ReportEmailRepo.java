package com.ford.gcamp.targeting.reports.batch;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import com.ford.gcamp.targeting.common.CommonConstants;
import com.ford.gcamp.targeting.common.JobQueueRepository;
import com.ford.gcamp.targeting.common.TargetingUtil;
import com.ford.gcamp.targeting.common.entity.JobQueueData;
import com.ford.gcamp.targeting.common.entity.JobQueueDataId;
import com.ford.gcamp.targeting.core.exception.GCAMPException;
import com.ford.gcamp.targeting.reports.batch.api.ReportMetaData;
import com.ford.gcamp.targeting.reports.batch.common.ReportConstants;
import com.ford.gcamp.targeting.reports.batch.common.ReportStandardConstants;
import com.ford.gcamp.targeting.reports.batch.exception.GCAMPReportDB2Exception;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Repository
public class ReportEmailRepo {

	@Value("${db2.uncommit.read}")
	private String uncommitRead;

	@Value("${DB_OWNER}")
	private String ownerId;

	private JdbcTemplate jdbcTemplate;

	private static final String REPORT_ID = "reportId";

	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;
	private JobQueueRepository jobQueueRepository;

	public ReportEmailRepo(JdbcTemplate jdbcTemplate, NamedParameterJdbcTemplate namedParameterJdbcTemplate,
			JobQueueRepository jobQueueRepository) {
		super();
		this.jdbcTemplate = jdbcTemplate;
		this.namedParameterJdbcTemplate = namedParameterJdbcTemplate;
		this.jobQueueRepository = jobQueueRepository;
	}

	public void updateEmailData(ReportMetaData metaData) throws GCAMPException {
		this.executeProcedure(ReportConstants.COMPLETED_JOBS_STORE_PROC, metaData);
	}

	public void getDistList(ReportMetaData metaData) throws GCAMPException {
		this.executeProcedure(ReportConstants.DIST_PROC_NAME, metaData);
	}

	public void getEmailData(ReportMetaData reportMetaData) throws GCAMPException {
		this.executeProcedure(ReportConstants.COMPLETED_JOBS_STORE_PROC, reportMetaData);
	}

	public void processError(ReportMetaData metaData) throws GCAMPException {
		this.executeProcedure(ReportConstants.COMPLETED_JOBS_STORE_PROC, metaData);
	}

	private void executeProcedure(String procedureName, ReportMetaData metaData) throws GCAMPException {

		Map<String, Object> outputMap;
		SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withSchemaName("SYSPROC")
				.withProcedureName(procedureName);

		// Set Row Mapper if any in implementation class
		setRowMapper(simpleJdbcCall, metaData);

		// Set Input Parameters
		SqlParameterSource sqlParameterSource = setInputParameters(metaData);

		// execute the procedure
		try {
			outputMap = simpleJdbcCall.execute(sqlParameterSource);
		} catch (Exception e) {
			throw new GCAMPException("Error in executing procedure: ", e);
		}
		// Return the results and get it from respective implementation class
		getResultSet(outputMap, metaData);
	}

	private SqlParameterSource setInputParameters(ReportMetaData metaData) {
		String inputParm1 = getInputParam(metaData);
		return new MapSqlParameterSource().addValue("INPUT_PARM1", inputParm1);
	}

	private void getResultSet(Map<String, Object> outputMap, ReportMetaData metaData) {

		if (metaData.getActionType().equalsIgnoreCase(ReportStandardConstants.DIST_LIST)) {
			List<String> distList = (List<String>) outputMap.get("distList");
			metaData.setDistributionList(StringUtils.join(distList, ReportStandardConstants.SEMI_COLON));
		} else if (metaData.getActionType().equalsIgnoreCase(ReportStandardConstants.RETRIEVE)) {
			String outputParm1 = (String) outputMap.get("OUTPUT_PARM1");
			if (StringUtils.isNoneBlank(outputParm1) && outputParm1.length() > 1) {
				metaData.setProcessComplete(outputParm1.substring(0, 1));
				metaData.setEmailSubject(StringUtils.trimToEmpty(outputParm1.substring(1)));
			}
			metaData.setEmailBody(StringUtils.trimToEmpty((String) outputMap.get("OUTPUT_PARM2")));
			metaData.setDistributionList(StringUtils.trimToEmpty((String) outputMap.get("OUTPUT_PARM3")));
		}
	}

	private void setRowMapper(SimpleJdbcCall simpleJdbcCall, ReportMetaData metaData) {

		if (metaData.getActionType().equalsIgnoreCase(ReportStandardConstants.DIST_LIST)) {
			simpleJdbcCall.returningResultSet("distList", new RowMapper<String>() {

				@Override
				public String mapRow(ResultSet rs, int rowNum) throws SQLException {
					return rs.getString(1).trim();
				}

			});
		}
	}

	private String getInputParam(ReportMetaData reportMetaData) {

		String action = reportMetaData.getActionType();

		StringBuilder builder = new StringBuilder();
		if (action.equalsIgnoreCase(ReportStandardConstants.RETRIEVE)) {

			builder.append(action);
			builder.append(StringUtils.rightPad(reportMetaData.getRptCode(), 5, StringUtils.SPACE));
			builder.append(reportMetaData.getJobQue());
			builder.append(reportMetaData.getReportId());
			builder.append(StringUtils.rightPad(reportMetaData.getEmailCode(), 5, StringUtils.SPACE));
			builder.append(reportMetaData.getRptFormat());
			builder.append(StringUtils.rightPad(reportMetaData.getDistListFlag(), 1, StringUtils.SPACE));
			builder.append(StringUtils.rightPad(reportMetaData.getHubCode(), 2, StringUtils.SPACE));
			builder.append(StringUtils.rightPad(reportMetaData.getCountryCode(), 3, StringUtils.SPACE));
			if (StringUtils.isNotBlank(reportMetaData.getAgencyCode())) {
				builder.append(StringUtils.rightPad(reportMetaData.getAgencyCode().trim(), 5, StringUtils.SPACE));
			} else {
				builder.append(TargetingUtil.addSpaceToProc(5));
			}
			builder.append(String.format("%05d", reportMetaData.getProcessId()));
			builder.append(StringUtils.rightPad(reportMetaData.getBatchCode(), 3, StringUtils.SPACE));
			builder.append(TargetingUtil.addSpaceToProc(9));

		} else if (action.equalsIgnoreCase(ReportStandardConstants.MODIFY)) {

			builder.append(action);
			builder.append(StringUtils.rightPad(reportMetaData.getRptCode(), 5, StringUtils.SPACE));
			builder.append(reportMetaData.getJobQue());
			builder.append(reportMetaData.getReportId());
			builder.append(TargetingUtil.addSpaceToProc(19));
			builder.append(String.format("%05d", 0));
			builder.append(StringUtils.rightPad(reportMetaData.getBatchCode(), 3, StringUtils.SPACE));
			builder.append(TargetingUtil.addSpaceToProc(9));

		} else if (action.equalsIgnoreCase(ReportStandardConstants.ERROR)) {

			builder.append(action);
			builder.append(StringUtils.rightPad(reportMetaData.getRptCode(), 5, StringUtils.SPACE));
			builder.append(reportMetaData.getJobQue());
			builder.append(reportMetaData.getReportId());
			builder.append(TargetingUtil.addSpaceToProc(5));
			builder.append(reportMetaData.getRptFormat());
			builder.append(TargetingUtil.addSpaceToProc(1));
			builder.append(StringUtils.rightPad(reportMetaData.getHubCode(), 2, StringUtils.SPACE));
			builder.append(StringUtils.rightPad(reportMetaData.getCountryCode(), 3, StringUtils.SPACE));
			if (StringUtils.isNotBlank(reportMetaData.getAgencyCode())) {
				builder.append(StringUtils.rightPad(reportMetaData.getAgencyCode().trim(), 5, StringUtils.SPACE));
			} else {
				builder.append(TargetingUtil.addSpaceToProc(5));
			}
			builder.append(String.format("%05d", 0));
			builder.append(StringUtils.rightPad(reportMetaData.getBatchCode(), 3, StringUtils.SPACE));
			builder.append(TargetingUtil.addSpaceToProc(9));

		} else if (action.equalsIgnoreCase(ReportStandardConstants.DIST_LIST)) {
			builder.append(String.valueOf(reportMetaData.getProcessId()));
			builder.append(StringUtils.rightPad(reportMetaData.getHubCode(), 2, StringUtils.SPACE));
			builder.append(StringUtils.rightPad(reportMetaData.getCountryCode(), 3, StringUtils.SPACE));
			builder.append(ReportStandardConstants.FILLER);
		}

		log.info("Process ID for the Report: {}", reportMetaData.getProcessId());
		log.info("******* Input Param to CSGCSG19 for the action [{}] *******  {}", action, builder.toString());
		return builder.toString();
	}

	public List<String> getAgencys(int reportId) throws GCAMPReportDB2Exception {
		MapSqlParameterSource inQueryParams = new MapSqlParameterSource();
		List<String> agencyList = new ArrayList<>();

		try {
			StringBuilder sql = new StringBuilder();
			sql.append("SELECT  GCPE44_AGENCY_C").append(CommonConstants.FROM_KEYWORD).append(ownerId)
					.append(ReportConstants.META_DATA_TABLE).append("WHERE GCPF01_REPORT_ID_D = :reportId")
					.append(StringUtils.SPACE).append(uncommitRead);

			inQueryParams.addValue(REPORT_ID, reportId);

			log.info("*** INLINE SQL FOR AGENCY(s) CODE IS *** {}", sql.toString());

			agencyList = namedParameterJdbcTemplate.query(sql.toString(), inQueryParams, new RowMapper<String>() {
				public String mapRow(ResultSet rs, int rowNum) throws SQLException {
					return rs.getString(1);
				}
			});

		} catch (Exception sqle) {

			throw new GCAMPReportDB2Exception("Exception in getting Agency Code", sqle);
		}

		return agencyList;
	}

	/**
	 * This method is called from Reporting Service frame work for getting the
	 * ReportGroup by passing Report Code
	 * 
	 * @param String rptCode
	 * @return String reportCode
	 * @exception GCampDatabaseException
	 */
	public String getReportGroup(String rptCode) throws GCAMPReportDB2Exception {
		MapSqlParameterSource inQueryParams = new MapSqlParameterSource();
		String reportCode;
		try {
			StringBuilder sql = new StringBuilder();
			sql.append("SELECT  GCPF04_RPT_GROUP_C").append(ReportConstants.FROM_KEYWORD).append(ownerId)
					.append("SGCPF04_REPORT ").append("WHERE GCPF04_REPORT_C").append(" = :rptCode")
					.append(StringUtils.SPACE).append(uncommitRead);

			inQueryParams.addValue("rptCode", rptCode);

			log.info("INLINE SQL FOR REPORT GROUP IS  {}", sql.toString());

			reportCode = namedParameterJdbcTemplate.queryForObject(sql.toString(), inQueryParams, String.class);

		} catch (Exception e) {
			throw new GCAMPReportDB2Exception("Exception in getting Report Code", e);
		}

		return reportCode;
	}

	public String getErrorEmailCount(int reportId) throws GCAMPReportDB2Exception {
		MapSqlParameterSource inQueryParams = new MapSqlParameterSource();
		try {
			StringBuilder sql = new StringBuilder();
			sql.append("SELECT GCPF02_RPT_FMT_C, GCPF04_REPORT_X, GCPE44_AGENCY_C").append(ReportConstants.FROM_KEYWORD)
					.append(ownerId).append("SGCPF04_REPORT f04, ").append(ownerId).append("SGCPF02_RPTCHILD f02 ")
					.append("WHERE GCPF01_REPORT_ID_D ").append(" = :reportId").append(" and  GCPF02_RPT_COMP_F ")
					.append(" = 'E' ").append(" and f04.GCPF04_REPORT_C = f02.GCPF04_REPORT_C ")
					.append(" and not exists(").append("select 1 ").append(ReportConstants.FROM_KEYWORD).append(ownerId)
					.append("SGCPF02_RPTCHILD ").append(" where GCPF02_RPT_COMP_F ").append(" = 'N'").append(" and ")
					.append("GCPF01_REPORT_ID_D").append("= :reportId").append(")").append(StringUtils.SPACE)
					.append(uncommitRead);

			inQueryParams.addValue(REPORT_ID, reportId);

			log.info("INLINE SQL FOR ERROR EMAIL CHECKING  IS  {}", sql.toString());

			List<String> errorMsgList = namedParameterJdbcTemplate.query(sql.toString(), inQueryParams,
					new RowMapper<String>() {

						@Override
						public String mapRow(ResultSet rs, int rowNum) throws SQLException {
							StringBuilder errorMsg = new StringBuilder();
							errorMsg.append(rs.getString(1).trim()).append(ReportStandardConstants.FILLER)
									.append(rs.getString(2).trim()).append(ReportStandardConstants.FILLER)
									.append(rs.getString(3).trim());
							return errorMsg.toString();
						}

					});
			log.info("Number of Error Records are {}", errorMsgList.size());
			log.info("ErrorMsg is *** {}", errorMsgList);
			return StringUtils.join(errorMsgList, ReportStandardConstants.COMMA);
		} catch (Exception ex) {
			throw new GCAMPReportDB2Exception("Exception in getting Error Email Count", ex);
		}

	}

	public Integer getGoodMailCount(int reportId) throws GCAMPReportDB2Exception {
		MapSqlParameterSource inQueryParams = new MapSqlParameterSource();
		Integer count = 0;
		try {
			StringBuilder sql = new StringBuilder();
			sql.append("SELECT count(1)").append(ReportConstants.FROM_KEYWORD).append(ownerId)
					.append("SGCPF04_REPORT f04, ").append(ownerId).append("SGCPF02_RPTCHILD f02 ")
					.append("WHERE GCPF01_REPORT_ID_D ").append(" = ").append(":reportId")
					.append(" and  GCPF02_RPT_COMP_F ").append(" = 'Y' ")
					.append(" and f04.GCPF04_REPORT_C = f02.GCPF04_REPORT_C ").append(" and not exists(")
					.append("select 1 ").append(ReportConstants.FROM_KEYWORD).append(ownerId)
					.append("SGCPF02_RPTCHILD ").append(" where GCPF02_RPT_COMP_F ").append(" = 'N'").append(" and ")
					.append("GCPF01_REPORT_ID_D").append("=").append(":reportId")
					.append(")").append(StringUtils.SPACE)
					.append(uncommitRead);
			inQueryParams.addValue(REPORT_ID, reportId);
			
			StringBuilder emailSentSql = new StringBuilder();
			
			emailSentSql.append("SELECT count(1)").append(ReportConstants.FROM_KEYWORD).append(ownerId)
			.append("SGCPF01_RPTMASTER ").append("WHERE GCPF01_REPORT_ID_D = :reportId")
			.append(" AND GCPF01_EMAIL_SNT_F = 'Y' ")
			.append(uncommitRead);
			
			log.info("***********SQL FOR EMAIL ALREADY SENT OR NOT ********* {}", emailSentSql.toString());
			
			Integer emailSentCount = namedParameterJdbcTemplate.queryForObject(emailSentSql.toString(), inQueryParams, Integer.class);

			log.info("***********SQL FOR GOOD EMAIL CHECKING ********* {}", sql.toString());

			if (emailSentCount != null && emailSentCount > 0) {
				return 0;
			} else {
				count = namedParameterJdbcTemplate.queryForObject(sql.toString(), inQueryParams, Integer.class);
			}

			log.info("The Good Email Count for report Id {} is {}", reportId, count);

		} catch (Exception e) {
			log.error("Exception occured {}", e.getMessage());
			throw new GCAMPReportDB2Exception("Exception in getting Good Email Count", e);
		}
		return count;
	}
	
	public boolean doesNavisFetchSuccessful(int jobQueueId) {
		JobQueueDataId jobQueueDataId = new JobQueueDataId();
		jobQueueDataId.setBatchCode("001");
		jobQueueDataId.setJobQueueId(jobQueueId);
		Optional<JobQueueData> jobQueueData = jobQueueRepository.findById(jobQueueDataId);
		if (jobQueueData.isPresent()) {
			log.info("Parameter: {}",  jobQueueData.get().getParameter());
			return StringUtils.isNotBlank(jobQueueData.get().getParameter())
					&& jobQueueData.get().getParameter().length() > 680
					&& CommonConstants.FLAG_Y.equalsIgnoreCase(jobQueueData.get().getParameter().substring(680, 681));
		} else {
			return false;
		}
	}
	

}
