package com.ford.gcamp.targeting.common;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.text.ParseException;
import java.util.List;
import java.util.Optional;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ford.gcamp.targeting.common.api.CommonResponse;
import com.ford.gcamp.targeting.common.api.FSACommonGoRequest;
import com.ford.gcamp.targeting.common.api.GenericLookup;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class TargetingUtil {

	private TargetingUtil() {
	}

	public static String addSpaceToProc(String concatValue, int length) {
		StringBuilder sb = new StringBuilder();
		sb.append(concatValue.trim());
		int maxLength = length;
		while (maxLength > 0) {
			sb.append(" ");
			maxLength--;
		}
		return sb.toString();
	}

	public static String addSpaceToProc(int length) {
		StringBuilder sb = new StringBuilder();
		int maxLength = length;
		while (maxLength > 0) {
			sb.append(" ");
			maxLength--;
		}
		return sb.toString();
	}

	public static String addZerosToProc(int length) {
		StringBuilder sb = new StringBuilder();
		int maxLength = length;
		while (maxLength > 0) {
			sb.append("0");
			maxLength--;
		}
		return sb.toString();
	}

	public static String fillRemainingString(String fsaInput, int totalLength, String filter) {
		StringBuilder builder = new StringBuilder();
		if (fsaInput == null) {
			fsaInput = StringUtils.EMPTY;
		}
		if ((" ").equals(filter)) {
			builder.append(fsaInput);
		}
		if (fsaInput != null) {
			int length = fsaInput.length();
			if (length <= totalLength) {
				int remainingLength = totalLength - length;
				int count = 0;
				while (count < remainingLength) {
					builder.append(filter);
					count++;
				}
				if (("0").equals(filter)) {
					builder.append(fsaInput);
				}
			}
		}
		return builder.toString();
	}

	public static String fillRemainingString(int totalLength, String filler) {
		StringBuilder builder = new StringBuilder();
		int maxLength = totalLength;
		while (maxLength > 0) {
			builder.append(filler);
			maxLength--;
		}
		return builder.toString();
	}

	public static String fillFsaTypeValue(String fsaInput, int totalLength, String fsaType) {
		StringBuilder builder = new StringBuilder();
		int length = fsaInput.trim().length();
		String filler = null;
		if ("L".equalsIgnoreCase(fsaType)) {
			builder.append(fsaInput.trim());
			filler = " ";
		} else {
			filler = "0";
		}
		if (length <= totalLength) {
			int remainingLength = totalLength - length;
			int count = 0;
			while (count < remainingLength) {
				builder.append(filler);
				count++;
			}
		}
		if ("G".equalsIgnoreCase(fsaType)) {
			builder.append(fsaInput);
		}
		return builder.toString();
	}

	public static String fillWithZeros(String fsaInput, int totalLength) {
		StringBuilder builder = new StringBuilder();
		if (fsaInput == null || fsaInput.trim().length() == 0) {
			fsaInput = "";
		}
		int length = fsaInput.trim().length();
		String filler = "0";
		if (length <= totalLength) {
			int remainingLength = totalLength - length;
			int count = 0;
			while (count < remainingLength) {
				builder.append(filler);
				count++;
			}
		}
		builder.append(fsaInput.trim());
		return builder.toString();
	}

	public static CommonResponse getCommonResponse(String errorParm1) {

		String statusInd = errorParm1 != null ? errorParm1.substring(9, 10) : "N";
		if (errorParm1 != null && statusInd != null && "Y".equalsIgnoreCase(statusInd)) {
			String errorCode = errorParm1.substring(37, 40);
			String errorDesc = StringUtils.trimToEmpty(errorParm1.substring(40, 150));
			return CommonResponse.builder().status(CommonConstants.FAILURE).statusCode(CommonConstants.FAILURE_CODE)
					.statusDescription(errorCode + errorDesc).build();

		} else {
			return CommonResponse.builder().status(CommonConstants.SUCCESS).statusCode(CommonConstants.SUCCESS_CODE)
					.statusDescription(CommonConstants.SUCCESS_DESCRIPTION).build();

		}

	}

	public static void getResponseStatus(String errorParm1, CommonResponse response) {

		String statusInd = errorParm1 != null ? errorParm1.substring(9, 10) : "N";
		if (errorParm1 != null && statusInd != null && "Y".equalsIgnoreCase(statusInd)) {
			String errorCode = errorParm1.substring(37, 40);
			String errorDesc = StringUtils.trimToEmpty(errorParm1.substring(40, 150));
			response.setStatus(CommonConstants.FAILURE);
			response.setStatusCode(CommonConstants.FAILURE_CODE);
			response.setStatusDescription(errorCode + errorDesc);
		} else {
			response.setStatus(CommonConstants.SUCCESS);
			response.setStatusCode(CommonConstants.SUCCESS_CODE);
			response.setStatusDescription(CommonConstants.SUCCESS_DESCRIPTION);

		}
	}

	public static String getHubDesc(List<Hubs> hubs, String hubCode) {
		if (CollectionUtils.isEmpty(hubs) || StringUtils.isEmpty(hubCode)) {
			return StringUtils.EMPTY;
		}
		Optional<Hubs> hubDetail = hubs.stream().filter(hubData -> hubData.getHubCode().equalsIgnoreCase(hubCode))
				.findFirst();
		if (hubDetail.isPresent()) {
			return hubDetail.get().getHubDescription();
		}
		return StringUtils.EMPTY;
	}
	
	public static String getCntryDesc(List<GenericLookup> countryData, String countryCode) {
		
		if (CollectionUtils.isEmpty(countryData) || StringUtils.isEmpty(countryCode) ){
			return StringUtils.EMPTY;
		}
		Optional<GenericLookup> countryDetail = countryData.stream().filter(countries -> countries.getCode().equalsIgnoreCase(countryCode))
				.findFirst();
		if (countryDetail.isPresent()) {
			return countryDetail.get().getDescription();
		}
		return StringUtils.EMPTY;
	}


	public static String commonFsaGoRequest(FSACommonGoRequest fsaGoRequest) {

		StringBuilder goParm = new StringBuilder();
		goParm.append(fsaGoRequest.getFsaType());
		goParm.append(CommonConstants.FLAG_G.equalsIgnoreCase(fsaGoRequest.getFsaType())
				? TargetingUtil.fillRemainingString(fsaGoRequest.getFsaNumber(), 8, "0")
				: TargetingUtil.fillRemainingString(fsaGoRequest.getFsaNumber(), 10, " "));
		return goParm.toString();
	}

	public static String removeZeros(String input) {

		String pattern = "^0+(?!$)";
		return input.replaceAll(pattern, "");
	}

	public static String formatDate(String date) {

		DateFormat originalFormat = new SimpleDateFormat("yyyy-MM-dd");
		DateFormat preferredFormat = new SimpleDateFormat("dd-MMM-yyyy");
		String parsedDate = StringUtils.EMPTY;
		try {
			if (StringUtils.isNotEmpty(date) && !CommonConstants.INVALID_DATE.equalsIgnoreCase(date)) {
				parsedDate = preferredFormat.format(originalFormat.parse(date));
			}
		} catch (ParseException e) {
			log.error("error while parsing date", e);
		}
		return parsedDate;

	}

	public static boolean compareDates(String input1, String input2) {
		DateTimeFormatter formate = DateTimeFormatter.ofPattern("yyyy-MM-dd-HH.mm.ss");
		LocalDate date1 = LocalDate.parse(input1, formate);
		LocalDate date2 = LocalDate.parse(input2, formate);
		return date1.isAfter(date2);
	}

	public static String getWersDescWithFamilyCode(String wersDesc, String wersFamilyCode) {
		StringBuilder wersDescFamilyCode = new StringBuilder();
		wersDescFamilyCode.append(wersDesc); 
		wersDescFamilyCode.append(" (");
		wersDescFamilyCode.append(wersFamilyCode);
		wersDescFamilyCode.append(")");
		return wersDescFamilyCode.toString();
	}

	public static void getJobCompletionResponse(String batchCode, int jobId, CommonResponse commonResponse) {
		StringBuilder message=new StringBuilder();
		message.append(CommonConstants.JOB_SUBMISSION_MSG);
		message.append(jobId);
		message.append(CommonConstants.BATCH_CODE_MSG);
		message.append(batchCode);
		commonResponse.setStatus(CommonConstants.SUCCESS);
		commonResponse.setStatusCode(CommonConstants.SUCCESS_CODE);
		commonResponse.setStatusDescription(message.toString());
	}
	
	public static <T> String prettyPrintJSON(T object) {
		ObjectMapper objectMapper = new ObjectMapper();
		try {
			return objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(object);
		} catch (Exception e) {
			log.error("Java Object to JSON Parsing Exception: ", e);
		}
		return StringUtils.EMPTY;
	}
}
