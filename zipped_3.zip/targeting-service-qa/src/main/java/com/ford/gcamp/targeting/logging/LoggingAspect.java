package com.ford.gcamp.targeting.logging;

import com.ford.gcamp.targeting.common.CommonConstants;
import java.util.Map;
import java.util.Optional;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationToken;
import org.springframework.stereotype.Component;
import org.springframework.util.StopWatch;

@Aspect
@Component
@Slf4j
public class LoggingAspect {

    @Around(
            "execution(* com.ford.gcamp.targeting.user.*.*(..)) "
                    + "|| execution(* com.ford.gcamp.targeting.common.*.*(..))"
                    + "|| execution(* com.ford.gcamp.targeting.cache.*.*(..))"
                    + "|| execution(* com.ford.gcamp.targeting.core.*.*(..))"
                    + "|| execution(* com.ford.gcamp.targeting.frozenvin.*.*(..))"
                    + "|| execution(* com.ford.gcamp.targeting.fsacriteria.*.*(..))"
                    + "|| execution(* com.ford.gcamp.targeting.gfsasetup.*.*(..))"
                    + "|| execution(* com.ford.gcamp.targeting.gridgcamp.*.*(..))"
                    + "|| execution(* com.ford.gcamp.targeting.gsar.*.*(..))"
                    + "|| execution(* com.ford.gcamp.targeting.manualaddvin.*.*(..))"
                    + "|| execution(* com.ford.gcamp.targeting.prelaunchreports.*.*(..))"
                    + "|| execution(* com.ford.gcamp.targeting.regionalfilters.*.*(..))"
                    + "|| execution(* com.ford.gcamp.targeting.reports.*.*(..))"
                    + "|| execution(* com.ford.gcamp.targeting.segmentation.*.*(..))"
                    + "|| execution(* com.ford.gcamp.targeting.setupfsa.*.*(..))"
                    + "|| execution(* com.ford.gcamp.targeting.supplement.*.*(..))"
                    + "|| execution(* com.ford.gcamp.targeting.vin.*.*(..))")
    public Object methodTimeLogger(ProceedingJoinPoint proceedingJoinPoint) throws Throwable {
        MethodSignature methodSignature = (MethodSignature) proceedingJoinPoint.getSignature();
        Object[] arguments = proceedingJoinPoint.getArgs();

        // Get intercepted method details
        String className = methodSignature.getDeclaringType().getSimpleName();
        String methodName = methodSignature.getName();
        StringBuilder paramBuilder = new StringBuilder();
        for (Object argument : arguments) {
            paramBuilder.append(" {");
            paramBuilder.append(Optional.ofNullable(argument).orElse(StringUtils.EMPTY));
            paramBuilder.append("} ");
        }

        // Measure method execution time
        StopWatch stopWatch =
                new StopWatch(className + "->" + methodName + " ->" + paramBuilder.toString());
        stopWatch.start(methodName);
        Object result = proceedingJoinPoint.proceed();
        stopWatch.stop();
        // Log method execution time
        log.info(
                "Classname={}, MethodName={}, ExecutionTime={}, LoggedInUser={}",
                className,
                methodName,
                String.format("%f", stopWatch.getTotalTimeSeconds()),
                getLoggedInUser());
        return result;
    }

    private String getLoggedInUser() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication != null && !(authentication instanceof AnonymousAuthenticationToken)) {
            if (authentication instanceof JwtAuthenticationToken jwtAuth) {
                Map<String, Object> claims = jwtAuth.getToken().getClaims();
                if (claims.containsKey(CommonConstants.JWT_CDSID_CLAIM)) {
                    return claims.get(CommonConstants.JWT_CDSID_CLAIM)
                            .toString()
                            .split("@")[0]
                            .toLowerCase();
                }
            }
            return authentication.getName();
        } else {
            return "SYSTEM";
        }
    }
}
