package com.ford.gcamp.targeting.prelaunchreports.api;

import io.swagger.v3.oas.annotations.extensions.Extension;
import io.swagger.v3.oas.annotations.extensions.ExtensionProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ViewTargetReportRequest {

	@Size(min = 5, max = 6)
	@Pattern(regexp = "^\\d{2}[A-Za-z\\d]{2}\\d{1}\\d*$")
	@Schema(type="string", description = "FSA number",minLength=5,maxLength = 6, extensions = @Extension(properties = @ExtensionProperty(name = "x-42c-sample", value = "15311")))
	private String fsaNumber;

	@Schema(example = "G", description = "fsaType")
	@Size(min = 0, max = 1)
	@Pattern(regexp = "^[A-Za-z]$", message = "FSA Type")
	private String fsaType;

	@Size(min = 0, max = 8)
	@Pattern(regexp = "^[a-zA-Z\\d\\-]*$")
	@Schema(example = "TDHARTI", description = "CDSID")
	private String cdsId;

	@Min(0)
	@Max(999999999)
	@Schema(example = "15S21", description = "CDSID")
	private int localFsaNumber;

	@Schema(description = "population")
	@Size(min = 1, max = 2, message = "length 1-2")
	@Pattern(regexp ="^[A-Za-z\\d\\*\\s]*$", message = "Supplement Code")
	private String supplementCode;

	@Size(min = 0, max = 2)
	@Pattern(regexp = "^[a-zA-Z\\s\\*\\d]*$")
	@Schema(example = "NA", description = "Hub code")
	private String hubCode;

	@Size(min = 0, max = 2)
	@Pattern(regexp = "^[a-zA-Z\\*\\s\\d]*$")
	@Schema(example = "NA", description = "Hub code")
	private String userHub;

	@Size(min = 0, max = 3)
	@Pattern(regexp = "^[a-zA-Z\\*\\s\\d]*$")
	@Schema(example = "CAN", description = "CountryCode")
	private String userCountryCode;	

}
