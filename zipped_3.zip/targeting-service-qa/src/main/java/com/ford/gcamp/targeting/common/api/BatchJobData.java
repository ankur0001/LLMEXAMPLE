package com.ford.gcamp.targeting.common.api;

import org.springframework.stereotype.Component;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Component
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class BatchJobData {

	@SuppressWarnings("unused")
	private static final long serialVersionUID = -4639041037014306027L;
	private String batchCode;
	private int globalFSANo;
	private String localFSANo;
	private String hubCode;
	private String countryCode;
	private String cdsId;
	private String emailIndicator;
	// All segments
	private int segment = 9999;
	private String supplement;
	private String parameters;
	private int jobId;
	private String jobName;
	// for all jobs except for project A it will be Q
	private String jobStatus = "";
	private String fileName;
	private String requestTime;
	private String folderId = "999";
	private String vin;
	private String assignCode;

	private static final int INPUT_LENGTH1 = 100;
	private static final int INPUT_LENGTH2 = 32000;

	
	public String getInputString1() {

		LayoutBuffer layout = new LayoutBuffer(INPUT_LENGTH1);

		layout.addField(LayoutBuffer.FIELDTYPE_PICX, 3);
		layout.addField(LayoutBuffer.FIELDTYPE_PIC9, 8);
		layout.addField(LayoutBuffer.FIELDTYPE_PICX, 10);
		layout.addField(LayoutBuffer.FIELDTYPE_PICX, 2);
		layout.addField(LayoutBuffer.FIELDTYPE_PICX, 3);
		layout.addField(LayoutBuffer.FIELDTYPE_PICX, 8);
		addPicXOnefield(layout);		
		layout.addField(LayoutBuffer.FIELDTYPE_PIC9, 5);
		layout.addField(LayoutBuffer.FIELDTYPE_PICX, 2);
		addPicXOnefield(layout);
		addPicXOnefield(layout);
		layout.addField(LayoutBuffer.FIELDTYPE_PIC9, 2);
		addPicXOnefield(layout);
		addPicXOnefield(layout);
		layout.addField(LayoutBuffer.FIELDTYPE_PIC9, 3);
		layout.addField(LayoutBuffer.FIELDTYPE_PICX, 17);
		layout.addField(LayoutBuffer.FIELDTYPE_PICX, 32);

		layout.setString(0, this.getBatchCode());
		layout.setString(1, Integer.toString(this.getGlobalFSANo()));
		layout.setString(2, this.getLocalFSANo());
		layout.setString(3, this.getHubCode());
		layout.setString(4, this.getCountryCode());
		layout.setString(5, this.getCdsId());
		layout.setString(6, this.getEmailIndicator());
		layout.setString(7, Integer.toString(this.getSegment()));
		layout.setString(8, this.getSupplement());
		// batch group blank rt now
		layout.setString(9, " ");
		// job status "" in most "Q" for project-A CTS queued jobs
		layout.setString(10, this.getJobStatus());
		layout.setString(11, "");
		layout.setString(12, "");
		layout.setString(13, this.getAssignCode());
		layout.setString(14, this.getFolderId());
		layout.setString(15, this.getVin());
		layout.setString(16, "");

		return layout.toString();
	}

	private void addPicXOnefield(LayoutBuffer layout) {
		layout.addField(LayoutBuffer.FIELDTYPE_PICX, 1);
		
	}

	public String getInputString2() {

		LayoutBuffer layout = new LayoutBuffer(INPUT_LENGTH2);

		layout.addField(LayoutBuffer.FIELDTYPE_PICX, INPUT_LENGTH2);

		layout.setString(0, this.getParameters());

		return layout.toString();
	}

}