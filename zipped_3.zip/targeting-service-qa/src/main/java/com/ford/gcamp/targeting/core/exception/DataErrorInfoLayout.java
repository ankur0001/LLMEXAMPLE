package com.ford.gcamp.targeting.core.exception;

import java.io.Serializable;

import com.ford.gcamp.targeting.common.api.LayoutBuffer;

public class DataErrorInfoLayout extends LayoutBuffer implements Serializable{
	
	
	private static final long serialVersionUID = 1L;
	private static final int EOF_INDICATOR	 = 0;
	private static final int PRG_NAME		 = 1;
	private static final int ERR_FLAG		 = 2;
	private static final int RETURN_CODE	 = 3;
	private static final int PARAGRAPH		 = 4;
	private static final int TABLE_NAME	 = 5;
	private static final int SQL_CODE		 = 6;
	private static final int ERR_MESSAGE	 = 7;
	private static final int ERR_PARAS		 = 8;

	private static final int ERR_LAYOUT_LENGTH = 256;

	private static final String DB2_ERROR_CODE = "001";
	
	private static final String STORED_PROC_ERROR_FLAG = "Y";

	/**
	 * Constructor for DataErrorInfoLayout
	 */
	public DataErrorInfoLayout(int length) {
		super(length);
	}

	/**
	 * Constructor for DataErrorInfoLayout
	 */
	public DataErrorInfoLayout() {
		this(ERR_LAYOUT_LENGTH);
		initializeLayout();
	}
	
	public void initializeLayout(){
		super.addField(LayoutBuffer.FIELDTYPE_PICX, 1);
		super.addField(LayoutBuffer.FIELDTYPE_PICX, 8);
		super.addField(LayoutBuffer.FIELDTYPE_PICX, 1);
		super.addField(LayoutBuffer.FIELDTYPE_PICX, 3);
		super.addField(LayoutBuffer.FIELDTYPE_PICX, 5);
		super.addField(LayoutBuffer.FIELDTYPE_PICX, 18);
		super.addField(LayoutBuffer.FIELDTYPE_PICX, 4);
		super.addField(LayoutBuffer.FIELDTYPE_PICX, 110);
		super.addField(LayoutBuffer.FIELDTYPE_PICX, 105);
	}

	public boolean isStoredProcError(){
		return getErrFlag().equals(STORED_PROC_ERROR_FLAG);
	}

	public boolean isStoredProcDB2Error(){
		return getErrFlag().equals(STORED_PROC_ERROR_FLAG) && getReturnCode().equals(DB2_ERROR_CODE);
	}
	
	/**
	 * Gets the eOF_INDICATOR
	 * @return Returns a String
	 */
	public String getEofIndicator() {
		return super.getString(EOF_INDICATOR);
	}

	/**
	 * Gets the pRG_NAME
	 * @return Returns a String
	 */
	public String getPrgName() {
		return super.getString(PRG_NAME);
	}

	/**
	 * Gets the eRR_FLAG
	 * @return Returns a String
	 */
	public String getErrFlag() {
		return super.getString(ERR_FLAG);
	}

	/**
	 * Gets the rETURN_CODE
	 * @return Returns a String
	 */
	public String getReturnCode() {
		return super.getString(RETURN_CODE);
	}

	/**
	 * Gets the pARAGRAPH
	 * @return Returns a String
	 */
	public String getParagraph() {
		return super.getString(PARAGRAPH);
	}

	/**
	 * Gets the tABLE_NAME
	 * @return Returns a String
	 */
	public String getTableName() {
		return super.getString(TABLE_NAME);
	}

	/**
	 * Gets the sQL_CODE
	 * @return Returns a String
	 */
	public String getSqlCode() {
		return super.getString(SQL_CODE);
	}

	/**
	 * Gets the eRR_CODE
	 * @return Returns a String
	 */
	public String getErrMessage() {
		return super.getString(ERR_MESSAGE);
	}

	/**
	 * Gets the eRR_PARAS
	 * @return Returns a String
	 */
	public String getErrParas() {
		return super.getString(ERR_PARAS);
	}

}

