package com.ford.gcamp.targeting.fsacriteria.api;

import com.fasterxml.jackson.annotation.JsonIgnore;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class GCPFilterList {
	@NotNull
	@Size(min = 1, max = 4)
	@Pattern(regexp = "^[\\d]*$")
	@Schema(example="2042",description = "GCP Filter Code")
	private int gcpFilterC;


	@NotNull
	@Size(min = 1, max = 50)
	@Pattern(regexp = "^[a-zA-Z\\d\\(\\)\\s\\/\\-\\.\\,]*$")
	@Schema(example="ZF -A-C -CHORD II - (2Z1)",description = "GCP Filter Code description")
	private String gcpFilterX;

	@NotNull
	@Size(min = 3, max = 3)
	@Pattern(regexp = "^[a-zA-Z\\d]*$")
	@Schema(example="2Z2",description = "WERS Family Code")
	private String wersFamilyCode;
	
	@JsonIgnore
	private String vehLine;
	
	
	public GCPFilterList(int gcpFilterC, String gcpFilterX,String wersFamilyCode) {
		super();
		this.gcpFilterC = gcpFilterC;
		this.gcpFilterX = gcpFilterX;
		this.wersFamilyCode=wersFamilyCode;
	}


	/**
	 * @return the gcpFilterC
	 */
	public int getGcpFilterC() {
		return gcpFilterC;
	}
	/**
	 * @param gcpFilterC the gcpFilterC to set
	 */
	public void setGcpFilterC(int gcpFilterC) {
		this.gcpFilterC = gcpFilterC;
	}
	/**
	 * @return the gcpFilterX
	 */
	public String getGcpFilterX() {
		return gcpFilterX;
	}
	/**
	 * @param gcpFilterX the gcpFilterX to set
	 */
	public void setGcpFilterX(String gcpFilterX) {
		this.gcpFilterX = gcpFilterX;
	}


	public String getVehLine() {
		return vehLine;
	}


	public void setVehLine(String vehLine) {
		this.vehLine = vehLine;
	}
	
	
}
