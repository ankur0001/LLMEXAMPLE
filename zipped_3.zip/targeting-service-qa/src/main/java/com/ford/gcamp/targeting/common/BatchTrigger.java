package com.ford.gcamp.targeting.common;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;

import com.ford.gcamp.targeting.common.api.BatchJobDataForPhaseByPercent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.ford.gcamp.targeting.core.exception.GCampBatchTriggerException;

import lombok.extern.slf4j.Slf4j;

import com.ford.gcamp.targeting.common.api.BatchJobData;

@Service
@Slf4j
public class BatchTrigger {

	@Autowired
	UJQBlockerDAO ujqBlockerDao;

	@Autowired
	UJQInsertJobDAO dao;

	@Autowired
	FTPSession ftp;

	@Value("${FTP_USERNAME}")
	private String userId;

	@Value("${ftp.templateFile}")
	private String jclTemplateName;

	@Value("${FTP_ENV}")
	private String environment;

	@Value("${ftp.systemReader}")
	private String systemReader;

	@Value("${ftp.bufferSize}")
	private int bufferSize;

	@Value("${ftp.privateKeyPath}")
	private String filePath;

	private String jclTemplate;

	private boolean readJCLTemplate() {

		if ((jclTemplateName == null)) {
			return false;
		}
		log.info("Reading JCLTemplate :{} ", jclTemplateName);

		try {
			jclTemplate = readFromInputStream(filePath+jclTemplateName);
		} catch (IOException e) {
			log.error("Error reading JCLTempalte ", e);
		}

		return (jclTemplate != null);
	}

	private String readFromInputStream(String file)
			throws IOException {
		StringBuilder resultStringBuilder = new StringBuilder();
		try (BufferedReader br
					 = new BufferedReader(new InputStreamReader(new FileInputStream(file), StandardCharsets.UTF_8))) {
			String line;
			while ((line = br.readLine()) != null) {
				resultStringBuilder.append(line).append("\n");
			}
		}
		return resultStringBuilder.toString();
	}

	/**
	 * Type I batch. The function handles inserting into job queue and sending
	 * jcl through FTP
	 * @param batchJobData The batch job data
	 */
	public int submitJob(BatchJobData job) throws GCampBatchTriggerException {
		log.info("Batch Trigger - Submitting Job");
		int jobId = 0;
		String jobName = null;

		if ("003".equals(job.getBatchCode()) || "007".equals(job.getBatchCode()) || "005".equals(job.getBatchCode())
				|| "011".equals(job.getBatchCode()) || "009".equals(job.getBatchCode())
				|| "118".equals(job.getBatchCode())) {
			jobName = job.getJobName();
		} else {
			jobId = insertJobQ(job);
			jobName = job.getJobName();
		}

		// send the JCL to mainframe reader
		submitJCL(jobName);

		return jobId;
	}

	public int submitJobForPhase(BatchJobDataForPhaseByPercent job) throws GCampBatchTriggerException {
		log.info("Batch Trigger - Submitting Job for Phase by percent");
		int jobId = 0;
		String jobName = null;
		jobId = insertJobQForPhase(job);
		jobName = job.getJobName();
		// send the JCL to mainframe reader
		submitJCL(jobName);
		return jobId;
	}

	/**
	 * The function handles inserting into job queue. Client controls transaction.
	 * @param con The database connection
	 * @param batchJobData The batch job data
	 */
	public int insertJobQ(BatchJobData job)
			throws GCampBatchTriggerException {

		boolean isConflict = ujqBlockerDao.hasConflict(job);
		log.info("Conflict in triggering batch : {}", isConflict);

		if (isConflict) {
			throw new GCampBatchTriggerException("Batch Cannot Run because some other Blocking Batch is running");
		}
		return dao.insertJobQ(job);

	}

	public int insertJobQForPhase(BatchJobDataForPhaseByPercent job) throws GCampBatchTriggerException {
		boolean isConflict = ujqBlockerDao.hasConflictForPhase(job);
		log.info("Conflict in triggering batch for phase by percent : {}", isConflict);
		if (isConflict) {
			throw new GCampBatchTriggerException("Batch Cannot Run because some other Blocking Batch is running");
		}
		return dao.insertJobQForPhase(job);
	}

	/**
	 * The function sends jcl through FTP.
	 * @param jobName The job name to be demanded on mainframe
	 */
	public void submitJCL(String jobName) throws GCampBatchTriggerException {
		String jclText = null;
		readJCLTemplate();
		if (jclTemplate == null) {
			throw new GCampBatchTriggerException("BatchTrigger class not initialized");
		}


		jclText = jclTemplate.replace("$jobName", jobName);

		jclText = jclText.replace("$env", environment);

		jclText = jclText.replace("$user", userId.toUpperCase());

		jclText = jclText.replace("$user", userId.toUpperCase());

		log.info("JCLTemplate : {}", jclText);

		try {
			jclText = jclText.replace("\r\n", "\n");
			ftp.uploadFile("''", "ftadv:P=UNIX,FILETYPE="+systemReader+"/___SYSIN=A", jclText);

			ftp.logout();
		} catch (Exception e) {
			throw new GCampBatchTriggerException("FTP batch failed.", e);

		}
	}


}
