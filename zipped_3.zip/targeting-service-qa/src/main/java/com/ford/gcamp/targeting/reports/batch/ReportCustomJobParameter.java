package com.ford.gcamp.targeting.reports.batch;

import org.springframework.batch.core.JobParameter;

import com.ford.gcamp.targeting.reports.batch.api.ReportMetaData;

import lombok.EqualsAndHashCode;

@EqualsAndHashCode(callSuper = true)
public class ReportCustomJobParameter extends JobParameter {

	private static final long serialVersionUID = 1L;

	private ReportMetaData metaData;

	public ReportCustomJobParameter(ReportMetaData metaData) {
		super("", "".getClass());
		this.metaData = metaData;
	}

	@Override
	public ReportMetaData getValue() {
		return metaData;
	}

}
