package com.ford.gcamp.targeting.prelaunchreports.api;

import java.util.List;

import com.ford.gcamp.targeting.common.LDAPModel;
import com.ford.gcamp.targeting.common.api.CommonResponse;
import com.ford.gcamp.targeting.common.api.FSAInfoVO;
import com.ford.gcamp.targeting.common.api.SuppPopulationVo;
import com.ford.gcamp.targeting.prelaunchreports.ReportsSelection;
import com.ford.gcamp.targeting.prelaunchreports.Wers;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class ExtractOptionResponse extends CommonResponse{

	@Size(min = 0, max = 300, message = "added By")
	private List<@Valid LDAPModel> addedBy;

    @Valid
	private ReportsSelection reportSelection;

	@Size(min = 0, max = 300, message = "wers List")
	private List<@Valid Wers> wersList;

    @Valid
	private FSAInfoVO fsaInfoVO;

	@Size(min = 0, max = 300, message = "Supplements")
	private List<@Valid SuppPopulationVo> supplements;

	@Size(min = 0, max = 300, message = "last Wers Reports")
	private List<String> lastWersReports;
	private boolean latestGridVernInfoExists;
	
}
