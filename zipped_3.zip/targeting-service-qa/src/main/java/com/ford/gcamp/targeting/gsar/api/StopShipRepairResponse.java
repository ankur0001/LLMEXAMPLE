package com.ford.gcamp.targeting.gsar.api;

import java.util.List;

import com.ford.gcamp.targeting.common.api.CommonResponse;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class StopShipRepairResponse extends  CommonResponse {
	@Size(min = 0, max = 300, message = "stopShipRepairDetails List")
	private List<@Valid StopShipRepair> stopShipRepairDetails;
}
