package com.ford.gcamp.targeting.gridgcamp.gcamp.api;

import java.util.List;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Size;

import com.ford.gcamp.targeting.common.api.CommonResponse;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class GridVernResponse extends CommonResponse {
	
	@Size(min=0, max = 500)
	private List< @Valid GridVernInfo> gridVernData;
}
