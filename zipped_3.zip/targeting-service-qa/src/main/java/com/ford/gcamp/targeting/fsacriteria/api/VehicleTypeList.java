package com.ford.gcamp.targeting.fsacriteria.api;

import com.fasterxml.jackson.annotation.JsonIgnore;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class VehicleTypeList {

	@Size(min = 0, max = 3)
	@Pattern(regexp = "^[a-zA-Z\\d]*$")
	@Schema(example = "CQP", description = "VehicleLine Code")
	private String vehicleLnC;


	@Size(min = 1, max = 50)
	@Pattern(regexp = "^[a-zA-Z\\d\\(\\)\\s\\/\\-\\.\\,]*$")
	@Schema(example ="323 (MAZDA) (CQP)" , description = "Vehicle Line Description")
	private String vehicleLnX;
	@JsonIgnore
	private String brandCode;
	@JsonIgnore
	private String modelYear;
	
	public VehicleTypeList(String vehicleLnC, String vehicleLnX) {
		super();
		this.vehicleLnC = vehicleLnC;
		this.vehicleLnX = vehicleLnX;
	}

}
