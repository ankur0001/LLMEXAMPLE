package com.ford.gcamp.targeting.cache;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.stereotype.Service;

import com.ford.gcamp.targeting.fsacriteria.AddModifyCriteriaService;
import com.ford.gcamp.targeting.fsacriteria.FsaCriteriaFilterService;

@Service
public class CachingService{

	@Autowired
	private CacheManager cacheManager;
	
	@Autowired
	private AddModifyCriteriaService addModifyCriteriaService;
	
	@Autowired
	private FsaCriteriaFilterService fsaCriteriaFilterService;
	
	public void evictSingleCache(String cacheName) {
	   Cache cache =  cacheManager.getCache(cacheName);
	   if(cache != null) {
		   cache.clear();
	   }	    
	}

	public void evictAllCache() {
		cacheManager.getCacheNames().stream()
	      .forEach(cacheName -> cacheManager.getCache(cacheName).clear());
	}
	
	public void refreshFsaCriteria() {
		evictAllCache();
		fsaCriteriaFilterService.getFsaBrandModelVehLinePlant();
		fsaCriteriaFilterService.getAllWersDetails();
		addModifyCriteriaService.getFscFormDetails();
	}

}
