package com.ford.gcamp.targeting.prelaunchreports.api;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Builder
@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class FsaGoRequest {
	@Size(min = 5, max = 10)
	@Pattern(regexp = "^[a-zA-z\\d\\s]*$")
	@Schema(example = "17768", description = "Global FSA Number")
	private String fsaNumber;

	@Schema(example = "G", description = "fsaType")
	@Size(min = 0, max = 1)
	@Pattern(regexp = "^[A-Za-z]$", message = "FSA Type")
	private String fsaType;

	@Schema(description = "population", example = "00")
	@Size(min = 0, max = 2, message = "length 1-2")
	@Pattern(regexp ="^[A-Za-z\\d\\s\\*]*$", message = "population Code")
	private String population;

	@Schema(description = "requestType")
	@Size(min = 0, max = 1, message = "length 1")
	@Pattern(regexp ="^[A-Za-z\\s]*$")
	@Builder.Default
	private String requestType = "T";
}
