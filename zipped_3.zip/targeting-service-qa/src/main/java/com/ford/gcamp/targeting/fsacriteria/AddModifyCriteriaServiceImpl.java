package com.ford.gcamp.targeting.fsacriteria;

import java.util.List;
import java.util.Map;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.util.HtmlUtils;
import com.ford.gcamp.targeting.common.BatchTrigger;
import com.ford.gcamp.targeting.common.CommonConstants;
import com.ford.gcamp.targeting.common.Hubs;
import com.ford.gcamp.targeting.common.TargetingUtil;
import com.ford.gcamp.targeting.common.api.BatchJobData;
import com.ford.gcamp.targeting.common.api.CommonResponse;
import com.ford.gcamp.targeting.common.api.FSACommonGoRequest;
import com.ford.gcamp.targeting.common.api.FSATypes;
import com.ford.gcamp.targeting.common.api.FSATypesResponse;
import com.ford.gcamp.targeting.common.api.FscCriteriaRequest;
import com.ford.gcamp.targeting.common.api.HubResponse;
import com.ford.gcamp.targeting.core.exception.GCAMPException;
import com.ford.gcamp.targeting.core.exception.GCampBatchTriggerException;
import com.ford.gcamp.targeting.fsacriteria.api.DeleteConfirmResponse;
import com.ford.gcamp.targeting.fsacriteria.api.DeleteFsaInfoReq;
import com.ford.gcamp.targeting.fsacriteria.api.FsaCriteriaParamRequest;
import com.ford.gcamp.targeting.fsacriteria.api.FsaDeleteResponseDTO;
import com.ford.gcamp.targeting.fsacriteria.api.FsaGlobalSearchDTO;
import com.ford.gcamp.targeting.fsacriteria.api.FsaGlobalSearchRequest;
import com.ford.gcamp.targeting.fsacriteria.api.FscCriteriaResponseGoDTO;
import com.ford.gcamp.targeting.fsacriteria.api.LoadFsaResponseDTO;
import com.ford.gcamp.targeting.fsacriteria.api.LoadSelectCounValDTO;
import com.ford.gcamp.targeting.fsacriteria.api.LoadStateProvinceDTO;
import com.ford.gcamp.targeting.fsacriteria.api.LoadVehAttValDTO;
import com.ford.gcamp.targeting.vin.api.ExistingVinGrpList;

@Service
public class AddModifyCriteriaServiceImpl implements AddModifyCriteriaService {

	private static final Logger LOGGER = LoggerFactory.getLogger(AddModifyCriteriaServiceImpl.class);
	@Autowired
	AddModifyCriteriaRepoImpl addModifyCriteriaRepository;
	@Autowired
	FsaSaveCopyDataUtil fsaSaveCopyDataUtil;
	@Autowired
	FsaUtil fscCriteriaUtil;
	@Autowired
	DeleteJobStoreProcUtil deleteUtil;
	@Autowired
	BatchTrigger trigger;
	@Autowired
	BatchJobData job;

	@Autowired
	FSACriteriaRegionalFilterRepository regionalFilterRepository;

	@Autowired
	FSACriteriaRegionalFilterService fsaCriteriaRegionalFilterService;

	@Cacheable("getFscFormDetails")
	public LoadFsaResponseDTO getFscFormDetails() {

		return addModifyCriteriaRepository.loadFscCriteriaDetails();
	}

	public FscCriteriaResponseGoDTO getFscSearchResult(FscCriteriaRequest fscCriteriaRequest) {

		FscCriteriaResponseGoDTO fsaCriteriaResponse = addModifyCriteriaRepository.getFscSearchList(fscCriteriaRequest);

		if (CollectionUtils.isNotEmpty(fsaCriteriaResponse.getVinGrpCriteriaVOs())) {

			fsaCriteriaRegionalFilterService.loadRegionalFilters(fscCriteriaRequest, fsaCriteriaResponse);

		}

		return fsaCriteriaResponse;
	}

	@Override
	public LoadVehAttValDTO loadDynamicQueryDataForVehAtt(String attrGrpVvalue) {
		String inputModelValue = String.valueOf(attrGrpVvalue);
		return addModifyCriteriaRepository.loadDynamicQueryDetailsForVehAtt(inputModelValue);
	}

	@Override
	public CommonResponse saveFSACriteriaList(FsaCriteriaParamRequest fsaCriteriaParam) throws GCAMPException {
		CommonResponse commonResponse = new CommonResponse();
		Map<String, Object> saveResponse = addModifyCriteriaRepository.saveFscSearchListDesc(fsaCriteriaParam);
		TargetingUtil.getResponseStatus(String.valueOf(saveResponse.get(CommonConstants.ERROR_PARM)), commonResponse);
		if (CommonConstants.SUCCESS.equals(commonResponse.getStatus()) && fsaCriteriaParam.isExtractRun()) {
			String outputparam17 = String.valueOf(saveResponse.get("OUTPUT_PARM17"));
			if (outputparam17.length() >= 45) {
				LOGGER.info("output param3 value is {}", outputparam17);
				String jobName = outputparam17.substring(45, 53);
				String jobId = outputparam17.substring(53, 63);
				LOGGER.info("output jaobname value is {}", jobName);
				try {
					trigger.submitJCL(jobName);
					commonResponse.setStatusDescription(CommonConstants.JOB_SUBMISSION_MSG + Integer.parseInt(jobId));
				} catch (GCampBatchTriggerException e) {
					LOGGER.error(CommonConstants.EXCEPTION_OCCURED, e);
					throw new GCAMPException("Update Failed");
				}
			}
		}

		return commonResponse;
	}

	@Override
	@Transactional("jpaDb2TransactionManager")
	public FscCriteriaResponseGoDTO copyFSACriteriaList(FsaCriteriaParamRequest fsaCriteriaParam) {

		FscCriteriaResponseGoDTO copyCriteriaResponse = addModifyCriteriaRepository
				.copyFscSearchListDesc(fsaCriteriaParam);
		if (CommonConstants.SUCCESS.equalsIgnoreCase(copyCriteriaResponse.getStatus())) {
			LOGGER.info("saving regional filter data starts{}", fsaCriteriaParam.getCopiedVinGroupCode());
			fsaCriteriaRegionalFilterService.copyRegionalFilterData(fsaCriteriaParam);
		}

		return copyCriteriaResponse;
	}


	@Override
	public LoadStateProvinceDTO loadDynamicQueryDetailsForStateProv() {

		return addModifyCriteriaRepository.loadDynamicQueryDetailsForStateProv();
	}

	@Override
	public LoadSelectCounValDTO loadDynamicQueryDataForSelectCountry(FscCriteriaRequest fscCriteriaRequest) {
		return addModifyCriteriaRepository.loadDynamicQueryDetailsForSelectCountry(fscCriteriaRequest);
	}

	@Override
	public FsaGlobalSearchDTO getFsaGlobalSearch(FsaGlobalSearchRequest globalFsaSearch) {

		String dynamicQueryInutParam = "";
		String fsaType = null;
		if (globalFsaSearch != null) {
			dynamicQueryInutParam = fscCriteriaUtil.getGlobalFsaParam1(globalFsaSearch);
			fsaType = globalFsaSearch.getFsaType();
		}

		return addModifyCriteriaRepository.globalFsaSearchDetails(dynamicQueryInutParam, fsaType);
	}

	@Override
	@Transactional("jpaDb2TransactionManager")
	public FsaDeleteResponseDTO deleteFSACriteriaList(FsaCriteriaParamRequest fsaCriteriaParam) {
		String deleteInputParam = fsaSaveCopyDataUtil.deleteInputParam(fsaCriteriaParam);
		LOGGER.info("Blocker check - input param: {}", fsaCriteriaParam);
		FsaDeleteResponseDTO responseDto = new FsaDeleteResponseDTO();
		List<String> vinGrpCodes = deleteUtil.getVinGrpInData(fsaCriteriaParam.getVinGrpCode());
		List<ExistingVinGrpList> existingVinList = addModifyCriteriaRepository
				.checkVinExistence(HtmlUtils.htmlEscape(fsaCriteriaParam.getFsaNumber()), vinGrpCodes);
		if (existingVinList.isEmpty()) {
			responseDto.setStatus(CommonConstants.FAILURE);
			responseDto.setStatusCode(CommonConstants.FAILURE_CODE);
			responseDto.setStatusDescription(CommonConstants.VINGRP_CODE_DELETE_ERROR);
		} else {
			Map<String, Object> checkBlockerResponse = addModifyCriteriaRepository.checkBlocker(deleteInputParam);
			LOGGER.info("Check for Blocker Response: {}", checkBlockerResponse);
			responseDto = deleteUtil.blockerProcess(checkBlockerResponse);

			if (!responseDto.getStatus().equalsIgnoreCase(CommonConstants.FAILURE)) {
				Map<String, Object> deleteListResponse = addModifyCriteriaRepository
						.deleteFscSearchListDesc(fsaCriteriaParam);
				LOGGER.info("Delete store proc Response {}", deleteListResponse);
				responseDto = deleteUtil.deleteFsaList(deleteListResponse);
				String jobName = responseDto.getJobName();

				if (!responseDto.getStatus().equalsIgnoreCase(CommonConstants.FAILURE)) {

					LOGGER.info("Triggering Batch :{}", CommonConstants.PARTIAL_DELETE_JOB_CODE);
					try {
						job.setBatchCode(CommonConstants.PARTIAL_DELETE_JOB_CODE);
						job.setCdsId(fsaCriteriaParam.getCdsId());
						job.setGlobalFSANo(Integer.parseInt(fsaCriteriaParam.getFsaNumber()));
						job.setHubCode("  ");
						job.setSupplement(fsaCriteriaParam.getVehiclePopUpCode());
						job.setParameters("000");
						job.setJobName(jobName);
						trigger.submitJCL(job.getJobName());
						LOGGER.info("Triggering Batch End");
						
					} catch (GCampBatchTriggerException e) {
						LOGGER.error("Exception ", e);
						responseDto.setStatus(CommonConstants.FAILURE);
						responseDto.setStatusCode(CommonConstants.FAILURE_CODE);
						responseDto.setStatusDescription(CommonConstants.FAILURE_BATCH_DESC);
					}

				}
			}
		}
		return responseDto;
	}

	@Override
	public FsaDeleteResponseDTO deleteCompleteCriteriaList(DeleteFsaInfoReq deleteFsaInfoReq) {

		FsaDeleteResponseDTO responseDto = new FsaDeleteResponseDTO();
		responseDto.setStatus("");
		if (deleteFsaInfoReq != null) {
			String deleteInputParam = fsaSaveCopyDataUtil.deleteAllInputParam(deleteFsaInfoReq);
			LOGGER.info("Blocker check - input param: {}", deleteInputParam);
			Map<String, Object> checkBlockerResponse = addModifyCriteriaRepository.checkBlocker(deleteInputParam);
			LOGGER.info("Check for Blocker Response: {}", checkBlockerResponse);
			responseDto = deleteUtil.blockerProcess(checkBlockerResponse);

			if (!responseDto.getStatus().equalsIgnoreCase(CommonConstants.FAILURE)) {

				Map<String, Object> responseMap = addModifyCriteriaRepository.deleteAllFsaInfo(
						deleteFsaInfoReq);
				responseDto = deleteUtil.globalFsaDelete(responseMap);
				LOGGER.info(CommonConstants.SP_RESPONSE_TEXT, responseMap);
				LOGGER.info("SP Status : {}", responseDto.getStatus());
				String jobName = responseDto.getJobName();

				if (!responseDto.getStatus().equalsIgnoreCase(CommonConstants.FAILURE)) {

					try {
						job.setBatchCode(CommonConstants.GLOBAL_DELETE_JOB_CODE);
						job.setCdsId(deleteFsaInfoReq.getCdsId());
						job.setGlobalFSANo(Integer.parseInt(deleteFsaInfoReq.getFsaNumber()));
						job.setHubCode("  ");
						job.setSupplement(deleteFsaInfoReq.getPopulation());
						job.setParameters("000");
						job.setJobName(jobName);
						trigger.submitJCL(job.getJobName());
						LOGGER.info("Triggering Batch End :{}", CommonConstants.GLOBAL_DELETE_JOB_CODE);
					} catch (GCampBatchTriggerException e) {
						responseDto.setStatus(CommonConstants.FAILURE);
						responseDto.setStatusCode(CommonConstants.FAILURE_CODE);
						responseDto.setStatusDescription(CommonConstants.FAILURE_BATCH_DESC);
						LOGGER.error(CommonConstants.EXCEPTION_OCCURED, e);
					}
				}
			}

		}

		return responseDto;
	}

	@Override
	public HubResponse getHubsList() {
		HubResponse hubResponse = new HubResponse();
		List<Hubs> hubCodes = addModifyCriteriaRepository.getHubCodes();
		Hubs hub = Hubs.builder().hubCode("* ").hubDescription("ALL").build();
		hubCodes.add(0, hub);
		hubResponse.setHubs(hubCodes);
		hubResponse.setStatus(CommonConstants.SUCCESS);
		hubResponse.setStatusCode(CommonConstants.SUCCESS_CODE);
		hubResponse.setStatusDescription(CommonConstants.SUCCESS_DESC);
		return hubResponse;
	}

	@Override
	public FSATypesResponse getFSATypes() {

		FSATypesResponse fsaTypesResponse = new FSATypesResponse();

		try {
			List<FSATypes> fsaTypesList = addModifyCriteriaRepository.getFsaTypes();
			FSATypes fsaTypes = FSATypes.builder().fsaTypeCode("**").fsaTypeDesc("ALL").build();
			fsaTypesList.add(0, fsaTypes);
			fsaTypesResponse.setFsaTypeList(fsaTypesList);
			fsaTypesResponse.setStatus(CommonConstants.SUCCESS);
			fsaTypesResponse.setStatusCode(CommonConstants.SUCCESS_CODE);
			fsaTypesResponse.setStatusDescription(CommonConstants.SUCCESS_DESC);
		} catch (Exception e) {
			LOGGER.error("Error Occured ", e);
			fsaTypesResponse.setStatus(CommonConstants.FAILURE);
			fsaTypesResponse.setStatusCode(CommonConstants.FAILURE_CODE);
			fsaTypesResponse.setStatusDescription(CommonConstants.FAILURE_DESC);
		}
		return fsaTypesResponse;
	}

	@Override
	public DeleteConfirmResponse getExtractTimeStamp(FSACommonGoRequest fsaCommonGoRequest) throws GCAMPException {

		DeleteConfirmResponse deleteConfirmResponse = new DeleteConfirmResponse();
		StringBuilder parm = new StringBuilder();
		parm.append(fsaCommonGoRequest.getPopulation());
		parm.append("T");
		Map<String, Object> getResponse = addModifyCriteriaRepository
				.getExtractTimeStamp(TargetingUtil.commonFsaGoRequest(fsaCommonGoRequest), parm.toString());
		TargetingUtil.getResponseStatus(String.valueOf(getResponse.get(CommonConstants.ERROR_PARM)),
				deleteConfirmResponse);
		String outparm3 = String.valueOf(getResponse.get(CommonConstants.OUTPUT_PARM3));
		String criteriaDate = outparm3.substring(8, 27);
		String extractDate = outparm3.substring(34, 53);
		LOGGER.info("Delete Confirm - Criteria Date: {}", criteriaDate);
		LOGGER.info("Delete Confirm - Extract Date: {}", extractDate);
		String extractStatusFlag = outparm3.substring(60, 61);
		if (StringUtils.EMPTY.equalsIgnoreCase(StringUtils.trimToEmpty(extractStatusFlag))) {
			deleteConfirmResponse.setExtractFlag("D");
		} else {
			deleteConfirmResponse.setExtractFlag(TargetingUtil.compareDates(criteriaDate, extractDate) ? "E" : "R");
		}
		return deleteConfirmResponse;
	}

	

}
