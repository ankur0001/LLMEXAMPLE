
package com.ford.gcamp.targeting.reports.batch.exception.writer;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import com.ford.gcamp.targeting.reports.batch.common.ReportGenerationUtil;
import org.apache.poi.xssf.streaming.SXSSFSheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.item.Chunk;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.ford.gcamp.targeting.reports.batch.api.ExcelConfig;
import com.ford.gcamp.targeting.reports.batch.api.ReportMetaData;
import com.ford.gcamp.targeting.reports.batch.common.ReportCodeConstants;
import com.ford.gcamp.targeting.reports.batch.exception.GCAMPReportException;
import com.ford.gcamp.targeting.reports.batch.exception.api.CDMReport;
import com.ford.gcamp.targeting.reports.batch.writer.GCAMPXSSFReportWriter;

@Component(ReportCodeConstants.CDM + "itemWriter")
@StepScope
public class ExcelCDMReportItemWriter extends GCAMPXSSFReportWriter implements ItemWriter<CDMReport> {

	private List<CDMReport> cdmList;

	@Value("#{jobParameters['reportMetaData']}")
	private String reportMetaDataString;

	private ReportMetaData reportData;

	@Override
	public void write(Chunk<? extends CDMReport> items) throws Exception {
		reportData = ReportGenerationUtil.getReportMetaDataObject(reportMetaDataString);
		cdmList = new ArrayList<>(items.getItems());
		this.createReport(reportData);
	}

	@Override
	public void createWorksheet(SXSSFWorkbook hssfWorkbook, ReportMetaData metaData) throws GCAMPReportException {

		initializeWorkbook(hssfWorkbook);

		SXSSFSheet sheet = hssfWorkbook.createSheet("Country Dealer Mismatch Report");

		try {

			createProfile(sheet, metaData, "Country Dealer Mismatch");

			List<ExcelConfig> cdmConfigList = loadConfigFile(ReportCodeConstants.CDM, metaData.getSuppCode());

			setColumnWidth(sheet, cdmConfigList);

			setColumnHeader(sheet, cdmConfigList);

			setRowData(sheet,cdmConfigList, cdmList);

		} catch (Exception e) {
			throw new GCAMPReportException("Country Dealer Mismatch REPORT ERROR: Error in creating the report", e);
		}

	}

}