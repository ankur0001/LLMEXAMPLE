package com.ford.gcamp.targeting.prelaunchreports;

import com.ford.gcamp.targeting.common.CommonConstants;
import com.ford.gcamp.targeting.common.api.SuppPopulationVo;
import com.ford.gcamp.targeting.core.exception.GCAMPException;
import com.ford.gcamp.targeting.prelaunchreports.api.DownloadReportRequest;
import com.ford.gcamp.targeting.prelaunchreports.api.ReportResponseHistoric;
import com.ford.gcamp.targeting.prelaunchreports.api.ReportsResponse;
import java.io.InputStream;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.jdbc.support.lob.DefaultLobHandler;
import org.springframework.jdbc.support.lob.LobHandler;
import org.springframework.stereotype.Repository;

@Repository
@Slf4j
public class ViewTargetingReportsRepository {

    @Value("${DB_OWNER}")
    private String ownerId;

    @Value("${db2.uncommit.read}")
    private String uncommitRead;

    private JdbcTemplate jdbcTemplate;

    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    public static final String REPORT_BLOB_DATA = "GCPH00_BLOBIMAGE_I";

    @Autowired
    public ViewTargetingReportsRepository(
            JdbcTemplate jdbcTemplate, NamedParameterJdbcTemplate namedParameterJdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
        this.namedParameterJdbcTemplate = namedParameterJdbcTemplate;
    }

    public Map<String, Object> getAllReports(String inputParam1, String inputParam2)
            throws GCAMPException {

        SimpleJdbcCall simpleJdbcCall = null;
        Map<String, Object> reportsAllResponse = null;
        try {
            simpleJdbcCall =
                    creatSimpleJdbcCall(
                            CommonConstants.FSA_SCHEMA_NAME, CommonConstants.VIEW_REPORTS_STORPROC);

            SqlParameterSource sqlParameterSource =
                    createSqlParameterSource(
                            CommonConstants.INPUT_PARM1,
                            inputParam1,
                            CommonConstants.INPUT_PARM2,
                            inputParam2);
            log.info(" SQL Parm source for all reports {}", sqlParameterSource);
            reportsAllResponse = simpleJdbcCall.execute(sqlParameterSource);
        } catch (Exception e) {
            throw new GCAMPException(CommonConstants.DB_EXCEPTION, e);
        }

        return reportsAllResponse;
    }

    public Map<String, Object> getFsaDetails(String j12Param1) throws GCAMPException {
        Map<String, Object> fsaInfoMap = null;
        try {
            SimpleJdbcCall simpleJdbcCall =
                    new SimpleJdbcCall(jdbcTemplate)
                            .withSchemaName(CommonConstants.FSA_SCHEMA_NAME)
                            .withProcedureName(CommonConstants.J12_STORE_PROC);
            SqlParameterSource sqlParameterSource =
                    new MapSqlParameterSource().addValue(CommonConstants.INPUT_PARM1, j12Param1);

            fsaInfoMap = simpleJdbcCall.execute(sqlParameterSource);
        } catch (Exception e) {
            throw new GCAMPException(CommonConstants.DB_EXCEPTION, e);
        }

        return fsaInfoMap;
    }

    public List<SuppPopulationVo> getSupplements(String globalFsaNumber) {

        SqlParameterSource sqlSource =
                new MapSqlParameterSource().addValue("globalFsaNumber", globalFsaNumber);
        String sqlQuery =
                "SELECT DISTINCT  GCPA09_SUPPL_C, GCPA09_SUPP_DESC_X,GCPA07_FSA_STAT_C  FROM "
                        + ownerId
                        + " SGCPA09_FSA_SUPPL WHERE GCPA15_GLOBL_FSA_R = :globalFsaNumber "
                        + " ORDER BY GCPA09_SUPPL_C  "
                        + uncommitRead;

        List<SuppPopulationVo> populations = new ArrayList<>();
        namedParameterJdbcTemplate.query(
                sqlQuery,
                sqlSource,
                new RowMapper<Object>() {

                    public Object mapRow(ResultSet resultSet, int i) throws SQLException {
                        if (!("U".equalsIgnoreCase(resultSet.getString(3)))) {
                            SuppPopulationVo suppPopulationVo = new SuppPopulationVo();
                            suppPopulationVo.setFsaStatus(resultSet.getString(3).trim());
                            suppPopulationVo.setSupDesc(
                                    resultSet.getString(1).trim()
                                            + "-"
                                            + resultSet.getString(2).trim());
                            suppPopulationVo.setSupCode(resultSet.getString(1));

                            populations.add(suppPopulationVo);
                        }
                        return populations;
                    }
                });
        return populations;
    }

    MapSqlParameterSource createSqlParameterSource(
            String inputParamKey1,
            String inputParamVal1,
            String inputParamKey2,
            String inputParamVal2) {
        return new MapSqlParameterSource()
                .addValue(inputParamKey1, inputParamVal1)
                .addValue(inputParamKey2, inputParamVal2);
    }

    SimpleJdbcCall creatSimpleJdbcCall(String schemaName, String procedureName) {
        return new SimpleJdbcCall(jdbcTemplate)
                .withSchemaName(schemaName)
                .withProcedureName(procedureName);
    }

    public ReportsResponse getReportBlob(DownloadReportRequest downloadRequest)
            throws GCAMPException {
        try {
            StringBuilder query = new StringBuilder();
            query.append("SELECT F38.GCPF01_REPORT_ID_D, H00.GCPH00_BLOBIMAGE_I FROM ");
            query.append(ownerId);
            query.append("SGCPF38_BLOB_DATA F38,");
            query.append(ownerId);
            query.append("SGCPH00_RPT_IMAGE H00 WHERE F38.GCPF01_REPORT_ID_D = :reportId");
            query.append(" AND F38.GCPF04_REPORT_C = :reportCode");
            query.append(" AND F38.GCPF02_RPT_FMT_C = :reportFormat");
            query.append(" AND F38.GCPH00_BLOB_ID_K = H00.GCPH00_BLOB_ID_K");

            SqlParameterSource parameters =
                    new MapSqlParameterSource()
                            .addValue("reportId", downloadRequest.getReportId())
                            .addValue("reportCode", downloadRequest.getReportCode())
                            .addValue("reportFormat", downloadRequest.getReportFormat());
            log.info("SGCPF38_BLOB_DATA called");
            return getBlobAsByteArray(query.toString(), parameters);

        } catch (Exception e) {
            throw new GCAMPException(CommonConstants.DB_EXCEPTION, e);
        }
    }

    private ReportsResponse getBlobAsByteArray(String query, SqlParameterSource parameters) {
        List<ReportsResponse> reportData =
                namedParameterJdbcTemplate.query(
                        query,
                        parameters,
                        new RowMapper<ReportsResponse>() {
                            @Override
                            public ReportsResponse mapRow(ResultSet rs, int rowNum)
                                    throws SQLException {
                                ReportsResponse reportResponse = new ReportsResponse();
                                reportResponse.setReportId(rs.getString(1));
                                LobHandler lobHandler = new DefaultLobHandler();
                                byte[] requestData =
                                        lobHandler.getBlobAsBytes(rs, REPORT_BLOB_DATA);
                                if (null != requestData && requestData.length > 0) {
                                    reportResponse.setByteArry(requestData);
                                }
                                return reportResponse;
                            }
                        });
        return CollectionUtils.isNotEmpty(reportData) ? reportData.get(0) : new ReportsResponse();
    }

    private ReportResponseHistoric getBlobAsByteArrayForHistoricReport(
            String query, SqlParameterSource parameters) {
        List<ReportResponseHistoric> reportData =
                namedParameterJdbcTemplate.query(
                        query,
                        parameters,
                        new RowMapper<ReportResponseHistoric>() {
                            @Override
                            public ReportResponseHistoric mapRow(ResultSet rs, int rowNum)
                                    throws SQLException {
                                ReportResponseHistoric reportResponse =
                                        new ReportResponseHistoric();
                                reportResponse.setReportId(rs.getString(1));
                                reportResponse.setRequestedBy(rs.getString(2));
                                reportResponse.setReportFormatCode(rs.getString(3));
                                LobHandler lobHandler = new DefaultLobHandler();

                                InputStream is =
                                        lobHandler.getBlobAsBinaryStream(rs, REPORT_BLOB_DATA);
                                if (is == null) {
                                    log.warn(
                                            "LobHandler returned null InputStream for report ID: {}",
                                            reportResponse.getReportId());
                                }
                                reportResponse.setReportContentStream(
                                        is); // Assign the InputStream directly
                                return reportResponse;
                            }
                        });
        return CollectionUtils.isNotEmpty(reportData)
                ? reportData.stream()
                        .max(
                                (r1, r2) -> {
                                    try {
                                        return Long.compare(
                                                Long.parseLong(r1.getReportId()),
                                                Long.parseLong(r2.getReportId()));
                                    } catch (NumberFormatException e) {
                                        return 0;
                                    }
                                })
                        .orElse(new ReportResponseHistoric())
                : new ReportResponseHistoric();
    }

    public ReportResponseHistoric getReportBlobHistoric(
            int globalFSANumber, String supplementCode, String reportCode) {
        StringBuilder query = new StringBuilder();
        query.append(
                "SELECT F38.GCPF01_REPORT_ID_D,F38.GCPF38_REQ_BY_ID_D,F38.GCPF02_RPT_FMT_C, H00.GCPH00_BLOBIMAGE_I FROM ");
        query.append(ownerId);
        query.append("SGCPF38_BLOB_DATA F38,");
        query.append(ownerId);
        query.append("SGCPH00_RPT_IMAGE H00 WHERE F38.GCPA15_GLOBL_FSA_R = :globalFSANumber");
        query.append(" AND F38.GCPA09_SUPPL_C = :supplementCode");
        query.append(" AND F38.GCPF04_REPORT_C = :reportCode");
        query.append(" AND F38.GCPF02_RPT_FMT_C IN ('XLX', 'XLS')");
        query.append(" AND F38.GCPH00_BLOB_ID_K = H00.GCPH00_BLOB_ID_K");

        Map<String, Object> valueByKey = new HashMap<>();
        valueByKey.put("globalFSANumber", globalFSANumber);
        valueByKey.put("supplementCode", supplementCode);
        valueByKey.put("reportCode", reportCode);
        SqlParameterSource parameters = new MapSqlParameterSource(valueByKey);

        return getBlobAsByteArrayForHistoricReport(query.toString(), parameters);
    }

    public ReportsResponse getReportBlob(
            int globalFSANumber, String supplementCode, String reportCode) {
        StringBuilder query = new StringBuilder();
        query.append(
                "SELECT F38.GCPF01_REPORT_ID_D,F38.GCPF38_REQ_BY_ID_D,F38.GCPF02_RPT_FMT_C, H00.GCPH00_BLOBIMAGE_I FROM ");
        query.append(ownerId);
        query.append("SGCPF38_BLOB_DATA F38,");
        query.append(ownerId);
        query.append("SGCPH00_RPT_IMAGE H00 WHERE F38.GCPA15_GLOBL_FSA_R = :globalFSANumber");
        query.append(" AND F38.GCPA09_SUPPL_C = :supplementCode");
        query.append(" AND F38.GCPF04_REPORT_C = :reportCode");
        query.append(" AND F38.GCPF02_RPT_FMT_C IN ('XLX', 'XLS')");
        query.append(" AND F38.GCPH00_BLOB_ID_K = H00.GCPH00_BLOB_ID_K");

        Map<String, Object> valueByKey = new HashMap<>();
        valueByKey.put("globalFSANumber", globalFSANumber);
        valueByKey.put("supplementCode", supplementCode);
        valueByKey.put("reportCode", reportCode);
        SqlParameterSource parameters = new MapSqlParameterSource(valueByKey);

        return getBlobAsByteArray(query.toString(), parameters);
    }

    public boolean checkBatchBlockerExists(int globalFSANumber, String supplCode)
            throws GCAMPException {
        MapSqlParameterSource inQueryParams = new MapSqlParameterSource();
        try {
            StringBuilder addlBatchBlockCheckSql = new StringBuilder();

            addlBatchBlockCheckSql
                    .append("SELECT count(1) FROM ")
                    .append(ownerId)
                    .append("SGCPE21_JOB_DEPEND ")
                    .append("WHERE GCPA15_GLOBL_FSA_R = :fsaNum")
                    .append(" AND GCPA09_SUPPL_C = :supplCode ")
                    .append(uncommitRead);

            log.info("Additional Batch Blocker check query: {}", addlBatchBlockCheckSql.toString());
            inQueryParams.addValue("fsaNum", globalFSANumber).addValue("supplCode", supplCode);

            Integer blockerCount =
                    namedParameterJdbcTemplate.queryForObject(
                            addlBatchBlockCheckSql.toString(), inQueryParams, Integer.class);

            if (blockerCount != null && blockerCount > 0) {
                log.info("Batch Blocker exists for Confirm Population: true");
                return true;
            }

        } catch (Exception e) {
            throw new GCAMPException(CommonConstants.DB_EXCEPTION, e);
        }
        return false;
    }
}
