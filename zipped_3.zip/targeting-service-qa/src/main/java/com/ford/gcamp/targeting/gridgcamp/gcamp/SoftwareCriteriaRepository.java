package com.ford.gcamp.targeting.gridgcamp.gcamp;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ford.gcamp.targeting.gridgcamp.gcamp.entity.SoftwareCriteriaData;
import com.ford.gcamp.targeting.gridgcamp.gcamp.entity.SoftwareCriteriaId;

@Repository
public interface SoftwareCriteriaRepository extends JpaRepository<SoftwareCriteriaData, SoftwareCriteriaId> {

}
