
package com.ford.gcamp.targeting.reports.batch.exception.writer;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import com.ford.gcamp.targeting.reports.batch.common.ReportGenerationUtil;
import org.apache.commons.collections4.ListUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.xssf.streaming.SXSSFSheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.item.Chunk;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.ford.gcamp.targeting.reports.batch.api.ExcelConfig;
import com.ford.gcamp.targeting.reports.batch.api.ReportMetaData;
import com.ford.gcamp.targeting.reports.batch.common.ReportCodeConstants;
import com.ford.gcamp.targeting.reports.batch.exception.GCAMPReportException;
import com.ford.gcamp.targeting.reports.batch.exception.api.TargetingExceptionReport;
import com.ford.gcamp.targeting.reports.batch.writer.GCAMPXSSFReportWriter;

@Component(ReportCodeConstants.T14 + "itemWriter")
@StepScope
public class ExcelVINsForReOpenExceptionsReportItemWriter extends GCAMPXSSFReportWriter
		implements ItemWriter<TargetingExceptionReport> {

	private List<TargetingExceptionReport> vinsForReOpenExceptionsList;

	@Value("#{jobParameters['reportMetaData']}")
	private String reportMetaDataString;

	private ReportMetaData reportData;

	@Value("${exception.report.xlsx.maxrecords}")
	private int xlsxMaxRecords;

	@Override
	public void write(Chunk<? extends TargetingExceptionReport> items) throws Exception {
		reportData = ReportGenerationUtil.getReportMetaDataObject(reportMetaDataString);
		vinsForReOpenExceptionsList = new ArrayList<>(items.getItems());
		this.createReport(reportData);
	}

	@Override
	public void createWorksheet(SXSSFWorkbook hssfWorkbook, ReportMetaData metaData) throws GCAMPReportException {

		initializeWorkbook(hssfWorkbook);
		List<List<TargetingExceptionReport>> vinsForReOpenExceptions = ListUtils.partition(
				vinsForReOpenExceptionsList,
				xlsxMaxRecords);
		List<ExcelConfig> vinsForReOpenExceptionsConfigList = loadConfigFile(ReportCodeConstants.T14,
				metaData.getSuppCode());
		int index = 1;
		for (List<TargetingExceptionReport> vinsForReOpenException : vinsForReOpenExceptions) {

			SXSSFSheet sheet = hssfWorkbook
					.createSheet(vinsForReOpenExceptionsList.size() > xlsxMaxRecords
							? "VINs For ReOpen Exceptions" + StringUtils.SPACE + index
							: "VINs For ReOpen Exceptions");
			try {

				createProfile(sheet, metaData, "VINs For ReOpen Exceptions Report");

				setColumnWidth(sheet, vinsForReOpenExceptionsConfigList);

				setColumnHeader(sheet, vinsForReOpenExceptionsConfigList);

				setRowData(sheet, vinsForReOpenExceptionsConfigList, vinsForReOpenException);

			} catch (Exception e) {
				throw new GCAMPReportException("Error in processing VINs ReOpen Exceptions Report", e);
			}
			index++;
		}

	}

	public void setXlsxMaxRecords(int xlsxMaxRecords) {
		this.xlsxMaxRecords = xlsxMaxRecords;
	}

	public void setReportData(ReportMetaData metadata) {
		this.reportData = metadata;
	}

}