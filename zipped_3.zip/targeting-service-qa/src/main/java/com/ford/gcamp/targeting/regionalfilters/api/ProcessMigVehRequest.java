package com.ford.gcamp.targeting.regionalfilters.api;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.v3.oas.annotations.extensions.Extension;
import io.swagger.v3.oas.annotations.extensions.ExtensionProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@Getter
@Setter
@NoArgsConstructor
@Builder
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class ProcessMigVehRequest {

	@Size(min = 1, max = 2)
	@Pattern(regexp = "^[a-zA-Z\\*]*$")
	@Schema(example = "NA", description = "Hub code")
	private String hub;

	@NotNull
	@Size(min = 5, max = 6)
	@Pattern(regexp = "^\\d{2}[A-Za-z\\d]{2}\\d{1}\\d*$")
	@Schema(type="string", description = "FSA number",minLength=5,maxLength = 6, extensions = @Extension(properties = @ExtensionProperty(name = "x-42c-sample", value = "15311")))
	private String fsaNumber;


	@Size(min = 1, max = 3)
	@Pattern(regexp = "^[a-zA-Z\\*\\s\\d]*$")
	@Schema(example = "CAN", description = "CountryCode")
	private String country;

	@Size(min = 1, max = 8)
	@Pattern(regexp = "^[a-zA-Z\\d\\-]*$")
	@Schema(example = "TDHARTI", description = "CDSID")
	private String cdsId;
	
	}

	