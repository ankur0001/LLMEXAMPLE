package com.ford.gcamp.targeting.gridgcamp.gcamp.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.sql.Timestamp;

@Setter
@Getter
@Entity
@Table(name = "SGCPG13_DST_PRC")
public class DistributionProcessEntity {

    @Id
    @Column(name = "GCPG13_PROCESS_D")
    private int processId;

    @Column(name = "GCPG13_PROCESS_X")
    private String processInfo;

    @Column(name = "GCPG13_UPDATE_ID_C")
    private String updateId;

    @Column(name = "GCPG13_UPDATE_S")
    private Timestamp updatedTimestamp;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "GCPG13_PROCESS_D", referencedColumnName = "GCPG13_PROCESS_D", insertable = false, updatable = false)
    private ProcessDistributionMapEntity priceDistributionMap;

}
