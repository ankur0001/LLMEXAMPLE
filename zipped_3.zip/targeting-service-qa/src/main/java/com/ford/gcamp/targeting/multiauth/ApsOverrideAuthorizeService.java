package com.ford.gcamp.targeting.multiauth;

import com.ford.aps.core.exception.ApsClientException;
import com.ford.aps.spring.service.ApsPdpService;
import com.ford.aps.spring.service.AuthorizeService;
import com.ford.gcamp.targeting.common.CommonConstants;
import java.util.Collections;
import java.util.Optional;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnExpression;
import org.springframework.context.annotation.Primary;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.stereotype.Service;

@Primary
@ConditionalOnExpression(value = "!'${aps.pdp-base-url:}'.equals('')")
@Service
@Slf4j
public class ApsOverrideAuthorizeService extends AuthorizeService {

    private final ApsPdpService apsPdpService;

    public ApsOverrideAuthorizeService(ApsPdpService apsPdpService) {
        super(apsPdpService, Collections.emptyMap());
        this.apsPdpService = apsPdpService;
    }

    @Override
    public boolean isAuthorized(String resource, String action) throws ApsClientException {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication == null) {
            return false;
        }

        Object principal = authentication.getPrincipal();
        if (!(principal instanceof Jwt jwt)) {
            return false;
        }

        String userName = resolveUserName(jwt);
        if (userName == null) {
            log.warn("[Auth] Could not resolve user name from JWT; denying access to {}", resource);
            return false;
        }

        return apsPdpService.getPolicyDecisions(userName, resource, action);
    }

    private String resolveUserName(Jwt jwt) {
        String issuer = String.valueOf(jwt.getIssuer());

        if (issuer.contains("adfs")) {
            return jwt.getSubject();
        }

        // Entra path: try upn claim first, fall back to subject
        String upnClaim =
                Optional.ofNullable(jwt.getClaims())
                        .map(claims -> (String) claims.get(CommonConstants.JWT_CDSID_CLAIM))
                        .orElse(null);

        if (upnClaim != null) {
            return upnClaim.split("@")[0];
        }

        return jwt.getSubject();
    }
}
