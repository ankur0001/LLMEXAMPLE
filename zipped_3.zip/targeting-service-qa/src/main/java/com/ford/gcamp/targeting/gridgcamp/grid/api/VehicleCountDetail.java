package com.ford.gcamp.targeting.gridgcamp.grid.api;

import com.ford.gcamp.targeting.common.api.GenericLookup;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class VehicleCountDetail {
	private GenericLookup vehicleLine;
	private int modelYear;
	private GenericLookup brand;
	private int sold;
	private int unSold;
}
