package com.ford.gcamp.targeting.properties;

import java.util.Map;

import org.springframework.boot.context.properties.ConfigurationProperties;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@ConfigurationProperties(prefix = "vin.lists.aps")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class VinListApsAccess {
	
	private String pageName;
	private Map<String, String> resources;
	
}
