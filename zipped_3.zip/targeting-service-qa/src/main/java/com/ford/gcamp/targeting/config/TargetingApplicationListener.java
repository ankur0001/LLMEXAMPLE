package com.ford.gcamp.targeting.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import com.ford.gcamp.targeting.fsacriteria.AddModifyCriteriaService;
import com.ford.gcamp.targeting.fsacriteria.FsaCriteriaFilterService;

@Component
@Order(0)
public class TargetingApplicationListener implements ApplicationListener<ApplicationReadyEvent> {

	private static final Logger LOGGER = LoggerFactory.getLogger(TargetingApplicationListener.class);
	
	@Autowired
	private AddModifyCriteriaService addModifyCriteriaService;
	
	@Autowired
	private FsaCriteriaFilterService fsaCriteriaFilterService;
	
	@Override
	public void onApplicationEvent(ApplicationReadyEvent event) {
		LOGGER.info("ApplicationListener#onApplicationEvent() {}", event);
		fsaCriteriaFilterService.getFsaBrandModelVehLinePlant();
		fsaCriteriaFilterService.getAllWersDetails();
		addModifyCriteriaService.getFscFormDetails();
		LOGGER.info("ApplicationListener#onApplicationEvent() executed");
	}

}
