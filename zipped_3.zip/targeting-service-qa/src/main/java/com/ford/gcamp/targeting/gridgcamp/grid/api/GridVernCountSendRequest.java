package com.ford.gcamp.targeting.gridgcamp.grid.api;

import io.swagger.v3.oas.annotations.extensions.Extension;
import io.swagger.v3.oas.annotations.extensions.ExtensionProperty;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.ToString;

@Setter
@Getter
@ToString
public class GridVernCountSendRequest {

	@NotNull
	@NotBlank(message = "Global FSA Number is mandatory")
	@Size(min = 0, max = 8, message = "Max length 8")
	@Schema(extensions =@Extension(properties = @ExtensionProperty(name = "x-42c-sample", value = "69366")))
	@Pattern(regexp ="^|[\\d]*$", message = "FSA number")
	private String globalFSANumber;

	@NotNull
	@NotBlank(message = "Supplement Code is mandatory")
	@Size(min = 1, max = 2, message = "length 1-2")
	@Schema(example = "00",description = "cdsid")
	@Pattern(regexp ="^[A-Za-z\\d]*$", message = "Supplement Code")
	private String supplementCode;

	@NotNull
	@Size(min = 1, max = 8, message = "length 1-8")
	@Schema(example = "DMADHUMI",description = "cdsid")
	@Pattern(regexp ="^[A-Za-z\\d\\-]*$", message = "CDS Id")
	private String cdsId;


	@Schema(example = "Testing",description = "comments")
	@Size(min = 0, max = 2000, message = "length 0-2000")
	@Pattern(regexp ="^[a-zA-Z\\d .\\-_,\\s]*$", message = "Comments")
	private String comments;

	private String actionFlag;
}
