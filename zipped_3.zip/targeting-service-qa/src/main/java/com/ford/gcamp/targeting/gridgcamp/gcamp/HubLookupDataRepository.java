package com.ford.gcamp.targeting.gridgcamp.gcamp;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ford.gcamp.targeting.gridgcamp.grid.entity.HubLookupData;

@Repository
public interface HubLookupDataRepository extends JpaRepository<HubLookupData, String> {

}
