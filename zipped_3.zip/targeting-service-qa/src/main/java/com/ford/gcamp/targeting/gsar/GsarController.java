package com.ford.gcamp.targeting.gsar;

import java.io.IOException;

import com.ford.cloudnative.base.api.StandardErrorResponse;
import com.ford.gcamp.targeting.common.api.CommonErrorResponse;
import com.ford.gcamp.targeting.gsar.api.*;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.ford.gcamp.targeting.common.api.CommonResponse;
import com.ford.gcamp.targeting.common.api.FscCriteriaRequest;
import com.ford.gcamp.targeting.core.exception.GCAMPException;
import com.ford.gcamp.targeting.logging.LogExecutionTime;
import com.ford.gcamp.targeting.vin.api.VinListResponseDTO;

import lombok.extern.slf4j.Slf4j;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping(path = "/api/v1/targeting/gsar")
@Slf4j
@Validated
public class GsarController {
	
	private GsarService gsarService;
	
	@Autowired
	public GsarController(GsarService gsarService) {
		this.gsarService = gsarService;
	}
	
	@PostMapping("/searchgsarreports")
	@Operation(summary = "Get UnAssigned GridVernInfoCount",security = {
			@SecurityRequirement(name = "ADFS"),
			@SecurityRequirement(name = "AzureAD")
	})
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "UnAssignedGridVernInfo request fetched successfully",
					content = @Content(mediaType = "application/problem+json",schema = @Schema(implementation = GsarSearchResponse.class))),
			@ApiResponse(responseCode = "default", description = "All Errors", content = @Content(schema = @Schema(implementation = StandardErrorResponse.class)))
	})
	@PreAuthorize("@authorizeService.isAuthorized('GCAMP:GsarReports:go','execute')")
	@LogExecutionTime
	public ResponseEntity<GsarSearchResponse> searchGsarReports(
			@RequestBody @Valid final GsarSearchRequest gsarSearchRequest) {
		GsarSearchResponse response = gsarService.searchGsarReports(gsarSearchRequest);
		return ResponseEntity.ok(response);
	}
	

	@PostMapping("/fetchgsarreports")
	@Operation(summary = "Fetch Gsar Reports",security = {
			@SecurityRequirement(name = "ADFS"),
			@SecurityRequirement(name = "AzureAD")
	})
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "UnAssignedGridVernInfo request fetched successfully",
					content = @Content(mediaType = "application/problem+json",schema = @Schema(implementation = CommonResponse.class))),
			@ApiResponse(responseCode = "default", description = "All Errors", content = @Content(schema = @Schema(implementation = StandardErrorResponse.class)))
	})
	@PreAuthorize("@authorizeService.isAuthorized('GCAMP:GsarReports:fetch','execute')")
	@LogExecutionTime
	public ResponseEntity<CommonResponse> fetchGsarReports(
			@RequestBody @Valid final GsarSearchRequest gsarSearchRequest) {
		CommonResponse response = gsarService.fetchGsarReports(gsarSearchRequest);
		return ResponseEntity.ok(response);
	}
	
	@GetMapping("/viewreports/{userHub}")
	@Operation(summary = "View Reports Userhub",security = {
			@SecurityRequirement(name = "ADFS"),
			@SecurityRequirement(name = "AzureAD")
	})
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "View Reports userhub request fetched successfully",
					content = @Content(mediaType = "application/problem+json",schema = @Schema(implementation = ViewReportsResponse.class))),
			@ApiResponse(responseCode = "400", description = "Bad Request, missing required fields"),
			@ApiResponse(responseCode = "401", description = "Unauthorized"),
			@ApiResponse(responseCode = "403", description = "Forbidden"),
			@ApiResponse(responseCode = "404", description = "Not Found", content = @Content(schema = @Schema(implementation = CommonResponse.class))),
			@ApiResponse(responseCode = "406", description = "Invalid Response type"),
			@ApiResponse(responseCode = "405", description = "Invalid Method type"),
			@ApiResponse(responseCode = "412", description = "Precondition Failed", content = @Content(schema = @Schema(implementation = CommonResponse.class))),
			@ApiResponse(responseCode = "415", description = "Unsupported Media Type"),
			@ApiResponse(responseCode = "428", description = "Bad Request, missing required fields",content = @Content(array = @ArraySchema(schema = @Schema(implementation = CommonResponse.class)))),
			@ApiResponse(responseCode = "429", description = "Too many bad request"),
			@ApiResponse(responseCode = "429", description = "Too many bad request"),
			@ApiResponse(responseCode = "504", description = "Gateway Timeout"),
			@ApiResponse(responseCode = "default", description = "All Errors", content = @Content(schema = @Schema(implementation = StandardErrorResponse.class)))
	})
	@PreAuthorize("@authorizeService.isAuthorized('GCAMP:GsarReports:go','execute')")
	@LogExecutionTime
	public ResponseEntity<ViewReportsResponse> viewReports(@PathVariable("userHub") @Valid @NotNull @Size(min = 1, max = 2)
															   @Pattern(regexp = "^[a-zA-Z\\*\\s]*$")
															   @Schema(example = "NA", description = "User Hub") String userHub) {
		ViewReportsResponse response = gsarService.viewReports(userHub);
		return ResponseEntity.ok(response);
	}
	
	@GetMapping(value = "/download/{resultId}/{id}/{userHub}")
	@Operation(summary = "Download resultId Userhub",security = {
			@SecurityRequirement(name = "ADFS"),
			@SecurityRequirement(name = "AzureAD")
	})
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Download resultId Userhub request fetched successfully",
					content = @Content(mediaType = "text/plain",schema = @Schema(implementation = ByteArrayResource.class))),
			@ApiResponse(responseCode = "default", description = "All Errors", content = @Content(schema = @Schema(implementation = StandardErrorResponse.class)))
	})
	@PreAuthorize("@authorizeService.isAuthorized('GCAMP:GsarReports:download','execute')")
	@LogExecutionTime
	public ResponseEntity<ByteArrayResource> downloadVinGroup(@PathVariable @Valid @Min(0) @Max(999999999)
																  @Parameter(required = true, schema = @Schema(type = "integer",example = "1894", description = "result Id") )Integer resultId,
			@PathVariable("id")  @Valid @Min(0) @Max(999999999)
			@Parameter(required = true , schema = @Schema(type = "integer",format = "int64",example = "3", description = "Unique Id")) Long uniqueId, @PathVariable @Valid @NotNull @Size(min = 1, max = 2)
																  @Pattern(regexp = "^[a-zA-Z\\*\\s]*$")
																  @Schema(example = "NA", description = "User Hub")  String userHub) {
		ByteArrayResource fileresource = gsarService.downloadVinDetails(resultId, uniqueId, userHub);
		String fileName = String.valueOf(uniqueId).concat(String.valueOf(resultId));
		log.info("fileName in download {}", fileName.replaceAll("[\r\n]",""));
		return ResponseEntity.ok().header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" +fileName  + ".txt")
				.contentType(MediaType.TEXT_PLAIN).body(fileresource);
	}
	
	@GetMapping("/delete/{resultId}/{id}/{userHub}")
	@Operation(summary = "Delete resultId Userhub",security = {
			@SecurityRequirement(name = "ADFS"),
			@SecurityRequirement(name = "AzureAD")
	})
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Download resultId Userhub request fetched successfully",
					content = {
							@Content(mediaType = "application/json", schema = @Schema(implementation = CommonResponse.class)),
							@Content(mediaType = "text/plain", schema = @Schema(implementation = CommonResponse.class))
					}),
			@ApiResponse(responseCode = "default", description = "All Errors", content = @Content(schema = @Schema(implementation = StandardErrorResponse.class)))
	})
	@PreAuthorize("@authorizeService.isAuthorized('GCAMP:GsarReports:delete','execute')")
	public ResponseEntity<CommonResponse> deleteVinGroup(@PathVariable("resultId") @Valid @NotNull @Min(0) @Max(9999)
															 @Schema(type = "integer", example = "1894", description = "result Id") Integer resultId,
			@PathVariable("id") @Valid @NotNull @Min(0) @Max(999999999)
			@Schema( type = "integer",format = "int64",example = "3", description = "Unique Id") Long uniqueId,
														 @PathVariable("userHub") @Valid @NotNull @Size(min = 1, max = 2)
															 @Pattern(regexp = "^[a-zA-Z\\*\\s]*$")
															 @Schema(example = "NA", description = "User Hub") String userHub){
		CommonResponse deleteResponse = gsarService.deleteVinGroup(resultId, uniqueId, userHub);
		return ResponseEntity.ok(deleteResponse);
	}
	

	@PostMapping("/uploadgsar")
	@Operation(summary = "upload gsar",security = {
			@SecurityRequirement(name = "ADFS"),
			@SecurityRequirement(name = "AzureAD")
	})
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Upload gsar request fetched successfully",
					content = @Content(mediaType = "application/problem+json",schema = @Schema(implementation = CommonResponse.class))),
			@ApiResponse(responseCode = "412", description = "Precondition Failed" ,content = @Content(schema = @Schema(implementation = CommonErrorResponse.class))),
			@ApiResponse(responseCode = "default", description = "All Errors", content = @Content(schema = @Schema(implementation = StandardErrorResponse.class)))
	})
	@PreAuthorize("@authorizeService.isAuthorized('GCAMP:GsarUpload:add','execute')")
	public ResponseEntity<CommonResponse> uploadGsarFile(@RequestBody @Valid final GsarFileUploadRequest gsarFileUploadRequest) throws GCAMPException {
		CommonResponse uploadResposne = gsarService.uploadGsarFile(gsarFileUploadRequest);
		return ResponseEntity.ok(uploadResposne);
	}

	@PostMapping("/history")
	@Operation(summary = "History gsar",security = {
			@SecurityRequirement(name = "ADFS"),
			@SecurityRequirement(name = "AzureAD")
	})
	@PreAuthorize("@authorizeService.isAuthorized('GCAMP:GsarReports:upload','execute')")
	@LogExecutionTime
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Data Retrieved Successfully", content = {
					@Content(mediaType = "application/problem+json",schema = @Schema(implementation = VinListResponseDTO.class))}),
			@ApiResponse(responseCode = "400", description = "Bad Request, missing required fields"),
			@ApiResponse(responseCode = "401", description = "Unauthorized"),
			@ApiResponse(responseCode = "403", description = "Forbidden"),
			@ApiResponse(responseCode = "404", description = "Not Found"),
			@ApiResponse(responseCode = "405", description = "Invalid Method type"),
			@ApiResponse(responseCode = "412", description = "Precondition Failed"),
			@ApiResponse(responseCode = "415", description = "Unsupported Media Type"),
			@ApiResponse(responseCode = "428", description = "Bad Request, missing required fields"),
			@ApiResponse(responseCode = "429", description = "Too many bad request"),
			@ApiResponse(responseCode = "500", description = "Internal Server Error"),
			@ApiResponse(responseCode = "default", description = "All Errors", content = @Content(schema = @Schema(implementation = StandardErrorResponse.class)))})
	public ResponseEntity<VinListResponseDTO> getGsarHistory(@RequestBody @Valid final FscCriteriaRequestForGsar fscCriteriaRequest) throws HttpMessageNotReadableException {
		VinListResponseDTO vinListResponse = gsarService.getGsarHistory(fscCriteriaRequest);
		return ResponseEntity.ok(vinListResponse);
	}
	@PreAuthorize("@authorizeService.isAuthorized('GCAMP:GsarReports:go','execute')")
	@GetMapping("/gsarstopship/{startDate}/{endDate}")
	@Operation(summary = "gsar stop ship",security = {
			@SecurityRequirement(name = "ADFS"),
			@SecurityRequirement(name = "AzureAD")
	})
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "gsar stop ship request fetched successfully",
					content = @Content(mediaType = "application/problem+json",schema = @Schema(implementation = StopShipRepairResponse.class))),
			@ApiResponse(responseCode = "412", description = "Precondition Failed",content = @Content(schema = @Schema(implementation = CommonErrorResponse.class))),
			@ApiResponse(responseCode = "default", description = "All Errors", content = @Content(schema = @Schema(implementation = StandardErrorResponse.class)))
	})
	public ResponseEntity<StopShipRepairResponse> getGsarStopShipDetails(@PathVariable("startDate") @NotNull @Size(min = 0, max = 20)
																			 @Schema(example = "2022-02-11", description = "startDate")
																			 @Pattern(regexp ="^[\\d\\-]*$", message = "startDate")  String startDate,
			@PathVariable("endDate")  @NotNull @Size(min = 0, max = 20)
			@Schema(example = "2025-03-11", description = "endDate")
			@Pattern(regexp ="^[\\d\\-]*$", message = "endDate")  String endDate) throws GCAMPException{
		StopShipRepairResponse response = gsarService.getGsarStopShipRepairDetails(startDate, endDate);
		log.info("Gsar Stop Ship Response {}", response);
		return ResponseEntity.ok().body(response);
	}
	

}
