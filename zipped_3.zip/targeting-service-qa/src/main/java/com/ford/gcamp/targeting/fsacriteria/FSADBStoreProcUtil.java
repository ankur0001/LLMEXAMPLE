package com.ford.gcamp.targeting.fsacriteria;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ford.gcamp.targeting.common.CommonConstants;
import com.ford.gcamp.targeting.common.TargetingUtil;
import com.ford.gcamp.targeting.fsacriteria.api.AssemblyPlantList;
import com.ford.gcamp.targeting.fsacriteria.api.AttributeGroupingList;
import com.ford.gcamp.targeting.fsacriteria.api.GCPFilterList;
import com.ford.gcamp.targeting.fsacriteria.api.LoadFsaResponseDTO;
import com.ford.gcamp.targeting.fsacriteria.api.ModelYearList;
import com.ford.gcamp.targeting.fsacriteria.api.VehicleBrandList;
import com.ford.gcamp.targeting.fsacriteria.api.VehicleTypeList;

@Component
public class FSADBStoreProcUtil {
	@Autowired
	private LoadFsaResponseDTO addorModifyModelYrResponse;
	
	public LoadFsaResponseDTO callStoreProcedure(Map<String, Object> map){

		List<AttributeGroupingList> attributeLists = new ArrayList<>();
		List<ModelYearList> modelYearLists = new ArrayList<>();

		@SuppressWarnings("unchecked")
		List<Map<String, Object>> vehicleData = (List<Map<String, Object>>) map.get("#result-set-3");
		List<VehicleTypeList> listVehicles = getVehicleData(vehicleData);

		@SuppressWarnings("unchecked")
		List<Map<String, Object>> brandData = (List<Map<String, Object>>) map.get("#result-set-2");
		List<VehicleBrandList> listBrands = getBrandData(brandData);
		
		// changes for all
		@SuppressWarnings("unchecked")
		List<Map<String, Object>> assemblyPlantList = (List<Map<String, Object>>) map.get("#result-set-4");
		List<AssemblyPlantList> assemblyPlant = getAssemblyPlantList(assemblyPlantList);
		
		@SuppressWarnings("unchecked")
		List<Map<String, Object>> gcpFilterMapList = (List<Map<String, Object>>) map.get("#result-set-5");
		List<GCPFilterList> listCPFilter = getGcpFilerMapList(gcpFilterMapList);
		
		@SuppressWarnings("unchecked")
		List<Map<String, Object>> attributeGroupig = (List<Map<String, Object>>) map.get("#result-set-6");
		if (attributeGroupig != null) {

			for (Map<String, Object> map1 : attributeGroupig) {
				AttributeGroupingList attributeGroupList = new AttributeGroupingList();

				attributeGroupList.setGcpFilterGRPC((int) map1.get("GCPD03_FILTR_GRP_C"));
				attributeGroupList.setGcpFilterGRPX(((String) map1.get("GCPD03_FILTR_GRP_X")).trim());

				attributeLists.add(attributeGroupList);

			}
			if (!attributeLists.isEmpty()) {
				attributeLists.remove(0);
			}

		}

		@SuppressWarnings("unchecked")
		List<Map<String, Object>> modelYears = (List<Map<String, Object>>) map.get("#result-set-1");
		if (modelYears != null) {
			String modelYr = null;
			for (Map<String, Object> map1 : modelYears) {
				modelYr = String.valueOf(map1.get("GCPB22_MODEL_YR_C"));
				if (!("0   ".equals(modelYr))) {
					ModelYearList modelYearslist = new ModelYearList();
					modelYearslist.setModelYears(modelYr);
					modelYearLists.add(modelYearslist);
				}
			}
		}

		addorModifyModelYrResponse.setModelYear(modelYearLists);
		addorModifyModelYrResponse.setAssemblyPlantList(assemblyPlant);
		addorModifyModelYrResponse.setVehicleTypeList(listVehicles);
		addorModifyModelYrResponse.setVehicleBrandLists(listBrands);
		addorModifyModelYrResponse.setGcpFilterList(listCPFilter);
		addorModifyModelYrResponse.setAttributeGroupingLists(attributeLists);
		if (addorModifyModelYrResponse.getModelYear() != null || addorModifyModelYrResponse.getVehicleBrandLists()!=null) {
			addorModifyModelYrResponse.setStatusCode(CommonConstants.SUCCESS);
			addorModifyModelYrResponse.setStatusDescription(CommonConstants.SUCCESS_DESC);
		} else {

			addorModifyModelYrResponse.setStatusCode(CommonConstants.FAILURE);
			addorModifyModelYrResponse.setStatusDescription(CommonConstants.FAILURE_DESC);
		}
		return addorModifyModelYrResponse;
	}

	

	private List<GCPFilterList> getGcpFilerMapList(List<Map<String, Object>> gcpFilterMapList) {
		List<GCPFilterList> listCPFilter = new ArrayList<>();
		if (gcpFilterMapList != null) {
			for (Map<String, Object> map1 : gcpFilterMapList) {
				GCPFilterList gcpFilterList = new GCPFilterList();
				String wersFamily = StringUtils.trimToEmpty(String.valueOf(map1.get("GCPB09_WERS_FMLY_C")));
				gcpFilterList.setGcpFilterC((int) map1.get("GCPD02_FILTER_C"));
				gcpFilterList.setGcpFilterX(TargetingUtil.getWersDescWithFamilyCode(StringUtils.trimToEmpty(String.valueOf(map1.get("GCPD02_FILTER_X"))),wersFamily));
				gcpFilterList.setWersFamilyCode(wersFamily);

				listCPFilter.add(gcpFilterList);
			}
		}
		return listCPFilter;
	}



	private List<AssemblyPlantList> getAssemblyPlantList(List<Map<String, Object>> assemblyPlantList) {
		List<AssemblyPlantList> assemblyPlant = new ArrayList<>();
		if (assemblyPlantList != null) {
			for (Map<String, Object> map1 : assemblyPlantList) {
				AssemblyPlantList assPlantList = new AssemblyPlantList();
				String vehicleType = (String) map1.get("WRSFTR");
				String gcpFilteValueX = (String) map1.get("GCPB08_WERS_FTR_X");
				assPlantList.setWsrFilterCode((String) map1.get("WRSFTR"));
				assPlantList.setGcpWersFtrX(gcpFilteValueX.trim() + " ( " + vehicleType.substring(5) + " )");

				assemblyPlant.add(assPlantList);

			}
		}
		return assemblyPlant;
	}



	private List<VehicleBrandList> getBrandData(List<Map<String, Object>> brandData) {
		List<VehicleBrandList> listBrands = new ArrayList<>();
		if (brandData != null) {
			for (Map<String, Object> map1 : brandData) {
				VehicleBrandList vehicleBrandList = new VehicleBrandList();
				vehicleBrandList.setBrandC(((String) map1.get("GCPB03_BRAND_C")).trim());
				vehicleBrandList.setBrandX(((String) map1.get("GCPB03_BRAND_X")).trim());
				listBrands.add(vehicleBrandList);

			}
		}
		return listBrands;
	}

	private List<VehicleTypeList> getVehicleData(List<Map<String, Object>> vehicleData) {
		List<VehicleTypeList> listVehicles = new ArrayList<>();
		if (vehicleData != null) {
			for (Map<String, Object> map1 : vehicleData) {
				VehicleTypeList vehicleTypeList = new VehicleTypeList();
				String vehicleLNC = ((String) map1.get("GCPB13_VEH_TYP_C")).trim()
						+ ((String) map1.get("GCPB22_VEH_LN_C")).trim();
				vehicleTypeList.setVehicleLnC(vehicleLNC);
				vehicleTypeList
						.setVehicleLnX(((String) map1.get(("GCPB22_VEH_LN_X"))).trim() + " (" + vehicleLNC + ")");
				listVehicles.add(vehicleTypeList);

			}
		}
		return listVehicles;
	}

}
