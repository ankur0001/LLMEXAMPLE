package com.ford.gcamp.targeting.config;

import com.ford.gcamp.targeting.common.CommonConstants;
import com.ford.gcamp.targeting.common.CommonService;
import com.ford.gcamp.targeting.common.LDAPModel;
import com.ford.gcamp.targeting.user.UserService;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Arrays;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationToken;
import org.springframework.web.filter.OncePerRequestFilter;

@Slf4j
public class CountryRestrictionFilter extends OncePerRequestFilter {

    private final UserService userService;

    @Autowired private CommonService commonService;

    private final Set<String> restrictedCountries;

    public CountryRestrictionFilter(UserService userService, String restrictedCountries) {
        this.userService = userService;
        this.restrictedCountries =
                Optional.ofNullable(restrictedCountries)
                        .filter(s -> !s.isBlank())
                        .map(
                                s ->
                                        Arrays.stream(s.split(","))
                                                .map(String::trim)
                                                .filter(t -> !t.isBlank())
                                                .map(String::toUpperCase)
                                                .collect(Collectors.toUnmodifiableSet()))
                        .orElse(Set.of());
    }

    @Override
    protected void doFilterInternal(
            HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
            throws ServletException, IOException {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String principalName = null;
        if (authentication != null
                && authentication.isAuthenticated()
                && !"anonymousUser".equals(authentication.getPrincipal())) {
            if (authentication instanceof JwtAuthenticationToken jwtAuth) {
                Map<String, Object> claims = jwtAuth.getToken().getClaims();
                if (claims.containsKey(CommonConstants.JWT_CDSID_CLAIM))
                    principalName =
                            claims.get(CommonConstants.JWT_CDSID_CLAIM)
                                    .toString()
                                    .split("@")[0]
                                    .toLowerCase();
                else principalName = authentication.getName();
            } else {
                principalName = authentication.getName();
            }
            if (isMachineClient(authentication)) {
                log.info(
                        "Allowing access for machine client (Principal: {}) - skipping country restriction.",
                        principalName);
                filterChain.doFilter(request, response);
                return;
            }
            Optional<LDAPModel> ldapModelOptional = userService.getByCDSId(principalName);

            if (ldapModelOptional.isPresent()) {
                LDAPModel ldap = ldapModelOptional.get();
                String country = ldap.getCountry();

                if (country != null && restrictedCountries.contains(country.toUpperCase())) {
                    response.setStatus(HttpStatus.FORBIDDEN.value());
                    response.setContentType("application/json");
                    response.getWriter()
                            .write(
                                    "{\"statusCode\":403,\"statusDescription\":\"Access denied: Not permitted from your country of origin.\"}");
                    return;
                }
            } else {

                response.setStatus(HttpStatus.NOT_FOUND.value());
                response.setContentType("application/json");
                response.getWriter()
                        .write(
                                "{\"statusCode\":404,\"statusDescription\":\"User details not found for authentication.\"}");
                return;
            }
        }

        filterChain.doFilter(request, response);
    }

    private boolean isMachineClient(Authentication authentication) {
        if (authentication.getPrincipal() instanceof Jwt) {
            Jwt jwt = (Jwt) authentication.getPrincipal();
            boolean appidPresent = jwt.hasClaim("appid");
            boolean hasAppIdClaim = appidPresent || jwt.hasClaim("azp");
            boolean lacksHumanUserClaim =
                    !jwt.hasClaim(CommonConstants.JWT_CDSID_CLAIM)
                            && (!appidPresent || !jwt.hasClaim("sub"));
            if (hasAppIdClaim && lacksHumanUserClaim) {
                log.debug(
                        "JWT principal identified as machine client (appid present, human-user claims absent).");
                return true;
            }
        }

        return false;
    }
}
