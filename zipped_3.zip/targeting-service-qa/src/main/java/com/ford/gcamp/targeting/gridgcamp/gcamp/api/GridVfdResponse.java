package com.ford.gcamp.targeting.gridgcamp.gcamp.api;

import com.ford.gcamp.targeting.common.api.CommonResponse;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class GridVfdResponse extends CommonResponse {

	private Integer gridYearId;
	private Integer gridSequence;
	private Integer implementationId;
	private Integer version;
	private String supplementId;
	private String vernNumber;
	private Integer globalFSANumber;
	private String vfdFilePath;
	private String vfdFileName;
	private Integer totalVehicleCount;
}
