package com.ford.gcamp.targeting.common;

public class APSConstants {

	public static final String APS_SEGMENT_SETUP_PAGE_NAME = "segsetup";
	public static final String APS_SEGMENT_RESULTS_PAGE_NAME = "segresults";
	public static final String APS_PROGRAM_CLOSER_PAGE_NAME = "ProgramCloser";
	public static final String APS_VINBASED_EXPIRY_PAGE_NAME = "VinBasedExpiry";
	public static final String APS_SEGMENT_ATTRIBUTE_PAGE_NAME= "segmentattribute";
	public static final String APS_SEGMENT_BY_VINFILE_UPLOAD_PAGE_NAME =  "segByVinFileUpload:LoadPage";
	public static final String APS_HOME_PAGE_NAME = "login";
	
	private APSConstants() {

	}
}
