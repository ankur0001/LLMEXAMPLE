package com.ford.gcamp.targeting.fsacriteria.api;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class DeleteFsaInfoReq {
    @NotNull
	@Size(min = 0, max = 10)
	@Pattern(regexp = "^[a-zA-Z\\d\\s]*$")
	@Schema(example = "15S01", description = "Local FSA number")
	private String fsaNumber;

	@NotNull
	@Size(min = 0, max = 1)
	@Pattern(regexp = "^[A-Z]$")
	@Schema(example = "L", description = "G-Global, L-Local")
	private String fsaType;
	private boolean isLocalTest;


	@Size(min = 0, max = 8)
	@Pattern(regexp = "^[a-zA-Z\\d\\-]*$")
	@Schema(example = "TDHARTI", description = "CDSID")
	private String cdsId;

    @NotNull
	@Size(min = 0, max = 2)
	@Pattern(regexp ="^[A-Za-z\\d\\s\\*]*$", message = "population Code")
	@Schema(example = "**", description = "Population")
	private String population;
	
		
	
}
