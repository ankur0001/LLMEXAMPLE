package com.ford.gcamp.targeting.fsacriteria;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.ford.gcamp.targeting.common.CommonConstants;
import com.ford.gcamp.targeting.fsacriteria.api.FscCriteriaResponseGoDTO;


@Component
public class FsaListingSaveSoreProc {
	private static final Logger LOGGER = LoggerFactory.getLogger(FsaListingSaveSoreProc.class);
	public FscCriteriaResponseGoDTO listingSoreProc(Map<String, Object> fscCriteriaResponseMap) {
		LOGGER.info("save vin group response::{}", fscCriteriaResponseMap);
		FscCriteriaResponseGoDTO fcresponse=new FscCriteriaResponseGoDTO();
		String erParam = (String) fscCriteriaResponseMap.get("ERROR_PARM1");
		LOGGER.info("errorParam::{}", erParam);
		String statusInd = erParam.substring(9, 10);
		if (statusInd != null && ("Y").equalsIgnoreCase(statusInd)) {
			String errorCode = erParam.substring(37, 40);
			String errorDesc = erParam.substring(40, 150);
			fcresponse.setStatus(CommonConstants.FAILURE);
			fcresponse.setStatusCode(CommonConstants.FAILURE_CODE);
			fcresponse.setStatusDescription(errorCode + errorDesc);
		} else {
			LOGGER.info("copy vin group response::{}", CommonConstants.SUCCESS);
			fcresponse.setStatus(CommonConstants.SUCCESS);
			fcresponse.setStatusCode(CommonConstants.SUCCESS_CODE);
			fcresponse.setStatusDescription(CommonConstants.SUCCESS_DESC);
		}
		
		return fcresponse;

	}
	
	
}
