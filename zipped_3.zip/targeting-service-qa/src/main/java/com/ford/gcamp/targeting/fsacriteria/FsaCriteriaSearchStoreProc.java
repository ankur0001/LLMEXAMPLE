package com.ford.gcamp.targeting.fsacriteria;

import static java.util.Comparator.comparingInt;
import static java.util.stream.Collectors.collectingAndThen;
import static java.util.stream.Collectors.toCollection;

import java.util.*;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ford.gcamp.targeting.fsacriteria.api.FscCriteriaResponseGoDTO;
import com.ford.gcamp.targeting.common.api.FSAInfoVO;
import com.ford.gcamp.targeting.common.CommonConstants;
import com.ford.gcamp.targeting.common.DateConvert;
import com.ford.gcamp.targeting.common.TargetingUtil;
import com.ford.gcamp.targeting.common.api.LayoutBuffer;
import com.ford.gcamp.targeting.fsacriteria.api.VINGrpCriteriaVO;

@Component
public class FsaCriteriaSearchStoreProc {
	private static final Logger LOGGER = LoggerFactory.getLogger(FsaCriteriaSearchStoreProc.class);
	
	@Autowired
	FsaUtil fscCriteriaUtil;

	private static final int OUTPUT_LAYOUT_LENGTH = 1170;
	String mapKey;
	Map<String, Object> response = new LinkedHashMap<>();
	private static final String VEHICLE_LINE_FILTER = "VEHICLE LINE";
	private static final String ASSEMBLY_PLANT_FILTER = "ASSEMBLY PLANT";
	private static final String WARRANTY_CANCELATION_CODE_FILTER = "WARRANTY CANCELATION CODE";
	private static final String MODEL_YEAR_FILTER = "MODEL YEAR";

	private static final String BRAND_FILTER = "BRAND";
	private static final String PRODUCTION_DATE_FILTER = "PRODUCTION DATE";
	private static final String VIN_RANGE_FILTER = "VIN RANGE";
	private static final String VOC_START_END = "VEHICLE ORDER CODE";
	private static final String EOC_START_END = "EUROPEAN ORDER CODE";
	private static final String WERS_FILTER = "WERS";
	private static final String SYSTEM_SOURCE_FILTER = "SYSTEM SOURCE";


	public FscCriteriaResponseGoDTO callFsaSearch(Map<String, Object> fscCriteriaResponseMap) {
		TreeMap<String,VINGrpCriteriaVO> vinGroupMap = new TreeMap<>();
		FscCriteriaResponseGoDTO criteriaResponse = new FscCriteriaResponseGoDTO();
		FSAInfoVO fsaInfoVO = new FSAInfoVO();
		String outPutFSA02 = null;
		String outPutFSA012 = null;
		int j = 0;
		String[] outParms = new String[16];

			String errorParam = (String) fscCriteriaResponseMap.get("ERROR_PARM1");
			LOGGER.info("errorParam::{}", errorParam);
					String statusInd = errorParam.substring(9, 10);
					if (statusInd != null && "Y".equalsIgnoreCase(statusInd)) {
						String errorCode = errorParam.substring(37, 40);
						String errorDesc = errorParam.substring(40, 150);
						criteriaResponse.setStatus(CommonConstants.FAILURE);
						criteriaResponse.setStatusCode(CommonConstants.FAILURE_CODE);
						criteriaResponse.setStatusDescription(errorCode + errorDesc);
			}else {
			 for (Map.Entry<String, Object> entry : fscCriteriaResponseMap.entrySet()) {
				outPutFSA012 = getFSA(outPutFSA012, entry, "OUTPUT_FSAGO1");
				outPutFSA02 = getFSA(outPutFSA02, entry, "OUTPUT_FSAGO2");
				j = setOutPutParms(j, outParms, entry);
			 }

		fsaInfoVO.setString(outPutFSA012, outPutFSA02);
		ArrayList<VINGrpCriteriaVO> vingroupList = new ArrayList<>();
		if (outParms != null) { 
			// if condition main: 1 begin
			String recParam = "";
			Integer vinGrpNum = null;

			getVinGrpNum(vinGroupMap, outParms, vingroupList, recParam, vinGrpNum);
		}

		List<VINGrpCriteriaVO> vinGrpCriteriaVo = vingroupList.stream().collect(collectingAndThen(
				toCollection(() -> new TreeSet<>(comparingInt(VINGrpCriteriaVO::getVinGroupSeqNum))), ArrayList::new));

			criteriaResponse.setStatus(CommonConstants.SUCCESS);
			criteriaResponse.setStatusCode(CommonConstants.SUCCESS_CODE);
			criteriaResponse.setFsaInfoVO(fsaInfoVO);
		criteriaResponse.setVinGrpCriteriaVOs(vinGrpCriteriaVo);
		if (vinGrpCriteriaVo.isEmpty()
				&& !criteriaResponse.getStatusCode().equals(CommonConstants.FAILURE_CODE)) {
			criteriaResponse.setStatusDescription(CommonConstants.NO_GRP_DESC);
		}
		
	}
		return criteriaResponse;

	}

	private void getVinGrpNum(TreeMap<String, VINGrpCriteriaVO> vinGroupMap, String[] outParms, ArrayList<VINGrpCriteriaVO> vingroupList, String recParam, Integer vinGrpNum) {
		StringTokenizer st;
		for (int i = 0; i < outParms.length; i++) {
			if (outParms[i] != null) {
				recParam = (outParms[i]).trim();
			}
			if (recParam != null && !(" ".equalsIgnoreCase(recParam.trim()))) {
				// if condition : 2 begin
				st = new StringTokenizer(recParam, "|");
				vinGrpNum = getInteger(vinGroupMap, vingroupList, vinGrpNum, st);

			}

		}
	}

	private Integer getInteger(TreeMap<String, VINGrpCriteriaVO> vinGroupMap, ArrayList<VINGrpCriteriaVO> vingroupList, Integer vinGrpNum, StringTokenizer st) {
		String filterDesc;
		String token;
		VINGrpCriteriaVO vinGrpVO;
		String vinGrpSeq;
		VINGrpCriteriaVO criteriaVO;
		boolean isExists;
		String attribute;
		while (st.hasMoreTokens()) {

			LayoutBuffer layout = new LayoutBuffer(OUTPUT_LAYOUT_LENGTH);
			layout.addField(LayoutBuffer.FIELDTYPE_PICX, 4);
			layout.addField(LayoutBuffer.FIELDTYPE_PICX, 5);
			layout.addField(LayoutBuffer.FIELDTYPE_PICX, 4);
			layout.addField(LayoutBuffer.FIELDTYPE_PICX, 83);
			layout.addField(LayoutBuffer.FIELDTYPE_PICX, 83);
			layout.addField(LayoutBuffer.FIELDTYPE_PICX, 83);
			layout.addField(LayoutBuffer.FIELDTYPE_PICX, 46);
			layout.addField(LayoutBuffer.FIELDTYPE_PICX, 10);
			layout.addField(LayoutBuffer.FIELDTYPE_PICX, 4);
			layout.addField(LayoutBuffer.FIELDTYPE_PICX, 26);
			layout.addField(LayoutBuffer.FIELDTYPE_PICX, 8);
			layout.addField(LayoutBuffer.FIELDTYPE_PICX, 30);
			layout.addField(LayoutBuffer.FIELDTYPE_PICX, 30);
			layout.addField(LayoutBuffer.FIELDTYPE_PICX, 2);
			layout.addField(LayoutBuffer.FIELDTYPE_PICX, 254);
			layout.addField(LayoutBuffer.FIELDTYPE_PICX, 1);//ota
			layout.addField(LayoutBuffer.FIELDTYPE_PICX, 1);//fhm
			layout.addField(LayoutBuffer.FIELDTYPE_PICX, 1);//delem
			layout.addField(LayoutBuffer.FIELDTYPE_PICX, 449); //changed from 495
			token = st.nextToken();
			layout.fromString(token);

			String operator = layout.getString(7).trim();
			if("<>".equalsIgnoreCase(operator)) {
				operator = "!=";
			}
			vinGrpSeq = layout.getString(2).trim();
			if (!("".equalsIgnoreCase(vinGrpSeq))) {
				vinGrpSeq = Integer.toString(Integer.parseInt(vinGrpSeq));
				vinGrpNum = Integer.parseInt(vinGrpSeq);
			}
			isExists = vinGroupMap.containsKey(layout.getString(13).trim() + vinGrpNum);
			vinGrpVO = getVinGrpCriteriaVO(vinGroupMap, vinGrpSeq, vinGrpNum, isExists, layout);

			filterDesc = layout.getString(11);
			attribute = layout.getString(12);
			addVinGrpVODetails(filterDesc, attribute, vinGrpVO, layout, operator);
			if (!isExists) {
				vinGroupMap.put(layout.getString(13).trim() + vinGrpNum, vinGrpVO);
			}

			criteriaVO = new VINGrpCriteriaVO();
			setCriteriaVO(vinGrpVO, criteriaVO);
			vingroupList.add(criteriaVO);
		}
		return vinGrpNum;
	}

	private void addVinGrpVODetails(String filterDesc, String attribute, VINGrpCriteriaVO vinGrpVO, LayoutBuffer layout, String operator) {
		String genericFilter;
		Boolean realValue=!("".equalsIgnoreCase(layout.getString(6).trim()));

		if(Boolean.TRUE.equals(realValue)) {
			addVinGrpVOForVLModelBrand(filterDesc, vinGrpVO, layout);
		}
		else if(filterDesc.trim().equalsIgnoreCase(MODEL_YEAR_FILTER)){
				vinGrpVO.getModelYearFilter().add("ALL");
				vinGrpVO.getModelYearOperator().add("ALL");
		} else if(filterDesc.trim().equalsIgnoreCase(PRODUCTION_DATE_FILTER))
			validateAndAddProdDate(filterDesc, vinGrpVO, layout);
		else if(filterDesc.trim().equalsIgnoreCase(VIN_RANGE_FILTER)
				|| (filterDesc.trim().indexOf("DATE") > -1)
				|| (filterDesc.trim().indexOf("RANGE") > -1))
			addProdDateForVinRange(filterDesc, vinGrpVO, layout, operator);
		else if (filterDesc.trim().equalsIgnoreCase(VOC_START_END)
				|| filterDesc.trim().equalsIgnoreCase(EOC_START_END)) setVinGrpVoForEOC(filterDesc, vinGrpVO, layout, operator);
		else if (filterDesc.trim().equalsIgnoreCase(WARRANTY_CANCELATION_CODE_FILTER)) {
			if (!("".equalsIgnoreCase(layout.getString(3).trim()))) {
				genericFilter = filterDesc.trim() + ": " + layout.getString(3).trim();
				vinGrpVO.getGenericFilter().add(genericFilter);
			}
		} else if (attribute.trim().equalsIgnoreCase(WERS_FILTER)
				|| attribute.trim().equalsIgnoreCase(SYSTEM_SOURCE_FILTER))
			addVinGrpVOForWers(filterDesc, vinGrpVO, layout);
		else {
			addVinGrpVOForOthers(filterDesc, vinGrpVO, layout, operator);
		}
	}

	private void addVinGrpVOForVLModelBrand(String filterDesc, VINGrpCriteriaVO vinGrpVO, LayoutBuffer layout) {
		if (filterDesc.trim().equalsIgnoreCase(VEHICLE_LINE_FILTER)) {
			vinGrpVO.getVehicleLineFilter().add(layout.getString(6).trim());
		} else if (filterDesc.trim().equalsIgnoreCase(ASSEMBLY_PLANT_FILTER)) {
			vinGrpVO.getAssemblyPlantFilter().add(layout.getString(6).trim());
		} else if (filterDesc.trim().equalsIgnoreCase(MODEL_YEAR_FILTER)) {
			vinGrpVO.getModelYearFilter().add("<>".equals(layout.getString(7).trim()) ? "!=" : layout.getString(7).trim());
			vinGrpVO.getModelYearOperator().add(layout.getString(6).trim());
		} else if (filterDesc.trim().equalsIgnoreCase(BRAND_FILTER)) {
			vinGrpVO.getBrandFilter().add(layout.getString(6).trim());
		}
	}

	private void addVinGrpVOForOthers(String filterDesc, VINGrpCriteriaVO vinGrpVO, LayoutBuffer layout, String operator) {
		String genericFilter;
		if (!("".equalsIgnoreCase(filterDesc.trim()))) {
			if (!("".equalsIgnoreCase(layout.getString(4).trim()))
					&& !("".equalsIgnoreCase(layout.getString(5).trim()))
					&& !("0000000000".equalsIgnoreCase(layout.getString(5).trim()))) {
				genericFilter = filterDesc.trim() + ": " + layout.getString(4).trim() + " TO "
						+ layout.getString(5).trim();
			} else {
				genericFilter = filterDesc.trim() + ": " + operator + "  "
						+ layout.getString(3).trim();
			}
			vinGrpVO.getGenericFilter().add(genericFilter);
		}
	}

	private void addVinGrpVOForWers(String filterDesc, VINGrpCriteriaVO vinGrpVO, LayoutBuffer layout) {
		String genericFilter;
		String wersAtrCode = layout.getString(3).trim();

		if (!("".equalsIgnoreCase(layout.getString(3).trim()))) {

			if ("R".equalsIgnoreCase((wersAtrCode.substring(wersAtrCode.length() - 1, wersAtrCode.length())))) {
				String code = StringUtils.trimToEmpty(layout.getString(3));
				genericFilter = TargetingUtil.getWersDescWithFamilyCode(filterDesc.trim(), code.substring(0,3)) + ":  " + layout.getString(6).trim() + "  " + "("
						+ code.substring(0, code.length() - 1)
						+ ")" + "(" + code.substring(code.length() - 1)
						+ ")";
			}else {
				String wersValueCode = StringUtils.trimToEmpty(layout.getString(3));
				genericFilter = TargetingUtil.getWersDescWithFamilyCode(filterDesc.trim(), wersValueCode.substring(0,3)) + ":  " + layout.getString(6).trim() + "  " + "("
						+ (wersValueCode).substring(0, wersValueCode.length())
						+ ")";
			}
			vinGrpVO.getGenericFilter().add(genericFilter);
		}
	}

	private void setVinGrpVoForEOC(String filterDesc, VINGrpCriteriaVO vinGrpVO, LayoutBuffer layout, String operator) {
		String genericFilter;
		String startEndVals = "";
		if (!("".equalsIgnoreCase(layout.getString(4).trim()))
				&& !("".equalsIgnoreCase(layout.getString(5).trim()))) {
			startEndVals += "[" + Integer.parseInt(layout.getString(4).trim());
			startEndVals += "-" + Integer.parseInt(layout.getString(5).trim());
			startEndVals += "]";
		}
		genericFilter = filterDesc.trim() + ": " + startEndVals + " " + operator + "  "
				+ layout.getString(3).trim();
		vinGrpVO.getGenericFilter().add(genericFilter);
	}

	private void addProdDateForVinRange(String filterDesc, VINGrpCriteriaVO vinGrpVO, LayoutBuffer layout, String operator) {
		String genericFilter;
		if (StringUtils.isNotBlank(layout.getString(4).trim())
					&& (StringUtils.isNotBlank(layout.getString(5).trim()))
					&& !layout.getString(4).trim().equalsIgnoreCase(CommonConstants.INVALID_DATE)
					&& !layout.getString(5).trim().equalsIgnoreCase(CommonConstants.INVALID_DATE)) {
				genericFilter = " Between " + layout.getString(4).trim() + " - " + layout.getString(5).trim();
				LOGGER.info("Date Filter Between value {}",genericFilter);
				addProdDate(vinGrpVO, filterDesc,genericFilter);
			}
		if ((StringUtils.isBlank(layout.getString(4).trim()) || StringUtils.equals(layout.getString(4).trim(), CommonConstants.INVALID_DATE))
				&& StringUtils.isBlank(layout.getString(5).trim()) && "=".equals(operator)) {
			genericFilter = " ISNULL ";
			LOGGER.info("Date ISNULL FILTER value {}",genericFilter);
			addProdDate(vinGrpVO, filterDesc,genericFilter);
		}
		if ((StringUtils.isBlank(layout.getString(4).trim()) || StringUtils.equals(layout.getString(4).trim(),
				CommonConstants.INVALID_DATE))
				&& StringUtils.isBlank(layout.getString(5).trim()) && ">".equals(operator)) {
			genericFilter = " ISNOTNULL ";
			LOGGER.info("DATE ISNOTNULL FILTER {}",genericFilter);
			addProdDate(vinGrpVO, filterDesc,genericFilter);
		}
		if (">".equals(operator) && (StringUtils.isNotBlank(layout.getString(4).trim())
				&& !layout.getString(4).trim().equalsIgnoreCase(CommonConstants.INVALID_DATE))) {
			genericFilter = " > " + layout.getString(4).trim();
			LOGGER.info("GREATER THAN DATE FILTER {}", genericFilter);
			addProdDate(vinGrpVO, filterDesc, genericFilter);
		}
		if ((StringUtils.isNotBlank(layout.getString(4).trim())
						|| !layout.getString(4).trim().equalsIgnoreCase(CommonConstants.INVALID_DATE)) && "<".equals(operator)) {
			genericFilter = " < " + layout.getString(4).trim();
			LOGGER.info("LESS THAN DATE FILTER {}",genericFilter);
			addProdDate(vinGrpVO, filterDesc,genericFilter);
		}
		addProdDateBasedOnOperator(filterDesc, vinGrpVO, layout, operator);
	}

	private void addProdDateBasedOnOperator(String filterDesc, VINGrpCriteriaVO vinGrpVO, LayoutBuffer layout, String operator) {
		String genericFilter;
		if ("<=".equals(operator) && (StringUtils.isNotBlank(layout.getString(4).trim())
						|| !layout.getString(4).trim().equalsIgnoreCase(CommonConstants.INVALID_DATE))) {
			genericFilter = " <= " + layout.getString(4).trim();
			LOGGER.info("LESS THAN OR EQUAL TO  DATE FILTER {}",genericFilter);
			addProdDate(vinGrpVO, filterDesc,genericFilter);
		}
		if (">=".equals(operator) && (StringUtils.isNotBlank(layout.getString(4).trim())
				|| !layout.getString(4).trim().equalsIgnoreCase(CommonConstants.INVALID_DATE))) {
				genericFilter = " >= " + layout.getString(4).trim();
				LOGGER.info("GREATER THAN OR EQUAL TO DATE FILTER {}",genericFilter);
				addProdDate(vinGrpVO, filterDesc,genericFilter);
			}
		if ("=".equals(operator) && (StringUtils.isNotBlank(layout.getString(4).trim())
				&& !layout.getString(4).trim().equalsIgnoreCase(CommonConstants.INVALID_DATE))) {
			genericFilter = " = " + layout.getString(4).trim();
			LOGGER.info("EQUAL DATE FILTER {}", genericFilter);
			addProdDate(vinGrpVO, filterDesc, genericFilter);
		}
		if ("!=".equals(operator) && (StringUtils.isNotBlank(layout.getString(4).trim())
				|| !layout.getString(4).trim().equalsIgnoreCase(CommonConstants.INVALID_DATE))) {
			genericFilter = " != " + layout.getString(4).trim();
			LOGGER.info("NOT EQUAL DATE FILTER {}", genericFilter);
			addProdDate(vinGrpVO, filterDesc, genericFilter);
		}
	}

	private void validateAndAddProdDate(String filterDesc, VINGrpCriteriaVO vinGrpVO, LayoutBuffer layout) {
		String genericFilter;
		if (!("".equalsIgnoreCase(layout.getString(4).trim()))
				&& !("".equalsIgnoreCase(layout.getString(5).trim()))
				&& !layout.getString(4).trim().equalsIgnoreCase(CommonConstants.INVALID_DATE)
				&& !layout.getString(5).trim().equalsIgnoreCase(CommonConstants.INVALID_DATE)) {
			genericFilter = layout.getString(4).trim() + " TO " + layout.getString(5).trim();
			LOGGER.info("date filter value {}",genericFilter);
			addProdDate(vinGrpVO, filterDesc,genericFilter);
		}
		if (!("".equalsIgnoreCase(layout.getString(4).trim()))
				&& ("".equalsIgnoreCase(layout.getString(5).trim())
						|| layout.getString(5).trim().equalsIgnoreCase(CommonConstants.INVALID_DATE))) {
			genericFilter = " GREATER THAN OR EQUAL TO  " + layout.getString(4).trim();
			LOGGER.info("GREATER THAN OR EQUAL TO DATE FILTER {}",genericFilter);
			addProdDate(vinGrpVO, filterDesc,genericFilter);
		}
		if (!("".equalsIgnoreCase(layout.getString(5).trim()))
				&& ("".equalsIgnoreCase(layout.getString(4).trim())
						|| layout.getString(4).trim().equalsIgnoreCase(CommonConstants.INVALID_DATE))) {
			genericFilter = " LESS THAN OR EQUAL TO "
					+ layout.getString(5).trim();
			LOGGER.info("LESS THAN OR EQUAL TO  DATE FILTER {}",genericFilter);
			addProdDate(vinGrpVO, filterDesc,genericFilter);
		}
	}

	private VINGrpCriteriaVO getVinGrpCriteriaVO(TreeMap<String, VINGrpCriteriaVO> vinGroupMap, String vinGrpSeq, Integer vinGrpNum, boolean isExists, LayoutBuffer layout) {
		StringBuilder lastModifiedDate;
		VINGrpCriteriaVO vinGrpVO;
		if (!isExists) {
			vinGrpVO = new VINGrpCriteriaVO();
			vinGrpVO.setVinGroupSeqNum(Integer.parseInt(vinGrpSeq));
			vinGrpVO.setVinGroupLabel(layout.getString(13).trim());
			vinGrpVO.setVinGroupDesc(layout.getString(14).trim());
			vinGrpVO.setOtaIndicator(StringUtils.trimToEmpty(layout.getString(16)).isBlank() ? CommonConstants.FLAG_N : StringUtils.trimToEmpty(layout.getString(16)));
			vinGrpVO.setFhmIndication(StringUtils.trimToEmpty(layout.getString(17)).isBlank() ? CommonConstants.FLAG_N : StringUtils.trimToEmpty(layout.getString(17)));
			lastModifiedDate = new StringBuilder();

			if (!("".equalsIgnoreCase(layout.getString(9).trim()))) {
				lastModifiedDate.append(DateConvert.getInstance()
						.formatOutputDate(layout.getString(9).trim().substring(0, 10)));
				lastModifiedDate.append(" ");
				lastModifiedDate.append(
						layout.getString(9).trim().substring(11, 19).replace('.', ':'));
			}
			vinGrpVO.setLastModified(lastModifiedDate.toString());

			vinGrpVO.setLastModifiedBy(layout.getString(10).trim());
			if ("Y".equalsIgnoreCase(layout.getString(15).trim())) {
				vinGrpVO.setIsChecked(true);
			}
		} else {
			vinGrpVO = vinGroupMap.get(layout.getString(13).trim() + vinGrpNum);
		}
		return vinGrpVO;
	}

	private void setCriteriaVO(VINGrpCriteriaVO vinGrpVO, VINGrpCriteriaVO criteriaVO) {
		if (vinGrpVO != null) {
			if (vinGrpVO.getVinGroupSeqNum() > 0) {
				criteriaVO.setVinGroupSeqNum(vinGrpVO.getVinGroupSeqNum());
			}
			criteriaVO.setVinGroupSeqNum(vinGrpVO.getVinGroupSeqNum());
			criteriaVO.setVinGroupLabel(Objects.requireNonNullElse(vinGrpVO.getVinGroupLabel(), criteriaVO.getVinGroupLabel()));
			criteriaVO.setVinGroupDesc(Objects.requireNonNullElse(vinGrpVO.getVinGroupDesc(), criteriaVO.getVinGroupDesc()));
			criteriaVO.setLastModified(Objects.requireNonNullElse(vinGrpVO.getLastModified(), criteriaVO.getLastModified()));
			criteriaVO.setLastModifiedBy(Objects.requireNonNullElse(vinGrpVO.getLastModifiedBy(), criteriaVO.getLastModifiedBy()));
			criteriaVO.setOtaIndicator(Objects.requireNonNullElse(vinGrpVO.getOtaIndicator(), criteriaVO.getOtaIndicator()));
			criteriaVO.setFhmIndication(Objects.requireNonNullElse(vinGrpVO.getFhmIndication(), criteriaVO.getFhmIndication()));
			criteriaVO.setAssemblyPlantFilter(Objects.requireNonNullElse(vinGrpVO.getAssemblyPlantFilter(), criteriaVO.getAssemblyPlantFilter()));
			criteriaVO.setBrandFilter(Objects.requireNonNullElse(vinGrpVO.getBrandFilter(), criteriaVO.getBrandFilter()));
			criteriaVO.setModelYearFilter(Objects.requireNonNullElse(vinGrpVO.getModelYearFilter(), criteriaVO.getModelYearFilter()));
			criteriaVO.setModelYearOperator(Objects.requireNonNullElse(vinGrpVO.getModelYearOperator(), criteriaVO.getModelYearOperator()));
			criteriaVO.setVehicleLineFilter(Objects.requireNonNullElse(vinGrpVO.getVehicleLineFilter(), criteriaVO.getVehicleLineFilter()));
			criteriaVO.setGenericFilter(Objects.requireNonNullElse(vinGrpVO.getGenericFilter(), criteriaVO.getGenericFilter()));
			criteriaVO.setProductionDate(Objects.requireNonNullElse(vinGrpVO.getProductionDate(), criteriaVO.getProductionDate()));
		}
	}

	private String getFSA(String outPutFSA, Map.Entry<String, Object> entry, String outputFsa) {
		if (outputFsa.equals(entry.getKey())) {
			outPutFSA = (String) entry.getValue();
		}
		return outPutFSA;
	}

	private int setOutPutParms(int j, String[] outParms, Map.Entry<String, Object> entry) {
		if ("OUTPUT_PARM1".equals(entry.getKey())) {
			setOutParms(j, outParms, entry);
			j++;
		}
		if ("OUTPUT_PARM2".equals(entry.getKey())) {
			setOutParms(j, outParms, entry);
			j++;

		}

		if ("OUTPUT_PARM3".equals(entry.getKey())) {
			setOutParms(j, outParms, entry);
			j++;

		}
		if ("OUTPUT_PARM4".equals(entry.getKey())) {
			setOutParms(j, outParms, entry);
			j++;
		}

		if ("OUTPUT_PARM5".equals(entry.getKey())) {
			setOutParms(j, outParms, entry);
			j++;
		}

		if ("OUTPUT_PARM6".equals(entry.getKey())) {
			setOutParms(j, outParms, entry);
			j++;
		}
		if ("OUTPUT_PARM7".equals(entry.getKey())) {
			setOutParms(j, outParms, entry);
			j++;
		}

		if ("OUTPUT_PARM8".equals(entry.getKey())) {
			setOutParms(j, outParms, entry);
			j++;
		}
		if ("OUTPUT_PARM9".equals(entry.getKey())) {
			setOutParms(j, outParms, entry);
			j++;
		}
		if ("OUTPUT_PARM10".equals(entry.getKey())) {
			setOutParms(j, outParms, entry);
			j++;
		}
		if ("OUTPUT_PARM11".equals(entry.getKey())) {
			setOutParms(j, outParms, entry);
			j++;
		}
		if ("OUTPUT_PARM12".equals(entry.getKey())) {
			setOutParms(j, outParms, entry);
			j++;
		}
		if ("OUTPUT_PARM13".equals(entry.getKey())) {
			setOutParms(j, outParms, entry);
			j++;
		}

		if ("OUTPUT_PARM14".equals(entry.getKey())) {
			setOutParms(j, outParms, entry);
			j++;

		}
		if ("OUTPUT_PARM15".equals(entry.getKey())) {
			setOutParms(j, outParms, entry);
			j++;
		}
		return j;
	}

	private void setOutParms(int j, String[] outParms, Map.Entry<String, Object> entry) {
		String keyValue=(String) entry.getValue();
		if (keyValue != null) {
			outParms[j] = keyValue;
		}
	}


	private void addProdDate(VINGrpCriteriaVO vinGrpVO, String filterDesc, String genericFilter) {
		if(filterDesc.trim().equals(CommonConstants.PRODUCTION_DATE)) {
			vinGrpVO.getProductionDate().add(genericFilter);
		}else { 
		vinGrpVO.getGenericFilter().add(filterDesc.trim() + ":"+genericFilter);
		}		
	}
}
