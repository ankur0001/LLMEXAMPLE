package com.ford.gcamp.targeting.gridgcamp.gcamp;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ford.gcamp.targeting.gridgcamp.gcamp.entity.CriteriaSelectionDataId;
import com.ford.gcamp.targeting.gridgcamp.gcamp.entity.VehicleCriteriaSelectionData;

public interface VehicleCriteriaSelectionRepository extends JpaRepository<VehicleCriteriaSelectionData, CriteriaSelectionDataId> {

	public Optional<VehicleCriteriaSelectionData> findByGlobalFSANumberAndFilterCodeAndVehicleAttributeValue(int globalFSANumber, int filterCode,
			String vehicleCode);

	public List<VehicleCriteriaSelectionData> findAllByGlobalFSANumberAndFilterCodeAndVehicleAttributeValue(
			int globalFSANumber, int i, String trimToEmpty);

    boolean existsByGlobalFSANumberAndSupplementCode(int globalFSANumber, String supplementCode);

}
