package com.ford.gcamp.targeting.properties;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class HubPropertiesResponse {

	@Size(min = 1, max = 2)
	@Pattern(regexp = "^[A-Z\\*\\s]{1,2}$")
	@Schema(types = {"string", "null"},example = "NA", description = "Hub Code")
	private String hub;
}

