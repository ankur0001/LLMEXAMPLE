package com.ford.gcamp.targeting.gsar.entity;

import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "GCAMP_SNAP", schema = "APP_SERVER")
public class GcampSnapEntity {
	
	@Id
	@Column(name = "RESULT_ID")
	Integer resultId;
	
	@Column(name = "U_ID")
	Long uniqueId;
	
	@Column(name = "RES_ID")
	Long resId;

	@Column(name = "USER_ID")
	String userId;
	
	@Column(name = "REQ_ID")
	Integer reqId;

	@Column(name = "REQ_NAME")
	String reqName;
	
	@Column(name = "REQ_DESC")
	String reqDescription;
	
	@Column(name = "ROW_CNT")
	Integer rowCount;
	
	@Column(name = "RPT_SEL")
	String rptSel;
	
	@Column(name = "RPT_OPT")
	String rptOption;
	
	@Column(name = "RPT_CRT")
	String rptCrt;

	@Column(name = "REQ_RUN_DT")
	@Setter(AccessLevel.NONE)
	@Getter(AccessLevel.NONE)
	Date runDate;
	
	public Date getRunDate() {
		if (runDate!= null) {
			return new Date(runDate.getTime());
		} else {
			return null;
		}
	}
	public void setRunDate(Date runDate) {
		if (runDate == null) {
			this.runDate = null;
		} else {
			this.runDate = new Date(runDate.getTime()); 
		}
	}

}
