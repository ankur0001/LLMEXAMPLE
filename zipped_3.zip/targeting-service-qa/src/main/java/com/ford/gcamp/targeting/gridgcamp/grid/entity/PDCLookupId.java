package com.ford.gcamp.targeting.gridgcamp.grid.entity;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class PDCLookupId implements Serializable {
	
	private static final long serialVersionUID = 1L;

	private String reportId;
	private String countryName;
	private String pdcType;
	private String pdcCode;
	private String vinGroup;
	
}
