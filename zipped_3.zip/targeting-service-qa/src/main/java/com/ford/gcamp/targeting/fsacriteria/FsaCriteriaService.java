package com.ford.gcamp.targeting.fsacriteria;

import com.ford.gcamp.targeting.core.exception.ResourceNotFoundException;
import com.ford.gcamp.targeting.fsacriteria.api.DynamicQueryMappingReq;
import com.ford.gcamp.targeting.fsacriteria.api.DynamicQueryResponse;


import com.ford.gcamp.targeting.common.api.ResponseStatusDTO;
import com.ford.gcamp.targeting.fsacriteria.api.FsaCriteriaEditVO;
import com.ford.gcamp.targeting.fsacriteria.api.FsaCriteriaParam;
import com.ford.gcamp.targeting.fsacriteria.api.FsaCriteriaSaveParam;
import com.ford.gcamp.targeting.fsacriteria.api.LoadFsaResponseDTO;

public interface FsaCriteriaService {
	
	FsaCriteriaEditVO modify(FsaCriteriaParam criteriaParam);
	FsaCriteriaEditVO saveFsaCriteria(FsaCriteriaSaveParam fsaCriteriaModifySaveParam) throws ResourceNotFoundException;
	DynamicQueryResponse getFsaWersWersValue(DynamicQueryMappingReq dynamicMappingRequest);
	DynamicQueryResponse getFsaBrandModelVehPlant(DynamicQueryMappingReq dynamicMappingRequest);
	DynamicQueryResponse getFsaWersDetail(DynamicQueryMappingReq dynamicMappingRequest);
	ResponseStatusDTO validateAssemblyPlantSelect(DynamicQueryMappingReq dynamicMappingRequest);
	public LoadFsaResponseDTO getFSACriteriaLookupData();

}