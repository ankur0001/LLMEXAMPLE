package com.ford.gcamp.targeting.fsacriteria.api;

import java.util.List;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import org.springframework.stereotype.Component;

import com.ford.gcamp.targeting.common.api.ResponseStatusDTO;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

@Component
@EqualsAndHashCode(callSuper=false)
@Getter
@Setter
public class LoadFsaResponseDTO extends ResponseStatusDTO{

	@Size(min = 0, max = 250, message = "modelYear List")
	private List<@Valid ModelYearList> modelYear;

	@Size(min = 0, max = 250, message = "assemblyPlantList List")
	private List<@Valid AssemblyPlantList> assemblyPlantList;

	@Size(min = 0, max = 250, message = "vehicleTypeList List")
	private List<@Valid VehicleTypeList> vehicleTypeList;

	@Size(min = 0, max = 250, message = "vehicleBrandLists List")
	private List<@Valid VehicleBrandList> vehicleBrandLists;

	@Size(min = 0, max = 250, message = "gcpFilterList List")
	private List<@Valid GCPFilterList> gcpFilterList;

	@Size(min = 0, max = 250, message = "attributeGroupingLists List")
	private List<@Valid AttributeGroupingList> attributeGroupingLists;
	
}
