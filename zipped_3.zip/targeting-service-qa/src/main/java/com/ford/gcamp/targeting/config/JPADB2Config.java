package com.ford.gcamp.targeting.config;


import java.util.Properties;

import javax.sql.DataSource;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.dao.annotation.PersistenceExceptionTranslationPostProcessor;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.JpaVendorAdapter;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@Configuration
@EnableJpaRepositories(basePackages = {"com.ford.gcamp.targeting.gridgcamp","com.ford.gcamp.targeting.common","com.ford.gcamp.targeting.setupfsa.dependentfsa","com.ford.gcamp.targeting.fsacriteria"}, entityManagerFactoryRef = "jpaDb2EntityManager", transactionManagerRef = "jpaDb2TransactionManager")
@EnableTransactionManagement
public class JPADB2Config {
	
	private static final String DB2_DIALECT ="org.hibernate.dialect.DB2400Dialect";
	
	private Environment env;
	
	@Value("${DB_URL}")
    private String dbUrl;
	
	@Value("${DB_USERNAME}")
    private String dbUserName;
	
	@Value("${DB_PASSWORD}")
    private String dbPassword;
	
	@Value("${DB_OWNER}")
	private String ownerId;

	public JPADB2Config(Environment env) {
		super();
		this.env = env;
	}

	@Bean(name="db2DataSource")
	public DataSource dataSource() {
		DriverManagerDataSource dataSource = new DriverManagerDataSource();
		String driverClassName = env.getProperty("spring.datasource.db2.driver-class-name");
		dataSource.setDriverClassName(StringUtils.trimToEmpty(driverClassName));
		dataSource.setUrl(dbUrl);
		dataSource.setUsername(dbUserName);
		dataSource.setPassword(dbPassword);
		return dataSource;
	}
	
	@Bean(name="jpaDb2EntityManager")
	public LocalContainerEntityManagerFactoryBean db2EntityManagerFactory(@Qualifier("db2DataSource") DataSource ds) {
		LocalContainerEntityManagerFactoryBean em = new LocalContainerEntityManagerFactoryBean();
		em.setDataSource(ds);
		em.setPackagesToScan("com.ford.gcamp.targeting");
		JpaVendorAdapter vendorAdapter = new HibernateJpaVendorAdapter();
		em.setJpaVendorAdapter(vendorAdapter);
		em.setJpaProperties(getJpaProperties());
		return em;
	}
	
	
	private Properties getJpaProperties() {
		Properties properties = new Properties();
		properties.setProperty("spring.jpa.database", "db2");
		properties.setProperty("spring.jpa.database-platform", DB2_DIALECT);
		properties.setProperty("spring.jpa.properties.hibernate.dialect", DB2_DIALECT);
		properties.setProperty("hibernate.dialect", DB2_DIALECT);
		properties.setProperty("spring.jpa.properties.hibernate.show_sql", "true");
		properties.setProperty("hibernate.show_sql", "true");
		properties.setProperty("spring.jpa.hibernate.ddl-auto", "true");
		properties.setProperty("hibernate.default_schema", ownerId.replace(".", StringUtils.EMPTY));
		return properties;
	}
	
	@Bean(name = "jpaDb2TransactionManager")
	public PlatformTransactionManager accountTransactionManager(@Qualifier("db2DataSource") DataSource ds) {
	    JpaTransactionManager tm = new JpaTransactionManager();
	    tm.setEntityManagerFactory(db2EntityManagerFactory(ds).getObject());
	    tm.setDataSource(ds);
	    return tm;
	}

	@Bean
	public PersistenceExceptionTranslationPostProcessor exceptionTranslation() {
		return new PersistenceExceptionTranslationPostProcessor();
	}

}
