package com.ford.gcamp.targeting.fsacriteria.api;

import com.ford.gcamp.targeting.common.api.ResponseStatusDTO;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.*;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;


@EqualsAndHashCode(callSuper=false)
@Getter
@Setter
public class FsaDeleteResponseDTO extends ResponseStatusDTO{


	@Size(min = 0, max = 8)
	@Pattern(regexp = "^[a-zA-Z\\d]*$")
	@Schema(example = "CS019G0S", description = "Job Name")
	private String jobName;

	}
