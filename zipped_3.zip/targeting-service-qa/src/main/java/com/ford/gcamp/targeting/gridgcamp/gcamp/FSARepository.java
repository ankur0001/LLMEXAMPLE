package com.ford.gcamp.targeting.gridgcamp.gcamp;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ford.gcamp.targeting.gridgcamp.gcamp.entity.FSAData;

@Repository
public interface FSARepository extends JpaRepository<FSAData, Integer> {

	public FSAData findTopByOrderByGlobalFSANumberDesc();

	public FSAData findByGlobalFSANumber(int globalFSANumber);

}
