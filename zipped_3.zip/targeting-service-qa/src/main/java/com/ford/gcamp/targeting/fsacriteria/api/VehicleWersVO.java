package com.ford.gcamp.targeting.fsacriteria.api;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class VehicleWersVO extends FsaVehicleCommonVO {

	@Schema(example = " ", description = "wersFilterCode")
	@Size(min=0, max = 10)
	@Pattern(regexp ="^|[A-Za-z\\d\\s_.,'()\"\\=\\<>]*$")
	private String wersFilterCode;

	@Min(0)
	@Max(99999999)
	@Schema(type= "integer",example = " ", description = "mappedFilterCode")
	private Integer mappedFilterCode;

	@Schema(example = " ", description = "wersFilterDesc")
	@Size(min=0, max = 250)
	@Pattern(regexp ="^|[A-Za-z\\d\\s_.,'()\"\\=\\<>\\#\\&/*+\\-]*$")
	private String wersFilterDesc;

	@Schema(example = " ", description = "wersOperator")
	@Size(min=0, max = 2)
	@Pattern(regexp ="^|[A-Za-z\\d\\s_.,'()\"\\=\\<>|\\!]*$")
	private String wersOperator;

	@Schema(example = " ", description = "wersValueCode")
	@Size(min=0, max = 10)
	@Pattern(regexp ="^|[A-Za-z\\d\\s_.,'()\"\\=\\<>]*$")
	private String wersValueCode;

	@Schema(example = " ", description = "wersOperator")
	@Size(min=0, max = 250)
	@Pattern(regexp ="^|[A-Za-z\\d\\s_.,'()\"\\=\\<>/\\#\\&*+:;\\-]*$")
	private String wersValueDesc;
	
	
}