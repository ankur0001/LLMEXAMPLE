package com.ford.gcamp.targeting.reports.batch.api;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class VehLineByPlant extends GenericReportData {

    /**
     * Contains the plant
     */
    private String plant;

    /**
     * Contains the brand
     */
    private String brand;

    /**
     * Contains the vehicle line
     */
    private String vehLine;

    /**
     * Contains the model year
     */
    private String modelYear;

    /**
     * Contains the count for a particular set of keys.
     */
    private int count;

}
