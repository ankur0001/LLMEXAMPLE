package com.ford.gcamp.targeting.frozenvin.api;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class HubList {

	@Size(min = 1, max = 2)
	@Pattern(regexp = "^[a-zA-Z\\*]*$")
	@Schema(example = "NA", description = "Hub code")
	private  String hubCode;


	@Size(min = 1, max = 30)
	@Pattern(regexp = "^[a-zA-Z\\*\\d]*$")
	@Schema(example = "NA", description = "Hub code")
	private String hubDesc;

	@Size(min = 0, max = 3)
	@Pattern(regexp = "^[a-zA-Z\\*\\s]*$")
	@Schema(example = "USA", description = "Country ISO Code")
	private String countIsoC;

	@Size(min = 0, max = 20)
	@Pattern(regexp = "^[a-zA-Z\\*\\s]*$")
	@Schema(example = "United States", description = "Count Name")
	private String countName;

	@Size(min = 0, max = 10)
	@Pattern(regexp = "^[\\d]*$")
	@Schema(example = "98", description = "Param Five")
	private String paramFive;

	@Size(min = 0, max = 10)
	@Pattern(regexp = "^[\\d]*$")
	@Schema(example = "98", description = "Param Five")
	private String frznByC;

	@Size(min = 0, max = 10)
	@Pattern(regexp = "^[\\d]*$")
	@Schema(example = "98", description = "Param sev")
	private String parmSev;

	@Size(min = 0, max = 8)
	@Pattern(regexp = "^[a-zA-Z\\d\\-]*$")
	@Schema(example = "tdharti", description = "CDSID")
	private String updateIndC;

	@Size(min = 0, max = 10)
	@Pattern(regexp = "^[\\d]*$")
	@Schema(example = "98", description = "Param Five")
	private String paramNine;
}
