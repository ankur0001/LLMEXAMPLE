package com.ford.gcamp.targeting.common.api;

import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.NoArgsConstructor;

@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ApiError {
	@JsonProperty("message")
	@Size(min = 1, max = 500) 
	@Pattern(regexp ="^[A-Za-z\\d]*$")
	private String message;

}