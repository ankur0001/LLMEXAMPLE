package com.ford.gcamp.targeting.gridgcamp.gcamp.entity;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import jakarta.persistence.Table;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@Embeddable
@Table(name="SGCPD26_GRID_SFT_CRIT")
public class SoftwareCriteriaId implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Column(name = "GCPF59_GRID_IMPL_D")
	private int implementationId;
	@Column(name = "GCPF59_GRID_YR_D")
	private int gridYearId;
	@Column(name = "GCPF59_GRID_SEQ_R")
	private int gridSequence;
	@Column(name = "GCPF59_CRIT_R")
	private int criteriaNumber;
	@Column(name = "GCPF59_GRID_VERSION_R")
	private int version;
	@Column(name = "GCPF59_GRID_SUPPL_C")
	private String supplementId;
	@Column(name = "GCPD26_SEQ_R")
	private int sequenceId;
	
	public SoftwareCriteriaId(GridCriteriaId gridCriteriaId, int criteriaSeqId, int seqId) {
		super();
		this.gridYearId = gridCriteriaId.getGridYearId();
		this.gridSequence = gridCriteriaId.getGridSequence();
		this.implementationId = gridCriteriaId.getImplementationId();
		this.version = gridCriteriaId.getVersion();
		this.supplementId = gridCriteriaId.getSupplementId();
		this.criteriaNumber = criteriaSeqId;
		this.sequenceId = seqId;
	}
}
