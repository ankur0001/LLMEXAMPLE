package com.ford.gcamp.targeting.regionalfilters.api;

import java.util.List;
import com.ford.gcamp.targeting.common.api.CommonResponse;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RegionalAuditReportResponse extends CommonResponse {

	@Size(min = 0, max = 250, message = "regionalAuditReport List")
	private List<@Valid RegionalAuditReport> regionalAuditReport;

}
