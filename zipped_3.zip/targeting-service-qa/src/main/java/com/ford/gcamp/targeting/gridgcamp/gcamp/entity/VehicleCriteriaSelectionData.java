package com.ford.gcamp.targeting.gridgcamp.gcamp.entity;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.IdClass;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Entity
@IdClass(CriteriaSelectionDataId.class)
@Table(name = "SGCPD20_SLCN_CRIT")
public class VehicleCriteriaSelectionData implements Serializable{

	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name = "GCPA15_GLOBL_FSA_R")
	private int globalFSANumber;
	
	@Id
	@Column(name = "GCPD02_FILTER_C")
	private int filterCode;
	
	@Id
	@Column(name = "GCPD20_SLCTN_SEQ_R")
	private int selectionSequenceNumber;
	
	
	@Column(name = "GCPD20_VINGRPSEQ_R")
	private int vinGroupSequenceNuber;
	
	@Column(name = "GCPD20_VHATR_VAL_X")
	private String vehicleAttributeValue;

    @Column(name = "GCPA09_SUPPL_C")
    private String supplementCode;
}
