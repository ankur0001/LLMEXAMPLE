package com.ford.gcamp.targeting.reports.batch.api;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class CountryByPlant extends GenericReportData {

    private String countryName;

    private String plantName;

    private int count;

}
