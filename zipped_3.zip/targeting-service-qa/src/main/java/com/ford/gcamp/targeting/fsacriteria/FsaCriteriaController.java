package com.ford.gcamp.targeting.fsacriteria;

import com.ford.aps.core.exception.ApsClientException;
import com.ford.cloudnative.base.api.StandardErrorResponse;
import com.ford.gcamp.targeting.common.api.CommonErrorResponse;
import com.ford.gcamp.targeting.core.exception.ResourceNotFoundException;
import com.ford.gcamp.targeting.supplement.api.SupplementResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import jakarta.validation.Valid;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.WebRequest;

import com.ford.gcamp.targeting.common.api.ResponseStatusDTO;
import com.ford.gcamp.targeting.fsacriteria.api.DynamicQueryMappingReq;
import com.ford.gcamp.targeting.fsacriteria.api.DynamicQueryResponse;
import com.ford.gcamp.targeting.fsacriteria.api.FsaCriteriaEditVO;
import com.ford.gcamp.targeting.fsacriteria.api.FsaCriteriaParam;
import com.ford.gcamp.targeting.fsacriteria.api.FsaCriteriaSaveParam;
import com.ford.gcamp.targeting.logging.LogExecutionTime;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping(path = "/api/v1/targeting/fsaCriteria")
@Validated
public class FsaCriteriaController {
	    
    @Autowired
    private FsaCriteriaService fsaCriteriaService;
    
    @Autowired
    private FsaCriteriaFilterService fsaCriteriaFilterService;
    

    @PostMapping(value ="/modify")
    @PreAuthorize("@authorizeService.isAuthorized('GCAMP:addModifyFSACriteria:loadWithCriteria','execute')")
	@Operation(summary = "modify" , security = {
			@SecurityRequirement(name = "ADFS"),
			@SecurityRequirement(name = "AzureAD")
	})
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Validate Token request fetched successfully",content = {
			@Content(mediaType = "application/problem+json",schema = @Schema(implementation = FsaCriteriaEditVO.class))}),
			@ApiResponse(responseCode = "400", description = "Bad Request, missing required fields"),
			@ApiResponse(responseCode = "401", description = "Unauthorized"),
			@ApiResponse(responseCode = "403", description = "Forbidden"),
			@ApiResponse(responseCode = "404", description = "Not Found"),
			@ApiResponse(responseCode = "405", description = "Invalid Method type"),
			@ApiResponse(responseCode = "412", description = "Precondition Failed", content = @Content(schema = @Schema(implementation = CommonErrorResponse.class))),
			@ApiResponse(responseCode = "415", description = "Unsupported Media Type"),
			@ApiResponse(responseCode = "428", description = "Bad Request, missing required fields"),
			@ApiResponse(responseCode = "429", description = "Too many bad request"),
			@ApiResponse(responseCode = "500", description = "Internal Server Error"),
			@ApiResponse(responseCode = "default", description = "All Errors", content = @Content(schema = @Schema(implementation = CommonErrorResponse.class)))
	})
    @LogExecutionTime
	public @ResponseBody ResponseEntity<FsaCriteriaEditVO> modify(@RequestBody @Valid FsaCriteriaParam fsaCriteriaParam) {
    	FsaCriteriaEditVO response =  fsaCriteriaService.modify(fsaCriteriaParam);
        return ResponseEntity.ok(response);

	}
    
    @PostMapping(value ="/saveFsa")
    @PreAuthorize("@authorizeService.isAuthorized('GCAMP:addModifyFSACriteria:SAVE','execute')")
	@Operation(summary = "save Fsa" , security = {
			@SecurityRequirement(name = "ADFS"),
			@SecurityRequirement(name = "AzureAD")
	})
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Validate Token request fetched successfully",content = {
					@Content(mediaType = "application/problem+json",schema = @Schema(implementation = FsaCriteriaEditVO.class))}),
			@ApiResponse(responseCode = "400", description = "Bad Request, missing required fields"),
			@ApiResponse(responseCode = "401", description = "Unauthorized"),
			@ApiResponse(responseCode = "403", description = "Forbidden"),
			@ApiResponse(responseCode = "404", description = "Not Found"),
			@ApiResponse(responseCode = "405", description = "Invalid Method type"),
			@ApiResponse(responseCode = "412", description = "Precondition Failed", content = @Content(schema = @Schema(implementation = CommonErrorResponse.class))),
			@ApiResponse(responseCode = "415", description = "Unsupported Media Type"),
			@ApiResponse(responseCode = "428", description = "Bad Request, missing required fields"),
			@ApiResponse(responseCode = "429", description = "Too many bad request"),
			@ApiResponse(responseCode = "500", description = "Internal Server Error"),
			@ApiResponse(responseCode = "default", description = "All Errors", content = @Content(schema = @Schema(implementation = CommonErrorResponse.class)))
	})
    @LogExecutionTime
   	public @ResponseBody ResponseEntity<FsaCriteriaEditVO> saveFsa(@RequestBody @Valid FsaCriteriaSaveParam fsaCriteriaModifySaveParam) throws ResourceNotFoundException {
       	FsaCriteriaEditVO response =  fsaCriteriaService.saveFsaCriteria(fsaCriteriaModifySaveParam);
        return ResponseEntity.ok(response);

   	}
    
    @PostMapping(value ="/getFsaCriteriaDetails")
	@Operation(summary = "Get Fsa Criteria" , security = {
			@SecurityRequirement(name = "ADFS"),
			@SecurityRequirement(name = "AzureAD")
	})
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Validate Token request fetched successfully",
					content = @Content(schema = @Schema(implementation = DynamicQueryResponse.class))),
			@ApiResponse(responseCode = "400", description = "Bad Request, missing required fields"),
			@ApiResponse(responseCode = "401", description = "Unauthorized"),
			@ApiResponse(responseCode = "403", description = "Forbidden"),
			@ApiResponse(responseCode = "404", description = "Not Found"),
			@ApiResponse(responseCode = "405", description = "Invalid Method type"),
			@ApiResponse(responseCode = "412", description = "Precondition Failed", content = @Content(schema = @Schema(implementation = CommonErrorResponse.class))),
			@ApiResponse(responseCode = "415", description = "Unsupported Media Type"),
			@ApiResponse(responseCode = "428", description = "Bad Request, missing required fields"),
			@ApiResponse(responseCode = "429", description = "Too many bad request"),
			@ApiResponse(responseCode = "500", description = "Internal Server Error"),
			@ApiResponse(responseCode = "default", description = "All Errors", content = @Content(schema = @Schema(implementation = CommonErrorResponse.class)))
	})
    @LogExecutionTime
	public ResponseEntity<DynamicQueryResponse> getFsaCriteriaDetails(
			@RequestBody @Valid final DynamicQueryMappingReq dynamicMappingRequest) {
    	DynamicQueryResponse dynamicQueryResponse = fsaCriteriaFilterService.getFsaDetails(dynamicMappingRequest);
    	return ResponseEntity.ok(dynamicQueryResponse);

   	}
    
    @PostMapping(value ="/getFsaBrandModelVehPlant")
    @PreAuthorize("@authorizeService.isAuthorized('GCAMP:addModifyFSACriteria:loadWithCriteria','execute')")
	@Operation(summary = "Get Fsa Brand Model Veh Plant" , security = {
			@SecurityRequirement(name = "ADFS"),
			@SecurityRequirement(name = "AzureAD")
	})
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Validate Token request fetched successfully",
					content = @Content(schema = @Schema(implementation = DynamicQueryResponse.class))),
			@ApiResponse(responseCode = "400", description = "Bad Request, missing required fields"),
			@ApiResponse(responseCode = "401", description = "Unauthorized"),
			@ApiResponse(responseCode = "403", description = "Forbidden"),
			@ApiResponse(responseCode = "404", description = "Not Found"),
			@ApiResponse(responseCode = "405", description = "Invalid Method type"),
			@ApiResponse(responseCode = "412", description = "Precondition Failed", content = @Content(schema = @Schema(implementation = CommonErrorResponse.class))),
			@ApiResponse(responseCode = "415", description = "Unsupported Media Type"),
			@ApiResponse(responseCode = "428", description = "Bad Request, missing required fields"),
			@ApiResponse(responseCode = "429", description = "Too many bad request"),
			@ApiResponse(responseCode = "500", description = "Internal Server Error"),
			@ApiResponse(responseCode = "default", description = "All Errors", content = @Content(schema = @Schema(implementation = CommonErrorResponse.class)))
			})
    @LogExecutionTime
	public ResponseEntity<DynamicQueryResponse> getFsaBrandModelVehPlant(
			@RequestBody @Valid final DynamicQueryMappingReq dynamicMappingRequest) {
    	DynamicQueryResponse dynamicQueryResponse = fsaCriteriaService.getFsaBrandModelVehPlant(dynamicMappingRequest);
    	return ResponseEntity.ok(dynamicQueryResponse);

   	}
    
    @PostMapping(value ="/validateAssemblyPlantSelect")
    @PreAuthorize("@authorizeService.isAuthorized('GCAMP:addModifyFSACriteria:loadWithCriteria','execute')")
	@Operation(summary = "Validate Assembly Plant Select" , security = {
			@SecurityRequirement(name = "ADFS"),
			@SecurityRequirement(name = "AzureAD")
	})
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Validate Token request fetched successfully",
					content = @Content(schema = @Schema(implementation = ResponseStatusDTO.class))),
			@ApiResponse(responseCode = "default", description = "All Errors", content = @Content(schema = @Schema(implementation = CommonErrorResponse.class)))
	})
    @LogExecutionTime
	public ResponseEntity<ResponseStatusDTO> validateAssemblyPlantSelect(
			@RequestBody @Valid final DynamicQueryMappingReq dynamicMappingRequest) {
    	ResponseStatusDTO responseStatusDTO = fsaCriteriaService.validateAssemblyPlantSelect(dynamicMappingRequest);
    	return ResponseEntity.ok(responseStatusDTO);

   	}
    
    @PostMapping(value ="/getFsaWers")
    @PreAuthorize("@authorizeService.isAuthorized('GCAMP:addModifyFSACriteria:loadWithCriteria','execute')")
	@Operation(summary = "Get Fsa Wers" , security = {
			@SecurityRequirement(name = "ADFS"),
			@SecurityRequirement(name = "AzureAD")
	})
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Validate Token request fetched successfully",
					content = @Content(schema = @Schema(implementation = DynamicQueryResponse.class))),
			@ApiResponse(responseCode = "400", description = "Bad Request, missing required fields"),
			@ApiResponse(responseCode = "401", description = "Unauthorized"),
			@ApiResponse(responseCode = "403", description = "Forbidden"),
			@ApiResponse(responseCode = "404", description = "Not Found"),
			@ApiResponse(responseCode = "405", description = "Invalid Method type"),
			@ApiResponse(responseCode = "412", description = "Precondition Failed", content = @Content(schema = @Schema(implementation = CommonErrorResponse.class))),
			@ApiResponse(responseCode = "415", description = "Unsupported Media Type"),
			@ApiResponse(responseCode = "428", description = "Bad Request, missing required fields"),
			@ApiResponse(responseCode = "429", description = "Too many bad request"),
			@ApiResponse(responseCode = "500", description = "Internal Server Error"),
			@ApiResponse(responseCode = "default", description = "All Errors", content = @Content(schema = @Schema(implementation = CommonErrorResponse.class)))
	})
    @LogExecutionTime
	public ResponseEntity<DynamicQueryResponse> getFsaWers(
			@RequestBody @Valid final DynamicQueryMappingReq dynamicMappingRequest) {
    	DynamicQueryResponse dynamicQueryResponse = null;
    	setRequestForAllOption(dynamicMappingRequest);
    	if(StringUtils.isNotBlank(dynamicMappingRequest.getWers())) {
    		dynamicQueryResponse = fsaCriteriaService.getFsaWersWersValue(dynamicMappingRequest);
    	} else {
    		dynamicQueryResponse = fsaCriteriaService.getFsaWersDetail(dynamicMappingRequest);
    	}
    	return ResponseEntity.ok(dynamicQueryResponse);

   	}
    
    @PostMapping(value ="/loadWers")
    @PreAuthorize("@authorizeService.isAuthorized('GCAMP:addModifyFSACriteria:loadWithCriteria','execute')")
	@Operation(summary = "Load Wers" , security = {
			@SecurityRequirement(name = "ADFS"),
			@SecurityRequirement(name = "AzureAD")
	})
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Validate Token request fetched successfully",
					content = @Content(schema = @Schema(implementation = DynamicQueryResponse.class))),
			@ApiResponse(responseCode = "400", description = "Bad Request, missing required fields"),
			@ApiResponse(responseCode = "401", description = "Unauthorized"),
			@ApiResponse(responseCode = "403", description = "Forbidden"),
			@ApiResponse(responseCode = "404", description = "Not Found"),
			@ApiResponse(responseCode = "405", description = "Invalid Method type"),
			@ApiResponse(responseCode = "412", description = "Precondition Failed", content = @Content(schema = @Schema(implementation = CommonErrorResponse.class))),
			@ApiResponse(responseCode = "415", description = "Unsupported Media Type"),
			@ApiResponse(responseCode = "428", description = "Bad Request, missing required fields"),
			@ApiResponse(responseCode = "429", description = "Too many bad request"),
			@ApiResponse(responseCode = "500", description = "Internal Server Error"),
			@ApiResponse(responseCode = "default", description = "All Errors", content = @Content(schema = @Schema(implementation = CommonErrorResponse.class)))
	})
    @LogExecutionTime
	public ResponseEntity<DynamicQueryResponse> loadWers(
			@RequestBody @Valid final DynamicQueryMappingReq dynamicMappingRequest) {
    	setRequestForAllOption(dynamicMappingRequest);
    	DynamicQueryResponse dynamicQueryResponse = fsaCriteriaService.getFsaWersDetail(dynamicMappingRequest);
    	return ResponseEntity.ok(dynamicQueryResponse);

   	}
    
    @ExceptionHandler({AccessDeniedException.class})
    public ResponseEntity<Object> handleAccessDeniedException(Exception ex, WebRequest request) {
        if (ex.getMessage().toLowerCase().indexOf("access is denied") > -1) {
            return new ResponseEntity<>("You are not Authorized by APS to access the Resource", new HttpHeaders(), HttpStatus.FORBIDDEN);
        }
        return new ResponseEntity<>(ex.getMessage(), new HttpHeaders(), HttpStatus.INTERNAL_SERVER_ERROR);
    }
    
    private void setRequestForAllOption(DynamicQueryMappingReq dynamicMappingRequest) {
		if(StringUtils.equalsAnyIgnoreCase(dynamicMappingRequest.getModelYear(), "ALL")) {
			dynamicMappingRequest.setModelYear("");
		}
		if(StringUtils.equalsAnyIgnoreCase(dynamicMappingRequest.getVehicleLine(), "ALL")) {
			dynamicMappingRequest.setVehicleLine("");
		}
		if(StringUtils.equalsAnyIgnoreCase(dynamicMappingRequest.getBrand(), "ALL")) {
			dynamicMappingRequest.setBrand("");
		}
	}
    

}