package com.ford.gcamp.targeting.reports.batch;

import java.sql.SQLException;
import java.sql.SQLTransientConnectionException;

import com.ibm.db2.jcc.am.SqlException;
import org.apache.commons.lang3.StringUtils;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.ford.gcamp.targeting.reports.batch.common.ReportCodeConstants;
import com.ford.gcamp.targeting.reports.batch.common.ReportConstants;
import com.ford.gcamp.targeting.reports.batch.exception.GCAMPReportException;
import com.ford.gcamp.targeting.reports.batch.exception.ReportExceptionHandler;
import com.ford.gcamp.targeting.reports.batch.writer.TargetingCompositeReportWriterTasklet;
import com.ibm.db2.jcc.am.SqlSyntaxErrorException;
import org.springframework.transaction.PlatformTransactionManager;

@Component
@SuppressWarnings("unchecked")
public class ReportStepFactory {

	private final BeanFactory beanFactory;


	private JobRepository jobRepository;

	private ReportExceptionHandler exceptionHandler;

	private TargetingCompositeReportWriterTasklet compositeWriterTasklet;

	private PlatformTransactionManager platformTransactionManager;

	private TargetingReportRepo targetingReportRepo;

	private ReportStepResultListener stepListener;

	public ReportStepFactory(BeanFactory beanFactory,
							 ReportExceptionHandler exceptionHandler, TargetingCompositeReportWriterTasklet compositeWriterTasklet,
							 TargetingReportRepo targetingReportRepo, ReportStepResultListener stepListener, JobRepository jobRepository, @Qualifier("jpaDb2TransactionManager") PlatformTransactionManager platformTransactionManager) {
		this.beanFactory = beanFactory;
		this.exceptionHandler = exceptionHandler;
		this.compositeWriterTasklet = compositeWriterTasklet;
		this.stepListener = stepListener;
		this.targetingReportRepo = targetingReportRepo;
		this.jobRepository = jobRepository;
		this.platformTransactionManager = platformTransactionManager;
	}

	public Step getStep(String reportCode, String supplementCode) throws GCAMPReportException {

		if (ReportCodeConstants.T20.equalsIgnoreCase(reportCode)) {
			return new StepBuilder(reportCode,jobRepository).tasklet(compositeWriterTasklet,platformTransactionManager)
					.exceptionHandler(exceptionHandler).listener(stepListener).build();
		} else if (ReportCodeConstants.REPORT_CODE_SQL_ID_MAP.containsKey(reportCode)
				|| ReportCodeConstants.IAD.equalsIgnoreCase(reportCode)) {
			return getTargetingReportStep(reportCode, supplementCode);
		} else if (ReportCodeConstants.EXCEPTION_REPORTS.contains(reportCode)) {
			return getExceptionReportStep(reportCode);
		} else if (StringUtils.startsWithIgnoreCase(reportCode, "W")) {
			return getWERSReportStep(reportCode, supplementCode);
		} else {
			throw new GCAMPReportException(
					"The Step can't be created. The reader and writer are not available for the report code : "
							+ reportCode);
		}

	}

	private String getWERSDescription(String wersCode) {
		return StringUtils.trimToEmpty(targetingReportRepo.getWERSDescription(wersCode.substring(1)));
	}

	private Step getTargetingReportStep(String reportCode, String supplementCode) {
		String beanName = reportCode + ReportConstants.READER_NAME_SUFFIX;
		if (ReportConstants.ALL_POPULATION.equalsIgnoreCase(supplementCode)) {
			beanName = reportCode + ReportConstants.ALL_POPULATION + ReportConstants.READER_NAME_SUFFIX;
		}
		return getReportStep(reportCode, beanName);
	}

	private Step getExceptionReportStep(String reportCode) {
		String beanName = reportCode + ReportConstants.READER_NAME_SUFFIX;
		return getReportStep(reportCode, beanName);
	}

	private Step getReportStep(String reportCode, String beanName) {
		return new StepBuilder(reportCode,jobRepository).chunk(ReportConstants.FETCH_SIZE,platformTransactionManager)
				.reader((ItemReader<? extends Object>) beanFactory.getBean(beanName))
				.writer((ItemWriter<? super Object>) beanFactory
						.getBean(reportCode + ReportConstants.WRITER_NAME_SUFFIX))
				.faultTolerant().retryLimit(3).retry(IllegalStateException.class)
				.retry(SQLException.class)
				.retry(SqlException.class)
				.retry(SqlSyntaxErrorException.class)
				.retry(SQLTransientConnectionException.class).exceptionHandler(exceptionHandler).listener(stepListener)
				.build();

	}

	private Step getWERSReportStep(String reportCode, String supplementCode) {
		String stepName = String.join(":", reportCode, getWERSDescription(reportCode));
		String beanName = "WERS" + ReportConstants.READER_NAME_SUFFIX;
		if (ReportConstants.ALL_POPULATION.equalsIgnoreCase(supplementCode)) {
			beanName = "WERS" + ReportConstants.ALL_POPULATION + ReportConstants.READER_NAME_SUFFIX;
		}
		return new StepBuilder(stepName,jobRepository).chunk(ReportConstants.FETCH_SIZE,platformTransactionManager)
				.reader((ItemReader<? extends Object>) beanFactory.getBean(beanName))
				.writer((ItemWriter<? super Object>) beanFactory.getBean("WERS" + ReportConstants.WRITER_NAME_SUFFIX))
				.faultTolerant().retryLimit(3).retry(IllegalStateException.class)
				.retry(SQLException.class)
				.retry(SqlException.class)
				.retry(SqlSyntaxErrorException.class)
				.retry(SQLTransientConnectionException.class).exceptionHandler(exceptionHandler).listener(stepListener)
				.build();
	}

}
