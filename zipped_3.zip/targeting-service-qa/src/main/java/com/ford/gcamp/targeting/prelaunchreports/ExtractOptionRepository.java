package com.ford.gcamp.targeting.prelaunchreports;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;
import org.springframework.web.util.HtmlUtils;

import com.ford.gcamp.targeting.common.CommonConstants;
import com.ford.gcamp.targeting.common.Hubs;
import com.ford.gcamp.targeting.common.api.SuppPopulationVo;
import com.ford.gcamp.targeting.core.exception.GCAMPException;

import lombok.extern.slf4j.Slf4j;

@Repository
@Slf4j
public class ExtractOptionRepository {

	@Value("${DB_OWNER}")
	private String ownerId;

	@Value("${db2.uncommit.read}")
	private String uncommitRead;

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Autowired
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

	public Map<String, Object> getUpdatedDistID(String inputJ18) throws GCAMPException {

		Map<String, Object> distListUpdateResp = null;
		try {
			SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate)
					.withSchemaName(CommonConstants.FSA_SCHEMA_NAME).withProcedureName(CommonConstants.J18_STORE_PROC);
			SqlParameterSource sqlParameterSource = new MapSqlParameterSource().addValue(CommonConstants.IPARM1,
					inputJ18);

			log.info(" getUpdatedList params {}", sqlParameterSource);
			distListUpdateResp = simpleJdbcCall.execute(sqlParameterSource);
		} catch (Exception e) {
			throw new GCAMPException(CommonConstants.DB_EXCEPTION, e);
		}

		return distListUpdateResp;
	}

	public Map<String, Object> getWersCodes() throws GCAMPException {
		Map<String, Object> wersMap = null;
		try {
			SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate)
					.withSchemaName(CommonConstants.FSA_SCHEMA_NAME)
					.withProcedureName(CommonConstants.LOAD_ERS_STOREPROC);
			SqlParameterSource sqlParameterSource = new MapSqlParameterSource()
					.addValue(CommonConstants.INPUT_PARM1, CommonConstants.DOUBLE_ZEROS)
					.addValue(CommonConstants.INPUT_PARM2, " ");
			wersMap = simpleJdbcCall.execute(sqlParameterSource);
		} catch (Exception e) {
			throw new GCAMPException(CommonConstants.DB_EXCEPTION, e);
		}
		return wersMap;

	}

	public List<Hubs> getHubCodes() {

		List<Hubs> hubsList = new ArrayList<>();
		StringBuilder sql=new StringBuilder();
		sql.append("SELECT DISTINCT GCPE10_HUB_C, GCPE10_HUB_DESC_X FROM ").append(ownerId).append(" SGCPE10_HUB ORDER BY GCPE10_HUB_DESC_X  ")
		.append(uncommitRead);
		jdbcTemplate.query(sql.toString(), new Object[] {}, (rs, rowNum) -> hubsList
				.add(new Hubs(rs.getString("GCPE10_HUB_C").trim(), rs.getString("GCPE10_HUB_DESC_X").trim())));
		return hubsList;

	}

	public List<Countries> getCountryList(String hubCode) {

		SqlParameterSource parameters = new MapSqlParameterSource().addValue("hubCode", hubCode);
		String sql = "SELECT c.COUNTRY_ISO3_C AS countryCode,c.COUNTRY_NAME_X AS countryDesc  FROM " + ownerId
				+ " SGCPE02_CTRY_HUB h, " + ownerId + "SDPMA01_COUNTRY c WHERE  h.GCPE10_HUB_C = :hubCode "
				+ "AND h.COUNTRY_ISO3_C = c.COUNTRY_ISO3_C AND h.GCPE02_EFF_TO_Y >= (SELECT current date FROM sysibm.sysdummy1) ORDER BY c.COUNTRY_NAME_X  "
				+ uncommitRead;

		return namedParameterJdbcTemplate.query(sql, parameters, new BeanPropertyRowMapper<Countries>(Countries.class));

	}

	public Map<String, Object> getProcessList(String inputParm1H1Q, String inputParm2H1Q) throws GCAMPException {
		Map<String, Object> processListMap = null;
		try {
			SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate)
					.withSchemaName(CommonConstants.FSA_SCHEMA_NAME).withProcedureName(CommonConstants.H1Q_STORE_PROC);
			SqlParameterSource sqlParameterSource = new MapSqlParameterSource()
					.addValue(CommonConstants.INPUT_PARM1, inputParm1H1Q)
					.addValue(CommonConstants.INPUT_PARM2, inputParm2H1Q);

			log.info(" SQL Parm source for process list {}", sqlParameterSource);
			processListMap = simpleJdbcCall.execute(sqlParameterSource);
		} catch (Exception e) {
			throw new GCAMPException(CommonConstants.DB_EXCEPTION, e);
		}

		return processListMap;

	}

	public Map<String, Object> getDistributionList(String inputParm1A50, String inputParm2A50) throws GCAMPException {

		Map<String, Object> distributionListMap = null;
		try {
			SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate)
					.withSchemaName(CommonConstants.FSA_SCHEMA_NAME).withProcedureName(CommonConstants.H50_STORE_PROC);
			SqlParameterSource sqlParameterSource = new MapSqlParameterSource()
					.addValue(CommonConstants.INPUT_PARM1, inputParm1A50)
					.addValue(CommonConstants.INPUT_PARM2, inputParm2A50);

			log.info(" SQL Parm source for distribution list {}", sqlParameterSource);
			distributionListMap = simpleJdbcCall.execute(sqlParameterSource);
		} catch (Exception e) {
			throw new GCAMPException(CommonConstants.DB_EXCEPTION, e);
		}

		return distributionListMap;
	}

	public List<SuppPopulationVo> getSupplementVo(String globalFsaNumber) {

		SqlParameterSource parameters = new MapSqlParameterSource().addValue("globalFsaNumber", globalFsaNumber);
		String query = "SELECT DISTINCT  GCPA09_SUPPL_C, GCPA09_SUPP_DESC_X,GCPA07_FSA_STAT_C  FROM " + ownerId
				+ " SGCPA09_FSA_SUPPL WHERE GCPA15_GLOBL_FSA_R = :globalFsaNumber " + " ORDER BY GCPA09_SUPPL_C  "
				+ uncommitRead;

		List<SuppPopulationVo> populationList = new ArrayList<>();
		namedParameterJdbcTemplate.query(query, parameters, new RowMapper<Object>() {

			public Object mapRow(ResultSet resultSet, int i) throws SQLException {
				if (!("U".equalsIgnoreCase(resultSet.getString(3)))) {
					SuppPopulationVo suppPopulationVo = new SuppPopulationVo();
					suppPopulationVo.setSupCode(resultSet.getString(1));
					suppPopulationVo.setSupDesc(resultSet.getString(1).trim() + "-" + resultSet.getString(2).trim());
					suppPopulationVo.setFsaStatus(resultSet.getString(3).trim());
					populationList.add(suppPopulationVo);

				}
				return populationList;
			}
		});
		return populationList;

	}

	public Map<String, Object> saveMemebersList(String saveParam1H51, String saveParam2H51) throws GCAMPException {

		Map<String, Object> processListMap = null;
		try {
			SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate)
					.withSchemaName(CommonConstants.FSA_SCHEMA_NAME).withProcedureName(CommonConstants.H51_STORE_PROC);
			SqlParameterSource sqlParameterSource = new MapSqlParameterSource()
					.addValue(CommonConstants.INPUT_PARM1, saveParam1H51)
					.addValue(CommonConstants.INPUT_PARM2, saveParam2H51);

			log.info(" SQL Parm source for process list {}", sqlParameterSource);
			processListMap = simpleJdbcCall.execute(sqlParameterSource);
		} catch (Exception e) {
			throw new GCAMPException(CommonConstants.DB_EXCEPTION, e);
		}

		return processListMap;

	}

	public Map<String, Object> extractOptionFsaCheck(String j12Param1) throws GCAMPException {
		Map<String, Object> processListMap = null;
		try {
			SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate)
					.withSchemaName(CommonConstants.FSA_SCHEMA_NAME).withProcedureName(CommonConstants.J12_STORE_PROC);
			SqlParameterSource sqlParameterSource = new MapSqlParameterSource().addValue(CommonConstants.INPUT_PARM1,
					j12Param1);

			log.info(" SQL Parm source list {}", sqlParameterSource);
			processListMap = simpleJdbcCall.execute(sqlParameterSource);
		} catch (Exception e) {
			throw new GCAMPException(CommonConstants.DB_EXCEPTION, e);
		}

		return processListMap;

	}

	public Map<String, Object> processExtract(String inputParm1, String inputParm2) throws GCAMPException {
		Map<String, Object> savedListResp = null;
		try {
			SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate)
					.withSchemaName(CommonConstants.FSA_SCHEMA_NAME).withProcedureName(CommonConstants.A65_STORE_PROC);
			SqlParameterSource sqlParameterSource = new MapSqlParameterSource()
					.addValue(CommonConstants.INPUT_FSAGO1, inputParm1)
					.addValue(CommonConstants.INPUT_PARM1, inputParm2);

			log.info(" SQL Parm source for default selections {}", sqlParameterSource);
			savedListResp = simpleJdbcCall.execute(sqlParameterSource);
		} catch (Exception e) {
			throw new GCAMPException(CommonConstants.DB_EXCEPTION, e);
		}

		return savedListResp;
	}

	public List<String> getFsaWersReports(String fsaNumber, String population) {

		List<String> wersList = new ArrayList<>();
		Map<String, Object> valueByKey = new HashMap<>();
		valueByKey.put("fsaNumber", HtmlUtils.htmlEscape(fsaNumber));
		valueByKey.put("population", HtmlUtils.htmlEscape(population));
		valueByKey.put("reportCode", ViewTargetReportConstants.WERS_LIKE_OPERATOR);

		SqlParameterSource parameters = new MapSqlParameterSource(valueByKey);
		StringBuilder query = new StringBuilder();
		query.append("SELECT GCPF04_REPORT_C  FROM ");
		query.append(ownerId);
		query.append(" SGCPF38_BLOB_DATA WHERE GCPA15_GLOBL_FSA_R= :fsaNumber ");
		query.append(" AND GCPA09_SUPPL_C = :population  ");
		query.append(" AND GCPF04_REPORT_C like :reportCode ");
		query.append(uncommitRead);
		log.info("SGCPF38_BLOB_DATA called");
		namedParameterJdbcTemplate.query(query.toString(), parameters,
				(rs, rowNum) -> wersList.add((rs.getString("GCPF04_REPORT_C")).substring(1, 5)));

		return wersList;
	}

}
