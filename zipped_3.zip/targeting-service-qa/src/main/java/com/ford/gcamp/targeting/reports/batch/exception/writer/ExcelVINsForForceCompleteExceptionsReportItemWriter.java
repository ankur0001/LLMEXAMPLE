
package com.ford.gcamp.targeting.reports.batch.exception.writer;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import com.ford.gcamp.targeting.reports.batch.common.ReportGenerationUtil;
import org.apache.commons.collections4.ListUtils;
import org.apache.poi.xssf.streaming.SXSSFSheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.item.Chunk;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.ford.gcamp.targeting.reports.batch.api.ExcelConfig;
import com.ford.gcamp.targeting.reports.batch.api.ReportMetaData;
import com.ford.gcamp.targeting.reports.batch.common.ReportCodeConstants;
import com.ford.gcamp.targeting.reports.batch.exception.GCAMPReportException;
import com.ford.gcamp.targeting.reports.batch.exception.api.TargetingExceptionReport;
import com.ford.gcamp.targeting.reports.batch.writer.GCAMPXSSFReportWriter;

@Component(ReportCodeConstants.T04 + "itemWriter")
@StepScope
public class ExcelVINsForForceCompleteExceptionsReportItemWriter extends GCAMPXSSFReportWriter
		implements ItemWriter<TargetingExceptionReport> {

	private List<TargetingExceptionReport> vinsForForceCompleteExceptionList;

	@Value("#{jobParameters['reportMetaData']}")
	private String reportMetaDataString;

	private ReportMetaData reportData;

	@Value("${exception.report.xlsx.maxrecords}")
	private int xlsxMaxRecords;

	@Override
	public void write(Chunk<? extends TargetingExceptionReport> items) throws Exception {
		reportData = ReportGenerationUtil.getReportMetaDataObject(reportMetaDataString);
		vinsForForceCompleteExceptionList = new ArrayList<>(items.getItems());
		this.createReport(reportData);
	}

	@Override
	public void createWorksheet(SXSSFWorkbook hssfWorkbook, ReportMetaData metaData) throws GCAMPReportException {

		initializeWorkbook(hssfWorkbook);

		List<List<TargetingExceptionReport>> vinsForForceCompleteExceptions = ListUtils.partition(
				vinsForForceCompleteExceptionList,
				xlsxMaxRecords);
		List<ExcelConfig> vinsForForceCompleteExceptionConfigList = loadConfigFile(ReportCodeConstants.T04,
				metaData.getSuppCode());
		int index = 1;
		for (List<TargetingExceptionReport> vinsForForceCompleteException : vinsForForceCompleteExceptions) {

			SXSSFSheet sheet = hssfWorkbook
					.createSheet(vinsForForceCompleteExceptionList.size() > xlsxMaxRecords
							? "VINs For Force Complete " + index
							: "VINs For Force Complete ");
			try {

				createProfile(sheet, metaData, "VINs For Force Complete Exceptions Report");

				setColumnWidth(sheet, vinsForForceCompleteExceptionConfigList);

				setColumnHeader(sheet, vinsForForceCompleteExceptionConfigList);

				setRowData(sheet, vinsForForceCompleteExceptionConfigList, vinsForForceCompleteException);

			} catch (Exception e) {
				throw new GCAMPReportException("Error in processing VINs For Force Complete Exceptions Report", e);
			}
			index++;
		}

	}

	public void setXlsxMaxRecords(int xlsxMaxRecords) {
		this.xlsxMaxRecords = xlsxMaxRecords;
	}

	public void setReportData(ReportMetaData reportData) {
		this.reportData = reportData;
	}

}