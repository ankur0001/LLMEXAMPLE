package com.ford.gcamp.targeting.config;


import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.ldap.core.LdapTemplate;
import org.springframework.ldap.core.support.LdapContextSource;

@Configuration
@EnableConfigurationProperties
public class LDAPConfiguration {

    @Bean
    public LdapTemplate configureLdapTemplateForCloud() {
        return new LdapTemplate(contextSource()) ;
    }

    @Bean
    @ConfigurationProperties(prefix = "ldap")
    public LdapContextSource contextSource() {
        return new LdapContextSource();
    }

}
