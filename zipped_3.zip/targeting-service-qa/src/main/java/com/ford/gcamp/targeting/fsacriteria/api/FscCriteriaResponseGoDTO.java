package com.ford.gcamp.targeting.fsacriteria.api;

import java.util.List;

import com.ford.gcamp.targeting.common.api.FSAInfoVO;
import com.ford.gcamp.targeting.common.api.ResponseStatusDTO;
import com.ford.gcamp.targeting.common.api.SuppPopulationVo;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class FscCriteriaResponseGoDTO extends ResponseStatusDTO{
	private boolean vinFlag;
	private boolean serialFlag;

	@Size(min = 0, max = 300, message = "suppPopulation List")
	private List<@Valid SuppPopulationVo> suppPopulation;

	@Size(min = 0, max = 300, message = "vinGrpCriteriaVOs List")
	private List<@Valid VINGrpCriteriaVO> vinGrpCriteriaVOs;

    @Valid
	private FSAInfoVO fsaInfoVO;

	@Size(min = 0, max = 300, message = "regionalFilters List")
	private List<@Valid CriteriaRegionalFilterTreeView> regionalFilters;
	
}