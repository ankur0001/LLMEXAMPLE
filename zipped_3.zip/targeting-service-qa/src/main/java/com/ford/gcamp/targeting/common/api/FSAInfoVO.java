package com.ford.gcamp.targeting.common.api;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ford.gcamp.targeting.common.DateConvert;


public class FSAInfoVO implements Serializable {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(FSAInfoVO.class);

	private static final long serialVersionUID = 1L;
	
  protected static final int GLOBAL_FSA_LAYOUT_SIZE = 400;
  protected static final int LOCAL_FSA_LAYOUT_SIZE = 300;
  protected static final int COMMON_GO_INPUT_PARAM_SIZE = 20;
  public static final String FSA_INDICATOR_GLOBAL = "G";
  public static final String FSA_INDICATOR_LOCAL = "L";

    @Size(min=0,max=10)
    @Pattern(regexp = "^|[\\s]*$")
    @Schema(types ={"string", "null"})
  private String inputFSANumber = "";


    @Size(min=0,max=10)
    @Pattern(regexp = "^|[A-Za-z\\d\\s]*$")
    @Schema(types = {"string", "null"})
  private String inputFSAFormatType = "G";

    @Size(min=0,max=10)
    @Pattern(regexp = "^|[\\s]*$")
    @Schema(types = {"string", "null"})
  private String globalFSANumber = "";

    @Size(min=0,max=300)
    @Pattern(regexp = "^|[\\s]*$")
    @Schema(types = {"string", "null"})
  private String globalFSADescription = "";

    @Size(min=0,max=11)
    @Pattern(regexp = "^|[\\s]*$")
    @Schema(types = {"string", "null"})
    private String relinquishControlDate = "";


    @Max(100)
    @Schema(types = {"string", "null"})
    private int noOfFSAs = 0;

    private GenericLookup initatingHub = new GenericLookup();

  private GenericLookup fsaStatus = new GenericLookup();

  private GenericLookup fsaType = new GenericLookup();
    @Size(min=0,max=500)
    @Schema(types = {"array", "null"})
  private List<FSANumberVO> fsaNumberList = new ArrayList<>();

  private boolean isGlobalList = false;

/**
   * this contains the information(HTML formatted rows) to display the popup 
   * when user entered a Local FSA number and the entered Local FSA Number 
   * matches with multiple Global FSAs. Each row in this represents a
   * Global FSA.
   * This is stored in the UserProfile.
   */
  GlobalFSAPopupData popupData = new GlobalFSAPopupData();

    @Size(min=0,max=10)
    @Schema(types = {"string", "null"})
    @Pattern(regexp = "^|[a-zA-Z\\d]*$")
  private String fsaLangInfo = null;


    @Size(min=0,max=10)
    @Schema(types = {"string", "null"})
    @Pattern(regexp = "^|[a-zA-Z\\d]*$")
  private String nhtsaLangInfo = null;

    @Size(min=0,max=10)
    @Schema(types = {"string", "null"})
    @Pattern(regexp = "^|[a-zA-Z\\d]*$")
  private String serproLangInfo = null;

    @Size(min=0,max=10)
    @Schema(types = {"string", "null"})
    @Pattern(regexp = "^|[a-zA-Z\\d]*$")
  private String apcwLangInfo = null;

  public List<FSANumberVO> getFsaNumberList() {
	return fsaNumberList;
}

public void setFsaNumberList(List<FSANumberVO> fsaNumberList) {
	this.fsaNumberList = fsaNumberList;
}

public String getRelinquishControlDate() {
      return relinquishControlDate;
  }
 
  public void setRelinquishControlDate(String relControlDt) {
      this.relinquishControlDate = relControlDt;
  }

  public FSANumberVO getFsaNumber(int index) {
      FSANumberVO fsaNumber = null;
      if (index < fsaNumberList.size()) {
          fsaNumber = fsaNumberList.get(index);
      }
      return fsaNumber;
  }

  protected void addFsaNumber(FSANumberVO fsaNumber) {
      this.fsaNumberList.add(fsaNumber);
  }

  public String getInputFSANumber() {
      return inputFSANumber;
  }
  
  public void setInputFSANumber(String inputFSANumber) {
      this.inputFSANumber = inputFSANumber;
  }


  public String getInputFSAFormatType() {
      return inputFSAFormatType;
  }
 
  public void setInputFSAFormatType(String inputFSAFormatType) {
      this.inputFSAFormatType = inputFSAFormatType;
  }
  public String getGlobalFSANumber() {
      return globalFSANumber;
  }
 
  public void setGlobalFSANumber(String globalFSANumber) {
  	
  	this.globalFSANumber ="";
  	//Checking Null Pointer exceptions ---Chenna
  	if(globalFSANumber == null || globalFSANumber.trim().length() <= 0){
  		return;
  	}
      this.globalFSANumber = globalFSANumber.trim();
      try{
      	int number = Integer.parseInt(this.globalFSANumber);
      	this.globalFSANumber = Integer.toString(number);
      }      catch(Exception e)  {
    	  LOGGER.error("error",e);
      	
      }
  }

  public String getGlobalFSADescription() {
      return globalFSADescription;
  }
  public void setGlobalFSADescription(String globalFSADescription) {
      this.globalFSADescription = globalFSADescription;
  }

  public boolean getIsGlobalList() {
      return isGlobalList;
  }
  public void setIsGlobalList(boolean isGlobalList) {
      this.isGlobalList = isGlobalList;
  }

  public GenericLookup getInitatingHub() {
      return initatingHub;
  }
  public void setInitatingHub(GenericLookup initatingHub) {
      this.initatingHub = initatingHub;
  }

  public GenericLookup getFsaStatus() {
	return fsaStatus;
}

public void setFsaStatus(GenericLookup fsaStatus) {
	this.fsaStatus = fsaStatus;
}

public GenericLookup getFsaType() {
	return fsaType;
}

public void setFsaType(GenericLookup fsaType) {
	this.fsaType = fsaType;
}

public GlobalFSAPopupData getPopupData() {
      return popupData;
  }
  public void setPopupData(GlobalFSAPopupData popupData) {
      this.popupData = popupData;
  }
  public boolean setString(String globalFSAOutParam, String localFSAOutParam) {
  	/* Remove if there are any entries in the FSA Number List */
	//If any in the list
      fsaNumberList.clear(); 
		//set default to false
      setIsGlobalList(false);

      /* check for null and minimum length*/
      if (globalFSAOutParam == null
          || localFSAOutParam == null
          || globalFSAOutParam.length() < GLOBAL_FSA_LAYOUT_SIZE) {
          return false;
      }
      /* Populate Global FSA Information */
      if (!setGlobalFSAString(globalFSAOutParam, GLOBAL_FSA_LAYOUT_SIZE)) {
          return false;
      }
      
      /* Create layout buffer for all Local/Global FSAs */
      LayoutBuffer outerLayoutBuffer =
          new LayoutBuffer(noOfFSAs * LOCAL_FSA_LAYOUT_SIZE);

      outerLayoutBuffer.setTrim(false);

      //Add fields for each Local/Global FSA
      for (int i = 0; i < noOfFSAs; i++) {
          outerLayoutBuffer.addField(
        		  LayoutBuffer.FIELDTYPE_PICX,
              LOCAL_FSA_LAYOUT_SIZE);
      }

      outerLayoutBuffer.fromString(localFSAOutParam);

      /*Add all Local/Global FSAs to ArrayList*/
      for (int i = 0; i < noOfFSAs; i++) {
          FSANumberVO fsaNumberVO = new FSANumberVO();
          fsaNumberVO.setString(outerLayoutBuffer.getString(i), LOCAL_FSA_LAYOUT_SIZE);
          this.addFsaNumber(fsaNumberVO);
      }

      /* Get the first Local/Global FSA in the list  */
      FSANumberVO fsaNumberVO = null;
      if (fsaNumberList != null && !fsaNumberList.isEmpty()) {
          fsaNumberVO =  fsaNumberList.get(0);
      }

      /* Determine if the list contains Global FSAs or Local FSAs. */
      if (fsaNumberVO != null
          && fsaNumberVO.getFsaFormatType() != null
          && fsaNumberVO.getFsaFormatType().trim().equals(
              FSA_INDICATOR_GLOBAL)) {
          /*Set isGlobalList to true if the returned list is a Global List*/
          setIsGlobalList(true);
          setGlobalFSANumber("");
          setPopupString();
      }
      return true;
  }

  public boolean setString(String globalFSAOutParam, int globalStringLength, String localFSAOutParam, int localStringLength) {

      /* Remove if there are any entries in the FSA Number List */
	//If any in the list
      fsaNumberList.clear(); 

      /* check for null and minimum length*/
      if (globalFSAOutParam == null
          || localFSAOutParam == null
          || globalFSAOutParam.length() < GLOBAL_FSA_LAYOUT_SIZE
          || globalFSAOutParam.length() < globalStringLength
          || globalStringLength < GLOBAL_FSA_LAYOUT_SIZE) {
          return false;
      }
      /* Populate Global FSA Information */
      if (!setGlobalFSAString(globalFSAOutParam, globalStringLength)) {
          return false;
      }

      /* Create layout buffer for all Local/Global FSAs */
      LayoutBuffer outerLayoutBuffer =
          new LayoutBuffer(noOfFSAs * localStringLength);

      outerLayoutBuffer.setTrim(false);

      //Add fields for each Local/Global FSA
      for (int i = 0; i < noOfFSAs; i++) {
          outerLayoutBuffer.addField(
        		  LayoutBuffer.FIELDTYPE_PICX,
              localStringLength);
      }

      outerLayoutBuffer.fromString(localFSAOutParam);

      /*Add all Local/Global FSAs to ArrayList*/
      for (int i = 0; i < noOfFSAs; i++) {
          FSANumberVO fsaNumberVO = new FSANumberVO();
          fsaNumberVO.setString(outerLayoutBuffer.getString(i), localStringLength);
          this.addFsaNumber(fsaNumberVO);
      }

      /* Get the first Local/Global FSA in the list  */
      FSANumberVO fsaNumberVO = null;
      if (fsaNumberList != null && !fsaNumberList.isEmpty()) {
          fsaNumberVO =  fsaNumberList.get(0);
      }

      /* Determine if the list contains Global FSAs or Local FSAs. */
      if (fsaNumberVO != null
          && fsaNumberVO.getFsaFormatType() != null
          && fsaNumberVO.getFsaFormatType().trim().equals(
              FSA_INDICATOR_GLOBAL)) {
          /*Set isGlobalList to true if the returned list is a Global List*/
          setIsGlobalList(true);
          setGlobalFSANumber("");
          setPopupString();
      }
      return true;
  }


  protected boolean setGlobalFSAString(String globalFSAOutParam, int size) {

		DateConvert dateConvert = DateConvert.getInstance();
		String date="";
		
      /* Check the buffer size */
      if (globalFSAOutParam.length() < GLOBAL_FSA_LAYOUT_SIZE || size < GLOBAL_FSA_LAYOUT_SIZE) {
          return false;
      }
      LayoutBuffer layoutBuffer = new LayoutBuffer(size);

      //Global FSA Number
      layoutBuffer.addField(LayoutBuffer.FIELDTYPE_PICX, 10);

      //Format Type
      layoutBuffer.addField(LayoutBuffer.FIELDTYPE_PICX, 1);

      //FSA Count
      layoutBuffer.addField(LayoutBuffer.FIELDTYPE_PICX, 2);

      //FSA Status Code
      layoutBuffer.addField(LayoutBuffer.FIELDTYPE_PICX, 1);

      //FSA Status Description
      layoutBuffer.addField(LayoutBuffer.FIELDTYPE_PICX, 20);

      //FSA Type Code 
      layoutBuffer.addField(LayoutBuffer.FIELDTYPE_PICX, 2);

      //FSA Type Description
      layoutBuffer.addField(LayoutBuffer.FIELDTYPE_PICX, 30);

      //Initiating HUB code for the GFSA
      layoutBuffer.addField(LayoutBuffer.FIELDTYPE_PICX, 2);

      //Initiating HUB Description
      layoutBuffer.addField(LayoutBuffer.FIELDTYPE_PICX, 30);

      //FSA Description
      layoutBuffer.addField(LayoutBuffer.FIELDTYPE_PICX, 254);
      
      //Relinquish Control date
		layoutBuffer.addField(LayoutBuffer.FIELDTYPE_PICX, 10);
		
      //Filler
      layoutBuffer.addField(LayoutBuffer.FIELDTYPE_PICX, size - GLOBAL_FSA_LAYOUT_SIZE + 38);

      layoutBuffer.fromString(globalFSAOutParam);

      this.setGlobalFSANumber(layoutBuffer.getString(0));

      //NOTE: No need to change the input format Type
      // and input FSA Number.

      String fsaCount = layoutBuffer.getString(2).trim();
      if (fsaCount != null && fsaCount.length() > 0) {
          noOfFSAs = Integer.parseInt(fsaCount);
      }
      this.fsaStatus.setCode(layoutBuffer.getString(3).trim());
      this.fsaStatus.setDescription(layoutBuffer.getString(4).trim());


      this.fsaType.setCode(layoutBuffer.getString(5).trim());
      this.fsaType.setDescription(layoutBuffer.getString(6).trim());

      this.initatingHub.setCode(layoutBuffer.getString(7).trim());
      this.initatingHub.setDescription(layoutBuffer.getString(8).trim());

      this.setGlobalFSADescription(layoutBuffer.getString(9));

		date = dateConvert.formatOutputDate(layoutBuffer.getString(10));
		this.setRelinquishControlDate(date);

      return true;
  }

  
  public List<GenericLookup> getAffectingHubList() {
      ArrayList<GenericLookup> hubList = new ArrayList<>();
      if (!isGlobalList) {
          for (int i = 0; i < fsaNumberList.size(); i++) {
          	
          	GenericLookup hub =  fsaNumberList.get(i).getHub();
              hubList.add(hub);
          }
      }
      return hubList;
  }

  
  private void setPopupString() {
      if (isGlobalList) {
			StringBuilder buffer = new StringBuilder("");
			
			buffer.append("<center><b>Local FSA Number: ");
			buffer.append(inputFSANumber);
			buffer.append("</b></center>");
				       
          for (int i = 0; i < fsaNumberList.size(); i++) {

              FSANumberVO tempFsaNumberVO =  fsaNumberList.get(i);
              String color;
              if (i % 2 == 0) {
                  color = "";
              } else {
                  color = "bgcolor='#ffffff'";
              }
				
					   buffer.append("<tr ");
                     buffer.append(color);
                     buffer.append("><td><input type='radio' onclick=\"assignVal('");
                     buffer.append(tempFsaNumberVO.getFsaNumber().trim());
                     buffer.append("')\" name='globalNumber' value='");
                     buffer.append(tempFsaNumberVO.getFsaNumber().trim());
                     buffer.append("'/></td><td>");
                     buffer.append(tempFsaNumberVO.getFsaNumber().trim());
                     buffer.append("</td><td>");
                     buffer.append(tempFsaNumberVO.getHub().getDescription().trim());
                     buffer.append("</td><td>");
                     buffer.append(tempFsaNumberVO.getFsaDescription().trim());
                     buffer.append("</td></tr>");
                     
          }
          popupData.setPopupString(buffer.toString());
      }
  }
  


  public String getCommonGoInputParam()  {
		
		return getCommonGoInputParam(COMMON_GO_INPUT_PARAM_SIZE);
  }
  
  public String getCommonGoInputParam(int bufferSize)  {
		
		if(bufferSize < 11) {
			return null;
		}
		LayoutBuffer layoutBuffer = new LayoutBuffer(bufferSize);

		int globalFSALen = globalFSANumber.length();
		   		 
      if (globalFSALen > 0 || inputFSAFormatType.equals(FSA_INDICATOR_GLOBAL)) {
      	layoutBuffer.addField(LayoutBuffer.FIELDTYPE_PICX, 1);
	    	//Global FSA Number
     		layoutBuffer.addField(LayoutBuffer.FIELDTYPE_PIC9, 8);
     		layoutBuffer.addField(LayoutBuffer.FIELDTYPE_PICX, bufferSize - 9);

			layoutBuffer.setString(0,FSA_INDICATOR_GLOBAL);
			if(globalFSALen > 0) {
				layoutBuffer.setString(1, globalFSANumber);
			} else {
				layoutBuffer.setString(1, inputFSANumber);
			}
			layoutBuffer.setString(2, "");
			return layoutBuffer.toString();
      }  else   {
      	layoutBuffer.addField(LayoutBuffer.FIELDTYPE_PICX, 1);
	    	//Local FSA Number
     		layoutBuffer.addField(LayoutBuffer.FIELDTYPE_PICX, 10);
     		layoutBuffer.addField(LayoutBuffer.FIELDTYPE_PICX, bufferSize - 11);

			layoutBuffer.setString(0,FSA_INDICATOR_LOCAL);
			layoutBuffer.setString(1, inputFSANumber);
			layoutBuffer.setString(2, "");
			return layoutBuffer.toString();
      }
  }
  
  public String toString() {
	  StringBuilder str = new StringBuilder();
          for (int i = 0; i < fsaNumberList.size(); i++) {
              FSANumberVO tempFsaNumberVO =  fsaNumberList.get(i);
              str.append("\nLOCAL FSA#" + i + " = " + tempFsaNumberVO);
                   
          }
      return str.toString();
  }
	public String getFsaLangInfo() {
		return fsaLangInfo;
	}
	public void setFsaLangInfo(String fsaLangInfo) {
		this.fsaLangInfo = fsaLangInfo;
	}
	public String getNhtsaLangInfo() {
		return nhtsaLangInfo;
	}
	public void setNhtsaLangInfo(String nhtsaLangInfo) {
		this.nhtsaLangInfo = nhtsaLangInfo;
	}
	public String getSerproLangInfo() {
		return serproLangInfo;
	}
	public void setSerproLangInfo(String serproLangInfo) {
		this.serproLangInfo = serproLangInfo;
	}
	public String getApcwLangInfo() {
		return apcwLangInfo;
	}
	public void setApcwLangInfo(String apcwLangInfo) {
		this.apcwLangInfo = apcwLangInfo;
	}
}
