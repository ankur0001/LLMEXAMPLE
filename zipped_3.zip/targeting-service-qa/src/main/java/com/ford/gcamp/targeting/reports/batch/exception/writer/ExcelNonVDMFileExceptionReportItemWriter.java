
package com.ford.gcamp.targeting.reports.batch.exception.writer;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import com.ford.gcamp.targeting.reports.batch.common.ReportGenerationUtil;
import org.apache.commons.collections4.ListUtils;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.xssf.streaming.SXSSFSheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.item.Chunk;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.ford.gcamp.targeting.reports.batch.api.ExcelConfig;
import com.ford.gcamp.targeting.reports.batch.api.ReportMetaData;
import com.ford.gcamp.targeting.reports.batch.common.ReportCodeConstants;
import com.ford.gcamp.targeting.reports.batch.exception.GCAMPReportException;
import com.ford.gcamp.targeting.reports.batch.exception.api.TargetingExceptionReport;
import com.ford.gcamp.targeting.reports.batch.writer.GCAMPXSSFReportWriter;

@Component(ReportCodeConstants.T08 + "itemWriter")
@StepScope
public class ExcelNonVDMFileExceptionReportItemWriter extends GCAMPXSSFReportWriter
		implements ItemWriter<TargetingExceptionReport> {

	private List<TargetingExceptionReport> nonVDMFileExceptionList;

	@Value("#{jobParameters['reportMetaData']}")
	private String reportMetaDataString;

	private ReportMetaData reportData;

	@Value("${exception.report.xlsx.maxrecords}")
	private int xlsxMaxRecords;

	@Override
	public void write(Chunk<? extends TargetingExceptionReport> items) throws Exception {
		reportData = ReportGenerationUtil.getReportMetaDataObject(reportMetaDataString);
		nonVDMFileExceptionList = new ArrayList<>(items.getItems());
		this.createReport(reportData);
	}

	@Override
	public void createWorksheet(SXSSFWorkbook hssfWorkbook, ReportMetaData metaData) throws GCAMPReportException {

		initializeWorkbook(hssfWorkbook);

		List<List<TargetingExceptionReport>> uploadVINExceptions = ListUtils.partition(nonVDMFileExceptionList,
				xlsxMaxRecords);
		List<ExcelConfig> nonVDMFileConfigList = loadConfigFile(ReportCodeConstants.T08, metaData.getSuppCode());
		int index = 1;
		for (List<TargetingExceptionReport> uploadVINException : uploadVINExceptions) {

			SXSSFSheet sheet = hssfWorkbook
					.createSheet(uploadVINExceptions.size() > xlsxMaxRecords ? "NON-VDM File Exception " + index
							: "NON-VDM File Exception");

			try {

				createProfile(sheet, metaData, "NON-VDM File Exception Report");

				List<ExcelConfig> nonVDMFileExceptionConfigList = nonVDMFileConfigList.stream().limit(3)
						.toList();

				setColumnWidth(sheet, nonVDMFileExceptionConfigList);

				setColumnHeader(sheet, nonVDMFileExceptionConfigList);

				setRowData(sheet, nonVDMFileExceptionConfigList, uploadVINException);

				List<ExcelConfig> nonVDMFileCountConfigList = nonVDMFileConfigList.stream().skip(3)
						.toList();

				setRowPos(sheet.getPhysicalNumberOfRows() + 4);

				setColumnHeader(sheet, nonVDMFileCountConfigList);

				nonVDMFileCountConfigList.stream().forEach(config -> {
					if ("count".equalsIgnoreCase(config.getProperty())) {
						config.setColumnType(String.valueOf(CellType.NUMERIC));
					}
				});

				List<TargetingExceptionReport> nonVDMFileCounts = getNonVDMFileNameCount(reportData);

				setRowData(sheet, nonVDMFileCountConfigList, nonVDMFileCounts);

			} catch (Exception e) {
				throw new GCAMPReportException("VIN Not Found In VDM REPORT ERROR", e);
			}
			index++;
		}

	}

	public void setXlsxMaxRecords(int xlsxMaxRecords) {
		this.xlsxMaxRecords = xlsxMaxRecords;
	}

	public void setRptData(ReportMetaData metadata) {
		this.reportData = metadata;

	}

}