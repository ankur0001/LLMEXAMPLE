package com.ford.gcamp.targeting.prelaunchreports.api;

import lombok.*;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ExtractReportRequest {
    private String vernNumber;
    private int globalFsaNumber;
    private String supplementCode;
    private String cdsId;
    private String requestedSystem;
    private String requestType;
    private String hubCode;
}