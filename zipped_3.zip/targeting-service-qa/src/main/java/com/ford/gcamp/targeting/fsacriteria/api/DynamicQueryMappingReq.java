package com.ford.gcamp.targeting.fsacriteria.api;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.v3.oas.annotations.extensions.Extension;
import io.swagger.v3.oas.annotations.extensions.ExtensionProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class DynamicQueryMappingReq {
	@Size(min = 0, max =100000)
	@Pattern(regexp = "^[\\w\\d\\,]*$")
	@Schema(description = "Model Year",extensions = @Extension(properties = @ExtensionProperty(name = "x-42c-sample", value = "2020")))
	private String modelYear;

	@Size(min = 0, max =100000)
	@Pattern(regexp = "^[a-zA-Z\\d\\,\\s\\!]*$")
	@Schema(example = "FORD", description = "brand", minLength = 0, maxLength = 100000)
	private String brand;

	@Size(min = 0, max =100000)
	@Pattern(regexp = "^[a-zA-Z\\d\\,]*$")
	@Schema(example = "CB6,CBT", description = "vehicle Line", minLength = 0, maxLength = 100000)
	private String vehicleLine;

	@Size(min = 0, max =100000)
	@Pattern(regexp = "^[a-zA-Z\\d\\,]*$")
	@Schema(example = "AAGBUC,AAGC1C", description = "Assembly Plant", minLength = 0, maxLength = 100000)
	private String assemblyPlant;

	@Size(min = 0, max =1000000)
	@Pattern(regexp = "^[a-zA-Z\\d\\,]*$")
	@Schema(example = "513", description = "wers", minLength = 0, maxLength = 1000000)
	private String wers;

	@Size(min = 0, max =1000000)
	@Pattern(regexp = "^[a-zA-Z\\d\\,]*$")
	@Schema(example = "WV", description = "lastSelection", minLength = 0, maxLength = 1000000)
	private String lastSelection;

	@Size(min = 0, max =3)
	@Pattern(regexp = "^[\\=\\<\\>\\!]*$")
	@Schema(example = "=>", description = "modelYearOperator", minLength = 0, maxLength = 3)
	private String modelYearOperator;

	@Size(min = 0, max =1000000)
	@Pattern(regexp = "^[a-zA-Z\\d\\,\\s]*$")
	@Schema(example = "G3FADC0", description = "wers Value", minLength = 0, maxLength = 1000000)
	private String wersValue;

	@Size(min = 0, max =5)
	@Pattern(regexp = "^[\\=\\<\\>\\!]*$")
	@Schema(example = "=>", description = "wers Operator", minLength = 0, maxLength = 5)
	private String wersOpeator;

	@Min(0)
	@Max(9)
	@Schema(example = "1", description = "selected Flag")
	private int selectedFlag;

	
}
