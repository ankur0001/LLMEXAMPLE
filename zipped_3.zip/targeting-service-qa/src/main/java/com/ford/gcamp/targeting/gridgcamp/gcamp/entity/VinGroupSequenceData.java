package com.ford.gcamp.targeting.gridgcamp.gcamp.entity;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Entity
@Table(name = "SGCPB18_VINGRPSEQ")
public class VinGroupSequenceData implements Serializable{

	private static final long serialVersionUID = 1L;
	
	@EmbeddedId
	private VinGroupSequenceId vinGroupSequenceId;

	@Column(name = "GCPD22_VINGP_LBL_C")
	private String vinGroupLabel;
	
	@Column(name = "GCPB18_OTA_F")
	private String otaFlag;
	
	@Column(name = "GCPB18_UPDATE_ID_C")
	private String updateId;
	
	
	
}
