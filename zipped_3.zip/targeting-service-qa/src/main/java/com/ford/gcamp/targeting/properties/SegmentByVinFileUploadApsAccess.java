package com.ford.gcamp.targeting.properties;

import java.util.Map;

import org.springframework.boot.context.properties.ConfigurationProperties;

import lombok.Getter;
import lombok.Setter;

@ConfigurationProperties(prefix = "segmentation.segbyvinfileupload.aps")
@Getter
@Setter
public class SegmentByVinFileUploadApsAccess {

	private String pageName;
	private Map<String, String> resources;
}
