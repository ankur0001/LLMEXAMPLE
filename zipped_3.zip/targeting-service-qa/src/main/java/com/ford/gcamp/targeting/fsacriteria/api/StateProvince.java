package com.ford.gcamp.targeting.fsacriteria.api;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class StateProvince {
	@NotNull
	@Size(min = 1, max = 2)
	@Pattern(regexp = "^[a-zA-Z\\*]*$")
	@Schema(example = "", description = "CountryCode")
	private String stateProCode;

	@NotNull
	@Size(min = 1, max = 20)
	@Pattern(regexp = "^[a-zA-Z\\*\\s]*$")
	@Schema(example = "", description = "state label")
	private String label;
}
