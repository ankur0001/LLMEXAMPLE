package com.ford.gcamp.targeting.prelaunchreports;

import com.ford.gcamp.targeting.common.*;
import com.ford.gcamp.targeting.common.api.BatchJobData;
import com.ford.gcamp.targeting.common.api.CommonJobResponse;
import com.ford.gcamp.targeting.common.api.SuppPopulationVo;
import com.ford.gcamp.targeting.config.WebClientAdConfiguration;
import com.ford.gcamp.targeting.core.exception.GCAMPException;
import com.ford.gcamp.targeting.core.exception.GCampBatchTriggerException;
import com.ford.gcamp.targeting.gridgcamp.gcamp.GridGCampRepository;
import com.ford.gcamp.targeting.gridgcamp.gcamp.GridGCampService;
import com.ford.gcamp.targeting.gridgcamp.gcamp.VehicleCriteriaSelectionRepository;
import com.ford.gcamp.targeting.gridgcamp.gcamp.entity.GridVernData;
import com.ford.gcamp.targeting.gridgcamp.gcamp.IncludeExcludeRepository;
import com.ford.gcamp.targeting.prelaunchreports.api.*;
import com.ford.gcamp.targeting.properties.ConfigProperties;
import com.ford.gcamp.targeting.user.UserService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.jetbrains.annotations.NotNull;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Lazy;
import org.springframework.http.MediaType;
import org.springframework.http.client.MultipartBodyBuilder;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.util.HtmlUtils;
import reactor.core.publisher.Mono;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Slf4j
@Service
public class ExtractOptionService {

    @Value("${spring.security.oauth2.client.registration.client-reportingservice-azure-ad.scope}")
    private String scope;
    @Value("${config.toggle.parallelProcessingFlag}")
    private boolean parallelProcessFlag;
    public static final String ERROR_WHILE_UPLOAD_FILE = "Error while Uploading file in GCS in Targeting";
    private static final Logger LOGGER = LoggerFactory.getLogger(ExtractOptionService.class);
    private static final String SUBMIT_EXTRACT_REG_BATCH_CODE = "028";
    private static final String SUBMIT_REPORTS_BATCH_CODE = "002";
    public static final String BEARER = "Bearer ";
    public static final String AUTHORIZATION = "Authorization";
    private static final String ERROR_MSG_FSA_SERVICE_DYNAMIC_QUERY = "Error while creating Dynamic Query in FSA service";

    private ExtractOptionRepository extractRepository;
    private ExtractOptionMapper extractOptionMapper;
    private UserService userService;
    private BatchJobData batchJob;
    private BatchTrigger batchTrigger;
    private WebClient webClient;
    private WebClientAdConfiguration webClientAdConfiguration;
    private ConfigProperties configProperties;

    @Autowired
    private VehicleCriteriaSelectionRepository vehicleCriteriaSelectionRepository;

    @Autowired
    private IncludeExcludeRepository includeExcludeRepository;

    @Lazy
    @Autowired
    private GridGCampService gridGCampService;

    @Autowired
    private GridGCampRepository gridGCampRepository;

    public ExtractOptionService(ExtractOptionRepository extractRepository, ExtractOptionMapper extractOptionMapper,
            UserService userService, BatchJobData batchJob, BatchTrigger batchTrigger, @Qualifier("reportingServiceWebClient") WebClient webClient,
            WebClientAdConfiguration webClientAdConfiguration, ConfigProperties configProperties) {
        super();
        this.extractRepository = extractRepository;
        this.extractOptionMapper = extractOptionMapper;
        this.userService = userService;
        this.batchJob = batchJob;
        this.batchTrigger = batchTrigger;
        this.webClient = webClient;
        this.webClientAdConfiguration = webClientAdConfiguration;
        this.configProperties = configProperties;
    }

    public ExtractOptionResponse loadDefaultSelection(ExtractOptionRequest extractOptionReq) throws GCAMPException {
        String hubCode = extractOptionReq.getHubCode();
        String population = extractOptionReq.getPopulation();
        String inputJ18 = extractOptionMapper.parmj18(hubCode);
        String inputParm1 = extractOptionMapper.savedSelectParm1(extractOptionReq);
        String inputParm2 = extractOptionMapper.savedSelectParm2(extractOptionReq);
        String globalFsaNumber = null;
        Map<String, Object> updatedIdMap = extractRepository.getUpdatedDistID(inputJ18);
        Map<String, Object> responseMap = extractRepository.processExtract(inputParm1, inputParm2);
        Map<String, Object> wersListMap = extractRepository.getWersCodes();

        List<Wers> wersList = extractOptionMapper.getWersList(wersListMap);
        ExtractOptionResponse extractResponse = extractOptionMapper.getDefaultSelection(responseMap);
        if (extractResponse.getStatusCode().equals(CommonConstants.SUCCESS_CODE)
                && StringUtils.isNotBlank(extractResponse.getFsaInfoVO().getGlobalFSANumber())) {
            globalFsaNumber = extractResponse.getFsaInfoVO().getGlobalFSANumber();
            List<String> wersCodes = extractRepository.getFsaWersReports(HtmlUtils.htmlEscape(globalFsaNumber),
                    HtmlUtils.htmlEscape(population));
            extractResponse.setLastWersReports(wersCodes);
            List<SuppPopulationVo> populationList = extractRepository.getSupplementVo(globalFsaNumber);
            extractResponse.setSupplements(populationList);
            boolean latestGridVernInfoExists = gridGCampService
                    .checkIfLatestGridVernExists(Integer.parseInt(globalFsaNumber), population);
            extractResponse.setLatestGridVernInfoExists(latestGridVernInfoExists);
        }
        List<LDAPModel> lastUpdatedList = getLastUpdatedIds(updatedIdMap);
        extractResponse.setAddedBy(lastUpdatedList);
        extractResponse.setWersList(wersList);
        return extractResponse;
    }

    public SaveAsDefaultResponse saveAsDefault(ExtractOptionRequest extractOptionReq) throws GCAMPException {
        if (StringUtils.isNotBlank(extractOptionReq.getWersCodeSelected())) {
            String wersSelected = extractOptionReq.getWersCodeSelected();
            String werscodes = getWerscodeswithZeros(wersSelected);
            extractOptionReq.setWersCodeSelected(werscodes);
        }

        String inputParm1 = extractOptionMapper.savedSelectParm1(extractOptionReq);
        String inputParm2 = extractOptionMapper.savedSelectParm2(extractOptionReq);
        Map<String, Object> responseMap = extractRepository.processExtract(inputParm1, inputParm2);
        return extractOptionMapper.saveDefaultSelections(responseMap);
    }

    private String getWerscodeswithZeros(String wersSelected) {
        String[] wers = wersSelected.split(",");
        StringBuilder wersCode = new StringBuilder();
        for (String string : wers) {
            wersCode.append(TargetingUtil.fillRemainingString(string, 4, "0"));
        }
        return wersCode.toString();
    }

    public DistributionsResponse loadDistrubutions(DistributionsRequest distributionRequest) {

        DistributionsResponse distributionsResponse = new DistributionsResponse();
        String hubCode = distributionRequest.getHubCode();
        String inputParm1H1Q = extractOptionMapper.inputParm1H1Q(distributionRequest);
        String inputParm2H1Q = extractOptionMapper.input2PArmH1Q();
        String inputParm1A50 = extractOptionMapper.inputParm1A50(distributionRequest);
        String inputParm2A50 = extractOptionMapper.inputParm2A50(distributionRequest);
        String inputJ18 = null;
        if (StringUtils.isNotBlank(distributionRequest.getDistListCode())) {
            inputJ18 = extractOptionMapper.parmj18MemberList(distributionRequest.getDistListCode());
        } else {
            inputJ18 = extractOptionMapper.parmj18(hubCode);
        }

        List<Hubs> hubCodes = extractRepository.getHubCodes();
        List<Countries> countryList = extractRepository.getCountryList(hubCode);
        try {
            Map<String, Object> processListMap = extractRepository.getProcessList(inputParm1H1Q, inputParm2H1Q);
            Map<String, Object> distributionListMap = extractRepository.getDistributionList(inputParm1A50,
                    inputParm2A50);
            Map<String, Object> updatedIdMap = extractRepository.getUpdatedDistID(inputJ18);
            List<Processes> processLists = extractOptionMapper.parseProcessList(processListMap);
            List<Distributions> distibutionsList = extractOptionMapper.parseDistributionsList(distributionListMap);

            List<LDAPModel> lastUpdatedList = getLastUpdatedIds(updatedIdMap);
            distributionsResponse.setHubsList(hubCodes);
            distributionsResponse.setCountrysList(countryList);
            distributionsResponse.setProcessLists(processLists);
            distributionsResponse.setDistributionsList(distibutionsList);
            distributionsResponse.setAddedBy(lastUpdatedList);
            distributionsResponse.setStatus(CommonConstants.SUCCESS);
            distributionsResponse.setStatusCode(CommonConstants.SUCCESS_CODE);
            distributionsResponse.setStatusDescription(CommonConstants.SUCCESS_DESC);
        } catch (Exception e) {
            log.error(CommonConstants.EXCEPTION_OCCURED, e);
            distributionsResponse.setStatus(CommonConstants.FAILURE);
            distributionsResponse.setStatusCode(CommonConstants.FAILURE_CODE);
            distributionsResponse.setStatusDescription(CommonConstants.FAILURE_DESC);
        }

        return distributionsResponse;
    }

    public SaveDistributionsResponse saveDistributionList(DistributionsRequest distributionRequest)
            throws GCAMPException {

        SaveDistributionsResponse commonResponse = new SaveDistributionsResponse();
        if (CommonConstants.FLAG_Y.equalsIgnoreCase(distributionRequest.getSaveMemberListFlag())) {
            String saveParm1A50 = extractOptionMapper.inputParm1A50(distributionRequest);
            String saveParm2A50 = extractOptionMapper.inputParm2A50(distributionRequest);
            Map<String, Object> saveDistMap = extractRepository.getDistributionList(saveParm1A50, saveParm2A50);
            commonResponse = extractOptionMapper.saveDistributionsList(saveDistMap);
            if (commonResponse.getStatus().equals(CommonConstants.SUCCESS)
                    && StringUtils.isNotBlank(commonResponse.getDistListId())) {
                distributionRequest.setDistListCode(commonResponse.getDistListId());
            }
            String saveParam1H51 = extractOptionMapper.inputParam1H51(distributionRequest);
            String saveParam2H51 = extractOptionMapper.inputParam2H51(distributionRequest);
            Map<String, Object> memberListMap = extractRepository.saveMemebersList(saveParam1H51, saveParam2H51);
            commonResponse = extractOptionMapper.updateMemberList(memberListMap, commonResponse);
        } else {
            String param1 = extractOptionMapper.inputParam1H51(distributionRequest);
            String param2 = extractOptionMapper.inputParam2H51(distributionRequest);
            Map<String, Object> memberListMap = extractRepository.saveMemebersList(param1, param2);
            commonResponse = extractOptionMapper.updateMemberList(memberListMap, commonResponse);
        }

        return commonResponse;

    }

    public CommonJobResponse submitExtract(ExtractOptionRequest processExtractRequest, String requester) throws GCAMPException {
        String fsaNumber = processExtractRequest.getFsaNumber();
        log.info("sold/unsold request for FSA Number {} : slice5 - {} : parallelProcessFlag - {}", fsaNumber, configProperties.isSlice5Flag(), parallelProcessFlag);
        if (StringUtils.isBlank(fsaNumber)) {
            throw new GCAMPException("FSA Number cannot be blank");
        }
        if (!configProperties.isSlice5Flag()) {
            return mainframeProcessForExtract(processExtractRequest, fsaNumber);
        } else {
            if (parallelProcessFlag) {
                String supplementCode = processExtractRequest.getPopulation();
                if (!processExtractRequest.isFsaRequest()) {
                    createExtractRequestAndInsertInBq(processExtractRequest, supplementCode, requester);
                }
                return mainframeProcessForExtract(processExtractRequest, fsaNumber);
            } else {
                String supplementCode = processExtractRequest.getPopulation();
                return createExtractRequestAndInsertInBq(processExtractRequest, supplementCode, requester);
            }
        }

    }

    private CommonJobResponse createExtractRequestAndInsertInBq(ExtractOptionRequest processExtractRequest, String supplementCode,
            String requester) throws GCAMPException {

        // For the extract request, we want to make sure that there is at least one criteria or VIN list exists before we create the extract report entry in BQ and trigger the extract job in mainframe. So adding the check here before calling the reporting service.
        checkVinOrCriteriaExists(Integer.parseInt(processExtractRequest.getFsaNumber()), processExtractRequest.getPopulation());

        Optional<GridVernData>  gridVernData = gridGCampRepository.findByGlobalFSANumberAndGridVernId_SupplementIdAndFsaAssignedFlag(Integer.parseInt(processExtractRequest.getFsaNumber()),
                processExtractRequest.getPopulation(), "Y");

        String vernNumber = "";
        if (gridVernData.isPresent() && StringUtils.isNotBlank(gridVernData.get().getVernNumber())) {
            vernNumber = gridVernData.get().getVernNumber().trim();
        }
        ExtractReportRequest extractReporRequest = ExtractReportRequest.builder()
                .vernNumber(vernNumber)
                .globalFsaNumber(Integer.parseInt(processExtractRequest.getFsaNumber()))
                .supplementCode(supplementCode)
                .cdsId(requester)
                .requestedSystem(determineRequestedSystem(processExtractRequest))
                .requestType("R".equals(processExtractRequest.getProcessFlag())?"REPORT":"EXTRACT")
                .hubCode(processExtractRequest.getHubCode())
                .build();
        return callReportingServiceforEntryInBQ(extractReporRequest);
    }

    private String determineRequestedSystem(ExtractOptionRequest processExtractRequest) {
        return "GRID".equalsIgnoreCase(processExtractRequest.getCdsId()) ? "GRID" : "GCAMP";
    }

    @NotNull
    private CommonJobResponse mainframeProcessForExtract(ExtractOptionRequest processExtractRequest, String fsaNumber) throws GCAMPException {
        String fsaType = processExtractRequest.getFsaType();

        String j12Param1 = extractOptionMapper.fsaGoParam(fsaNumber, fsaType);
        Map<String, Object> globalFsaCheckMap = extractRepository.extractOptionFsaCheck(j12Param1);
        CommonJobResponse extractResponse = extractOptionMapper.saveDistLists(globalFsaCheckMap);
        if (StringUtils.equals(extractResponse.getStatusCode(), CommonConstants.SUCCESS_CODE)) {

            if (StringUtils.isNotBlank(processExtractRequest.getWersCodeSelected())) {
                String wersSelected = processExtractRequest.getWersCodeSelected();
                String werscodes = getWerscodeswithZeros(wersSelected);
                processExtractRequest.setWersCodeSelected(werscodes);
            }
            String inputParm1A56 = extractOptionMapper.savedSelectParm1(processExtractRequest);
            String inputParm2A56 = extractOptionMapper.reportSavedParam2(processExtractRequest);

            CommonJobResponse extractJobResponse = proccessExtractJobSubmission(processExtractRequest,
                    extractResponse.getStatusCode(), inputParm1A56, inputParm2A56);
            extractResponse.setJobId(extractJobResponse.getJobId());
            extractResponse.setStatusDescription(extractJobResponse.getStatusDescription());


        }
        return extractResponse;
    }

    private CommonJobResponse callReportingServiceforEntryInBQ(ExtractReportRequest extractReporRequest) throws GCAMPException {
        CommonJobResponse extractResponse = new CommonJobResponse();
        try {
            String response = webClient.post()
                    .uri("/api/v1/extract-reporting/insert")
                    .contentType(MediaType.APPLICATION_JSON)
                    .header(AUTHORIZATION, BEARER + webClientAdConfiguration.getAccessToken(scope, "reporting"))
                    .body(Mono.just(extractReporRequest), ExtractReportRequest.class)
                    .exchangeToMono(clientResponse -> {
                        if (clientResponse.statusCode().isError()) {
                            return errorHandler(clientResponse);
                        }
                        return clientResponse.bodyToMono(String.class);
                    })
                    .block();
            log.info("Response from Reporting Service  : {}", response);
            extractResponse.setStatusCode(CommonConstants.SUCCESS_CODE);
            extractResponse.setStatusDescription(response);
            extractResponse.setStatus(CommonConstants.SUCCESS);
            extractResponse.setJobId(0);
            return extractResponse;
        } catch (Exception e) {
            log.error("Error while adding entry in BQ: {}", extractReporRequest.getGlobalFsaNumber());
            throw new GCAMPException(
                    "Error while adding entry in BQ: " + extractReporRequest.getGlobalFsaNumber());
        }
    }

    private static Mono<String> errorHandler(ClientResponse clientResponse) {
        return clientResponse.bodyToMono(String.class)
                .flatMap(errorMessage -> {
                    JSONObject json = new JSONObject(errorMessage);
                    String messages = json.getJSONObject("error").getJSONArray("messages").join(", ");
                    log.error("Error while creating extract report: {}, error message: {}",
                            clientResponse.statusCode(), messages);
                    return Mono.error(new GCAMPException(
                            "Error while creating extract report: " + clientResponse.statusCode() + ", error message: " + messages));
                });

    }

    private CommonJobResponse proccessExtractJobSubmission(ExtractOptionRequest processExtractRequest,
            String statusCode, String inputParm1A56, String inputParm2A56) throws GCAMPException {

        Map<String, Object> processExtractMap = extractRepository.processExtract(inputParm1A56, inputParm2A56);
        CommonJobResponse extractResponse = extractOptionMapper.processExtractSelections(processExtractMap);

        if (StringUtils.equals(statusCode, CommonConstants.SUCCESS_CODE)) {
            ExtractReports reportSelection = extractOptionMapper.getReportLists(processExtractMap);
            int jobId = initiateExtractJobSubmission(processExtractRequest, reportSelection);
            extractResponse.setJobId(jobId);
            extractResponse.setStatusDescription(CommonConstants.JOB_SUBMISSION_MSG + jobId);
        }
        return extractResponse;
    }

    private int initiateExtractJobSubmission(ExtractOptionRequest processExtractRequest, ExtractReports reportSelection)
            throws GCampBatchTriggerException {
        StringBuilder ujqParameters = new StringBuilder();
        ujqParameters.append("3|EMAIL_SUBMIT:");
        ujqParameters.append(processExtractRequest.getEmailSubmitInd());
        ujqParameters.append("|CHK_MISS_SER:");
        ujqParameters.append(processExtractRequest.getSerialNumInd());
        ujqParameters.append("|RUN_REGIONAL:");
        ujqParameters.append(processExtractRequest.getRegionalFilter());
        ujqParameters.append("|BUSINESS_OBJ:");
        ujqParameters.append(processExtractRequest.getLoadTeraDataInd());
        ujqParameters.append("|EXTRA_PARAM1:N|EXTRA_PARAM2:N|WRKG_CNTRY:");
        ujqParameters.append(reportSelection.getCountry());
        LOGGER.info("ujparameter value{}", ujqParameters.toString().length());
        ujqParameters.append("|000000000|XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        LOGGER.info("input ujparameter value{}", ujqParameters.toString().length());

        ujqParameters.append(processExtractRequest.getReportChecked());

        LOGGER.info("input Reports{}", reportSelection.getReports());
        LOGGER.info("input ujparameter value{}", ujqParameters.toString().length());
        ujqParameters.append("|");
        LOGGER.info("input Reports{}", reportSelection.getReports());
        ujqParameters.append(TargetingUtil.addSpaceToProc(618 - ujqParameters.toString().length()));
        ujqParameters.append("|");
        ujqParameters.append(String.format("%02d", processExtractRequest.getWersCodeCount()));
        ujqParameters.append(TargetingUtil.fillRemainingString(processExtractRequest.getWersCodeSelected(), 40, " "));
        ujqParameters.append(TargetingUtil.addZerosToProc(9));
        ujqParameters.append("|");
        ujqParameters.append(TargetingUtil.addZerosToProc(9));
        ujqParameters.append(processExtractRequest.getNavisIndicator());

        String supplement = null;
        String batchName = null;
        if ("".equals(processExtractRequest.getPopulation().trim())) {
            supplement = "00";
        } else {
            supplement = processExtractRequest.getPopulation().trim();
        }

        if ("R".equalsIgnoreCase(processExtractRequest.getProcessFlag())) {
            batchName = SUBMIT_REPORTS_BATCH_CODE;
        } else if ("E".equalsIgnoreCase(processExtractRequest.getProcessFlag())) {
            String checkedRunRegional = processExtractRequest.getRegionalFilter();

            if (checkedRunRegional != null && StringUtils.equalsAnyIgnoreCase("Y", checkedRunRegional)) {
                batchName = SUBMIT_EXTRACT_REG_BATCH_CODE;
            } else {
                batchName = CommonConstants.SUBMIT_EXTRACT_BATCH_CODE;
            }
        }

        batchJob.setBatchCode(batchName);
        batchJob.setGlobalFSANo(Integer.parseInt(processExtractRequest.getFsaNumber()));
        batchJob.setSupplement(supplement);
        batchJob.setCdsId(processExtractRequest.getCdsId());
        batchJob.setHubCode(processExtractRequest.getHubCode());
        batchJob.setCountryCode(processExtractRequest.getCountryCode());
        batchJob.setParameters(ujqParameters.toString());
        return batchTrigger.submitJob(batchJob);
    }

    public CommonJobResponse submitReports(ExtractOptionRequest processExtractRequest) throws GCAMPException {
        if (!configProperties.isSlice5Flag()) {
            return mainframeProcessForReport(processExtractRequest);
        } else {
            if (parallelProcessFlag) {
                callReportingServiceforEntryInBQ(ExtractReportRequest.builder()
                        .vernNumber("")
                        .globalFsaNumber(Integer.parseInt(processExtractRequest.getFsaNumber()))
                        .supplementCode(processExtractRequest.getPopulation())
                        .cdsId(processExtractRequest.getCdsId())
                        .requestedSystem("GCAMP")
                        .requestType("REPORT")
                        .hubCode(processExtractRequest.getHubCode())
                        .build());
                return mainframeProcessForReport(processExtractRequest);
            } else {
                //check the at least one criteria or VIN list exists for the FSA and supplement before calling the reporting service and triggering the mainframe job, if not then throw exception to avoid report submission as it will fail in mainframe due to missing criteria/VIN list and also we are creating the entry in BQ. so we want to avoid creating the entry in BQ if there is no criteria/VIN list exists for the FSA and supplement.
                checkVinOrCriteriaExists(Integer.parseInt(processExtractRequest.getFsaNumber()), processExtractRequest.getPopulation());
                Optional<GridVernData>  gridVernData = gridGCampRepository.findByGlobalFSANumberAndGridVernId_SupplementIdAndFsaAssignedFlag(Integer.parseInt(processExtractRequest.getFsaNumber()),
                        processExtractRequest.getPopulation(), "Y");

                String vernNumber = "";
                if (gridVernData.isPresent() && StringUtils.isNotBlank(gridVernData.get().getVernNumber())) {
                    vernNumber = gridVernData.get().getVernNumber().trim();
                }

                return callReportingServiceforEntryInBQ(ExtractReportRequest.builder()
                        .vernNumber(vernNumber)
                        .globalFsaNumber(Integer.parseInt(processExtractRequest.getFsaNumber()))
                        .supplementCode(processExtractRequest.getPopulation())
                        .cdsId(processExtractRequest.getCdsId())
                        .requestedSystem("GCAMP")
                        .requestType("REPORT")
                        .build());
            }
        }
    }

    private void checkVinOrCriteriaExists(int fsaNumber, String population)
            throws GCAMPException {
        boolean criteriaExists = vehicleCriteriaSelectionRepository.existsByGlobalFSANumberAndSupplementCode(fsaNumber, population); //D20
        List<String> folderActionFlag = List.of("I", "E");
        boolean includeExcludeExists = includeExcludeRepository
                .existsByIncludeExcludeId_GlobalFsaNumberAndSupplementCodeAndFolderActionFlagIn( //D08
                        String.valueOf(fsaNumber), population, folderActionFlag);
        if (!criteriaExists && !includeExcludeExists) {
            log.info("No criteria or VIN list found for FSA : {} and Supplement : {}. Throwing Exception to avoid report submission.", fsaNumber, population);
            throw new GCAMPException("No criteria or VIN list found for FSA : " + fsaNumber + " and Supplement : " + population + ". Please Add Criteria or VIN List and try submitting the Report/Extract again.");
        }
    }

    @NotNull
    private CommonJobResponse mainframeProcessForReport(ExtractOptionRequest processExtractRequest) throws GCAMPException {
        String fsaNumber = processExtractRequest.getFsaNumber();
        String fsaType = processExtractRequest.getFsaType();
        String inputParm1A56 = extractOptionMapper.savedSelectParm1(processExtractRequest);
        String inputParm2A56 = extractOptionMapper.reportSavedParam2(processExtractRequest);
        String j12Param1 = extractOptionMapper.fsaGoParam(fsaNumber, fsaType);
        Map<String, Object> globalFsaCheckMap = extractRepository.extractOptionFsaCheck(j12Param1);
        CommonJobResponse extractResponse = extractOptionMapper.saveDistLists(globalFsaCheckMap);
        if (StringUtils.equals(extractResponse.getStatusCode(), CommonConstants.SUCCESS_CODE)) {
            CommonJobResponse extractJobResponse = proccessExtractJobSubmission(processExtractRequest,
                    extractResponse.getStatusCode(), inputParm1A56, inputParm2A56);
            extractResponse.setJobId(extractJobResponse.getJobId());
            extractResponse.setStatusDescription(extractJobResponse.getStatusDescription());
        }
        return extractResponse;
    }

    @SuppressWarnings("unchecked")
    public List<LDAPModel> getLastUpdatedIds(Map<String, Object> responseMap) {
        List<Map<String, Object>> cdsIdListMap = (List<Map<String, Object>>) responseMap
                .get(CommonConstants.RESULT_SET_1);
        List<LDAPModel> cdsIdList = new ArrayList<>();
        if (CollectionUtils.isNotEmpty(cdsIdListMap)) {
            for (Map<String, Object> map1 : cdsIdListMap) {
                Optional<LDAPModel> ldapUser = userService
                        .getByCDSId(StringUtils.trim(String.valueOf(map1.get("GCPG12_CDS_ID_C"))));
                if (ldapUser.isPresent()) {
                    cdsIdList.add(ldapUser.get());
                }
            }
        }
        return cdsIdList;
    }

    /***
     * To Upload file to GCS via FSA Service
     * ***/
    public String addFileToGcsViaFsaService(String fileName, MultipartFile multipartFile, String actionFlag, String requester, String contentType) {
        String responseString;
        try {
            MultipartBodyBuilder builder = new MultipartBodyBuilder();
            builder.part("fileName", fileName); // file name part
            builder.part("file", multipartFile.getResource()); // file part
            builder.part("actionFlag", actionFlag); // add action flag part
            builder.part("cdsId", requester.trim());
            builder.part("xmlContentType", contentType);
            boolean isSingleFile = fileName != null && fileName.contains("All");
            if (isSingleFile) {
                builder.part("singleFileFlag", isSingleFile);
            }
            responseString = webClient.post()
                    .uri("/api/v1/reporting/upload")
                    .contentType(MediaType.MULTIPART_FORM_DATA)
                    .header("Authorization", "Bearer " + webClientAdConfiguration.getAccessToken(scope, "reporting"))
                    .body(BodyInserters.fromMultipartData(builder.build()))
                    .exchangeToMono(clientResponse -> {
                        if (clientResponse.statusCode().isError()) {
                            return clientResponse.bodyToMono(String.class)
                                    .flatMap(errorMessage -> {
                                        JSONObject json = new JSONObject(errorMessage);
                                        String messages = json.getJSONObject("error").getJSONArray("messages").join(", ");
                                        log.error("Error while Uploading file to GCS. Reporting Service returned status code: {}, error message: {}",
                                                clientResponse.statusCode(), messages);
                                        return Mono.just(messages.replace("\"", ""));
                                    });
                        } else {
                            return clientResponse.bodyToMono(String.class);
                        }
                    })
                    .block();
            log.info("Response from FSA Service to Upload File to GCS : {}", responseString);
        } catch (Exception e) {
            log.error(ERROR_WHILE_UPLOAD_FILE, e);
            return ERROR_WHILE_UPLOAD_FILE;
        }
        return responseString;
    }

}
