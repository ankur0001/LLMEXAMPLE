package com.ford.gcamp.targeting.prelaunchreports;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class Processes {

	private String processId;
	private String processDesc;
	private String updatedBy;
	private String timeStamp;
}
