package com.ford.gcamp.targeting.fsacriteria.api;

import java.util.ArrayList;
import java.util.List;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class VINGrpCriteriaVO  {
	@NotNull
	@Size(min = 1, max = 1)
	@Pattern(regexp = "^[\\d]$")
	@Schema(example = "2", description = "Sequence number")
	private int vinGroupSeqNum;
	@NotNull
	@Size(min = 2, max = 2)
	@Pattern(regexp = "^[a-zA-Z\\d]*$")
	@Schema(example = "AA", description = "Vin group label")
	private String vinGroupLabel = "";

	@NotNull
	@Size(max = 254)
	@Pattern(regexp = "^[A-Za-z0-9\\s\\*]*$")
	@Schema(example = "**", description = "MRA2-VIN GROUP DESCRIPTION FOR **")
	private String vinGroupDesc = "";
	@NotNull
	@Size(min = 1, max = 1)
	@Pattern(regexp = "^[a-zA-Z]$")
	@Schema(example = "N", description = "OTA Indicator")
	private String otaIndicator = "";
	@Size(min = 0, max = 1)
	@Pattern(regexp = "^[a-zA-Z]$")
	@Schema(example = "", description = "FHM Indicator")
	private String fhmIndication = "";

	@NotNull
	@Size(min = 0, max = 20)
	@Pattern(regexp = "^[a-zA-Z\\d\\-\\s\\:]*$")
	@Schema(example = "27-May-2024 11:04:25", description = "Date and timestamp")
	private String lastModified = "";

	@Size(min = 1, max = 8)
	@Pattern(regexp = "^[a-zA-Z\\d\\-]*$")
	@Schema(example = "TDHARTI", description = "CDSID")
	private String lastModifiedBy = "";
	private List<String> vehicleLineFilter=new ArrayList<>();
	private List<String> assemblyPlantFilter=new ArrayList<>();
	private List<String> modelYearFilter=new ArrayList<>();
	private List<String> modelYearOperator=new ArrayList<>();
	private List<String> brandFilter=new ArrayList<>();
	private List<String> genericFilter=new ArrayList<>();
	private List<String> productionDate=new ArrayList<>();
	private boolean isChecked = false;
	
	private CriteriaRegionalFilterTreeView regionalFilters;
	
	public boolean getIsChecked() {
		return isChecked;
	}
	public void setIsChecked(boolean isChecked) {
		this.isChecked = isChecked;
	}
	
}


