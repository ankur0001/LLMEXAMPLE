package com.ford.gcamp.targeting.common;

public class CommonConstants {

    public static final String JWT_CDSID_CLAIM = "upn";

    public static final String FSA_SCHEMA_NAME = "SYSPROC";
    public static final String ADD_MODIFYSTOREDPROC_NAME = "CSGCSB62";
    public static final String FSC_GLOBAL = "global";
    public static final String FSC_LOCAL = "local";
    public static final String GLOBALFSA_STOREDPROC_NAME = "CSGCSA57";
    public static final String FSA_SEARCH_GO_PARM = "S";
    public static final String FSA_SEARCH_GO_POP_PARAM = "00";
    public static final String NOT_APPROVED = "NA";

    public static final String THREE_ZEROS = "000";
    public static final String FOUR_ZEROS = "0000";
    public static final String FIVE_ZEROS = "00000";
    public static final String STATE_PROV_STORE_PROC = "CSGCSB41";
    public static final String GLOBALFSA_SEARCH_STOREDPROC_NAME = "CSGCSJ03";
    public static final String LOCALFSA_SEARCH_STOREDPROC_NAME = "CSGCSJ04";
    public static final String SEGMENTATION_VIEW_RESULTS = "CSGCSB25";
    public static final String CONFIRM_DELETE_CHECK = "CSGCSB50";

    public static final String CREATE_MULTIPLE_GLOBAL_FSA_GO_PROC = "CSGCSJ12";

    public static final String HISTORY_OF_FROZEN = "CSGCSB20";

    public static final String PARTIAL_DELETE_JOB_CODE = "279";
    public static final String GLOBAL_DELETE_JOB_CODE = "280";

    public static final String FSA_SEARCH_COPY_POP_PARAM = "02";
    public static final String FSA_SEARCH_SAVE_POP_PARAM = "01";
    public static final String MANUAL_VIN_UPLOAD_BATCH_CODE = "025";

    public static final String FSA_FROZEN_B19 = "CSGCSB19";
    public static final String FSA_FROZEN_B11 = "CSGCSB11";
    public static final String FSA_SELECT_COUNTRY = "CSGCSB02";

    public static final String FSA_DELETE_ALL = "CSGCSA58";
    public static final String FSA_DELETE_CRITERIA = "CSGCSJ11";
    public static final String FSA_DELETE_DATA = "CSGCSJ17";

    public static final String VIN_LIST_PROC = "CSGCSC53";
    public static final String SERIAL_LIST_PROC = "CSGCSB61";

    public static final String VIN_LIST_PROC_COPY = "CSGCSC53";
    public static final String SERIAL_LIST_PROC_COPY = "CSGCSB61";

    public static final String MANUAL_UPLOAD = "CSGCSB09";
    public static final String FC_CLOSE_FSA_PROC = "CSGCSD06";

    public static final String F02_VFD_FSA_SEARCH_STORPROC = "CSGCSF02";
    public static final String F08_VFD_PRIOR_REQUEST_STORPROC = "CSGCSF08";
    public static final String F03_VFD_SUBMIT_STORPROC = "CSGCSF03";

    public static final String GLOBAL_FSA_SETUP_PROC = "CSGCSB05";

    public static final String VIN_LIST_PROC_NAME = "CSGCSZ05";
    public static final String VFD_JOB_SUBMIT_BATCH_CODE = "104";

    public static final String SUCCESS_CODE = "200";

    public static final String SUCCESS = "SUCCESS";

    public static final String SUCCESS_DESC = "SUCCESS";

    public static final String FAILURE_CODE = "403";

    public static final String FAILURE = "FAILED";
    public static final String FAILURE_BATCH_DESC = "Error is Batch Trigger";
    public static final String VINGRP_CODE_DELETE_ERROR =
            "Selected VIN Group has already been Deleted, please refresh the screen";
    public static final String FILE_UPLOAD_EXCEPTION = "Error streaming file upload";
    public static final String PROGRAM_CLOSURE_ERROR = "Only Launched FSA to be allowed";

    public static final String S3_UPLOAD_EXCEPTION = "Error ";

    public static final String SFTP_ERROR = "SFTP Connection Error";

    public static final String FAILURE_DESC = "No Data found from Backend";
    public static final String NO_GRP_DESC = "No Groupings were found for this criteria";
    public static final String FSA_SEARCH_FAILURE =
            "No FSA Number(s) found for the criteria entered";
    public static final String FSA_SEARCH_MAX_DATE = "STATUS FROM DATE CANNOT BE GREATER THAT TO";
    public static final String VIN_DUPLICATE_CHECK = "VINs already exist in the Global FSA.";

    public static final String INVALID_VIN_ERROR = "The Highlighted VINs are not found in VDM.";

    public static final String DOWNLOAD_FAILURE =
            "For this record there is no file present to download";
    public static final String RESPONSE = "dynamicQueryResponse {}";
    public static final String PARAM_LENGTH_TEXT = "param 1 length {} and param 2 length {}";
    public static final String SP_RESPONSE_TEXT = "Response from Store proc : {}";
    public static final String EXCEPTION_OCCURED = "Exception occured";
    public static final String INPUT_PARM1 = "INPUT_PARM1";
    public static final String INPUT_PARM2 = "INPUT_PARM2";
    public static final String INPUT_PARM3 = "INPUT_PARM3";
    public static final String INPUT_FSAGO1 = "INPUT_FSAGO1";
    public static final String INVALID_DATE = "0001-01-01";
    public static final String DEFAULT_END_DATE = "9999-12-31";
    public static final String PRODUCTION_DATE = "PRODUCTION DATE";
    public static final String ERROR_PARM = "ERROR_PARM1";
    public static final String DD_MM_YYYY = "dd-MMM-yyyy";
    public static final String YYYY_MM_DD = "yyyy-MM-dd";
    public static final String DOUBLE_SPACE_DELIMETER = "\\s{2,}";
    public static final String STPR_STATE_C = "STPR_STATE_C";

    public static final String APS_ACTION_NAME_EXECUTE = "execute";
    public static final String APS_FSACRITERIA_PAGE_NAME = "fsaCriteria";
    public static final String APS_FROZENVIN_PAGE_NAME = "frozenVin";
    public static final String APS_VINLIST_PAGE_NAME = "vinList";
    public static final String APS_MANUALADDVINS_PAGE_NAME = "manualAddVin";
    public static final String APS_PARTICIPATION_PAGE_NAME = "participation";
    public static final String APS_SUPPLEMENT_PAGE_NAME = "supplement";
    public static final String APS_VINDISTRIBUTION_PAGE_NAME = "InitializeVINFileRequestAction";
    public static final String APS_VINDISTRIBUTION_GRID_PAGE_NAME = "DisplayVINGrid";
    public static final String APS_VINDISTRIBUTION_PRIOREQUEST_PAGE_NAME = "PriorRequestAction";
    public static final String APS_VINDISTRIBUTION_FIELDSELECTION_PAGE_NAME = "FieldSelection";
    public static final String APS_MANUALCLOSEFSA_PAGE_NAME = "ManuallyCloseFSAAction";
    public static final String APS_CMGF_PAGE_NAME = "cmgf";
    public static final String APS_CREATE_GLOBAL_FSA_SETUP_PAGE_NAME = "globalfsasetup";
    public static final String APS_FORCECLOSERCODE_PAGE_NAME = "ForceClosureCodes";
    public static final String APS_TARGETING_EXTRACT_PAGE_NAME = "extractOption";
    public static final String APS_VIEW_TARGETING_REPORTS_PAGE_NAME = "viewTargetRprtAction";
    public static final String APS_REPORT_DISTRIBUTION_PAGE_NAME = "DistributionListAction";
    public static final String APS_VINMANAGEMENT_PAGE_NAME = "VinManagement";
    public static final String APS_LOCAL_FSA_PAGE_NAME = "localfsa";
    public static final String APS_MAINTAIN_LOCALFSA_PAGE_NAME = "maintainLocalFSASetup";
    public static final String APS_MODELYEAR_PAGE_NAME = "modelYearVehicleLineInfo";
    public static final String APS_SEGMENT_SUMMARY_PAGE_NAME = "segsummary";
    public static final String APS_SEGMENT_BY_PERCENT_PAGE_NAME = "segbypercent";
    public static final String APS_SEGMENT_PHASE_BY_PERCENT_PAGE_NAME = "phasebypercent";
    public static final String APS_SEGMENT_CRITERIA_PAGE_NAME = "segcriteria";
    public static final String APS_GOV_REPORT_MODIFY_PAGE_NAME = "govReportModify";
    public static final String APS_GOV_REPORT_DETAILS_PAGE_NAME = "govReportDetails";
    public static final String APS_MAINTAIN_GOV_DETAILS_PAGE_NAME = "maintainGovDetails";
    public static final String APS_FSAEXPIRATION_PAGE_NAME = "fsaexpiration";
    public static final String APS_SERPRORECALL_PAGE_NAME = "serprorecall";
    public static final String APS_NHTSARECALL_PAGE_NAME = "nhtsaRecallInfo";
    public static final String APS_REGIONALFILTERS_PAGE_NAME = "regionalfilters";
    public static final String APS_REGIONALFILTERS_STATE = "regionalstate";
    public static final String APS_REGIONALFILTERS_COUNTRY = "regionalcountry";
    public static final String APS_REGIONALFILTERS_REPORT = "regionalreport";
    public static final String APS_GSAR_REPORT = "gsarreport";
    public static final String VIEW_REPORTS_STORPROC = "CSGCSB50";
    public static final String J18_STORE_PROC = "CSGCSJ18";
    public static final String A65_STORE_PROC = "CSGCSA65";
    public static final String H1R_STORE_PROC = "CSGCSH1R";
    public static final String H1Q_STORE_PROC = "CSGCSH1Q";
    public static final String H50_STORE_PROC = "CSGCSH50";
    public static final String J12_STORE_PROC = "CSGCSJ12";
    public static final String J17_STORE_PROC = "CSGCSJ17";
    public static final String J11_STORE_PROC = "CSGCSJ11";
    public static final String H51_STORE_PROC = "CSGCSH51";
    public static final String B71_STORE_PROC = "CSGCSB71";
    public static final String B72_STORE_PROC = "CSGCSB72";
    public static final String B04_STORE_PROC = "CSGCSB04";
    public static final String B34_STORE_PROC = "CSGCSB34";
    public static final String SEGMENT_BY_VIN_FILE_UPLOAD = "CSGCSB46";
    public static final String VIN_GROUP_LABEL_COLUMN = "GCPD22_VINGP_LBL_C";
    public static final String VIN_GROUP_LABEL_DESCRIPTION_COLUMN = "GCPD22_LBL_DESC_X";
    public static final String EXISTING_VIN_GROUP_LABEL_DESCRIPTION_COLUMN = "GCPB18_VINGRP_X";
    public static final String FILE_PATH_COLUMN = "GCPD08_FLDR_PATH_X";
    public static final String FOLDER_ID_COLUMN = "GCPD08_FOLDER_D";
    public static final String SEGMENT_NUMBER_COLUMN = "GCPD14_SEGMENT_R";
    public static final String SUPPLEMENT_CODE_COLUMN = "4";
    public static final String DELETE_BATCH_CODE = "040";
    public static final String LOAD_INDICATOR = "C";
    public static final String UPDATE_INDICATOR = "U";
    public static final String DELETE_INDICATOR = "D";
    public static final String UPLOAD_INDICATOR = "A";

    public static final String G20_STORE_PROC = "CSGCSG20";

    public static final String RESULT_SET_1 = "#result-set-1";
    public static final String RESULT_SET_2 = "#result-set-2";
    public static final String RESULT_SET_3 = "#result-set-3";
    public static final String RESULT_SET_5 = "#result-set-5";
    public static final String IPARM1 = "IPARM1";
    public static final String IPARM5 = "IPARM5";
    public static final String LOAD_ERS_STOREPROC = "CSGCSB62";
    public static final String DOUBLE_ZEROS = "00";
    public static final String OUTPUT_PARM1 = "OUTPUT_PARM1";
    public static final String OUTPUT_PARM2 = "OUTPUT_PARM2";
    public static final String OUTPUT_PARM3 = "OUTPUT_PARM3";
    public static final String OUTPUT_ERR1 = "OUTPUT_ERR1";
    public static final String INVALID_INPUT = "Invalid input";

    public static final String FETCH_EVENT_CODE_STORE_PROC = "CSGCSB70";

    public static final String INPUT_PARM4 = "INPUT_PARM4";
    public static final String INPUT_PARM5 = "INPUT_PARM5";
    public static final String INPUT_PARM6 = "INPUT_PARM6";
    public static final String LOAD_SINGLEVINMAINTENANCE_NAME = "CSGCSD04";
    public static final String SUBMIT_SINGLEVINMAINTENANCE_NAME = "CSGCSD03";

    public static final String JOB_SUBMISSION_MSG =
            "Your Job has been successfully submitted with Job Id ";
    public static final String A53_STORE_PROC = "CSGCSA53";

    public static final String MANUAL_CLOSE_FSA_LOAD_PROC = "CSGCSD05";
    public static final String MANUAL_CLOSE_FSA_SUBMIT_PROC = "CSGCSD06";
    public static final String ASTERISK = "*";
    public static final String MANUAL_CLOSE_FSA_SUBMIT_BATCH = "120";

    public static final String INQUIRY = "I";
    public static final String SELECT = "S";
    public static final String ADD = "A";
    public static final String UPDATE = "U";
    public static final String FLAG_V = "V";
    public static final String FLAG_A = "A";
    public static final String DELETE = "D";
    public static final String FLAG_Y = "Y";
    public static final String FLAG_N = "N";
    public static final String FLAG_R = "R";
    public static final String FLAG_F = "F";
    public static final String FLAG_C = "C";
    public static final String FLAG_G = "G";
    public static final String FLAG_L = "L";
    public static final String FLAG_I = "I";
    public static final String FLAG_E = "E";
    public static final String FLAG_T = "T";
    public static final String FLAG_O = "O";
    public static final String FLAG_P = "P";
    public static final String ZERO = "0";
    public static final String DEFAULT_EVENT_CODE = "CFC";
    public static final String EOL_EVENT_CODE = "OON";
    public static final String FAKE_FSA_NUMBER = "99999";
    public static final String EIGHT_ZEROS = "00000000";
    public static final String TEN_ZEROES = "0000000000";
    public static final String TWO_ZEROS = "00";
    public static final String ORIGINAL = "ORIGINAL";
    public static final String ORIGINAL_POPULATION = "Original";

    public static final String B69_FILED_SELECTION_PROC = "CSGCSB69";
    public static final String CDSID_BLANK_EXCEPTION = "The CDSID can't be blank";

    public static final String PARSING_EXCEPTION = "Parsing Exception";
    public static final String DB_EXCEPTION = "Error while executing stored procedure";
    public static final String POPULATION_ALL_ERROR =
            "The ALL population can't be selected for FSA having ";
    public static final String POPULATION_ALL_EMPTY =
            "The ALL population can't be selected since there is no supplement";
    public static final String POPULATION_ALL_NO_REPORTS =
            "Please submit Targeting reports for any supplement once to get All population report";

    public static final String REPORT_BLOB_ERROR = "No Blob present";

    public static final String FORD_EMAIL_DOMAIN = "@ford.com";
    public static final String JOB_COMPLETION_MSG =
            "Your Job has been successfully submitted with Job Id ";
    public static final String FROM_KEYWORD = " FROM ";
    public static final String BATCH_CODE_MSG = " for the Batch Code ";
    public static final String SEARCH_VIN_LIST_STORE_PROC = "CSGCSD08";
    public static final String BATCH_CODE_ERROR = " Error executing job";

    public static final String ERROR_PARM1 = "ERROR_PARM1";
    public static final String ERROR_PARM2 = "ERROR_PARM2";
    public static final String LAUNCHED_STATUS = "LAUNCHED";

    public static final String IPARM2 = "IPARM2";
    public static final String IPARM3 = "IPARM3";
    public static final String IPARM4 = "IPARM4";

    public static final String OERR1 = "OERR1";
    public static final String OERR2 = "OERR2";

    public static final String LOCALFSA_SAVE_PROC = "CSGCSB47";
    public static final String COMMON_GO = "CSGCSB26";

    public static final String EMAIL_SUBJECT_FOR_CREATE_LFSA = "New Local FSA has been created";
    public static final String CREATE_LFSA_LOCAL_CONTENT = "New Local FSA has been created by Hub";

    public static final String MAIL_FROM = "gcampsys@ford.com";
    public static final String MAIL_SUBJECT = "FSA description retranslation required";
    public static final String MAIL_FOOTER = "\nRegards,\n";

    public static final String FORD_COM = "@ford.com";

    public static final String MODEL_YEAR_VECHICLE_INFO = "CSGCSB29";
    public static final String MODEL_YEAR_SAVE_PROC = "CSGCSB39";

    public static final String BATCH_BLOCKER_MESSAGE =
            "Batch Cannot Run because some other Blocking Batch is running";
    public static final String SUCCESS_DESCRIPTION = "Data Retrieved Successfully";
    public static final String SUBMIT_SUCCESS_DESCRIPTION = "Data Submitted Successfully";
    public static final String UPDATE_SUCCESS_DESCRIPTION = "Data Updated Successfully";
    public static final String SEGMENT_CREATION_SUCCESS_DESCRIPTION =
            "Segment created Successfully";
    public static final String VIEW_FSA_EXPIRATION = "CSGCSB28";
    public static final String UPDATE_FSA_EXPIRATION = "CSGCSB38";
    public static final String CLOSE_FSA_EXPIRATION = "CSGCSD06";
    public static final String GOVT_REPORT_PARAMS_INFO = "CSGCSB30";
    public static final String LOAD_NHTSA_DETAILS_PROC = "CSGCSB59";
    public static final String GOVTREPORTPARARAMS_SAVE_PROC = "CSGCSB40";
    public static final String SERPRO_RECALL_DETAILS_STORE_PROC = "CSGCSB60";
    public static final String MAINTAIN_GOV_DETAILS_INFO = "CSGCSB59";

    public static final String VIEW_SEGMENT_BY_PECENT_STORE_PROC = "CSGCSB43";
    public static final String SAVE_SEGMENT_BY_PECENT_STORE_PROC = "CSGCSB44";
    public static final String SEGMENT_PHASE_BY_PECENT_GO_STORE_PROC = "CSGCSB45";
    public static final String SEGMENT_PHASE_BY_PECENT_SAVE_STORE_PROC = "CSGCSB23";
    public static final String B58_SEGMENT_SUMMARY_PROC = "CSGCSB58";
    public static final String SEGMENT_SUMMARY_DELETE_BATCH_CODE = "029";
    public static final String SEGMENT_BY_ATTRIBUTE_STORE_PROC = "CSGCSB21";
    public static final String SEGMENTBYATTRIBUTE_SUBMIT_PROC = "CSGCSB36";
    public static final String SEGMENTBYATTRIBUTE_LOAD_PROC = "CSGCSB42";
    public static final String SEGMENTATION_CRITERIA_GO_STORE_PROC = "CSGCSB48";
    public static final String SEGMENTATION_CRITERIA_SAVE_STORE_PROC = "CSGCSB24";
    public static final String SEGMENTATION_CRITERIA_DELETE_STORE_PROC = "CSGCSB57";

    public static final String DELETE_SUCCESS_DESCRIPTION = "Data Deleted Successfully";
    public static final String DELETE_FAILURE_DESCRIPTION = "Data Deletion Successfully";
    public static final String PROCESS_MIG_VEH_BATCH_JOB_CODE = "021";
    public static final String REGIONAL_FILTER_GO = "CSGCSB02";
    public static final String REGIONAL_FILTER_GO1 = "CSGCSB92";
    public static final String REGIONAL_FILTERS_PROC = "CSGCSB03";
    public static final String RESULT_SET_4 = "#result-set-4";
    public static final String REGIONAL_FILTER_STATE_PROVINCE_STORE_PROC = "CSGCSB41";
    public static final String REGIONAL_FILTER_SAVE_STORE_PROC = "CSGCSB03";

    public static final String INCLUDE_REPORT_OPTION = "Include";
    public static final String EXLUDE_REPORT_OPTION = "Exclude";
    public static final String FORCE_COMPLETE_REPORT_OPTION = "Force Complete";

    public static final String GSAR_FILE_NAME_TEXT = "GSAR_";
    public static final String FAILURE_CODE_401 = "401";
    public static final String GSAR_DUPLICATE_FSA_CODE = "E0710";
    public static final String GSAR_UPLOAD_SUCCESS =
            "VIN(s) associated to GSAR Result Id have been uploaded successfully";
    public static final String GSAR_DUPLICATE_FSA_DESC =
            "This GSAR report id already used against the FSA, please select another FSA record to upload the GSAR report.";
    public static final String REPORT_ID = "reportId";
    public static final String GSAR_VINRPT = "SGCPF60_GSAR_VINRPT";

    public static final String INCL_EXCL = "SGCPD08_INCL_EXCL";

    public static final String SUBMIT_EXTRACT_BATCH_CODE = "001";
    public static final String TEXT_CONTENT_TYPE = "text/plain";
    public static final String CSV_CONTENT_TYPE = "text/csv";

    public static final String MANUAL_ADD_VIN_HUB_COUNTRY_PROP_KEY = "manualaddvin";
    public static final String REGIONAL_FILTERS_UNSUPPORTED_HUB_PROP_KEY =
            "regionalfilterunsupported";
    public static final String VIN_SERIAL_DELETE_COUNTRY_PROP_KEY = "vinserialdelete";

    public static final String AUTOMATIC_EMAIL_TEXT =
            "This Email was generated automatically by the GCamp System. Please do not reply to this email.";
    public static final String INSERT_SUCCESS = "Data Inserted Successfully";
    public static final String TANDEM_HUB_FIRST = "tandemfirst";
    public static final String TANDEM_HUB_SECOND = "tandemsecond";
    public static final String TANDEM_CREATE_ERROR_MESSAGE = "ERROR WHILE CREATING TANDEM LOCAL";

    public static final String PRODUCTION_PROFILE = "prod";

    public static final String OTA_UPDATE_SUCCESS = "OTA Indicator Updated Successfully";
    public static final String AUDIT_DATA = "CSGCSC54";
    public static final int SWAGGER_VALIDATION_MIN_INT_ZERO = 0;
    public static final String SWAGGER_ANY_CHARACTER_REGEX = "^[\\s\\S]*$";
    public static final String DATE_TIME_REGEX = "^[\\d\\w\\/\\s\\-\\.\\:]*$";
    public static final String DIGITS_REGEX = "^[\\d\\s\\,\\-\\%]*$";
    public static final String FORMATTED_DATE_REGEX = "(\\d{2}-\\w{3}-\\d{4})?";

    private CommonConstants() {}
}
