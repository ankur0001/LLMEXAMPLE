package com.ford.gcamp.targeting.prelaunchreports;

import java.io.ByteArrayInputStream;

import com.ford.cloudnative.base.api.StandardErrorResponse;
import com.ford.gcamp.targeting.common.api.CommonErrorResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.core.io.Resource;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import com.ford.gcamp.targeting.core.exception.GCAMPException;
import com.ford.gcamp.targeting.prelaunchreports.api.DownloadReportRequest;
import com.ford.gcamp.targeting.prelaunchreports.api.FsaGoRequest;
import com.ford.gcamp.targeting.prelaunchreports.api.LoadTargetingReportsResponse;
import com.ford.gcamp.targeting.prelaunchreports.api.ReportsResponse;
import com.ford.gcamp.targeting.prelaunchreports.api.ViewTargetReportRequest;
import com.ford.gcamp.targeting.prelaunchreports.api.ViewTargetReportResponse;

@RestController
@RequestMapping("/api/v1/targeting/reports")
@Validated
public class ViewTargetingReportsController {

	private ViewTargetingReportsService reportService;

	@Autowired
	public ViewTargetingReportsController(ViewTargetingReportsService reportService) {
		this.reportService = reportService;
	}

	@PreAuthorize("@authorizeService.isAuthorized('GCAMP:viewTargetRprtAction:loadTarget','execute')")
	@Operation(summary = "Load Targeting Reports", security = {
			@SecurityRequirement(name = "ADFS"),
			@SecurityRequirement(name = "AzureAD")
	})
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Load Targeting Reports request processed successfully",content = @Content(mediaType = "application/problem+json",schema = @Schema(implementation = LoadTargetingReportsResponse.class))),
			@ApiResponse(responseCode = "412", description = "Precondition Failed",  content = @Content(schema = @Schema(implementation = CommonErrorResponse.class))),
			@ApiResponse(responseCode = "default", description = "All Errors", content = @Content(schema = @Schema(implementation = StandardErrorResponse.class)))
	})
	@PostMapping(value = "/loadTargetingReports")
	public @ResponseBody ResponseEntity<LoadTargetingReportsResponse> loadTargetingReports(
			@RequestBody @Valid FsaGoRequest fsaGoRequestParm) throws GCAMPException {
		LoadTargetingReportsResponse response = reportService.loadAllReports(fsaGoRequestParm);
		return ResponseEntity.ok(response);

	}
	
	@PreAuthorize("@authorizeService.isAuthorized('GCAMP:viewTargetRprtAction:exp','execute')")
	@Operation(summary = "Load Exception Reports", security = {
			@SecurityRequirement(name = "ADFS"),
			@SecurityRequirement(name = "AzureAD")
	})
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Load Exception Reports request processed successfully",content = @Content(mediaType = "application/problem+json",schema = @Schema(implementation = LoadTargetingReportsResponse.class))),
			@ApiResponse(responseCode = "412", description = "Precondition Failed",  content = @Content(schema = @Schema(implementation = CommonErrorResponse.class))),
			@ApiResponse(responseCode = "default", description = "All Errors", content = @Content(schema = @Schema(implementation = StandardErrorResponse.class)))
	})
	@PostMapping(value = "/loadExceptionReports")
	public @ResponseBody ResponseEntity<LoadTargetingReportsResponse> loadExceptionReports(
			@RequestBody @Valid FsaGoRequest fsaGoRequestParm) throws GCAMPException {
		LoadTargetingReportsResponse response = reportService.loadReports(fsaGoRequestParm);
		return ResponseEntity.ok(response);
	}

	@PreAuthorize("@authorizeService.isAuthorized('GCAMP:viewTargetRprtAction:confirm','execute')")
	@Operation(summary = "Confirm Vehicle population", security = {
			@SecurityRequirement(name = "ADFS"),
			@SecurityRequirement(name = "AzureAD")
	})
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Confirm Vehicle Population request processed successfully",content = @Content(mediaType = "application/problem+json",schema = @Schema(implementation = ViewTargetReportResponse.class))),
			@ApiResponse(responseCode = "412", description = "Precondition Failed",  content = @Content(schema = @Schema(implementation = CommonErrorResponse.class))),
			@ApiResponse(responseCode = "default", description = "All Errors", content = @Content(schema = @Schema(implementation = StandardErrorResponse.class)))
	})
	@PostMapping(value = "/confirmVehiclePopulation")
	public @ResponseBody ResponseEntity<ViewTargetReportResponse> confirmVehiclePopulation(
			@RequestBody @Valid ViewTargetReportRequest viewTargetReportRequest) throws GCAMPException {
		ViewTargetReportResponse response = reportService.confirmPopulation(viewTargetReportRequest);
		return ResponseEntity.ok(response);

	}

	@PreAuthorize("@authorizeService.isAuthorized('GCAMP:viewTargetRprtAction:exp','execute')")
	@Operation(summary = "Download Reports", security = {
			@SecurityRequirement(name = "ADFS"),
			@SecurityRequirement(name = "AzureAD")
	})
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Download Reports request processed successfully",content = @Content(mediaType = "application/problem+json",schema = @Schema(implementation = Resource.class))),
			@ApiResponse(responseCode = "412", description = "Precondition Failed",  content = @Content(schema = @Schema(implementation = CommonErrorResponse.class))),
			@ApiResponse(responseCode = "default", description = "All Errors", content = @Content(schema = @Schema(implementation = StandardErrorResponse.class)))
	})
	@PostMapping(value = "/downloadReport")
	public @ResponseBody ResponseEntity<Resource> downloadReports(@RequestBody @Valid DownloadReportRequest downloadRequest)
			throws GCAMPException {
		ReportsResponse reportResponse = reportService.downloadReport(downloadRequest);
		byte[] reportData = reportResponse.getByteArry();
		InputStreamResource resource = new InputStreamResource(new ByteArrayInputStream(reportData));

		return ResponseEntity.ok().contentLength(reportData.length).body(resource);

	}
}
