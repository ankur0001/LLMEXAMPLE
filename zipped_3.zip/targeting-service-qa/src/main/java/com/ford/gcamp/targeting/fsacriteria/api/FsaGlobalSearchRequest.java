package com.ford.gcamp.targeting.fsacriteria.api;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class FsaGlobalSearchRequest {

    @NotNull
	@Size(min = 0, max = 10)
	@Pattern(regexp = "^[a-zA-Z\\d\\s]*$")
	@Schema(example = "15S01", description = "FSA number")
	private String fsaNumber;


    @NotNull
	@Schema(example="G" , description = "fsaType")
	@Size(min = 0, max = 1)
	@Pattern(regexp = "^[A-Za-z]$")
	private String fsaType;



	@Size(min = 0, max = 2)
	@Pattern(regexp = "^[a-zA-Z\\*\\s]*$")
	@Schema(example = "NA", description = "Hub code")
	private String hub;


	@Size(min = 0, max = 2)
	@Pattern(regexp = "^[a-zA-Z\\d\\*\\s]*$")
	@Schema(example = "ER", description = "search Type(ER,SC,SS,**)")
	private String searchType;


    @Size(min = 0, max = 1)
	@Pattern(regexp = "^[a-zA-Z\\*]*$")
	@Schema(example = "A", description = "Order type(Ascending or Descending)")
	private String orderType;

	@Size(min = 0, max = 1)
	@Pattern(regexp = "^[a-zA-Z\\*]*$")
	@Schema(example = "A", description = "result type")
	private String resultType;

	@Schema(description = "Description")
	@Size(min = 0, max = 254)
	@Pattern(regexp ="^[A-Za-z\\d\\s\\.\\,\\_\\-]*$")
	private String description;

	@Schema(description = "Description 2")
	@Size(min = 0, max = 254)
	@Pattern(regexp ="^[A-Za-z\\d\\s\\.\\,\\_\\-]*$")
	private String description2;


	@Size(min = 0, max = 1)
	@Pattern(regexp = "^[\\*\\+\\&]$")
	@Schema(example = "+", description = "descSerachCondition")
	private String descSearchCondition;

	@Schema(example = "I", description = "FSA Status I,C,L,C")
	@Size(min = 0, max = 1)
	@Pattern(regexp = "^[A-Za-z\\*]$")
	private String status;


	@Size(min=0, max = 11)
	@Pattern(regexp = "^[a-zA-Z\\d\\-]*$")
	@Schema(example = "31-Dec-9999", description = "search From Date")
	private String searchFromDate;


	@Size(min=0, max = 11)
	@Pattern(regexp = "^[a-zA-Z\\d\\-]*$")
	@Schema(example = "31-Dec-9999", description = "search To Date")
	private String searchToDate;
	
	
	
}
