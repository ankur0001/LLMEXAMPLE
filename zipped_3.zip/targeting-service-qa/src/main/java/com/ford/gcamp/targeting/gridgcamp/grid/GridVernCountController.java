package com.ford.gcamp.targeting.gridgcamp.grid;

import com.amazonaws.services.s3.model.S3ObjectSummary;
import com.ford.gcamp.targeting.common.CommonConstants;
import com.ford.gcamp.targeting.common.api.CommonResponse;
import com.ford.gcamp.targeting.common.api.ReportBatchStatusResponse;
import com.ford.gcamp.targeting.core.exception.GCAMPException;
import com.ford.gcamp.targeting.gridgcamp.GridGCampConstants;
import com.ford.gcamp.targeting.gridgcamp.gcamp.GridGCampService;
import com.ford.gcamp.targeting.gridgcamp.gcamp.api.GridVfdRequest;
import com.ford.gcamp.targeting.gridgcamp.gcamp.entity.GridVernData;
import com.ford.gcamp.targeting.gridgcamp.grid.api.AuditRequest;
import com.ford.gcamp.targeting.gridgcamp.grid.api.GridVernCountSendRequest;
import com.ford.gcamp.targeting.gridgcamp.grid.api.VehicleCountRegion;
import com.ford.gcamp.targeting.properties.ConfigProperties;
import com.ford.gcamp.targeting.vin.S3Service;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;


@RestController
@Slf4j
@RequestMapping(path = "/api/v1/targeting/gridgcamp/grid")
@Validated
public class GridVernCountController {

	private GridVernCountService gridVernCountService;

	private GridGCampService gridGCampService;
	private S3Service s3Service;

	private GridHistoryCountService gridHistoryCountService;
	@Autowired
	private ConfigProperties configProperties;


	public GridVernCountController(GridVernCountService gridVernCountService, GridGCampService gridGCampService,S3Service s3Service,
								   GridHistoryCountService gridHistoryCountService, ConfigProperties configProperties) {
		super();
		this.gridVernCountService = gridVernCountService;
		this.gridGCampService = gridGCampService;
		this.s3Service= s3Service;
		this.gridHistoryCountService = gridHistoryCountService;
		this.configProperties = configProperties;
	}

	@Operation(summary = "Sending the Vern Count to GRID System", description = "Sending the Vern Count to GRID System",security = {
			@SecurityRequirement(name = "ADFS"),
			@SecurityRequirement(name = "AzureAD")
	})
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Vern Records sends to GRID successful", content = @Content(mediaType = "application/problem+json",schema = @Schema(implementation = CommonResponse.class))),
			@ApiResponse(responseCode = "400", description = "Bad Request, missing required fields"),
			@ApiResponse(responseCode = "401", description = "Unauthorized"),
			@ApiResponse(responseCode = "403", description = "Forbidden"),
			@ApiResponse(responseCode = "404", description = "Not Found", content = @Content(schema = @Schema(implementation = CommonResponse.class))),
			@ApiResponse(responseCode = "406", description = "Invalid Response type"),
			@ApiResponse(responseCode = "405", description = "Invalid Method type"),
			@ApiResponse(responseCode = "412", description = "Precondition Failed", content = @Content(schema = @Schema(implementation = CommonResponse.class))),
			@ApiResponse(responseCode = "415", description = "Unsupported Media Type"),
			@ApiResponse(responseCode = "428", description = "Bad Request, missing required fields",content = @Content(array = @ArraySchema(schema = @Schema(implementation = CommonResponse.class)))),
			@ApiResponse(responseCode = "429", description = "Too many bad request"),
			@ApiResponse(responseCode = "500", description = "Internal Server Error") })
	@PostMapping(value = "/verncount/send")
	public ResponseEntity<CommonResponse> sendVernCountToGrid(
			@RequestBody @Valid GridVernCountSendRequest vernCountRequest) {
		GridVernData gridVernData = gridGCampService.getAssignedGridVernInfoBySupplement(
				Integer.parseInt(vernCountRequest.getGlobalFSANumber()), vernCountRequest.getSupplementCode());
		if (gridVernData == null) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND)
					.body(CommonResponse.builder().status(CommonConstants.FAILURE)
							.statusCode(String.valueOf(HttpStatus.NOT_FOUND.value()))
							.statusDescription("Grid Record not found").build());
		}
		CommonResponse response = gridVernCountService.sendVernCountToGrid(gridVernData, vernCountRequest);
		if (GridGCampConstants.GRID_VFD_REQ_RECEIVED
				.equalsIgnoreCase(StringUtils.trimToEmpty(gridVernData.getVfdRequestStatus()))) {
			gridGCampService.updateVfdReportRequestStatus(gridVernData.getGridVernId(), GridGCampConstants.GRID_VFD_REQ_PENDING);
		}
		return ResponseEntity.ok(response);
	}

	@GetMapping(value = "/{globalFSANumber}/{supplementCode}/verncount")
	@Operation(summary = "Get GRID Vern Count Details", description = "Getting GRID Vern Count Details",security = {
			@SecurityRequirement(name = "ADFS"),
			@SecurityRequirement(name = "AzureAD")
	})
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Vern Records sends to GRID successfull", content = @Content(mediaType = "application/problem+json",schema = @Schema(implementation = CommonResponse.class))),
			@ApiResponse(responseCode = "400", description = "Bad Request, missing required fields"),
			@ApiResponse(responseCode = "401", description = "Unauthorized"),
			@ApiResponse(responseCode = "403", description = "Forbidden"),
			@ApiResponse(responseCode = "404", description = "Not Found", content = @Content(schema = @Schema(implementation = CommonResponse.class))),
			@ApiResponse(responseCode = "406", description = "Invalid Response type"),
			@ApiResponse(responseCode = "405", description = "Invalid Method type"),
			@ApiResponse(responseCode = "412", description = "Precondition Failed", content = @Content(schema = @Schema(implementation = CommonResponse.class))),
			@ApiResponse(responseCode = "415", description = "Unsupported Media Type"),
			@ApiResponse(responseCode = "428", description = "Bad Request, missing required fields",content = @Content(array = @ArraySchema(schema = @Schema(implementation = CommonResponse.class)))),
			@ApiResponse(responseCode = "429", description = "Too many bad request"),
			@ApiResponse(responseCode = "500", description = "Internal Server Error") })
	public ResponseEntity<List<VehicleCountRegion>> getGridVernCountDetails(
			@Schema(type = "integer",example = "15543",description = "globalFSANumber")
			@PathVariable @Min(0) @Max(99999999) Integer globalFSANumber,
			@PathVariable @Size(min = 0, max = 2) 	@Schema(example = "AA", description = "Supplement Code")@Pattern(regexp = "^[A-Za-z\\d\\s\\*]*$") String supplementCode) {
		List<VehicleCountRegion> vernCountResponse = gridVernCountService.getVehicleCountRegions(globalFSANumber,
				supplementCode);
		return ResponseEntity.ok(vernCountResponse);
	}

	@Operation(summary = "Save Refresh Sold Unsold Count into GCAMP", description = "Update Refresh Sold Unsold Count",security = {
			@SecurityRequirement(name = "ADFS"),
			@SecurityRequirement(name = "AzureAD")
	})
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Update of Sold Unsold count successfull",content = @Content(mediaType = "application/problem+json",schema = @Schema(implementation = CommonResponse.class))),
			@ApiResponse(responseCode = "400", description = "Bad Request, missing required fields"),
			@ApiResponse(responseCode = "401", description = "Unauthorized"),
			@ApiResponse(responseCode = "403", description = "Forbidden"),
			@ApiResponse(responseCode = "404", description = "Not Found", content = @Content(schema = @Schema(implementation = CommonResponse.class))),
			@ApiResponse(responseCode = "406", description = "Invalid Response type"),
			@ApiResponse(responseCode = "405", description = "Invalid Method type"),
			@ApiResponse(responseCode = "412", description = "Precondition Failed", content = @Content(schema = @Schema(implementation = CommonResponse.class))),
			@ApiResponse(responseCode = "415", description = "Unsupported Media Type"),
			@ApiResponse(responseCode = "428", description = "Bad Request, missing required fields",content = @Content(array = @ArraySchema(schema = @Schema(implementation = CommonResponse.class)))),
			@ApiResponse(responseCode = "429", description = "Too many bad request"),
			@ApiResponse(responseCode = "429", description = "Too many bad request"),
			@ApiResponse(responseCode = "500", description = "Internal Server Error") })
	@PostMapping(value = "/soldunsold/refresh")
	public ResponseEntity<CommonResponse> refreshSoldUnsoldCount(@RequestBody @Valid GridVfdRequest gridVfdRequest)
			throws GCAMPException {
		log.info("Received request to refresh sold unsold count: {}", gridVfdRequest.toString());
		gridVernCountService.normalizeSupplementId(gridVfdRequest);
		ReportBatchStatusResponse reportAndBatchFlagResponse = gridVernCountService.getReportBatchStatus(gridVfdRequest.getGlobalFSANumber(), gridVfdRequest.getSupplementId());
		if (reportAndBatchFlagResponse.isBatchBlockFlag()) {
			return ResponseEntity
					.status(HttpStatus.PRECONDITION_FAILED)
					.body(CommonResponse.builder()
							.status(CommonConstants.FAILURE)
							.statusCode(String.valueOf(HttpStatus.PRECONDITION_FAILED.value()))
							.statusDescription(String.format(
									"Report cannot be submitted due to Batch Blocker. Targeting Extracts is in progress FSA Number: %s Supplement Population: %s",
									gridVfdRequest.getGlobalFSANumber(),
									gridVfdRequest.getSupplementId()
							))
							.build()
					);
		}
		if (gridVfdRequest.isVfdRequested()) {
            log.info("VFD request received for GridVfdRequest: {}", gridVfdRequest.isVfdRequested());
			gridGCampService.submitVfdReport(gridVfdRequest, GridGCampConstants.GRID_VFD_REQ_RECEIVED);
		}else{
            log.info("VFD request not received for GridVfdRequest: {}", gridVfdRequest.isVfdRequested());
        }
		CommonResponse response = gridVernCountService.refreshSoldUnsoldCount(gridVfdRequest);
		return ResponseEntity.ok(response);
	}

	@PostMapping("/files")
	@Operation(summary = "Get Files containing number", description = "Getting Files Containing Number",security = {
			@SecurityRequirement(name = "ADFS"),
			@SecurityRequirement(name = "AzureAD")
	})
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Update of Sold Unsold count successfull",content = @Content(mediaType = "application/problem+json",schema = @Schema(implementation = CommonResponse.class))),
			@ApiResponse(responseCode = "400", description = "Bad Request, missing required fields"),
			@ApiResponse(responseCode = "401", description = "Unauthorized"),
			@ApiResponse(responseCode = "403", description = "Forbidden"),
			@ApiResponse(responseCode = "404", description = "Not Found", content = @Content(schema = @Schema(implementation = CommonResponse.class))),
			@ApiResponse(responseCode = "406", description = "Invalid Response type"),
			@ApiResponse(responseCode = "405", description = "Invalid Method type"),
			@ApiResponse(responseCode = "412", description = "Precondition Failed", content = @Content(schema = @Schema(implementation = CommonResponse.class))),
			@ApiResponse(responseCode = "415", description = "Unsupported Media Type"),
			@ApiResponse(responseCode = "428", description = "Bad Request, missing required fields",content = @Content(array = @ArraySchema(schema = @Schema(implementation = CommonResponse.class)))),
			@ApiResponse(responseCode = "429", description = "Too many bad request"),
			@ApiResponse(responseCode = "429", description = "Too many bad request"),
			@ApiResponse(responseCode = "504", description = "Gateway Timeout"),
			@ApiResponse(responseCode = "500", description = "Internal Server Error") })
	public ResponseEntity<Map<String, Map<String, List<Map<String, String>>>>> getFilesContainingNumber(@RequestBody @Valid AuditRequest auditRequest) {
		Map<String, Map<String, List<Map<String, String>>>> data;
		if(!configProperties.isParallelProcessingFlag()) {
			List<S3ObjectSummary> filteredObjectSummaries = s3Service.getFilesContainingNumber(auditRequest.getFsaNumber());
			data = s3Service.retrieveDataFromXlsxFiles(filteredObjectSummaries);
		} else {
			data = gridHistoryCountService.getFilesContainingNumber(auditRequest.getFsaNumber());
		}
		return ResponseEntity.ok(data);
	}

	@GetMapping("/downloadFile/{fileName}")
	@Operation(summary = "Download Files", description = "Downloading Files",security = {
			@SecurityRequirement(name = "ADFS"),
			@SecurityRequirement(name = "AzureAD")
	})
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Update of Sold Unsold count successfull",content = @Content(mediaType = "application/octet-stream;charset=UTF-8",schema = @Schema(implementation = CommonResponse.class))),
			@ApiResponse(responseCode = "400", description = "Bad Request, missing required fields"),
			@ApiResponse(responseCode = "401", description = "Unauthorized"),
			@ApiResponse(responseCode = "403", description = "Forbidden"),
			@ApiResponse(responseCode = "404", description = "Not Found", content = @Content(schema = @Schema(implementation = CommonResponse.class))),
			@ApiResponse(responseCode = "406", description = "Invalid Response type"),
			@ApiResponse(responseCode = "405", description = "Invalid Method type"),
			@ApiResponse(responseCode = "412", description = "Precondition Failed", content = @Content(schema = @Schema(implementation = CommonResponse.class))),
			@ApiResponse(responseCode = "415", description = "Unsupported Media Type"),
			@ApiResponse(responseCode = "428", description = "Bad Request, missing required fields",content = @Content(array = @ArraySchema(schema = @Schema(implementation = CommonResponse.class)))),
			@ApiResponse(responseCode = "429", description = "Too many bad request"),
			@ApiResponse(responseCode = "429", description = "Too many bad request"),
			@ApiResponse(responseCode = "500", description = "Internal Server Error") })
	public ResponseEntity<byte[]> downloadFile(@PathVariable @Valid @NotNull  @Schema(description = "fileName",example= "20021_00_Targeting_Report.xlsx-0")
											   @Size(min = 5, max = 50, message = "length 50") @Pattern(regexp ="^|[A-Za-z\\d\\,\\.\\#\\_\\-\\s\\%\\+]*$", message = "File Name") String fileName) {
		return gridHistoryCountService.downloadFileFromFsaService(fileName);

	}

	@Operation(summary = "Process History Records Asynchronously", description = "Processing History Records Asynchronously",security = {
			@SecurityRequirement(name = "ADFS"),
			@SecurityRequirement(name = "AzureAD")
	})
	@ApiResponses(value = {
			@ApiResponse(responseCode = "202", description = "History record processing started asynchronously",content = @Content(mediaType = "application/problem+json",schema = @Schema(implementation = CommonResponse.class))),
			@ApiResponse(responseCode = "400", description = "Bad Request, missing required fields"),
			@ApiResponse(responseCode = "401", description = "Unauthorized"),
			@ApiResponse(responseCode = "403", description = "Forbidden"),
			@ApiResponse(responseCode = "404", description = "Not Found", content = @Content(schema = @Schema(implementation = CommonResponse.class))),
			@ApiResponse(responseCode = "406", description = "Invalid Response type"),
			@ApiResponse(responseCode = "405", description = "Invalid Method type"),
			@ApiResponse(responseCode = "412", description = "Precondition Failed", content = @Content(schema = @Schema(implementation = CommonResponse.class))),
			@ApiResponse(responseCode = "415", description = "Unsupported Media Type"),
			@ApiResponse(responseCode = "428", description = "Bad Request, missing required fields",content = @Content(array = @ArraySchema(schema = @Schema(implementation = CommonResponse.class)))),
			@ApiResponse(responseCode = "429", description = "Too many bad request"),
			@ApiResponse(responseCode = "429", description = "Too many bad request"),
			@ApiResponse(responseCode = "500", description = "Internal Server Error") })
	@GetMapping("/history")
	public ResponseEntity<String> saveHistoryRecord(@RequestParam("fileName") String fileName) throws InterruptedException {
		gridVernCountService.processHistoryRecordsAsync(fileName);
		return ResponseEntity.accepted().body("History record processing started asynchronously. Param: " + fileName);
	}


}
