package com.ford.gcamp.targeting.frozenvin.api;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class FrozenVINCountRequest {
    @NotNull
	@Size(min = 0, max = 10)
	@Pattern(regexp = "^[\\d\\s]*$")
	@Schema(example = "20405", description = "Global FSA Number")
	private String fsaNumber;


	@NotNull
	@Size(min = 0, max = 8)
	@Pattern(regexp = "^[a-zA-Z\\d\\-]*$")
	@Schema(example = "TDHARTI", description = "CDSID")
	private String cdsId;



	@Min(0)
	@Max(99999)
	@Schema(type = "Integer",example = "15S21", description = "localFsaNumber")
	private int localFsaNumber;

	@Size(min = 0, max = 3)
	@Pattern(regexp = "^[\\d]*$")
	@Schema(example = "24", description = "Batch Code")
	private String batchCode;

	@Schema(example = "00",description = "supplement Code")
	@Size(min = 0, max = 2, message = "length 1-2")
	@Pattern(regexp ="^[A-Za-z\\d]*$", message = "Supplement Code")
	private String supplementCode;


	@Schema(example = "G", description = "fsaType")
	@Size(min = 0, max = 1)
	@Pattern(regexp = "^[A-Za-z]*$", message = "FSA Type")
	private String fsaType;

	@NotNull
	@Schema(example = "UNACAN", description = "Batch Parameter")
	@Size(min = 0, max =250)
	@Pattern(regexp = "^[A-Za-z]*$")
	private String batchParameter;

	
}
