package com.ford.gcamp.targeting.fsacriteria;

import java.util.List;
import java.util.Map;

import com.ford.gcamp.targeting.fsacriteria.api.DynamicQueryMappingReq;
import com.ford.gcamp.targeting.fsacriteria.api.FsaCriteriaFilterFields;
import com.ford.gcamp.targeting.fsacriteria.api.FsaFilterCriteriaResponse;

public interface FsaCriteriaDAO {
	
	public Map<String, Object> modify(String inputParam1, String inputParam2);
	List<FsaCriteriaFilterFields> getFsaCriteriaFilters();
	Map<String, String> getFsaCriteriaGroupFilters();
	List<FsaFilterCriteriaResponse> getFsaModelBrandVehLinePlant(DynamicQueryMappingReq dynamicMappingRequest);
	List<FsaFilterCriteriaResponse> getFsaWersDetails(DynamicQueryMappingReq dynamicMappingRequest);


}
