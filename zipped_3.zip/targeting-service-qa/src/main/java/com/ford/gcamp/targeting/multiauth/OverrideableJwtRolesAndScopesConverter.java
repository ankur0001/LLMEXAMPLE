package com.ford.gcamp.targeting.multiauth;

import com.ford.cloudnative.base.app.security.resourceserver.JwtRolesAndScopesConverter;
import java.util.List;
import java.util.stream.Stream;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.lang.NonNull;
import org.springframework.security.authentication.AbstractAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationToken;

/**
 * Extends the JwtRolesAndScopesConverter from Ford's Cloud Native library to allow appending a
 * fixed set of roles for ADFS based on application properties. Entra ID tokens are processed
 * normally.
 *
 * <p>Determination of whether a token is from ADFS or Entra ID is based on the issuer claim in the
 * token.
 *
 * <p>If the issuer does not match either configured issuer, an IllegalArgumentException is thrown
 * upon attempting to convert a token.
 */
@Configuration
@Slf4j
public class OverrideableJwtRolesAndScopesConverter extends JwtRolesAndScopesConverter {
    private final MultiAuthConfigurationProperties properties;

    /**
     * Create a new converter with the given properties.
     *
     * @param properties configuration properties containing ADFS role overrides
     */
    @Autowired
    public OverrideableJwtRolesAndScopesConverter(MultiAuthConfigurationProperties properties) {
        super();
        this.properties = properties;
    }

    @Override
    public AbstractAuthenticationToken convert(@NonNull Jwt token) {
        String issuer = token.getIssuer().toString();
        AbstractAuthenticationToken authToken;
        if (properties.getAdfs().getIssuerUri().equals(issuer)) {
            authToken = convertAdfsToken(token);
        } else if (properties.getEntraId().getIssuerUri().equals(issuer)) {
            authToken = super.convert(token);
        } else {
            throw new IllegalArgumentException("Unsupported issuer " + issuer);
        }

        var clientId = "unknown";

        if (token.getClaims().containsKey("azp")) {
            clientId = token.getClaimAsString("azp");
        } else if (token.getClaims().containsKey("appid")) {
            clientId = token.getClaimAsString("appid");
        }

        log.info(
                "[Auth] {} {} {}",
                issuer.contains("adfs") ? "ADFS" : "Entra",
                clientId,
                authToken != null ? authToken.getAuthorities() : null);

        return authToken;
    }

    private JwtAuthenticationToken convertAdfsToken(Jwt token) {
        log.debug(
                "Converting ADFS JWT with roles override: {}",
                this.properties.getAdfs().getRoleOverrides());
        List<SimpleGrantedAuthority> authorities =
                Stream.concat(
                                this.properties.getAdfs().getRoleOverrides().stream()
                                        .map(role -> roleAuthorityPrefix.concat(role)),
                                this.properties.getAdfs().getScopeOverrides().stream()
                                        .map(scope -> scopeAuthorityPrefix.concat(scope)))
                        .map(SimpleGrantedAuthority::new)
                        .toList();
        return new JwtAuthenticationToken(token, authorities);
    }
}
