package com.ford.gcamp.targeting.reports.batch.api;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class VehicleLine extends GenericReportData {

    /**
     * Contains the hub description
     */
    private String hub;

    /**
     * Contains the local FSA
     */
    private String localFSA;

    /**
     * Contains the ROI description
     */
    private String roi;

    /**
     * Contains the Country name
     */
    private String country;

    /**
     * Contains the brand
     */
    private String brand;

    /**
     * Contains the vehicle line
     */
    private String vehLine;

    /**
     * Contains the model year
     */
    private String modelYear;

    /**
     * Contains the count for a particular set of keys.
     */
    private int count;
    
    
}
