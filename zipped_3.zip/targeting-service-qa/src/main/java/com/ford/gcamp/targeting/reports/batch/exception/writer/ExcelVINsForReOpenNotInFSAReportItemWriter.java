
package com.ford.gcamp.targeting.reports.batch.exception.writer;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import com.ford.gcamp.targeting.reports.batch.common.ReportGenerationUtil;
import org.apache.commons.collections4.ListUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.xssf.streaming.SXSSFSheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.item.Chunk;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.ford.gcamp.targeting.reports.batch.api.ExcelConfig;
import com.ford.gcamp.targeting.reports.batch.api.ReportMetaData;
import com.ford.gcamp.targeting.reports.batch.common.ReportCodeConstants;
import com.ford.gcamp.targeting.reports.batch.exception.GCAMPReportException;
import com.ford.gcamp.targeting.reports.batch.exception.api.TargetingExceptionReport;
import com.ford.gcamp.targeting.reports.batch.writer.GCAMPXSSFReportWriter;

@Component(ReportCodeConstants.T13 + "itemWriter")
@StepScope
public class ExcelVINsForReOpenNotInFSAReportItemWriter extends GCAMPXSSFReportWriter
		implements ItemWriter<TargetingExceptionReport> {

	private List<TargetingExceptionReport> vinsForReOpenNotInFSAList;

	@Value("#{jobParameters['reportMetaData']}")
	private String reportMetaDataString;

	private ReportMetaData rptData;

	@Value("${exception.report.xlsx.maxrecords}")
	private int xlsxMaxRecords;

	@Override
	public void write(Chunk<? extends TargetingExceptionReport> items) throws Exception {
		rptData = ReportGenerationUtil.getReportMetaDataObject(reportMetaDataString);
		vinsForReOpenNotInFSAList = new ArrayList<>(items.getItems());
		this.createReport(rptData);
	}

	@Override
	public void createWorksheet(SXSSFWorkbook hssfWorkbook, ReportMetaData metaData) throws GCAMPReportException {

		initializeWorkbook(hssfWorkbook);

		List<List<TargetingExceptionReport>> vinsForReOpenNotInFSAs = ListUtils.partition(
				vinsForReOpenNotInFSAList,
				xlsxMaxRecords);
		List<ExcelConfig> vinsForReOpenNotInFSAConfigList = loadConfigFile(ReportCodeConstants.T13,
				metaData.getSuppCode());
		int index = 1;
		for (List<TargetingExceptionReport> vinsForReOpenNotInFSA : vinsForReOpenNotInFSAs) {

			SXSSFSheet sheet = hssfWorkbook
					.createSheet(vinsForReOpenNotInFSAList.size() > xlsxMaxRecords
							? "VINs For ReOpen not in FSA" + StringUtils.SPACE + index
							: "VINs For ReOpen not in FSA");

			try {

				createProfile(sheet, metaData, "VINs For ReOpen not in FSA Report");

				setColumnWidth(sheet, vinsForReOpenNotInFSAConfigList);

				setColumnHeader(sheet, vinsForReOpenNotInFSAConfigList);

				setRowData(sheet, vinsForReOpenNotInFSAConfigList, vinsForReOpenNotInFSA);

			} catch (Exception e) {
				throw new GCAMPReportException("Error in processing VINs For ReOpen not in FSA report ", e);
			}
			index++;
		}

	}

	public void setXlsxMaxRecords(int xlsxMaxRecords) {
		this.xlsxMaxRecords = xlsxMaxRecords;
	}

	public void setReportData(ReportMetaData metadata) {
		this.rptData = metadata;
	}

}