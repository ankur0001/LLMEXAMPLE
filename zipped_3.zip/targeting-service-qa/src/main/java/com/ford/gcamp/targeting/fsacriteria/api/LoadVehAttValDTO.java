package com.ford.gcamp.targeting.fsacriteria.api;

import java.util.List;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import org.springframework.stereotype.Component;

import com.ford.gcamp.targeting.common.api.ResponseStatusDTO;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

@Component
@EqualsAndHashCode(callSuper=false)
@Getter
@Setter
public class LoadVehAttValDTO extends ResponseStatusDTO{
	

	@Size(min = 0, max = 250, message = "listVehAtt List")
	private List<@Valid VehicleAttriGrpReq> listVehAtt;

	@Size(min = 0, max = 250, message = "traceablityList List")
	private List<@Valid TraceablityList> traceablityList;
	
	public LoadVehAttValDTO(List<VehicleAttriGrpReq> listVehAtt) throws UnsupportedOperationException {
		//A public constructor - Sonar fix
	}
	
	public LoadVehAttValDTO() {

	}
		
}
