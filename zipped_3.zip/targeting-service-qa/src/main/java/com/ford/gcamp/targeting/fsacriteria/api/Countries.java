package com.ford.gcamp.targeting.fsacriteria.api;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor

public class Countries {
	@Size(min = 0, max = 3)
	@Pattern(regexp = "^[a-zA-Z\\*\\s]*$")
	@Schema(example = "CAN", description = "CountryCode")
	private String countryCode;

	@Size(min = 1, max = 64)
	@Pattern(regexp = "^[\\w\\s&\\.\\(\\)'\\*]*$")
	@Schema(example = "INDIA", description = "Country Description")
	private String label;
	
}
