package com.ford.gcamp.targeting.gridgcamp.gcamp.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import lombok.*;

@Setter
@Getter
@Entity
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "SGCPA11_FSA_TYPE")
public class FSATypeLookupData {

	@Id
	@Column(name = "GCPA11_FSA_TYPE_C")
	private String code;
	@Column(name = "GCPA11_LCFSA_GEN_C")
	private String gridCode;
	@Column(name = "GCPA11_FSA_TYPE_X")
	private String description;
	@Column(name = "GCPA11_TO_DATE_Y")
	private String toDate;
	
}
