package com.ford.gcamp.targeting.fsacriteria.api;

import com.ford.gcamp.targeting.common.api.CommonResponse;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.SuperBuilder;

@Setter
@Getter
@SuperBuilder(toBuilder = true)
@NoArgsConstructor
@AllArgsConstructor
public class DeleteConfirmResponse extends CommonResponse {

	@Size(min = 0, max = 1)
	@Pattern(regexp ="^|[A-Za-z]*$")
	@Schema(example= "D" , description = "Extract Flag")
	private String extractFlag;
}
