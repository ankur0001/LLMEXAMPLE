package com.ford.gcamp.targeting.gridgcamp.gcamp.entity;

import java.sql.Timestamp;
import java.time.LocalDate;
import java.util.Objects;

import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.Lob;
import jakarta.persistence.PostLoad;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;

import lombok.*;
import org.apache.commons.lang3.StringUtils;
import org.hibernate.annotations.UpdateTimestamp;

import com.ford.gcamp.targeting.common.CommonConstants;

@Setter
@Getter
@Entity
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "SGCPF59_GRID_VINRPT")
public class GridVernData {

	@EmbeddedId
	private GridVernId gridVernId;

	@Column(name = "GCPF59_GRID_VERN_C")
	private String vernNumber;
	@Column(name = "GCPF59_REQ_CDSID_C")
	private String requester;
	@Column(name = "GCPF59_REQ_Y")
	private String requestDate;
	@Column(name = "GCPF59_REQ_DEPT_X")
	private String requesterDept;
	@Column(name = "GCPF59_IMPL_TITLE_X")
	private String implementationDesc;
	@Column(name = "GCPF59_VIN_LIST_F")
	private String vinListAvailFlag;
	@Column(name = "GCPF59_VINLIST_FILE_X")
	@Lob
	private String vinListFileDetails;
	@Column(name = "GCPF59_FSA_ASSIGN_F")
	private String fsaAssignedFlag;
	@Column(name = "GCPF59_FRC_APPR_Y")
	private String frcApprovalDate;
	@Column(name = "GCPF59_CONCERN_DESC_X")
	private String concernDescription;
    @Column(name = "GCPF59_REQ_UPD_X")
	private String requestForUpdate;
	@Column(name = "GCPF59_FSA_CRIT_X")
	private String specialRequest;
	@Column(name = "GCPF59_GRID_HUB_C")
	private String initiatingHub;
	@Column(name = "GCPF59_GRID_HUB_X")
	private String initiatingHubDesc;
	@Column(name = "GCPA11_FSA_TYPE_C")
	private String globalFsaType;
	@Column(name = "GCPA15_GLOBL_FSA_R")
	private int globalFSANumber;
	@Column(name = "GCPF59_VER_APPR_F")
	private String vernStatus;
	@Column(name = "GCPF59_UPDATE_ID_C")
	private String updateId;
	@Setter(AccessLevel.NONE)
	@Getter(AccessLevel.NONE)	
	@Column(name = "GCPF59_UPDATE_S")
	@UpdateTimestamp
	private Timestamp updateDate;
	@Column(name = "GCPF59_STATUS_X")
	private String vernStatusDesc;
	@Column(name = "GCPF59_VINFILE_STA_X")
	private String vinFileStatus;
	@Column(name = "GCPF59_ACTIVE_F")
	private String extractCompleteFlag;
	@Column(name = "GCPF59_CONCERN_X")
	private String fsaTitle;
	@Column(name = "GCPF59_FRC_APPR_F")
	private String frcApprovedFlag;
	@Column(name = "GCPF59_REQ_Y", insertable = false, updatable = false)
	private LocalDate vernSubmittedDate;
	@Column(name = "GCPF59_VFD_WERS_X")
	private String wersCodes;
	@Column(name = "GCPF59_VFD_DATA_SET_N")
	private String vfdReportDataset;
	@Column(name = "GCPF59_VFD_REQSTA_X")
	private String vfdRequestStatus;

	@Column(name = "GCPF59_OTA_F")
	private String otaFlag;

	@Column(name = "GCPF59_TANDEM_F")
	private String isTandem;
	@Column(name = "GCPF59_ORIG_LCL_FSAS")
	private String originalFsas;
	@Column(name = "GCPF59_SUPP_FSAS")
	private String supplementFsas;
	@Column(name = "GCPF59_GLOBL_FSAS")
	private String globalFsas;


	@Transient
	private String reportId;
	@Transient
	private String comments;
	@Transient
	private String actionDate;

	@PrePersist
	@PreUpdate
	public void updateDefault() {

		frcApprovalDate = Objects.requireNonNullElse(frcApprovalDate, CommonConstants.INVALID_DATE);
		globalFsaType = Objects.requireNonNullElse(globalFsaType, StringUtils.EMPTY);
		extractCompleteFlag = Objects.requireNonNullElse(extractCompleteFlag, StringUtils.EMPTY);
		requestForUpdate = Objects.requireNonNullElse(requestForUpdate, StringUtils.EMPTY);
		vinFileStatus = Objects.requireNonNullElse(vinFileStatus, StringUtils.EMPTY);
		fsaTitle = Objects.requireNonNullElse(fsaTitle, StringUtils.EMPTY);
		wersCodes = Objects.requireNonNullElse(wersCodes, StringUtils.EMPTY);
		vfdReportDataset = Objects.requireNonNullElse(vfdReportDataset, StringUtils.EMPTY);
		vfdRequestStatus = Objects.requireNonNullElse(vfdRequestStatus, StringUtils.EMPTY);
		otaFlag = Objects.requireNonNullElse(otaFlag, CommonConstants.FLAG_N);
		isTandem = Objects.requireNonNullElse(isTandem, CommonConstants.FLAG_N);
		originalFsas = Objects.requireNonNullElse(originalFsas, StringUtils.EMPTY);
		supplementFsas = Objects.requireNonNullElse(supplementFsas, StringUtils.EMPTY);
		globalFsas = Objects.requireNonNullElse(globalFsas, StringUtils.EMPTY);

		frcApprovedFlag = StringUtils.isEmpty(frcApprovedFlag) ? CommonConstants.FLAG_N : frcApprovedFlag;
		vernStatus = StringUtils.isEmpty(vernStatus) ? CommonConstants.FLAG_T : vernStatus;
		fsaAssignedFlag = StringUtils.isEmpty(fsaAssignedFlag) ? CommonConstants.FLAG_N : fsaAssignedFlag;
		vernStatusDesc = StringUtils.isEmpty(vernStatusDesc) ? StringUtils.EMPTY : vernStatusDesc;
	}

	@PostLoad
	public void postLoad() {
		actionDate = updateDate.toString().substring(0, 10);
		globalFsaType = StringUtils.trimToEmpty(globalFsaType);
		originalFsas = originalFsas.trim();
		supplementFsas = supplementFsas.trim();
		globalFsas = globalFsas.trim();
	}
	
}
