package com.ford.gcamp.targeting.gridgcamp.gcamp.api;

import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class GridVernInfoExistsResponse {
	private boolean vernInfoExists;
}
