package com.ford.gcamp.targeting.fsacriteria.api;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class AttributeGroupingVO extends FsaVehicleCommonVO {

	@Schema(example = "", description = "attributeGroupCode")
	@Size(min=0, max = 10)
	@Pattern(regexp ="^[A-Za-z\\d\\s_.,'()\"\\=\\<>]*$")
	private String attributeGroupCode;

	@Schema(example = "", description = "attributeGroupDesc")
	@Size(min=0, max = 250)
	@Pattern(regexp ="^[A-Za-z\\d\\s_.,'()\"\\=\\<>\\/]*$")
	private String attributeGroupDesc;

	@Schema(example = "", description = "vehicleAttributeCode")
	@Size(min=0, max = 10)
	@Pattern(regexp ="^[A-Za-z\\d\\s_.,'()\"\\=\\<>]*$")
	private String vehicleAttributeCode;

	@Schema(example = "", description = "vehicleAttributeDesc")
	@Size(min=0, max = 250)
	@Pattern(regexp ="^[A-Za-z\\d\\s_.,'()\"\\=\\<>\\/]*$")
	private String vehicleAttributeDesc;

	@Schema(example = "", description = "vehicleAttrValue")
	@Size(min=0, max = 50)
	@Pattern(regexp ="^[A-Za-z\\d\\s_.,'()\"\\=\\<>\\-]*$")
	private String vehicleAttrValue;

	@Schema(example = "", description = "vehicleAttrBegin")
	@Size(min=0, max = 50)
	@Pattern(regexp ="^[A-Za-z\\d\\s_.,'()\"\\=\\<>\\-]*$")
	private String vehicleAttrBegin;

	@Schema(example = "", description = "vehicleAttrEnd")
	@Size(min=0, max = 50)
	@Pattern(regexp ="^[A-Za-z\\d\\s_.,'()\"\\=\\<>\\-]*$")
	private String vehicleAttrEnd;

	@Schema(types = {"string","null"},example = "=", description = "operator")
	@Size(min=0, max = 50)
	@Pattern(regexp ="^[A-Za-z\\d\\s_.,'()\"\\=\\<>\\!]*$")
	private String operator;
	
	
}
