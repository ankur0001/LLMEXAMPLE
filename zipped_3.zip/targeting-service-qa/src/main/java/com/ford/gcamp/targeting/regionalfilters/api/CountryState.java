package com.ford.gcamp.targeting.regionalfilters.api;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CountryState {
	@NotNull
	@Size(min = 1, max = 3)
	@Pattern(regexp = "^[a-zA-Z\\*\\s\\d]*$")
	@Schema(example = "CAN", description = "CountryCode")
	private String country;

	@NotNull
	@Size(min = 1, max = 2)
	@Pattern(regexp = "^[\\d]*$")
	@Schema(example = "03", description = "GeoCode")
	private String geoCode;

	@NotNull
	@Size(min = 1, max = 2)
	@Pattern(regexp = "^[a-zA-Z\\*]*$")
	@Schema(example = "CAN", description = "CountryCode")
	private String stateCode;
}
