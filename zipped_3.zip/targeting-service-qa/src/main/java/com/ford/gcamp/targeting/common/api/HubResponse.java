package com.ford.gcamp.targeting.common.api;

import java.util.List;

import com.ford.gcamp.targeting.common.Hubs;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class HubResponse extends ResponseStatusDTO{

	@Size(min = 0, max = 250, message = "Hubs List")
	private List<@Valid Hubs> hubs;
}
