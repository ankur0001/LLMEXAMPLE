package com.ford.gcamp.targeting.common.api;

import java.util.List;

import com.ford.gcamp.targeting.common.CommonConstants;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@NoArgsConstructor
public class GenericLookupResponse extends CommonResponse {
	@NotNull
	@Size(min= 0, max = 250)
	private List<@Valid GenericLookup> values;

	public void setValues(List<GenericLookup> values) {
		this.values = values;
		this.setStatus(CommonConstants.SUCCESS);
		this.setStatusCode(CommonConstants.SUCCESS_CODE);
		this.setStatusDescription(CommonConstants.SUCCESS_DESCRIPTION);
	}
}
