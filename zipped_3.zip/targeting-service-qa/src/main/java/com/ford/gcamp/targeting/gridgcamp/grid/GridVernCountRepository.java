package com.ford.gcamp.targeting.gridgcamp.grid;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ford.gcamp.targeting.gridgcamp.grid.entity.GridVernCountData;
import com.ford.gcamp.targeting.gridgcamp.grid.entity.GridVernCountId;

@Repository
public interface GridVernCountRepository extends JpaRepository<GridVernCountData, GridVernCountId>{

	List<GridVernCountData> findByGlobalFSANumber(int globalFSANumber);

	List<GridVernCountData> findByGlobalFSANumberAndSupplementCode(int globalFSANumber, String suppplementCode);

}
