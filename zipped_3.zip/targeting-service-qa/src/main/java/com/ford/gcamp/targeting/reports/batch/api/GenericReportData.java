package com.ford.gcamp.targeting.reports.batch.api;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class GenericReportData {
    private String supplementCode;
    private String supplementDescription;
    private String key;
    
}
