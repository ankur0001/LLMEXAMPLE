package com.ford.gcamp.targeting.gridgcamp.grid.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.IdClass;
import jakarta.persistence.Table;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Entity
@IdClass(PDCLookupId.class)
@Table(name = "SGCPF16_PDCVNGPCNT")
public class PDCLookupData {
	
	@Id
	@Column(name = "GCPF01_REPORT_ID_D")
	private String reportId;
	@Id
	@Column(name = "COUNTRY_NAME_X")
	private String countryName;
	@Id
	@Column(name = "GCPF16_PDC_TYPE_C")
	private String pdcType;
	@Id
	@Column(name = "GCPF16_PDC_C")
	private String pdcCode;
	@Id
	@Column(name = "GCPD22_VINGP_LBL_C")
	private String vinGroup;
	@Column(name = "GCPF16_PDC_X")
	private String pdcDescription;
	

}
