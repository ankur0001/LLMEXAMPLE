package com.ford.gcamp.targeting.common;


import java.text.SimpleDateFormat;
import java.util.Calendar;

/**
 * DateConvert - STATIC SINGLETON (use getInstance())
 * 
 * Convert the date format that is sent and received from
 * the strored procedure
 * 
 * @author: Y Chandrasekaran
 * @version 1.4
 * 
 */

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class DateConvert {
	
	/**
	 * Declare Preferred Date Format
	 */	
	
	private static final String PREFERRED_DATE_FORMAT ="dd-MMM-yyyy";
	private static final String INPUT_DATE_FORMAT ="yyyy-MM-dd";
	
	private static DateConvert instance = new DateConvert();
	
	private static final Logger LOGGER = LoggerFactory.getLogger(DateConvert.class);
	
	private static final String ERROR = "Parse of date failed.";
	
	/**
	* private Constructor
	*/
	private DateConvert() {
		super();
	}
	
	/**
	 * convert the date format from dd-"mon"-yyyy to "yyyy-mm-dd"	 
	 */
	public String formatInputDate(String strDate){
		//Mainframe Low date value
		String newdate="0001-01-01"; 
		String textDate = strDate;
		Date date = null;		
		//If a null value for a date is sent from the jsp then convert it into the Mainframe Low date value
		if((strDate!=null)&&(!("".equalsIgnoreCase(strDate.trim())))){
			
			SimpleDateFormat sdfInput = new SimpleDateFormat(PREFERRED_DATE_FORMAT); 
    		SimpleDateFormat sdfOutput = new SimpleDateFormat (INPUT_DATE_FORMAT); 
   	
			try{
    			date = sdfInput.parse(textDate);
    			// earlier this was outside catch block - Changed by Nitin Kumar
	         	newdate = sdfOutput.format(date);     			
			}catch( java.text.ParseException ex){
    			LOGGER.info(ERROR);
         	}

		}         
    	return newdate;  
	}	
	
	/**
	 * convert the date format from "yyyy-mm-dd" to dd-"mon"-yyyy
	 */
	public String formatOutputDate(String strDate){
		
		String newdate = ""; 
		String textDate = strDate;
		Date date = null;		

		//If a Low date value for a date is sent from the Mainframe then display a empty field on the jsp.
		if((strDate!=null)&&(!("0001-01-01".equalsIgnoreCase(strDate.trim())))&&(!("9999-12-31".equalsIgnoreCase(strDate.trim())))){
			
			SimpleDateFormat sdfInput = new SimpleDateFormat( INPUT_DATE_FORMAT); 
    		SimpleDateFormat sdfOutput = new SimpleDateFormat ( PREFERRED_DATE_FORMAT); 
   	
			try{
    			date = sdfInput.parse(textDate);
    			// earlier this was outside catch block - Changed by Nitin Kumar    			
	         	newdate = sdfOutput.format(date);     			
			}catch( java.text.ParseException ex){
    			LOGGER.info(ERROR);
         	}		

		}        
    	return newdate;  
	}		
		
	
	/**
	 * This method formats the date
	 * @param date 
	 * @return Returns a date
	 */
	public  String formatOutputDate(Date date){
		String dateString = null;
    	
    	if(date != null){    		
    		// Format the date.
 			SimpleDateFormat formatter = new SimpleDateFormat (PREFERRED_DATE_FORMAT);     				
     		dateString = formatter.format(date);
    	}
    	    	
    	return dateString;
    }
    
	public static String cnvrtCurrDtInMilliScndsFrmt() {
		Calendar now = Calendar.getInstance();
		long milliSec = now.getTimeInMillis();
		String dateFormat = "";
		try {
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd-HH:mm:ss.SSS");
			Date resultdate = new Date(milliSec);
			dateFormat = sdf.format(resultdate);
		} catch (NullPointerException pe) {
			LOGGER.info("Illegal date argument", pe);
		} catch (IllegalArgumentException iae) {
			LOGGER.info("Illegal date argument", iae);
		}
		return dateFormat;
	}
	
   /**
	* public Singleton 
	*/
	public static DateConvert getInstance() {
		return instance;
	}
					
}


