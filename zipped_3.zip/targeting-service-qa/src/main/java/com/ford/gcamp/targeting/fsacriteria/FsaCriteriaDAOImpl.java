package com.ford.gcamp.targeting.fsacriteria;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import com.ford.gcamp.targeting.common.CommonConstants;
import com.ford.gcamp.targeting.fsacriteria.api.DynamicQueryMappingReq;
import com.ford.gcamp.targeting.fsacriteria.api.FsaCriteriaFilterFields;
import com.ford.gcamp.targeting.fsacriteria.api.FsaFilterCriteriaResponse;
import com.ford.gcamp.targeting.logging.LogExecutionTime;

@Repository
public class FsaCriteriaDAOImpl implements FsaCriteriaDAO {

	private static final Logger LOGGER = LoggerFactory.getLogger(FsaCriteriaDAOImpl.class);

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Autowired
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

	@Value("${DB_OWNER}")
	private String ownerId;

	@Value("${db2.uncommit.read}")
	private String uncommitRead;

	@Value("${db2.mqt.modelbrand}")
	private String modelBrandMQT;

	@Value("${db2.mqt.wers}")
	private String wersMQT;

	MapSqlParameterSource createSqlParameterSource(String inputParamKey1, String inputParamVal1, String inputParamKey2,
			String inputParamVal2) {
		return new MapSqlParameterSource().addValue(inputParamKey1, inputParamVal1).addValue(inputParamKey2,
				inputParamVal2);
	}

	SimpleJdbcCall creatSimpleJdbcCall(String schemaName, String procedureName) {
		return new SimpleJdbcCall(jdbcTemplate).withSchemaName(schemaName).withProcedureName(procedureName);
	}

	@Override
	public Map<String, Object> modify(String inputParam1, String inputParam2) {
		LOGGER.info("modify input param1 {},{},{}", "[", inputParam1, "]");
		LOGGER.info("modify input param2 {},{},{}", "[", inputParam2, "]");
		SimpleJdbcCall simpleJdbcCall = null;
		SqlParameterSource sqlParameterSource = null;
		Map<String, Object> modifyMap = null;
		try {
			simpleJdbcCall = creatSimpleJdbcCall("SYSPROC", "CSGCSA63");
			sqlParameterSource = createSqlParameterSource(CommonConstants.INPUT_PARM1, inputParam1,
					CommonConstants.INPUT_PARM2, inputParam2);
			modifyMap = simpleJdbcCall.execute(sqlParameterSource);
		} catch (Exception e) {
			LOGGER.error(CommonConstants.EXCEPTION_OCCURED + " - modify() : ", e);
		}

		return modifyMap;
	}

	@Override
	public List<FsaCriteriaFilterFields> getFsaCriteriaFilters() {
		List<FsaCriteriaFilterFields> fsaCriteriaFilters = new ArrayList<>();
		StringBuilder sql=new StringBuilder();
		sql.append("SELECT GCPD02_FILTER_X,GCPD02_FILTER_C,GCPD03_FILTR_GRP_C FROM ").append(ownerId)
		.append(" SGCPD02_FILTER ").append(uncommitRead);
		
		jdbcTemplate.query(sql.toString(), new Object[] {},
				(rs, rowNum) -> fsaCriteriaFilters
						.add(new FsaCriteriaFilterFields(rs.getString("GCPD02_FILTER_C").trim(),
								rs.getString("GCPD02_FILTER_X").trim(), rs.getString("GCPD03_FILTR_GRP_C").trim())));
		return fsaCriteriaFilters;
	}

	@Override
	@LogExecutionTime
	public List<FsaFilterCriteriaResponse> getFsaModelBrandVehLinePlant(DynamicQueryMappingReq dynamicMappingRequest) {
		MapSqlParameterSource inQueryParams = new MapSqlParameterSource();
		StringBuilder sql = new StringBuilder();
		sql.append("SELECT GCPB11_POS_ID AS id, GCPB22_MODEL_YR_C  AS modelCode, GCPB03_BRAND_C AS brandCode, ");
		sql.append("GCPB03_BRAND_X AS brandDesc, GCPB11_VEH_LN_C as vehLine, GCPB22_VEH_LN_X AS vehLineDesc, ");
		sql.append("GCPB11_WERS_PLNT_C AS plant, GCPB11_WERS_PLNT_X AS plantDesc ");
		sql.append(" FROM  ");
		sql.append(ownerId);
		sql.append(modelBrandMQT);
		sql.append(nonWersMQTWhereClause(dynamicMappingRequest, inQueryParams) + " " + uncommitRead);

		LOGGER.info("MQT SQL {}", sql);
		return namedParameterJdbcTemplate.query(sql.toString(), inQueryParams,
				new BeanPropertyRowMapper<FsaFilterCriteriaResponse>(FsaFilterCriteriaResponse.class));
	}

	@Override
	@LogExecutionTime
	public List<FsaFilterCriteriaResponse> getFsaWersDetails(DynamicQueryMappingReq dynamicMappingRequest) {
		MapSqlParameterSource inQueryParams = new MapSqlParameterSource();
		StringBuilder sql = new StringBuilder();
		sql.append("SELECT GCPB12_POS_ID AS id, GCPB12_REL_ID  AS relatedId, GCPD02_FILTER_C AS wersCode, ");
		sql.append("GCPD02_FILTER_X AS wersDesc, GCPB12_WRSFTR as wersValue, GCPB08_WERS_FTR_X AS wersValueDesc ");
		sql.append(" FROM  ");
		sql.append(ownerId);
		sql.append(wersMQT);
		sql.append(wersWhereClause(dynamicMappingRequest, inQueryParams) + " " + uncommitRead);
		LOGGER.info("MQT SQL {}", sql);
		return namedParameterJdbcTemplate.query(sql.toString(), inQueryParams,
				new BeanPropertyRowMapper<FsaFilterCriteriaResponse>(FsaFilterCriteriaResponse.class));
	}

	private String nonWersMQTWhereClause(DynamicQueryMappingReq dynamicMappingRequest,
			MapSqlParameterSource inQueryParams) {
		StringBuilder sql = new StringBuilder();
		if (validateNoInput(dynamicMappingRequest)) {
			sql.append(" WHERE ");
			if (StringUtils.isNotBlank(dynamicMappingRequest.getModelYear())) {
				sql.append(" GCPB22_MODEL_YR_C IN(:models) AND");
				inQueryParams.addValue("models", Arrays.asList(dynamicMappingRequest.getModelYear().split(",")));
			}

			if (StringUtils.isNotBlank(dynamicMappingRequest.getBrand())) {
				sql.append(" GCPB03_BRAND_X IN(:brands) AND");
				inQueryParams.addValue("brands", Arrays.asList(dynamicMappingRequest.getBrand().split(",")));
			}

			if (StringUtils.isNotBlank(dynamicMappingRequest.getVehicleLine())) {
				sql.append(" GCPB11_VEH_LN_C IN(:vehLine) AND");
				inQueryParams.addValue("vehLine", Arrays.asList(dynamicMappingRequest.getVehicleLine().split(",")));
			}

			if (StringUtils.isNotBlank(dynamicMappingRequest.getAssemblyPlant())) {
				sql.append(" GCPB11_WERS_PLNT_C IN(:plants) AND");
				inQueryParams.addValue("plants", Arrays.asList(dynamicMappingRequest.getAssemblyPlant().split(",")));
			}

			if (StringUtils.endsWith(sql.toString(), "AND")) {
				sql.delete(sql.toString().lastIndexOf("AND"), sql.toString().length());
			}
		}

		return sql.toString();
	}

	private String wersWhereClause(DynamicQueryMappingReq dynamicMappingRequest, MapSqlParameterSource inQueryParams) {
		StringBuilder sql = new StringBuilder();
		if (validateNoInput(dynamicMappingRequest)) {
			sql.append(" WHERE ");
			if (StringUtils.isNotBlank(dynamicMappingRequest.getWers())) {
				sql.append(" GCPD02_FILTER_C IN(:wersValue) ");
				inQueryParams.addValue("wersValue", Arrays.asList(dynamicMappingRequest.getWers().split(",")));
			}
			if (StringUtils.isNotBlank(dynamicMappingRequest.getWersValue())) {
				sql.append(" GCPB12_WRSFTR IN(:wersValue) ");
				inQueryParams.addValue("wersValue", Arrays.asList(dynamicMappingRequest.getWersValue().split(",")));
			}
			if (StringUtils.endsWith(sql.toString(), "AND")) {
				sql.delete(sql.toString().lastIndexOf("AND"), sql.toString().length());
			}
		}

		return sql.toString();
	}

	private boolean validateNoInput(DynamicQueryMappingReq dynamicMappingRequest) {

		return (StringUtils.isNotBlank(dynamicMappingRequest.getModelYear())
				|| StringUtils.isNotBlank(dynamicMappingRequest.getBrand())
				|| StringUtils.isNotBlank(dynamicMappingRequest.getVehicleLine())
				|| StringUtils.isNotBlank(dynamicMappingRequest.getAssemblyPlant())
				|| StringUtils.isNotBlank(dynamicMappingRequest.getWers())
				|| StringUtils.isNotBlank(dynamicMappingRequest.getWersValue()));
	}

	@Override
	public Map<String, String> getFsaCriteriaGroupFilters() {
		Map<String, String> filterGroupMap = new HashMap<>();
		StringBuilder query = new StringBuilder();
		query.append("SELECT GCPD03_FILTR_GRP_C,GCPD03_FILTR_GRP_X FROM ").append(ownerId)
				.append(" SGCPD03_FILTER_GRP ").append(uncommitRead);
		jdbcTemplate.query(query.toString(), new Object[] {}, (rs, rowNum) -> filterGroupMap
				.put(rs.getString("GCPD03_FILTR_GRP_C").trim(), rs.getString("GCPD03_FILTR_GRP_X").trim()));
		return filterGroupMap;
	}

}
