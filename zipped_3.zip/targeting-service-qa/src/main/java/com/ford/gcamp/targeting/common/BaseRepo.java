package com.ford.gcamp.targeting.common;

import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;

import com.ford.gcamp.targeting.core.exception.GCAMPException;
import com.ford.gcamp.targeting.core.exception.GCAMPValidationException;

public abstract class BaseRepo {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    protected Object executeProcedure(String procedureName) throws GCAMPException {

	Map<String, Object> outputMap;
	SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withSchemaName("SYSPROC").withProcedureName(procedureName);

	// Set Row Mapper if any in implementation class
	setRowMapper(simpleJdbcCall);

	// Set Input Parameters
	SqlParameterSource sqlParameterSource = setInputParameters();
	if (sqlParameterSource == null) {
	    throw new GCAMPValidationException("The input parameter is missing");
	}
	// execute the procedure
	try {
	    outputMap = simpleJdbcCall.execute(sqlParameterSource);
	} catch (Exception e) {
	    throw new GCAMPException("Error in executing procedure: " + e.getMessage(), e);
	}
	// Check and throw error message from the execution if any
	checkforErrorMessage(outputMap);
	// Return the results and get it from respective implementation class
	return getResultSet(outputMap);

    }

    private void checkforErrorMessage(Map<String, Object> output) throws GCAMPException {
	String errorParam = "";
	if (output.keySet().contains("OUTPUT_ERR1")) {
	    errorParam = (String) output.get("OUTPUT_ERR1");
	} else if (output.keySet().contains("ERROR_PARM1")) {
	    errorParam = (String) output.get("ERROR_PARM1");
	}
	String statusInd = StringUtils.isNotBlank(errorParam) ? errorParam.substring(9, 10) : "N";
	if (statusInd != null && "Y".equalsIgnoreCase(statusInd)) {
	    String errorCode = errorParam.substring(37, 40);
	    String errorDesc = errorParam.substring(40, 150);
	    throw new GCAMPException(errorCode + errorDesc);
	}
    }

    protected abstract Object getResultSet(Map<String, Object> outputMap);

    protected abstract SqlParameterSource setInputParameters();

    protected abstract void setRowMapper(SimpleJdbcCall simpleJdbcCall);

}
