package com.ford.gcamp.targeting.common.api;

import java.util.List;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class RoiCountryResponse extends CommonResponse {

	@Size(min = 0, max = 250, message = "Hub Roi Countries")
	private List<@Valid HubTreeCurrent> hubRoiCountries;

}
