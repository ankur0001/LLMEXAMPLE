package com.ford.gcamp.targeting.config;

import net.javacrumbs.shedlock.core.LockProvider;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.sql.DataSource;

@Configuration
public class SchedulerConfig {

    @Value("${SCHEDULER_TABLE}")
    private String schedulerTable;

    private static final String COLUMN_NAME = "NAME";
    private static final String COLUMN_LOCK_UNTIL = "LOCK_UNTIL";
    private static final String COLUMN_LOCKED_AT = "LOCKED_AT";
    private static final String COLUMN_LOCKED_BY = "LOCKED_BY";

    @Bean
    public LockProvider lockProvider(@Qualifier("dataSource") DataSource dataSource) {
        return new SchedulerJdbcTemplateLockProvider(
                dataSource,
                schedulerTable,
                COLUMN_NAME,
                COLUMN_LOCK_UNTIL,
                COLUMN_LOCKED_AT,
                COLUMN_LOCKED_BY);
    }
}
