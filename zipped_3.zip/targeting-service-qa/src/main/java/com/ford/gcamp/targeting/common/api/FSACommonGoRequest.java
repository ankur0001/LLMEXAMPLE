package com.ford.gcamp.targeting.common.api;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.v3.oas.annotations.extensions.Extension;
import io.swagger.v3.oas.annotations.extensions.ExtensionProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class FSACommonGoRequest {


	@Size(min = 5, max = 6)
	@Pattern(regexp = "^\\d{2}[A-Za-z\\d]{2}\\d{1}\\d*$")
	@Schema(type="string", description = "FSA number",minLength=5,maxLength = 6, extensions = @Extension(properties = @ExtensionProperty(name = "x-42c-sample", value = "15311")))
	private String fsaNumber;



	@Schema(example = "G", description = "fsaType")
	@Size(min = 0, max = 1)
	@Pattern(regexp = "^[A-Za-z]$", message = "FSA Type")
	private String fsaType;



	@Schema(example = "00",description = "population")
	@Size(min = 0, max = 2, message = "length 1-2")
	@Pattern(regexp ="^[A-Za-z\\d\\s\\*]*$", message = "population Code")
	private String population;


	@Size(min = 0, max = 8)
	@Pattern(regexp = "^[a-zA-Z\\d\\-]*$")
	@Schema(example = "TDHARTI", description = "CDSID")
	private String cdsId;

	@Schema(example= "Y" , description = "Flag")
	@Size(min = 0, max = 1)
	@Pattern(regexp ="^[A-Za-z]*$")
	private String flag;

	@Size(min = 1, max = 500, message = "supplements")
	private List<@Size( min = 1,max = 2) @Pattern(regexp = "^[A-Za-z\\d\\s]*$") String> supplements;
}
