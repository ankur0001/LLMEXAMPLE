package com.ford.gcamp.targeting.fsacriteria;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import com.ford.gcamp.targeting.fsacriteria.api.DynamicQueryResponse;
import com.ford.gcamp.targeting.common.CommonConstants;
import com.ford.gcamp.targeting.common.TargetingUtil;
import com.ford.gcamp.targeting.fsacriteria.api.AssemblyPlantList;
import com.ford.gcamp.targeting.fsacriteria.api.AttributeGroupingList;
import com.ford.gcamp.targeting.fsacriteria.api.GCPFilterList;
import com.ford.gcamp.targeting.fsacriteria.api.ModelYearList;
import com.ford.gcamp.targeting.fsacriteria.api.VehicleBrandList;
import com.ford.gcamp.targeting.fsacriteria.api.VehicleTypeList;
import com.ford.gcamp.targeting.fsacriteria.api.WersValuesList;

@Component
public class DynamicNullSelectionUtil {

	public DynamicQueryResponse callStorProcIfRequestIsnull(Map<String, Object> map){

		List<GCPFilterList> listCPFilter = new ArrayList<>();
		List<VehicleTypeList> listVehicles = new ArrayList<>();
		List<VehicleBrandList> listBrands = new ArrayList<>();
		List<AttributeGroupingList> attributeLists = new ArrayList<>();
		List<ModelYearList> modelYearLists=new ArrayList<>();
		List<WersValuesList> nullWersList=new ArrayList<>();
		List<AssemblyPlantList> assemblyPlant = new ArrayList<>();
		
		@SuppressWarnings("unchecked")
		List<Map<String, Object>> vehicleData = (List<Map<String, Object>>) map.get("#result-set-3");
		if (vehicleData != null) {
		listVehicles=getVehicleList(vehicleData);
		}
		
		@SuppressWarnings("unchecked")
		List<Map<String, Object>> brandData = (List<Map<String, Object>>) map.get("#result-set-2");
		if(brandData!=null) {
			listBrands=getBrands(brandData);
		}
		@SuppressWarnings("unchecked")
		List<Map<String, Object>> assemblyPlantList = (List<Map<String, Object>>) map.get("#result-set-4");
		if (assemblyPlantList != null) {
			assemblyPlant=getAssemblyPlantList(assemblyPlantList);
		}
		
		@SuppressWarnings("unchecked")
		List<Map<String, Object>> gcpFilterMapList = (List<Map<String, Object>>) map.get("#result-set-5");
		if (gcpFilterMapList != null) {
			listCPFilter=getGcpFilterData(gcpFilterMapList);
		}
		@SuppressWarnings("unchecked")
		List<Map<String, Object>> attributeGroupig = (List<Map<String, Object>>) map.get("#result-set-6");
		if (attributeGroupig != null) {			
			for (Map<String, Object> map1 : attributeGroupig) {
				AttributeGroupingList attributeGroupList = new AttributeGroupingList();

				attributeGroupList.setGcpFilterGRPC((int) map1.get("GCPD03_FILTR_GRP_C"));
				attributeGroupList.setGcpFilterGRPX((String) map1.get("GCPD03_FILTR_GRP_X"));

				attributeLists.add(attributeGroupList);
				
			}
			if(!attributeLists.isEmpty()) {
				attributeLists.remove(0);
			}
			
		}
		
		@SuppressWarnings("unchecked")
		List<Map<String, Object>> modelYears = (List<Map<String, Object>>) map.get("#result-set-1");
		if (modelYears != null) {
			modelYearLists=getModelYears(modelYears);
		}
		
		 DynamicQueryResponse dynamicNullCheckResponse= new DynamicQueryResponse();
		dynamicNullCheckResponse.setModelYear(modelYearLists);
		dynamicNullCheckResponse.setAssemblyPlantList(assemblyPlant);
		dynamicNullCheckResponse.setVehicleTypeList(listVehicles);
		dynamicNullCheckResponse.setVehicleBrandLists(listBrands);
		dynamicNullCheckResponse.setGcpFilterList(listCPFilter);
		dynamicNullCheckResponse.setWersValue(nullWersList);
		if (dynamicNullCheckResponse.getModelYear() != null || dynamicNullCheckResponse.getVehicleBrandLists()!=null ) {
			dynamicNullCheckResponse.setStatusCode(CommonConstants.SUCCESS);
			dynamicNullCheckResponse.setStatusDescription(CommonConstants.SUCCESS_DESC);
		} else {
			dynamicNullCheckResponse.setStatusCode(CommonConstants.FAILURE);
			dynamicNullCheckResponse.setStatusDescription(CommonConstants.FAILURE_DESC);
		}
		return dynamicNullCheckResponse;
	}

	

	private List<ModelYearList> getModelYears(List<Map<String, Object>> modelYears) {
		String modelYr = null;
		List<ModelYearList> modelYearLists=new ArrayList<>();
		for (Map<String, Object> map1 : modelYears) {
			modelYr = String.valueOf(map1.get("GCPB22_MODEL_YR_C"));
			if (!("0   ".equals(modelYr))) {
				ModelYearList modelYearslist = new ModelYearList();
				modelYearslist.setModelYears((String) map1.get("GCPB22_MODEL_YR_C"));
				modelYearLists.add(modelYearslist);
			}
		}
		return modelYearLists;
	}



	private List<GCPFilterList> getGcpFilterData(List<Map<String, Object>> gcpFilterMapList) {
		List<GCPFilterList> listCPFilter = new ArrayList<>();
		for (Map<String, Object> map1 : gcpFilterMapList) {
			GCPFilterList gcpFilterList = new GCPFilterList();
			String wersDesc = StringUtils.trimToEmpty(String.valueOf(map1.get("GCPD02_FILTER_X")));
			String wersFamilyCode = StringUtils.trimToEmpty(String.valueOf(map1.get("GCPB09_WERS_FMLY_C")));
			gcpFilterList.setGcpFilterC((int) map1.get("GCPD02_FILTER_C"));
			gcpFilterList.setGcpFilterX(TargetingUtil.getWersDescWithFamilyCode(wersDesc,wersFamilyCode));
			gcpFilterList.setWersFamilyCode(wersFamilyCode);

			listCPFilter.add(gcpFilterList);
		}
		return listCPFilter;
	}



	private List<AssemblyPlantList> getAssemblyPlantList(List<Map<String, Object>> assemblyPlantList) {
		List<AssemblyPlantList> assemblyPlant = new ArrayList<>();
		for (Map<String, Object> map1 : assemblyPlantList) {
			AssemblyPlantList assPlantList = new AssemblyPlantList();
			String vehicleType=(String) map1.get("WRSFTR");
			String gcpFilteValueX=(String) map1.get("GCPB08_WERS_FTR_X");
			assPlantList.setWsrFilterCode((String) map1.get("WRSFTR"));
			assPlantList.setGcpWersFtrX(gcpFilteValueX.trim()+" ( "+vehicleType.substring(5)+" )");

			assemblyPlant.add(assPlantList);

		}
		return assemblyPlant;
	}



	private List<VehicleBrandList> getBrands(List<Map<String, Object>> brandData) {
		List<VehicleBrandList> listBrands = new ArrayList<>();
		for (Map<String, Object> map1 : brandData) {
			VehicleBrandList vehicleBrandList = new VehicleBrandList();
			vehicleBrandList.setBrandC(((String) map1.get("GCPB03_BRAND_C")).trim());
			vehicleBrandList.setBrandX(((String) map1.get("GCPB03_BRAND_X")).trim());

			listBrands.add(vehicleBrandList);

		}
		return listBrands;
	}

	private List<VehicleTypeList> getVehicleList(List<Map<String, Object>> vehicleData) {
		List<VehicleTypeList> listVehicles = new ArrayList<>();
		
			for (Map<String, Object> map1 : vehicleData) {
				VehicleTypeList vehicleTypeList = new VehicleTypeList();
				String vehicleLNC=((String) map1.get("GCPB13_VEH_TYP_C")).trim()+((String) map1.get("GCPB22_VEH_LN_C")).trim();
				 vehicleTypeList.setVehicleLnC(vehicleLNC);
				 vehicleTypeList.setVehicleLnX(((String)map1.get(("GCPB22_VEH_LN_X"))).trim()+" ("+vehicleLNC+")");
				listVehicles.add(vehicleTypeList);
			}
		
		return listVehicles;
	}
	
}
