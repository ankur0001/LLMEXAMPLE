package com.ford.gcamp.targeting.config;

import java.util.Arrays;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.web.firewall.StrictHttpFirewall;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class InterceptorConfig implements WebMvcConfigurer {

    private final RouteLoggingInterceptor routeLoggingInterceptor;

    public InterceptorConfig(RouteLoggingInterceptor routeLoggingInterceptor) {
        this.routeLoggingInterceptor = routeLoggingInterceptor;
    }

    @Bean
    public StrictHttpFirewall httpFirewall() {
        StrictHttpFirewall firewall = new StrictHttpFirewall();
        firewall.setAllowedHttpMethods(
                Arrays.asList("TRACE", "HEAD", "DELETE", "POST", "GET", "OPTIONS", "PATCH", "PUT"));
        return firewall;
    }

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(routeLoggingInterceptor);
        registry.addInterceptor(new MethodInterceptor()).addPathPatterns("/**");
    }
}
