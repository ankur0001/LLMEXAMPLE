package com.ford.gcamp.targeting.fsacriteria;

import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.ford.gcamp.targeting.common.CommonConstants;
import com.ford.gcamp.targeting.fsacriteria.api.FscCriteriaResponseGoDTO;


@Component
public class FsaListingCopyStoreProc {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(FsaListingCopyStoreProc.class);
	public FscCriteriaResponseGoDTO fsaCopySoreProc(Map<String, Object> fscCriteriaResponseMap) {
		
		FscCriteriaResponseGoDTO criteriaResp=new FscCriteriaResponseGoDTO();
		LOGGER.info("copy vin group response::{}", fscCriteriaResponseMap);
		String errorParm = (String) fscCriteriaResponseMap.get("ERROR_PARM1");
		LOGGER.info("errorParam::{}", errorParm);
		String statusInd = errorParm.substring(9, 10);
		if (statusInd != null && "Y".equalsIgnoreCase(statusInd)) {
			String errorCode = errorParm.substring(37, 40);
			String errorDesc = errorParm.substring(40, 150);
			criteriaResp.setStatus(CommonConstants.FAILURE);
			criteriaResp.setStatusCode(CommonConstants.FAILURE_CODE);
			criteriaResp.setStatusDescription(errorCode + errorDesc);
		} else {
			LOGGER.info("copy vin group response::{}", CommonConstants.SUCCESS);
			criteriaResp.setStatus(CommonConstants.SUCCESS);
			criteriaResp.setStatusCode(CommonConstants.SUCCESS_CODE);
			criteriaResp.setStatusDescription(CommonConstants.SUCCESS_DESC);
		}
		
		return criteriaResp;
	}

}
