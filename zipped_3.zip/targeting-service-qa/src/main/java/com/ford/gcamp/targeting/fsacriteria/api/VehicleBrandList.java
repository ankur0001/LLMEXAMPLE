package com.ford.gcamp.targeting.fsacriteria.api;

import com.fasterxml.jackson.annotation.JsonIgnore;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class VehicleBrandList {
	@NotNull
	@Size(min = 1, max = 1)
	@Pattern(regexp = "^[a-zA-Z]$")
	@Schema(example="F",description = "FORD")
	private String brandC;

	@NotNull
	@Size(min = 1, max = 20)
	@Pattern(regexp = "^[a-zA-Z\\!\\s]*$")
	@Schema(example="F",description = "FORD")
	private String brandX;
	@JsonIgnore
	private String modelYear;
	@JsonIgnore
	private String vehLine;
	@JsonIgnore
	private String vehLineDesc;
	
	
	public VehicleBrandList(String brandC, String brandX) {
		super();
		this.brandC = brandC;
		this.brandX = brandX;
	}
	
}
