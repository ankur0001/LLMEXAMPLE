package com.ford.gcamp.targeting.gridgcamp.grid;

import com.ford.gcamp.targeting.config.WebClientAdConfiguration;
import com.ford.gcamp.targeting.gridgcamp.grid.api.TargetingReportResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import org.springframework.web.util.UriBuilder;
import reactor.core.publisher.Mono;

import java.net.URI;
import java.util.*;
import java.util.function.Function;


@Slf4j
@Service
public class GridHistoryCountService {

    public static final String fsa = "fsa";
    public static final String REQUESTFROM = "gcamp";
    public static final String BEARER = "Bearer ";

    @Value("${spring.security.oauth2.client.registration.client-fsaservice-azure-ad.scope}")
    private String scope;

    private WebClient webClient;
    private final WebClientAdConfiguration webClientAdConfiguration;

    @Autowired
    public GridHistoryCountService(@Qualifier("fsaServiceWebClient")WebClient webClient, WebClientAdConfiguration webClientAdConfiguration) {
        this.webClient = webClient;
        this.webClientAdConfiguration = webClientAdConfiguration;
    }

    public Map<String, Map<String, List<Map<String, String>>>> getFilesContainingNumber(String fsaNumber) {
        log.info("Starting metadata processing for FSA number: {}", fsaNumber);

        List<TargetingReportResponse> targetingReports = fetchTargetingReportMetadata(fsaNumber);

        if (targetingReports.isEmpty()) {
            log.warn("No targeting reports metadata found for FSA number: {}. Returning empty map.", fsaNumber);
            return Collections.emptyMap();
        }

        Map<String, Map<String, List<Map<String, String>>>> dataForUi = new HashMap<>();

        for (TargetingReportResponse report : targetingReports) {
            String fileName = report.getTargetingFileName();

            if (fileName == null || fileName.trim().isEmpty()) {
                log.warn("Skipping report with empty 'targetingFileName'. Full report object: {}", report);
                continue;
            }

            if (!fileName.contains("-")) {
                log.debug("Skipping file '{}' as it does not contain '-' as per filtering rule.", fileName);
                continue;
            }
            processSingleTargetingReport(report, dataForUi);
        }

        log.info("Finished metadata processing for FSA number: {}. Returning {} files.", fsaNumber, dataForUi.size());
        return dataForUi;
    }

    private void processSingleTargetingReport(TargetingReportResponse report,
                                              Map<String, Map<String, List<Map<String, String>>>> dataForUi) {
        String fileName = report.getTargetingFileName();
        Map<String, List<Map<String, String>>> fileData = new HashMap<>();

        Map<String, String> detailsMap = new HashMap<>();
        detailsMap.put("timestamp", report.getUpdatedTimestamp() != null ? report.getUpdatedTimestamp() : "");
        detailsMap.put("uploadedby", report.getUploadedBy() != null ? report.getUploadedBy() : "");
        detailsMap.put("actionflag", report.getActionFlag() != null ? report.getActionFlag() : "");
        detailsMap.put("action", report.getAction() != null ? report.getAction() : "");
        detailsMap.put("vernNumber", report.getVernNumber() != null ? report.getVernNumber() : "");
        fileData.computeIfAbsent("details", k -> new ArrayList<>()).add(detailsMap); // This line is present

        Map<String, String> sumsMap = new HashMap<>();
        sumsMap.put("total", report.getTotalCount() != null ? String.valueOf(report.getTotalCount()) : "");
        fileData.computeIfAbsent("sums", k -> new ArrayList<>()).add(sumsMap);

        dataForUi.put(fileName, fileData);
    }

    private List<TargetingReportResponse> fetchTargetingReportMetadata(String fsaNumber) {


        try {
            log.info("Attempting to retrieve targeting reports metadata from FSA Service for FSA number: {}", fsaNumber);

            Function<UriBuilder, URI> uriFunction = uriBuilder -> uriBuilder
                    .path("/api/v1/targeting/reports/fsanumber/{fsanumber}")
                    .build(fsaNumber);

            return webClient.get()
                    .uri(uriFunction)
                    .header(HttpHeaders.AUTHORIZATION, BEARER + webClientAdConfiguration.getAccessToken(scope, fsa))
                    .retrieve()
                    .onStatus(HttpStatusCode::isError, clientResponse -> {
                        return clientResponse.bodyToMono(String.class)
                                .flatMap(errorBody -> {
                                    log.error("HTTP Error {} calling fetchTargetingReportMetadata from FSA Service for FSA number {}. Response: {}",
                                            clientResponse.statusCode(), fsaNumber, errorBody);
                                    return Mono.error(new RuntimeException("FSA Service metadata call failed. Status: " + clientResponse.statusCode()));
                                });
                    })
                    .bodyToFlux(TargetingReportResponse.class)
                    .collectList()
                    .block();
        } catch (Exception e) {
            log.error("Exception in calling FSA Service to get targeting reports metadata for FSA number {}: {}", fsaNumber, e.getMessage(), e);
            return Collections.emptyList();
        }
    }

    public ResponseEntity<byte[]> downloadFileFromFsaService(String fileName) {
        log.info("Initiating download for file '{}' from FSA Service.", fileName);
        try {
            Function<UriBuilder, URI> uriFunction = uriBuilder -> uriBuilder
                    .path("/api/v1/targeting/report/download")
                    .queryParam("fileName", fileName)
                    .build();
            byte[] fileBytes = webClient.get()
                    .uri(uriFunction)
                    .header(HttpHeaders.AUTHORIZATION, BEARER + webClientAdConfiguration.getAccessToken(scope, fsa))
                    .retrieve()
                    .bodyToMono(byte[].class) // Get the body directly as a byte array
                    .block();

            if (fileBytes == null) {
                log.error("Received null content for file '{}' from FSA service.", fileName);
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
            }

            log.info("Successfully received {} bytes for file '{}' from FSA Service.", fileBytes.length, fileName);
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
            headers.setContentDisposition(ContentDisposition.attachment().filename(fileName).build());
            headers.setContentLength(fileBytes.length);
            return new ResponseEntity<>(fileBytes, headers, HttpStatus.OK);

        } catch (WebClientResponseException e) {
            log.error("Error response from FSA Service for file '{}': Status {}, Body {}",
                    fileName, e.getStatusCode(), e.getResponseBodyAsString(), e);
            return ResponseEntity.status(e.getStatusCode()).body(e.getResponseBodyAsByteArray());
        } catch (Exception e) {
            log.error("An unexpected error occurred while trying to download file '{}' from FSA Service.", fileName, e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }
}
