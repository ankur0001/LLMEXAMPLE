package com.ford.gcamp.targeting.gsar;

import java.nio.charset.StandardCharsets;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.jdbc.core.support.SqlLobValue;
import org.springframework.jdbc.support.lob.DefaultLobHandler;
import org.springframework.jdbc.support.lob.LobHandler;
import org.springframework.stereotype.Repository;

import com.ford.gcamp.targeting.common.CommonConstants;
import com.ford.gcamp.targeting.gsar.api.GsarFileUploadRequest;
import com.ford.gcamp.targeting.gsar.api.GsarSearchRequest;
import com.ford.gcamp.targeting.gsar.api.ViewReports;
import com.ford.gcamp.targeting.gsar.entity.GcampSnapEntity;
import com.ford.gcamp.targeting.prelaunchreports.api.ReportsResponse;

import lombok.extern.slf4j.Slf4j;

@Repository
@Slf4j
public class GcampReportRepo {
	
	@Autowired
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;
	
	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Value("${DB_OWNER}")
	private String ownerId;

	@Value("${db2.uncommit.read}")
	private String uncommitRead;
	
	


	MapSqlParameterSource createSqlParameterSource(String inputParamKey1, String inputParamVal1, String inputParamKey2,
			String inputParamVal2, String inputParamKey3, String inputParamVal3) {
		return new MapSqlParameterSource().addValue(inputParamKey1, inputParamVal1).addValue(inputParamKey2,
				inputParamVal2).addValue(inputParamKey3, inputParamVal3);
	}
	
	MapSqlParameterSource createSqlParameterSource(String inputParamKey1, String inputParamVal1, String inputParamKey2,
			String inputParamVal2) {
		return new MapSqlParameterSource().addValue(inputParamKey1, inputParamVal1).addValue(inputParamKey2,
				inputParamVal2);
	}

	
	SimpleJdbcCall creatSimpleJdbcCall(String schemaName, String procedureName) {
		return new SimpleJdbcCall(jdbcTemplate).withSchemaName(schemaName).withProcedureName(procedureName);
	}

	public List<ViewReports> getGcampReport(String userhub) {
		SqlParameterSource parameters = new MapSqlParameterSource().addValue("userhub", userhub);
		StringBuilder sql = new StringBuilder();
		sql.append("SELECT GCPF60_USER_ID_C AS userId, GCPF60_RPT_D AS resultId, GCPF60_UNIQUE_REQUST_D AS uniqueId, ");
		sql.append("GCPF60_RPT_X AS description, GCPF60_RPT_RUN_Y as runDate, GCPF60_ROW_T AS count, ");
		sql.append("GCPF60_RPT_OPTION_F AS option,GCPF60_RPT_CRIT_X AS criteria, GCPF60_UPLOAD_F AS uploadFlag,");
		sql.append("GCPF60_DWLOAD_F AS downloadFlag, GCPF60_CREATE_Y AS createdDate ");
		sql.append(" FROM  ");
		sql.append(ownerId);
		sql.append(CommonConstants.GSAR_VINRPT);
		sql.append(" WHERE GCPE10_HUB_C = :userhub ");
		sql.append(" ORDER BY GCPF60_RPT_RUN_Y DESC ");
		sql.append(uncommitRead);
		log.info("getGcampReport SQL {} ", sql);
		return namedParameterJdbcTemplate.query(sql.toString(), parameters,
				new BeanPropertyRowMapper<ViewReports>(ViewReports.class));
	}
	
	public int deletePurgeGcampReport() {
		SqlParameterSource parameters = new MapSqlParameterSource();
		StringBuilder sql = new StringBuilder();
		sql.append("DELETE FROM ");
		sql.append(ownerId);
		sql.append(CommonConstants.GSAR_VINRPT);
		sql.append(" WHERE GCPF60_UPLOAD_F = 'N' AND GCPF60_CREATE_Y <=  CURRENT DATE - 6 MONTHS ");
		log.info("deletePurgeGcampReport SQL {} ", sql);
		return namedParameterJdbcTemplate.update(sql.toString(), parameters);
	}
	

	public ReportsResponse getDownloadVinDetails(int resultId, long uniqueId, String userHub) {
		ReportsResponse reportResponse = new ReportsResponse();
		MapSqlParameterSource parameters = new MapSqlParameterSource();
		parameters.addValue("resultId", resultId);
		parameters.addValue("hub", userHub);
		parameters.addValue("uId", uniqueId);
		StringBuilder sql = new StringBuilder();
		sql.append("SELECT GCPF60_RPT_DATA_X  ");
		sql.append(" FROM  ");
		sql.append(ownerId);
		sql.append(CommonConstants.GSAR_VINRPT);
		sql.append(" WHERE GCPF60_RPT_D =:resultId ");
		sql.append(" AND GCPE10_HUB_C =:hub");
		sql.append(" AND GCPF60_UNIQUE_REQUST_D= :uId ");
		sql.append(uncommitRead);
		log.info("getDownloadVinDetails SQL {}", sql);
		
		LobHandler lobHandler = new DefaultLobHandler();
		namedParameterJdbcTemplate.query(sql.toString(), parameters, new RowMapper<Object>() {
			@Override
			public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
				byte[] requestData = lobHandler.getBlobAsBytes(rs, "GCPF60_RPT_DATA_X");
				if (null != requestData && requestData.length > 0) {
					reportResponse.setByteArry(requestData);
				}
				return requestData;
			}
		});
		return reportResponse;
	}


	public int deleteGcampReport(int resultId, long uniqueId, String userHub) {
		StringBuilder sql = new StringBuilder();
		MapSqlParameterSource parameters = new MapSqlParameterSource();
		parameters.addValue(CommonConstants.REPORT_ID, resultId);
		parameters.addValue("hub", userHub);
		parameters.addValue("uniqueId", uniqueId);
		sql.append("DELETE FROM ");
		sql.append(ownerId);
		sql.append(CommonConstants.GSAR_VINRPT);
		sql.append(" WHERE GCPF60_RPT_D = :reportId ");
		sql.append(" AND GCPE10_HUB_C = :hub ");
		sql.append(" AND GCPF60_UNIQUE_REQUST_D = :uniqueId ");
		log.info("deleteGcampReport SQL {} for report id {}", sql, resultId);
		return namedParameterJdbcTemplate.update(sql.toString(), parameters);
		
	}
	
	public int updateGcampReport(GsarFileUploadRequest gsarFileUploadRequest) {
		StringBuilder sql = new StringBuilder();
		MapSqlParameterSource parameters = new MapSqlParameterSource();
		parameters.addValue(CommonConstants.REPORT_ID, gsarFileUploadRequest.getResultId());
		parameters.addValue("updatedBy", gsarFileUploadRequest.getCdsId());
		parameters.addValue("hub", gsarFileUploadRequest.getUserHub());
		parameters.addValue("uniqueId", gsarFileUploadRequest.getUniqueId());
		sql.append("UPDATE ");
		sql.append(ownerId);
		sql.append(CommonConstants.GSAR_VINRPT);
		sql.append(" SET GCPF60_UPLOAD_F = 'Y', ");
		sql.append("  GCPF60_UPDATE_Y = current date, ");
		sql.append("  GCPF60_UPDATE_ID_C = :updatedBy ");
		sql.append(" WHERE GCPF60_RPT_D = :reportId ");
		sql.append(" AND GCPF60_UNIQUE_REQUST_D = :uniqueId ");
		sql.append(" AND GCPE10_HUB_C = :hub "); 
		log.info("updateGcampReport SQL {} for report id {} , uId {} and hubCode {}", sql, gsarFileUploadRequest.getResultId(), gsarFileUploadRequest.getUniqueId(), gsarFileUploadRequest.getUserHub());
		return namedParameterJdbcTemplate.update(sql.toString(), parameters);
		
	}

	public int saveGsarReports(GcampSnapEntity gsarReports, GsarSearchRequest gsarSearchRequest, String vinDetail, String reportCode) {
		StringBuilder sql = new StringBuilder();
		byte[] vinData = vinDetail.getBytes(StandardCharsets.UTF_8);
		sql.append("INSERT INTO  ");
		sql.append(ownerId);
		sql.append(CommonConstants.GSAR_VINRPT+" (");
		sql.append("GCPF60_UNIQUE_REQUST_D, GCPF60_USER_ID_C,GCPF60_RPT_D,GCPF60_RPT_X,GCPF60_RPT_RUN_Y,");
		sql.append("GCPF60_ROW_T,GCPF60_RPT_OPTION_F,GCPF60_RPT_CRIT_X,GCPF60_UPLOAD_F,GCPF60_DWLOAD_F, ");
		sql.append("GCPE10_HUB_C,GCPF60_RPT_DATA_X,GCPF60_CREATE_Y,GCPF60_CREATE_ID_C,");
		sql.append("GCPF60_UPDATE_Y,GCPF60_UPDATE_ID_C) ");
		sql.append("values (:uniqueReqId,:gsarUserId,:reportId,:reqDesc,:rundate,:count,:rptOpt,:rptCrit,:upload,:download,");
		sql.append(":hub,:rptVinData,current date,:createBy,current date,:updatedBy)");

		MapSqlParameterSource parameters = new MapSqlParameterSource();
		parameters.addValue("uniqueReqId", gsarReports.getUniqueId());
		parameters.addValue("gsarUserId", gsarReports.getUserId());
		parameters.addValue(CommonConstants.REPORT_ID, gsarReports.getResultId());
		parameters.addValue("reqDesc", Optional.ofNullable(gsarReports.getReqName()).orElse(StringUtils.SPACE));
		parameters.addValue("rundate", gsarReports.getRunDate());
		parameters.addValue("count", gsarReports.getRowCount());
		parameters.addValue("rptOpt",reportCode);
		parameters.addValue("rptCrit", new SqlLobValue(gsarReports.getRptCrt(), new DefaultLobHandler()), Types.CLOB);
		parameters.addValue("upload", "N");
		parameters.addValue("download", "Y");
		parameters.addValue("hub", gsarSearchRequest.getHubCode());
		parameters.addValue("rptVinData", new SqlLobValue(vinData, new DefaultLobHandler()), Types.BLOB);
		parameters.addValue("createBy", gsarSearchRequest.getCdsId());
		parameters.addValue("updatedBy", gsarSearchRequest.getCdsId());
		
		
		return namedParameterJdbcTemplate.update(sql.toString(), parameters);
	}
	
	public Map<String, Object> uploadGsarFile(String inputParam1, String inputPAram2){
		Map<String, Object> maintenanceresponseMap = null;
		try {
			SimpleJdbcCall simpleJdbcCall = creatSimpleJdbcCall(CommonConstants.FSA_SCHEMA_NAME,
					CommonConstants.VIN_LIST_PROC);
			SqlParameterSource sqlParameterSource = createSqlParameterSource(CommonConstants.INPUT_PARM1,inputParam1,CommonConstants.INPUT_PARM2,inputPAram2,CommonConstants.INPUT_PARM3,"");
			log.info("input of uploadGsarFile submit {}", sqlParameterSource);
			maintenanceresponseMap = simpleJdbcCall.execute(sqlParameterSource);
			log.debug("response of uploadGsarFile procedure {}", maintenanceresponseMap);

		} catch (Exception e) {
			log.error(CommonConstants.EXCEPTION_OCCURED, e);
		}
		return maintenanceresponseMap;
	}
}	
		
			
