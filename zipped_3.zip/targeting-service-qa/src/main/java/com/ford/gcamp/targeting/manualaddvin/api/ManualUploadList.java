package com.ford.gcamp.targeting.manualaddvin.api;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ManualUploadList {
	
	private String segmentNum;
	private String vinGrpSeqNum;
	private String vinGrpLablCode;
	private String vinGrpDesc;
	private String vinCount;
}
