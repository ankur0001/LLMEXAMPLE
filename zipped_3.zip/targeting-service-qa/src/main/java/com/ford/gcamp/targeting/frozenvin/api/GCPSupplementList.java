package com.ford.gcamp.targeting.frozenvin.api;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class GCPSupplementList {

	private String gcpSuppCode;
	private String gcpsupDesc;
	
}
