package com.ford.gcamp.targeting.properties;

import java.util.Map;

import org.springframework.boot.context.properties.ConfigurationProperties;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@ConfigurationProperties(prefix = "segmentation.attribute.aps")
@Getter
@Setter
@NoArgsConstructor
public class SegmentAttributeApsAccess {
	private String pageName;
	private Map<String, String> resources;
}
