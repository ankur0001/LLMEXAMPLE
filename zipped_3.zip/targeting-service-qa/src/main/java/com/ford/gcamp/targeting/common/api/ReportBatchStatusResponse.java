package com.ford.gcamp.targeting.common.api;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ReportBatchStatusResponse {
    private boolean reportAvailableFlag;
    private boolean batchBlockFlag;
    private boolean deepLinkFlag;
}
