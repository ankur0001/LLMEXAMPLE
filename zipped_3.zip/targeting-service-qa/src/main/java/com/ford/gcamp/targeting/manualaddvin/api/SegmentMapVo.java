package com.ford.gcamp.targeting.manualaddvin.api;

import java.util.List;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class SegmentMapVo {

	private String segmentNumber;
	private String segmentDescription;
	private String launchedStatus;
	private List<ManualUploadList> manuluploadList;
	
}
