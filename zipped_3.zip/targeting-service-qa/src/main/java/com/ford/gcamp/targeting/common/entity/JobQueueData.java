package com.ford.gcamp.targeting.common.entity;


import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.IdClass;
import jakarta.persistence.Table;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Entity
@Table(name = "SGCPE12_JOB_QUEUE")
@IdClass(JobQueueDataId.class)
public class JobQueueData {

	@Id
	@Column(name = "GCPC01_BATCH_C")
	private String batchCode;
	@Id
	@Column(name = "GCPE12_JOB_QUE_R")
	private Integer jobQueueId;

	@Column(name = "GCPE12_PARMETERS_X")
	private String parameter;
	
}
