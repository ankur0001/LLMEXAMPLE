package com.ford.gcamp.targeting.fsacriteria.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.IdClass;
import jakarta.persistence.Table;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Entity
@IdClass(VinGroupLookupId.class)
@Table(name = "SGCPD22_GRP_LABEL")
public class VinGroupLookup {
	
	@Id
	@Column(name = "GCPA15_GLOBL_FSA_R")
	private int globalFSANumber;
	
	@Id
	@Column(name = "GCPD22_VINGP_LBL_C")
	private String vinGroupCode;
	
	@Column(name = "GCPD22_LBL_DESC_X")
	private String vinGroupDescription;

}
