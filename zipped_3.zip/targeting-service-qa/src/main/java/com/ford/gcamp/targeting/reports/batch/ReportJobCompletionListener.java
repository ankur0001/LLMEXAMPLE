package com.ford.gcamp.targeting.reports.batch;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.concurrent.TimeUnit;

import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.listener.JobExecutionListenerSupport;

import org.springframework.stereotype.Component;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class ReportJobCompletionListener extends JobExecutionListenerSupport {

	@Override
	public void afterJob(JobExecution jobExecution) {
		if (jobExecution.getStatus() == BatchStatus.COMPLETED) {
			LocalDateTime startTime = jobExecution.getCreateTime();
			LocalDateTime endTime = jobExecution.getEndTime();
			long diff = 0;
			if(endTime!=null) {
				diff = Duration.between(startTime, endTime).toMillis();
			}
			log.info("The Job {} has been completed successfully in {} seconds",
					jobExecution.getJobInstance().getJobName(), TimeUnit.SECONDS.convert(diff, TimeUnit.MILLISECONDS));

		}
	}
}
