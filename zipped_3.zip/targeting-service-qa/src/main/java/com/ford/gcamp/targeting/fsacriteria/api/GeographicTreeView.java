package com.ford.gcamp.targeting.fsacriteria.api;

import java.util.List;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Builder
public class GeographicTreeView {

	@Size(min = 1, max = 2)
	@Pattern(regexp = "^[\\d]*$")
	@Schema(example = "03", description = "GeoCode")
	private String geoCode;

	@Size(min = 0, max = 100)
	@Pattern(regexp = "^[a-zA-Z\\-\\s]*$")
	@Schema(example = "Stanford university", description = "label")
	private String label;

	@Size(min = 0, max = 250)
	private List<@Valid StateProvince> children;
}
