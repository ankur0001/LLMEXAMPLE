package com.ford.gcamp.targeting.frozenvin;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import com.ford.gcamp.targeting.common.CommonConstants;
import com.ford.gcamp.targeting.common.api.SuppPopulationVo;
import com.ford.gcamp.targeting.frozenvin.api.FrozenVin;
import com.ford.gcamp.targeting.frozenvin.api.FrozenVinResponseDTO;
import com.ford.gcamp.targeting.fsacriteria.AddModifyCriteriaRepoImpl;

@Repository
public class FrozenVinCountRepository {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(FrozenVinCountRepository.class);

	@Value("${DB_OWNER}")
	private String ownerId;
	
	@Autowired
	FrozenVinStorProc frozenVinProc;
	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	
	@Autowired
	AddModifyCriteriaRepoImpl addModifyCriteriaRepoImpl;
	
	MapSqlParameterSource createSqlParameterSource(String inputParamKey1, String inputParamVal1) {
		return new MapSqlParameterSource().addValue(inputParamKey1,inputParamVal1);
	}
	
	MapSqlParameterSource createSqlParameterSource(String inputParamKey1, String inputParamVal1, String inputParamKey2, String inputParamVal2) {
		return new MapSqlParameterSource().addValue(inputParamKey1,inputParamVal1)
				.addValue(inputParamKey2, inputParamVal2);
	}

	SimpleJdbcCall creatSimpleJdbcCall(String schemaName, String procedureName) {
		return new SimpleJdbcCall(jdbcTemplate).withSchemaName(schemaName)
				.withProcedureName(procedureName);
	}
	
	public FrozenVinResponseDTO getFSaHubDetails(FrozenVin frozenVin) {
		SimpleJdbcCall simpleJdbcCall;
		FrozenVinUtil frozenVinUtil = new FrozenVinUtil();
		FrozenVinResponseDTO frozenVinResponse = new FrozenVinResponseDTO();
		String supPopulation=null;
		try {
			if ("00".equalsIgnoreCase(frozenVin.getPopulation())) {
				simpleJdbcCall = creatSimpleJdbcCall(CommonConstants.FSA_SCHEMA_NAME, CommonConstants.FSA_FROZEN_B11);
				supPopulation="00";
			} else {
				simpleJdbcCall = creatSimpleJdbcCall(CommonConstants.FSA_SCHEMA_NAME, CommonConstants.FSA_FROZEN_B19);
				supPopulation=frozenVin.getPopulation();
			}
			String inputParam1 = frozenVinUtil.formInputParam(frozenVin.getFscNumber(), frozenVin.getOptRadio());
			String inputParam2 = frozenVinUtil.formInputParam2(frozenVin.getHub(), frozenVin.getPopulation());
			String filterByValue=frozenVin.getFilterBy();
			SqlParameterSource sqlParameterSource = createSqlParameterSource(CommonConstants.INPUT_PARM1, inputParam1,CommonConstants.INPUT_PARM2, inputParam2);
			Map<String, Object> mapResponse = simpleJdbcCall.execute(sqlParameterSource);

			frozenVinResponse = frozenVinProc.invokeStorProc(mapResponse,filterByValue,supPopulation);
			if(!frozenVinResponse.getStatusCode().equals(CommonConstants.FAILURE_CODE)&&frozenVinResponse.getFsaInfoVO().getGlobalFSANumber() != null) {
				String globalFsaNumber = frozenVinResponse.getFsaInfoVO().getGlobalFSANumber();

				List<SuppPopulationVo> populationList ;
				populationList = addModifyCriteriaRepoImpl.getSupplementVo(globalFsaNumber);

				frozenVinResponse.setSuppPopulation(populationList);
			}
		}catch(Exception e) {
			LOGGER.error(CommonConstants.EXCEPTION_OCCURED, e);
		}

		return frozenVinResponse;
	}
	public Map<String, Object> frozenHistoryData(String fsaGoParm) {
		SimpleJdbcCall simpleJdbcCall = null;
		Map<String, Object> historyOfFrozen = null;
		try {
			simpleJdbcCall = creatSimpleJdbcCall(CommonConstants.FSA_SCHEMA_NAME, CommonConstants.HISTORY_OF_FROZEN);

			SqlParameterSource sqlParameterSource = createSqlParameterSource("IPARM1", fsaGoParm);
					new MapSqlParameterSource().addValue("IPARM1", fsaGoParm);
					
			historyOfFrozen = simpleJdbcCall.execute(sqlParameterSource);

		} catch (Exception e) {
			LOGGER.error(CommonConstants.EXCEPTION_OCCURED +" - frozenHistoryData() :", e);
		}
		return historyOfFrozen;
	}
}
