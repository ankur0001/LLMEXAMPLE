package com.ford.gcamp.targeting.fsacriteria.api;

import java.util.List;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Builder
public class RegionalFilterRoiTreeView {
	@NotNull
	@Size(min = 0, max = 5)
	@Pattern(regexp = "^[a-zA-Z\\d\\*]*$")
	@Schema(example = "NR1", description = "Region of interest")
	private String roiCode;

	@Size(min = 0, max = 100)
	@Pattern(regexp = "^[a-zA-Z\\-\\s]*$")
	@Schema(example = "FORD - NORTH AMERICA", description = "ROI Description")
	private String label;

	@Size(min = 0, max = 500,  message = "regional filter country List")
	private List<@Valid RegionalFilterCountryTreeView> children;
}
