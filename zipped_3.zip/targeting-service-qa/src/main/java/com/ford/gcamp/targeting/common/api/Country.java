package com.ford.gcamp.targeting.common.api;

import java.util.List;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor

public class Country {
	@Size(min = 1, max = 3)
	@Pattern(regexp = "^[a-zA-Z\\*\\s]*$")
	@Schema(example = "USA", description = "Country ISO Code")
	private String countryCode;

	@Size(min = 1, max = 64)
	@Pattern(regexp = "^[a-zA-Z\\d\\s&().,\\-\\_\\&*']*$")
	@Schema(example = "INDIA", description = "Country Description")
	private String label;

	@Size(min = 0, max = 250, message = "Children List")
	private List<@Valid VinGroupDetail> children;

}
