package com.ford.gcamp.targeting.config;

import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.client.builder.AwsClientBuilder;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Configuration
public class GridS3Configuration {

	@Value("${grid.s3.accessKey}")
	private String accessKey;

	@Value("${GRID_S3}")
	private String secretKey;

	@Value("${grid.s3.bucketName}")
	private String bucket;

	@Value("${grid.s3.endpoint}")
	private String endpoint;

	@Bean
	public GridS3Storage gridS3Storage() {
		AmazonS3 client = AmazonS3ClientBuilder.standard().withPathStyleAccessEnabled(true)
				.withForceGlobalBucketAccessEnabled(true)
				.withCredentials(new AWSStaticCredentialsProvider(new BasicAWSCredentials(accessKey, secretKey)))
				.withEndpointConfiguration(
						new AwsClientBuilder.EndpointConfiguration(endpointUrlWithNamespace(endpoint, accessKey), null))
				.build();

		return new GridS3Storage(client, bucket, endpoint);
	}

	protected String endpointUrlWithNamespace(String endpoint, String accessKey) {
		Matcher matcher = Pattern.compile("(([^-]++){3}ns\\d\\d)-").matcher(accessKey);
		if (!matcher.find()) {
			return endpoint;
		}

		String namespace = matcher.group(1);
		return endpoint.contains("://s3-object") ? endpoint.replace("://", "://" + namespace + ".") : endpoint;
	}

	public static class GridS3Storage {
		private AmazonS3 client;
		private String endpoint;
		private String bucket;

		public GridS3Storage(AmazonS3 client2, String endpoint2, String bucket2) {
			this.endpoint = endpoint2;
			this.client = client2;
			this.bucket = bucket2;
		}

		public String getEndpoint() {
			return endpoint;
		}

		public void setEndpoint(String endpoint) {
			this.endpoint = endpoint;
		}

		public AmazonS3 getClient() {
			return client;
		}

		public void setClient(AmazonS3 client) {
			this.client = client;
		}

		public String getBucket() {
			return bucket;
		}

		public void setBucket(String bucket) {
			this.bucket = bucket;
		}
	}
	public String getAccessKey() {
		return accessKey;
	}

	public void setAccessKey(String accessKey) {
		this.accessKey = accessKey;
	}

	public String getSecretKey() {
		return secretKey;
	}

	public void setSecretKey(String secretKey) {
		this.secretKey = secretKey;
	}

	public String getBucket() {
		return bucket;
	}

	public void setBucket(String bucket) {
		this.bucket = bucket;
	}

	public String getEndpoint() {
		return endpoint;
	}

	public void setEndpoint(String endpoint) {
		this.endpoint = endpoint;
	}
}