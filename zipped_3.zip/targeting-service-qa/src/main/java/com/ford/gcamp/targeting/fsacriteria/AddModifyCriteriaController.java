package com.ford.gcamp.targeting.fsacriteria;

import com.ford.cloudnative.base.api.StandardErrorResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.WebRequest;
import com.ford.gcamp.targeting.common.api.CommonResponse;
import com.ford.gcamp.targeting.common.api.FSACommonGoRequest;
import com.ford.gcamp.targeting.common.api.FSATypesResponse;
import com.ford.gcamp.targeting.common.api.FscCriteriaRequest;
import com.ford.gcamp.targeting.common.api.GenericLookupResponse;
import com.ford.gcamp.targeting.common.api.HubResponse;
import com.ford.gcamp.targeting.core.exception.GCAMPException;
import com.ford.gcamp.targeting.fsacriteria.api.DeleteConfirmResponse;
import com.ford.gcamp.targeting.fsacriteria.api.DeleteFsaInfoReq;
import com.ford.gcamp.targeting.fsacriteria.api.FsaCriteriaParamRequest;
import com.ford.gcamp.targeting.fsacriteria.api.FsaDeleteResponseDTO;
import com.ford.gcamp.targeting.fsacriteria.api.FsaGlobalSearchDTO;
import com.ford.gcamp.targeting.fsacriteria.api.FsaGlobalSearchRequest;
import com.ford.gcamp.targeting.fsacriteria.api.FscCriteriaResponseGoDTO;
import com.ford.gcamp.targeting.fsacriteria.api.LoadFsaResponseDTO;
import com.ford.gcamp.targeting.fsacriteria.api.LoadSelectCounValDTO;
import com.ford.gcamp.targeting.fsacriteria.api.LoadStateProvinceDTO;
import com.ford.gcamp.targeting.fsacriteria.api.LoadVehAttValDTO;
import com.ford.gcamp.targeting.fsacriteria.api.VinGroupRegionalFilterResponse;
import com.ford.gcamp.targeting.logging.LogExecutionTime;
import io.micrometer.core.instrument.util.StringUtils;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/api/v1/targeting")
@Validated
public class AddModifyCriteriaController {

	@Autowired
	private AddModifyCriteriaService addModifyCriteriaService;
	@Autowired
	LoadFsaResponseDTO loadFsaResponseDto;
	@Autowired
	LoadVehAttValDTO vehicleAttributeResponseDto;
	@Autowired
	LoadStateProvinceDTO loadStateProvinceDTO;
	@Autowired
	LoadSelectCounValDTO selectCounResp;
	@Autowired
	FsaGlobalSearchDTO fsaGlobalSearchDto;
	
	@Autowired
	FSACriteriaRegionalFilterService fsaCriteriaRegionalFilterService;

	private static final Logger LOGGER = LoggerFactory.getLogger(AddModifyCriteriaController.class);

	@PreAuthorize("@authorizeService.isAuthorized('GCAMP:fsaCriteria:go','execute')")
	@Operation(summary = "FSC Search", security = {
			@SecurityRequirement(name = "ADFS"),
			@SecurityRequirement(name = "AzureAD")
	})
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "FSC Search request processed successfully",content = @Content(mediaType = "application/problem+json",schema = @Schema(implementation = FscCriteriaResponseGoDTO.class))),
			@ApiResponse(responseCode = "default", description = "All Errors", content = @Content(schema = @Schema(implementation = StandardErrorResponse.class)))
	})
	@PostMapping("/fscsearch")
	public ResponseEntity<FscCriteriaResponseGoDTO> fscCriteriaSearch(
			@RequestBody @Valid final FscCriteriaRequest fscCriteriaRequest) {
		FscCriteriaResponseGoDTO fscCriteriaGoDto = new FscCriteriaResponseGoDTO();
		if (fscCriteriaRequest != null && StringUtils.isNotEmpty(fscCriteriaRequest.getOptRadio())) {
			fscCriteriaGoDto = addModifyCriteriaService.getFscSearchResult(fscCriteriaRequest);
		}
		return ResponseEntity.ok(fscCriteriaGoDto);
	}
	@PreAuthorize("@authorizeService.isAuthorized('GCAMP:fsaCriteria:go','execute')")
	@GetMapping("/getIntialLoadData")
	@Operation(summary = "Initial load", security = {
			@SecurityRequirement(name = "ADFS"),
			@SecurityRequirement(name = "AzureAD")
	})
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Initial Load request processed successfully",content = @Content(mediaType = "application/problem+json",schema = @Schema(implementation = LoadFsaResponseDTO.class))),
			@ApiResponse(responseCode = "default", description = "All Errors", content = @Content(schema = @Schema(implementation = StandardErrorResponse.class)))
	})
	@LogExecutionTime
	public ResponseEntity<LoadFsaResponseDTO> getFormData() {
		loadFsaResponseDto = addModifyCriteriaService.getFscFormDetails();
		return ResponseEntity.ok(loadFsaResponseDto);
	}


	@PreAuthorize("@authorizeService.isAuthorized('GCAMP:fsaCriteria:go','execute')")
	@Operation(summary = "Get Query For Veh Attribute", security = {
			@SecurityRequirement(name = "ADFS"),
			@SecurityRequirement(name = "AzureAD")
	})
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Query For vehicle Attribute request processed successfully",content = @Content(mediaType = "application/problem+json",schema = @Schema(implementation = LoadVehAttValDTO.class))),
			@ApiResponse(responseCode = "default", description = "All Errors", content = @Content(schema = @Schema(implementation = StandardErrorResponse.class)))
	})
	@GetMapping("/getQueryForVehAtt/{attrGrpId}")
	@LogExecutionTime
	public ResponseEntity<LoadVehAttValDTO> getQueryForVehAtt(@PathVariable @NotNull
																  @Size(min = 0, max = 9)
																  @Pattern(regexp ="^[\\d]*$", message = "attribute Code")
																  @Schema(example= "19" ,description = "attribute Grp Id")
																  String attrGrpId) {
		vehicleAttributeResponseDto = addModifyCriteriaService.loadDynamicQueryDataForVehAtt(attrGrpId);
		return ResponseEntity.ok(vehicleAttributeResponseDto);
	}

	@PreAuthorize("@authorizeService.isAuthorized('GCAMP:fsaCriteria:save','execute')")
	@Operation(summary = "Save FsaList", security = {
			@SecurityRequirement(name = "ADFS"),
			@SecurityRequirement(name = "AzureAD")
	})
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Save FsaList request processed successfully",content = @Content(mediaType = "application/problem+json",schema = @Schema(implementation = CommonResponse.class))),
			@ApiResponse(responseCode = "default", description = "All Errors", content = @Content(schema = @Schema(implementation = StandardErrorResponse.class)))
	})
	@PostMapping("/saveFsaListData")
	public ResponseEntity<CommonResponse> saveFSAsearList(@RequestBody @Valid final FsaCriteriaParamRequest fsaCriteriaParam)
			throws GCAMPException {
		CommonResponse commonResponse = addModifyCriteriaService.saveFSACriteriaList(fsaCriteriaParam);
		return ResponseEntity.ok(commonResponse);
	}

	@PreAuthorize("@authorizeService.isAuthorized('GCAMP:fsaCriteria:copy','execute')")
	@Operation(summary = "Copy FSAList Data", security = {
			@SecurityRequirement(name = "ADFS"),
			@SecurityRequirement(name = "AzureAD")
	})
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Copy FSAList Data request processed successfully",content = @Content(mediaType = "application/problem+json",schema = @Schema(implementation = FscCriteriaResponseGoDTO.class))),
			@ApiResponse(responseCode = "default", description = "All Errors", content = @Content(schema = @Schema(implementation = StandardErrorResponse.class)))
	})
	@PostMapping("/copyFsaListData")
	public ResponseEntity<FscCriteriaResponseGoDTO> copyFSAsearList(
			@RequestBody @Valid FsaCriteriaParamRequest fsaCriteriaParam) {
		FscCriteriaResponseGoDTO fscCriteriaGoDto = new FscCriteriaResponseGoDTO();
		if (fsaCriteriaParam != null) {
			fscCriteriaGoDto = addModifyCriteriaService.copyFSACriteriaList(fsaCriteriaParam);
		}
		return ResponseEntity.ok(fscCriteriaGoDto);
	}

	@PreAuthorize("@authorizeService.isAuthorized('GCAMP:fsaCriteria:delete','execute')")
	@Operation(summary = "Delete FSAList Data", security = {
			@SecurityRequirement(name = "ADFS"),
			@SecurityRequirement(name = "AzureAD")
	})
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Delete FSAList Data request processed successfully",content = @Content(mediaType = "application/problem+json",schema = @Schema(implementation = FsaDeleteResponseDTO.class))),
			@ApiResponse(responseCode = "default", description = "All Errors", content = @Content(schema = @Schema(implementation = StandardErrorResponse.class)))
	})
	@PostMapping("/deleteFsaListData")
	public ResponseEntity<FsaDeleteResponseDTO> deleteFSAsearList(
			@RequestBody @Valid final FsaCriteriaParamRequest fsaCriteriaParam) {
		FsaDeleteResponseDTO responseDto = new FsaDeleteResponseDTO();
		if (fsaCriteriaParam != null) {
			responseDto = addModifyCriteriaService.deleteFSACriteriaList(fsaCriteriaParam);
		}

		return ResponseEntity.ok(responseDto);
	}

	@PreAuthorize("@authorizeService.isAuthorized('GCAMP:fsaCriteria:delete','execute')")
	@Operation(summary = "Delete FSAInfo", security = {
			@SecurityRequirement(name = "ADFS"),
			@SecurityRequirement(name = "AzureAD")
	})
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Delete FSAInfo request processed successfully",
					content = @Content(mediaType = "application/problem+json",schema = @Schema(implementation = FsaDeleteResponseDTO.class))),
			@ApiResponse(responseCode = "default", description = "All Errors", content = @Content(schema = @Schema(implementation = StandardErrorResponse.class)))
	})
	@PostMapping("/deleteFsaInfo")
	public ResponseEntity<FsaDeleteResponseDTO> deleteFsaCompleteInfo(
			@RequestBody @Valid final DeleteFsaInfoReq deleteFsaInfoReq) {
		FsaDeleteResponseDTO responseDto = new FsaDeleteResponseDTO();
		if (deleteFsaInfoReq != null) {
			responseDto = addModifyCriteriaService.deleteCompleteCriteriaList(deleteFsaInfoReq);
		}

		return ResponseEntity.ok(responseDto);
	}

	@PreAuthorize("@authorizeService.isAuthorized('GCAMP:fsaSearch:GoAction','execute')")
	@Operation(summary = "FSA Global Search", security = {
			@SecurityRequirement(name = "ADFS"),
			@SecurityRequirement(name = "AzureAD")
	})
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "FSA Global Search request processed successfully",content = @Content(mediaType = "application/problem+json",schema = @Schema(implementation = FsaGlobalSearchDTO.class))),
			@ApiResponse(responseCode = "default", description = "All Errors", content = @Content(schema = @Schema(implementation = StandardErrorResponse.class)))
	})
	@PostMapping("/fsaGlobalSearch")
	public ResponseEntity<FsaGlobalSearchDTO> globalFsaSearch(
			@RequestBody @Valid final FsaGlobalSearchRequest flobalFsaSearch) {
		if (flobalFsaSearch != null) {
			fsaGlobalSearchDto = addModifyCriteriaService.getFsaGlobalSearch(flobalFsaSearch);
		}

		return ResponseEntity.ok(fsaGlobalSearchDto);
	}

	@PreAuthorize("@authorizeService.isAuthorized('GCAMP:fsaCriteria:go','execute')")
	@GetMapping("/getStateProvince")
	@Operation(summary = "Get State Province", security = {
			@SecurityRequirement(name = "ADFS"),
			@SecurityRequirement(name = "AzureAD")
	})
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "State Province request processed successfully",content = @Content(mediaType = "application/problem+json",schema = @Schema(implementation = LoadStateProvinceDTO.class))),
			@ApiResponse(responseCode = "default", description = "All Errors", content = @Content(schema = @Schema(implementation = StandardErrorResponse.class)))
	})
	@LogExecutionTime
	public ResponseEntity<LoadStateProvinceDTO> getQueryForStateProv() {
		LOGGER.info("Get State Province Code");
		loadStateProvinceDTO = addModifyCriteriaService.loadDynamicQueryDetailsForStateProv();
		return ResponseEntity.ok(loadStateProvinceDTO);

	}
	@PreAuthorize("@authorizeService.isAuthorized('GCAMP:fsaSearch:GoAction','execute')")
	@PostMapping("/getQueryForSelectCountry")
	@Operation(summary = "Query For Select Country", security = {
			@SecurityRequirement(name = "ADFS"),
			@SecurityRequirement(name = "AzureAD")
	})
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Query For Select Country request processed successfully",content = @Content(mediaType = "application/problem+json",schema = @Schema(implementation = LoadSelectCounValDTO.class))),
			@ApiResponse(responseCode = "default", description = "All Errors", content = @Content(schema = @Schema(implementation = StandardErrorResponse.class)))
	})
	@LogExecutionTime
	public ResponseEntity<LoadSelectCounValDTO> getQueryForSelectCountry(
			@RequestBody @Valid FscCriteriaRequest fscCriteriaRequest) {
		selectCounResp = addModifyCriteriaService.loadDynamicQueryDataForSelectCountry(fscCriteriaRequest);
		return ResponseEntity.ok(selectCounResp);

	}
	@PreAuthorize("@authorizeService.isAuthorized('GCAMP:fsaSearch:GoAction','execute')")
	@GetMapping("/getHubs")
	@Operation(summary = "Get Hubs", security = {
			@SecurityRequirement(name = "ADFS"),
			@SecurityRequirement(name = "AzureAD")
	})
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Hub request processed successfully" ,content = @Content(mediaType = "application/problem+json",schema = @Schema(implementation = HubResponse.class))),
			@ApiResponse(responseCode = "default", description = "All Errors", content = @Content(schema = @Schema(implementation = StandardErrorResponse.class)))
	})
	@LogExecutionTime
	public ResponseEntity<HubResponse> getHubs() {
		HubResponse hubResponse = addModifyCriteriaService.getHubsList();
		return ResponseEntity.ok(hubResponse);
	}
	@PreAuthorize("@authorizeService.isAuthorized('GCAMP:fsaSearch:GoAction','execute')")
	@GetMapping("/getFSATypes")
	@Operation(summary = "Get FSA Types", security = {
			@SecurityRequirement(name = "ADFS"),
			@SecurityRequirement(name = "AzureAD")
	})
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "FSA Types request processed successfully" , content = @Content(mediaType = "application/problem+json",schema = @Schema(implementation = FSATypesResponse.class))),
			@ApiResponse(responseCode = "default", description = "All Errors", content = @Content(schema = @Schema(implementation = StandardErrorResponse.class)))
	})
	@LogExecutionTime
	public ResponseEntity<FSATypesResponse> getFSATypes() {
		FSATypesResponse typeResponse = addModifyCriteriaService.getFSATypes();
		return ResponseEntity.ok(typeResponse);
	}

	@PostMapping("/delete/confirm")
	@Operation(summary = "Delete Confirm", security = {
			@SecurityRequirement(name = "ADFS"),
			@SecurityRequirement(name = "AzureAD")
	})
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Delete Confirm request processed successfully", content = @Content(mediaType = "application/problem+json",schema = @Schema(implementation = DeleteConfirmResponse.class))),
			@ApiResponse(responseCode = "default", description = "All Errors", content = @Content(schema = @Schema(implementation = StandardErrorResponse.class)))
	})
	@LogExecutionTime
	public ResponseEntity<DeleteConfirmResponse> confirmDelete(@RequestBody @Valid FSACommonGoRequest fsaCommonGoRequest)
			throws GCAMPException {
		DeleteConfirmResponse deleteConfirmResponse = addModifyCriteriaService.getExtractTimeStamp(fsaCommonGoRequest);
		return ResponseEntity.ok(deleteConfirmResponse);

	}

	@ExceptionHandler({ AccessDeniedException.class })
	public ResponseEntity<Object> handleAccessDeniedException(Exception ex, WebRequest request) {
		if (ex.getMessage().toLowerCase().indexOf("access is denied") > -1) {
			return new ResponseEntity<>("You are not Authorized by APS to access the Resource", new HttpHeaders(),
					HttpStatus.FORBIDDEN);
		}
		return new ResponseEntity<>(ex.getMessage(), new HttpHeaders(), HttpStatus.INTERNAL_SERVER_ERROR);
	}

	@PreAuthorize("@authorizeService.isAuthorized('GCAMP:fsaSearch:GoAction','execute')")
	@GetMapping("/regionalfilter/vingroups/{globalFSANumber}/{supplementCode}")
	@Operation(summary = "get regionalFilter", security = {
			@SecurityRequirement(name = "ADFS"),
			@SecurityRequirement(name = "AzureAD")
	})
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "get regionalFilter request processed successfully", content = @Content(mediaType = "application/problem+json",schema = @Schema(implementation = GenericLookupResponse.class))),
			@ApiResponse(responseCode = "default", description = "All Errors", content = @Content(schema = @Schema(implementation = StandardErrorResponse.class)))
	})
	@LogExecutionTime
	public ResponseEntity<GenericLookupResponse> getRegionalFilterVinGrps(@PathVariable @NotNull @Valid
																			  @Schema(type = "integer",example = "15543",description = "globalFSANumber")
																			  @Min(0)
																			  @Max(99999999) int globalFSANumber,
			@PathVariable @NotNull @Valid
			@Size(min = 0, max = 2)
			@Pattern(regexp = "^[a-zA-Z\\d\\s\\*]*$")
			@Schema(example = "AA", description = "Supplement Code") String supplementCode) {
		GenericLookupResponse vinGroupResponse = fsaCriteriaRegionalFilterService.getRegionalFilterVinGrps(globalFSANumber,
				supplementCode);
		return ResponseEntity.ok(vinGroupResponse);
	}

	@PreAuthorize("@authorizeService.isAuthorized('GCAMP:fsaSearch:GoAction','execute')")
	@GetMapping("/{globalFSANumber}/{supplementCode}/{vinGroupCode}/regionalfilters")
	@Operation(summary = "globalFSANumber regionalFilters", security = {
			@SecurityRequirement(name = "ADFS"),
			@SecurityRequirement(name = "AzureAD")
	})
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "globalFSANumber regionalFilters request processed successfully",content = @Content(mediaType = "application/problem+json",schema = @Schema(implementation = VinGroupRegionalFilterResponse.class))),
			@ApiResponse(responseCode = "default", description = "All Errors", content = @Content(schema = @Schema(implementation = StandardErrorResponse.class)))
	})
	@LogExecutionTime
	public ResponseEntity<VinGroupRegionalFilterResponse> getVinGroupRegionalFilters(@PathVariable @Valid @NotNull
																						 @Schema(type = "integer",example="15543" ,description = "globalFSANumber")
																						 @Min(0)
																						 @Max(99999999) int globalFSANumber,
			@PathVariable @Valid @NotNull
			@Size(min = 0, max = 2)
			@Pattern(regexp = "^[a-zA-Z\\d\\s\\*]*$")
			@Schema(example = "AA", description = "Supplement Code") String supplementCode, @PathVariable @Valid @NotNull @Size(min = 1, max = 2)
	@Pattern(regexp = "^[A-Za-z\\d\\*]*$")
	@Schema(type = "string",example = "**", description = "Vin Group Code") String vinGroupCode) {
		VinGroupRegionalFilterResponse regionalFilterResponse = fsaCriteriaRegionalFilterService
				.getVinGroupRegionalFilters(globalFSANumber, supplementCode, vinGroupCode);
		return ResponseEntity.ok(regionalFilterResponse);
	}
	@PreAuthorize("@authorizeService.isAuthorized('GCAMP:fsaSearch:GoAction','execute')")
	@GetMapping("/{globalFSANumber}/{supplementCode}/regionalfilter/exists")
	@Operation(summary = "regional filters for a supplement", security = {
			@SecurityRequirement(name = "ADFS"),
			@SecurityRequirement(name = "AzureAD")
	})
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "regional filters for a supplement code processed successfully" ,  content = @Content(schema = @Schema(implementation = Boolean.class))),
			@ApiResponse(responseCode = "default", description = "All Errors", content = @Content(mediaType = "application/problem+json",schema = @Schema(implementation = StandardErrorResponse.class)))
	})
	public ResponseEntity<Boolean> isRegionalFilterExists(@PathVariable("globalFSANumber") @Valid  @NotNull
															  @Schema( type= "integer",example = "15543",description = "globalFSANumber")
															  @Min(0)
															  @Max(99999999) int globalFSANumber,@PathVariable @NotNull
	@Size(min = 0, max = 2)
	@Pattern(regexp = "^[a-zA-Z\\d\\s\\*]*$")
	@Schema(example = "AA", description = "Supplement Code") String supplementCode) {
		Boolean regionalFilterExists = fsaCriteriaRegionalFilterService.isRegionalFilterExists(globalFSANumber, supplementCode);
		return ResponseEntity.ok(regionalFilterExists);
	}
	@PreAuthorize("@authorizeService.isAuthorized('GCAMP:fsaSearch:GoAction','execute')")
	@GetMapping("/{globalFSANumber}/{supplementCode}/delete/regionalfilters")
	@Operation(summary = "Delete Regional filters", security = {
			@SecurityRequirement(name = "ADFS"),
			@SecurityRequirement(name = "AzureAD")
	})
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Delete Regional Filters request processed successfully", content = @Content(mediaType = "application/problem+json",schema = @Schema(implementation = CommonResponse.class))),
			@ApiResponse(responseCode = "default", description = "All Errors", content = @Content(mediaType = "application/problem+json",schema = @Schema(implementation = StandardErrorResponse.class)))
	})
		public ResponseEntity<CommonResponse> deleteVinGroupRegionalFilters(@PathVariable("globalFSANumber") @Valid @NotNull
																				@Schema(type = "integer",example = "15543",description = "globalFSANumber")
																				@Max(99999999) int globalFSANumber, @PathVariable @Valid @NotNull
	@Size(min = 0, max = 2)
	@Pattern(regexp = "^[a-zA-Z\\d\\s\\*]*$")
	@Schema(example = "AA", description = "Supplement Code") String supplementCode) {
		CommonResponse vinGroupRegionalFilterResponse = fsaCriteriaRegionalFilterService.deleteVinGroupRegionalFilters(globalFSANumber, supplementCode);
		return ResponseEntity.ok(vinGroupRegionalFilterResponse);
	}
}
