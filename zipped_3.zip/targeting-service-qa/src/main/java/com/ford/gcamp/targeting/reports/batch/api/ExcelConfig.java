package com.ford.gcamp.targeting.reports.batch.api;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class ExcelConfig {

    private String property;
    private String columnName;
    private int columnWidth;
    private String columnType;
    private int columnPos;
    private String dynamicColumn;
    
}
