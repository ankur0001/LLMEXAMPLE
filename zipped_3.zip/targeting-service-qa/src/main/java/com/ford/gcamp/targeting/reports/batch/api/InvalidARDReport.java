package com.ford.gcamp.targeting.reports.batch.api;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class InvalidARDReport extends GenericReportData {

    /**
     * This contains Hub
     */
    private String hubDesc;

    /**
     * This contains ROI
     */
    private String roi;

    /**
     * This contains Brand
     */
    private String brand;

    /**
     * This contains Dealer Code
     */
    private String dealerCode;

    /**
     * This contains Dealer Name
     */
    private String dealerName;

    /**
     * This contains Country
     */
    private String cntryDesc;

    /**
     * This contains Invalidity Reason
     */
    private String invalidityReason;

    /**
     * This contains Termination Date
     */
    private String terminationDate;

}
