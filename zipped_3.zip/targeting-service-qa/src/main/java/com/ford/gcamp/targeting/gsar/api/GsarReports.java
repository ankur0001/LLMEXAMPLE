package com.ford.gcamp.targeting.gsar.api;

import java.util.Date;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class GsarReports {
	@Size(min=0 ,max = 100)
	@Pattern(regexp = "^[A-Za-z\\d]*$")
	@Schema(example = "3", description = "uniqueId")
	private Long uniqueId;


	@Size(min = 0, max = 8)
	@Pattern(regexp = "^[a-zA-Z\\d\\-]*$")
	@Schema(example = "TDHARTI", description = "userId")
	private String userId;


	@Size(min = 0, max = 10)
	@Pattern(regexp = "^[\\d]*$")
	@Schema(example = "1036", description = "resultId")
	private String resultId;

	@Size(min = 0, max = 10)
	@Pattern(regexp = "^[a-zA-Z\\d]*$")
	@Schema(example = "1036", description = "resultId")
	private String resId;

	@Schema(description = "Description")
	@Size(min = 0, max = 254)
	@Pattern(regexp ="^[A-Za-z\\d\\s\\.\\,\\_\\-]*$")
	private String description;
	@Setter(AccessLevel.NONE)
	@Getter(AccessLevel.NONE)
	@Size(min = 0, max = 40)
	@Pattern(regexp = "^[a-zA-Z\\d\\-\\s\\.\\/\\:\\+]$")
	@Schema(example = "05-Jun-2024", description = "run Date")
	private Date runDate;

	@Schema(example="A",description = "Description")
	@Size(min = 0, max = 254)
	@Pattern(regexp ="^[A-Za-z\\d\\s\\.\\,\\_\\-]*$")
	private String option;

	@Schema(example = "test",description = "Description")
	@Size(min = 0, max = 254)
	@Pattern(regexp ="^[A-Za-z\\d\\s\\.\\,\\_\\-]*$")
	private String criteria;

	@Schema(example = "20",description = "count")
	@Size(min = 0, max = 100)
	@Pattern(regexp ="^[\\d]*$")
	private String count;
	private boolean fetchStatus;

	public void setRunDate(Date runDate) {
		if (runDate == null) {
			this.runDate = null;
		} else {
			this.runDate = new Date(runDate.getTime());
		}
	}

	public Date getRunDate() {
		if (runDate != null) {
			return new Date(runDate.getTime());
		} else {
			return null;
		}
	}
}
