package com.ford.gcamp.targeting.common;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Builder
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class Hubs {

	@Size(min = 0, max = 2)
	@Pattern(regexp = "^[a-zA-Z\\*\\s]*$")
	@Schema(example = "NA", description = "Hub code")
	private String hubCode;

	@Size(min = 1, max = 30)
	@Pattern(regexp = "^[a-zA-Z\\s\\-\\d\\,\\&]*$")
	@Schema(example = "FORD NORTH AMERICA", description = "Hub description")
	private String hubDescription;    
	
}
