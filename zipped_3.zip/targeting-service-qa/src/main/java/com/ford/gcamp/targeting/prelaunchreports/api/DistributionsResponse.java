package com.ford.gcamp.targeting.prelaunchreports.api;

import java.util.List;

import com.ford.gcamp.targeting.common.Hubs;
import com.ford.gcamp.targeting.common.LDAPModel;
import com.ford.gcamp.targeting.common.api.CommonResponse;
import com.ford.gcamp.targeting.prelaunchreports.Countries;
import com.ford.gcamp.targeting.prelaunchreports.Distributions;
import com.ford.gcamp.targeting.prelaunchreports.Processes;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class DistributionsResponse extends CommonResponse{

	@Size(min = 0, max = 300, message = "hubs List")
	private List<@Valid Hubs> hubsList;

	@Size(min = 0, max = 300, message = "countrys List")
	private List<@Valid Countries> countrysList;

	@Size(min = 0, max = 300, message = "process Lists")
	private List<@Valid Processes> processLists;

	@Size(min = 0, max = 300, message = "distributions List")
	private List<@Valid Distributions> distributionsList;

	@Size(min = 0, max = 300, message = "added By")
	private List<@Valid LDAPModel> addedBy;
	
}
