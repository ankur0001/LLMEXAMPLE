package com.ford.gcamp.targeting.properties;

import org.springframework.boot.context.properties.ConfigurationProperties;

import lombok.Getter;
import lombok.Setter;

@ConfigurationProperties(prefix = "ftp")
@Getter
@Setter
public class FtpConfiguration {
	
	private String sftpPrivateKey;
	private String sftpPublicKey;
	private String systemReader;
	private String templateFile;
	private String bufferSize;
	private String privateKeyPath;
	
		
}
