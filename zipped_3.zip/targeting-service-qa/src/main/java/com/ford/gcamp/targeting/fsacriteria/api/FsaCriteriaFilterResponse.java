package com.ford.gcamp.targeting.fsacriteria.api;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class FsaCriteriaFilterResponse {
	
	private List<FsaFilterCriteriaResponse> modelBrandVehLine;
	private List<FsaFilterCriteriaResponse> vehPlantModel;
	private List<FsaFilterCriteriaResponse> vehPlantWers;
	private List<FsaFilterCriteriaResponse> vehPlantWersCode;
	
	
	@Override
	public String toString() {
		return "FsaCriteriaFilterResponse [modelBrandVehLine=" + modelBrandVehLine + ", vehPlantModel=" + vehPlantModel
				+ ", vehPlantWers=" + vehPlantWers + "]";
	}
	
	
	
	
	

}
