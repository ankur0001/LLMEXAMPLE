package com.ford.gcamp.targeting.regionalfilters.api;



import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class StateProvince {

	@NotNull
	@Size(min = 1, max = 2)
	@Pattern(regexp = "^[\\d\\*]*$")
	@Schema(example = "AL", description = "state code")
	private String code;

	@Size(min = 0, max = 100)
	@Pattern(regexp = "^[a-zA-Z\\s]*$")
	@Schema(example = "Alabama", description = "State Description")
	private String label;

}
