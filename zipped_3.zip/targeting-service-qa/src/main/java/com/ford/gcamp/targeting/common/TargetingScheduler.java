package com.ford.gcamp.targeting.common;

import net.javacrumbs.shedlock.spring.annotation.SchedulerLock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.ford.gcamp.targeting.cache.CachingService;
import com.ford.gcamp.targeting.core.exception.GCAMPException;
import com.ford.gcamp.targeting.gridgcamp.gcamp.GridGCampService;
import com.ford.gcamp.targeting.gsar.GsarService;
import com.ford.gcamp.targeting.reports.batch.TargetingReportService;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class TargetingScheduler {


	@Autowired
	private CachingService cachingService;

	@Autowired
	private GsarService gsarService;
	@Autowired
	private TargetingReportService targetingReportService;
	@Autowired
	private GridGCampService gridGCampService;


	//@Scheduled(cron = "${fsa.criteria.refresh}")
	@Scheduled(cron = "${FSA_CRITERIA_REFRESH}")
	@SchedulerLock(name = "FSA CRITERIA REFRESH", lockAtLeastFor = "${COMMON_LK_ATLST_FR}", lockAtMostFor = "${COMMON_LK_ATMST_FR}")
	public void refreshFsaCriteria() {
		log.info("Executing Cache reload job for FSA");
		cachingService.refreshFsaCriteria();
	}

	//@Scheduled(cron = "${gsar.purge.record}")
	@Scheduled(cron = "${GSAR_PURGE_RECORD}")
	@SchedulerLock(name = "GSAR PURGE RECORD", lockAtLeastFor = "${COMMON_LK_ATLST_FR}", lockAtMostFor = "${COMMON_LK_ATMST_FR}")
	public void deleteGsarPurgeRecords() {
		log.info("Executing deleteGsarPurgeRecords for GSAR ");
		int deleteRowCount = gsarService.deletePurgedReports();
		log.info("deleteRowCount deleteGsarPurgeRecords for GSAR {}", deleteRowCount);
	}

	//@Scheduled(cron = "${report.scheduler.cron.expression}")
	@Scheduled(cron = "${REPORT_SCHEDULER_TARGETING}")
	@SchedulerLock(name = "REPORT SCHEDULER TARGETING", lockAtLeastFor = "${REPORTS_LK_ATLST_FR}", lockAtMostFor = "${REPORTS_LK_ATMST_FR}")
	public void runTargetingReports() {
		targetingReportService.getBMPCompletedJobs();
	}

	//@Scheduled(cron = "${grid.fsa.update}")
	@Scheduled(cron = "${GRID_FSA_UPDATE}")
	@SchedulerLock(name = "GRID FSA VERN UPDATE", lockAtLeastFor = "${COMMON_LK_ATLST_FR}", lockAtMostFor = "${COMMON_LK_ATMST_FR}")
	public void sendFSAUpdatesToGrid() {
		gridGCampService.sendVernStatusToGrid();
	}

	//@Scheduled(cron = "${gsar.stopship.fetch}")
	@Scheduled(cron = "${GSAR_STOPSHIP_FETCH}")
	@SchedulerLock(name = "GSAR STOPSHIP FETCH", lockAtLeastFor = "${COMMON_LK_ATLST_FR}", lockAtMostFor = "${COMMON_LK_ATMST_FR}")
	public void getGsarStopShipRepairDetails() throws GCAMPException {
		gsarService.getGsarStopShipRepairDetails();
	}

}
