package com.ford.gcamp.targeting.fsacriteria.api;

import java.util.List;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Size;
import org.springframework.stereotype.Component;

import com.ford.gcamp.targeting.common.api.ResponseStatusDTO;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

@Component
@EqualsAndHashCode(callSuper=false)
@Getter
@Setter
public class FsaGlobalSearchDTO extends ResponseStatusDTO{

	@Size(min = 0, max = 300, message = "fsa Global Num List")
	private List<@Valid FsaGlobalSearchList> fsaGlobalList;

}
