package com.ford.gcamp.targeting.gridgcamp.gcamp.api;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;


import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@JsonIgnoreProperties(ignoreUnknown = true)
public class SoftwareCriteria {


	@Schema(description = "node", example=" ")
	@Size(min = 0, max = 3, message = "length 3")
	@Pattern(regexp ="^|[A-Za-z\\d\\s]*$", message = "Node Code")
	private String node;


	@Schema(description = "did",example=" ")
	@Size(min = 0, max = 5, message = "length 5")
	@Pattern(regexp ="^|[A-Za-z\\d\\s]*$", message = "Module Code")
	private String module;


	@Schema(description = "did", example=" ")
	@Size(min = 0, max = 4, message = "length max 4")
	@Pattern(regexp ="^|[A-Za-z\\d\\s]*$", message = "Did Code")
	private String did;


	@Schema(description = "defectiveSoftwareVersion", example=" ")
	@Size(min = 0, max = 20, message = "length max 20")
	@Pattern(regexp ="^|[A-Za-z\\d\\s]*$", message = "Defect Software Version")
	private String defectiveSoftwareVersion;


	@Schema(description = "targetSoftwareVersion", example=" ")
	@Size(min = 0, max = 20, message = "length max 20")
	@Pattern(regexp ="^|[A-Za-z\\d\\s]*$", message = "Target Software Version")
	private String targetSoftwareVersion;


	@Schema(description = "operator", example=" ")
	@Size(min = 0, max = 30, message = "length max 25")
	@Pattern(regexp ="^|[A-Za-z\\s]*$", message = "Operator Value")
	private String operator;
}
