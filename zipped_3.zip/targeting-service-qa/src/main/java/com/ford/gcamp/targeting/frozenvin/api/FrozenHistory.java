package com.ford.gcamp.targeting.frozenvin.api;

import java.util.List;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class FrozenHistory {

	@Size(min = 1, max = 2)
	@Pattern(regexp = "^[a-zA-Z\\d\\*\\s]*$")
	@Schema(example = "NA", description = "Hub code")
	private String hubCode;



	@Size(min = 1, max = 30)
	@Pattern(regexp = "^[a-zA-Z\\*\\d]*$")
	@Schema(example = "FORD NORTH AMERICA", description = "Hub description")
	private String hubDesc;

	@Size(min = 0, max = 250, message = "CountryList")
	private List<@Valid CountryList> countryList;
	
}
