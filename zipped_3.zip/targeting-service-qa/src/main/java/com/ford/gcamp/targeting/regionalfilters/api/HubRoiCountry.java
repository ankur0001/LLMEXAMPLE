package com.ford.gcamp.targeting.regionalfilters.api;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class HubRoiCountry {
	private String hub;
	private String hubDescription;
	private String country;
	private String countryDescription;
	private String roi;
	private String roiDescription;
	
}
