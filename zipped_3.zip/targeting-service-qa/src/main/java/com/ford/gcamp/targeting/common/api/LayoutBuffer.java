package com.ford.gcamp.targeting.common.api;

import java.util.ArrayList;

import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component
public class LayoutBuffer {
	
	private static final   org.slf4j.Logger LOGGER = LoggerFactory.getLogger(LayoutBuffer.class);
	public static final   int FIELDTYPE_PIC9 = 0;
	public static  final   int FIELDTYPE_PICX = 1;
	public static final   int FIELDTYPE_PICS9 = 2;
	private static final   LayoutBufferField initField = new LayoutBufferField();
	private static final   char[] defaultPadding = { '0', ' ', '0' };
	private char[] buffer;
	private ArrayList<LayoutBufferField> fields;
	private boolean trim;
	private static class LayoutBufferField {
		int startingPosition;
		int length;
		int type;
		char pad;
	}
	/**
	 * LayoutBuffer constructor.
	 * This constructor initializes the internal
	 * buffer.
	 * The length of the buffer is specified
	 * in this routine.
	 * Creation date: (10/1/01 10:59:31 AM)
	 * @param length int
	 */
	public LayoutBuffer() {
		
	}
	
	public LayoutBuffer(int length) {
		super();
		this.buffer = new char[length];
		for (int i = 0; i < length; i++) {
			this.buffer[i] = ' ';
		}
		this.fields = new ArrayList<>();
	}
	/**
	 * Add a field to the layout format.
	 * The type argument may be:
	 *  LayoutBuffer.FIELDTYPE_PIC9 for right justified left padded with '0'
	 *  LayoutBuffer.FIELDTYPE_PICS9 for right justified left padded with '0'
	 *   and ending with a sign character '+'|'-'.
	 *  LayoutBuffer.FIELDTYPE_PICX for left justified right padded with ' '
	 *
	 * Answers with the field index that will be assigned to the field
	 * being added.
	 *
	 * Creation date: (10/1/01 11:12:37 AM)
	 * @param type int
	 * @param length int
	 * @return  int index of the field added.
	 */
	public int addField(int type, int length) {
		return this.addField(type, length, LayoutBuffer.defaultPadding[type]);
	}
	/**
	 * Add a field to the layout format.
	 * The type argument may be:
	 *  LayoutBuffer.FIELDTYPE_PIC9 for right justified
	 *  LayoutBuffer.FIELDTYPE_PICS9 for right justified
	 *   and ending with a sign character '+'|'-'.
	 *  LayoutBuffer.FIELDTYPE_PICX for left
	 *
	 * Answers with the field index that will be assigned to the field
	 * being added.
	 *
	 * Creation date: (10/1/01 11:12:37 AM)
	 * @param type int
	 * @param length int
	 * @param pad char
	 * @return  int index of the field added.
	 */
	public int addField(int type, int length, char pad) {
		LayoutBufferField lastField;
		LayoutBufferField newField;
		if (this.fields.isEmpty()) {
			lastField = LayoutBuffer.initField;
		} else {
			lastField = this.fields.get(this.fields.size() - 1);
		}
		newField = new LayoutBufferField();
		newField.startingPosition = lastField.startingPosition + lastField.length;
		newField.length = length;
		newField.type = type;
		newField.pad = pad;
		this.fields.add(newField);
		return this.fields.size() - 1;
	}
	/**
	 * Update this object from a string (opposite of this.toString).
	 * Creation date: (10/1/01 1:09:47 PM)
	 * @param value java.lang.String
	 */
	public void fromString(String value) {
		value.getChars(0, value.length(), this.buffer, 0);
	}
	/**
	 * Get the string associated with the indicated field.
	 * Creation date: (10/1/01 11:43:47 AM)
	 * @return java.lang.String
	 * @param field int
	 */
	public String getString(int fieldIndex) {
		LayoutBufferField field = this.fields.get(fieldIndex);
		String answer =
			String.valueOf(this.buffer, field.startingPosition, field.length);
		if (this.isTrim()) {
			answer = answer.trim();
		}
		return answer;
	}
	/**
	 * Accessor for trim.
	 * Creation date: (12/13/01 12:27:39 PM)
	 * @return boolean
	 */
	public boolean isTrim() {
		return trim;
	}
	/**
	 * Answers with the length of the buffer.
	 * Creation date: (11/28/01 4:44:23 PM)
	 * @return int
	 */
	public int length() {
		return this.buffer.length;
	}
	/**
	 * Set the field for the given value.
	 * If the value's length is longer than the field of the
	 * index, the value will be truncated.
	 * Creation date: (10/1/01 11:49:26 AM)
	 * @param fieldIndex int
	 * @param value java.lang.String
	 */
	public void setString(int fieldIndex, String value, boolean changeCase) {
		// use empty string if null.
		if (value == null) {
			value = ""; 
		}
		if (changeCase) {
			value = value.toUpperCase();
		}
		this.setFormattedString(fieldIndex, value);
	}
	/**
	 * Set the field for the given value.
	 * If the value's length is longer than the field of the
	 * index, the value will be truncated.
	 * Creation date: (10/1/01 11:49:26 AM)
	 * @param fieldIndex int
	 * @param value java.lang.String
	 */
	public void setString(int fieldIndex, String value) {
		// use empty string if null.
		if (value == null) {
			value = ""; 
		}
	    //  always change to upper case
		value = value.toUpperCase(); 
		this.setFormattedString(fieldIndex, value);
	}

	/**
	 * Set the field for the given value.
	 * If the value's length is longer than the field of the
	 * index, the value will be truncated.
	 * Creation date: (10/1/01 11:49:26 AM)
	 * @param fieldIndex int
	 * @param value java.lang.String
	 */
	private void setFormattedString(int fieldIndex, String value) {
		LayoutBufferField field =  this.fields.get(fieldIndex);
		int fieldBufferPosition = 0;
		char[] fieldBuffer1 = new char[field.length];
		value=getCobolRoutine(field,value);
		
		char[] fieldBuffer=layoutFieldBuffer(field,fieldBuffer1,value);
		
		int bufferPosition;
		for (bufferPosition = field.startingPosition, fieldBufferPosition = 0;
			bufferPosition < this.buffer.length && fieldBufferPosition < fieldBuffer.length;
			bufferPosition++, fieldBufferPosition++) {
			this.buffer[bufferPosition] = fieldBuffer[fieldBufferPosition];
		}
	}
	private char[] layoutFieldBuffer(LayoutBufferField field,
			char[] fieldBuffer, String value) {
		int stringPosition = 0;
		int inputFieldBufferPosition ;
		if (field.type == LayoutBuffer.FIELDTYPE_PIC9 || field.type == LayoutBuffer.FIELDTYPE_PICS9) {
			stringPosition = value.length() - 1;

			for (inputFieldBufferPosition = fieldBuffer.length - 1;
					inputFieldBufferPosition >= 0;
					inputFieldBufferPosition--, stringPosition--) {
				if (stringPosition < 0) {
					fieldBuffer[inputFieldBufferPosition] = field.pad;
				}else {
					fieldBuffer[inputFieldBufferPosition] = value.charAt(stringPosition);
				}
			}
		} else {
			stringPosition = 0;
			for (inputFieldBufferPosition = 0;
					inputFieldBufferPosition < fieldBuffer.length;
					inputFieldBufferPosition++, stringPosition++) {
				if (stringPosition >= value.length()) {
					fieldBuffer[inputFieldBufferPosition] = field.pad;
				}else {
					fieldBuffer[inputFieldBufferPosition] = value.charAt(stringPosition);
				}
			}
		}
		return fieldBuffer;
	}

	private String getCobolRoutine(LayoutBufferField field, String value) {
		
		if (field.type == LayoutBuffer.FIELDTYPE_PIC9 || field.type == LayoutBuffer.FIELDTYPE_PICS9) {
			value = value.trim();
		}
		if (field.type == LayoutBuffer.FIELDTYPE_PICS9) {
			try {
				// put the sign at the end of the number.
				char sign;
				Integer integerValue = Integer.valueOf(value.trim());
				sign = (integerValue.intValue() < 0 ? '-' : '+');
				integerValue = Integer.valueOf(Math.abs(integerValue.intValue()));
				value = integerValue.toString() + sign;
			} catch (Exception x) { 
				/*Let COBOL routine catch error*/
				LOGGER.error("Exception Occured ", x);
			}
		}
		return value;
	}

	/**
	 * Mutator for trim.
	 * Creation date: (12/13/01 12:27:39 PM)
	 * @param newTrim boolean
	 */
	public void setTrim(boolean newTrim) {
		trim = newTrim;
	}
	/**
	 * Returns a string representation of the object. In general, the 
	 * <code>toString</code> method returns a string that 
	 * "textually represents" this object. The result should 
	 * be a concise but informative representation that is easy for a 
	 * person to read.
	 * It is recommendedthat all subclasses override this method.
	 * <p>
	 * The <code>toString</code> method for class <code>Object</code> 
	 * returns a string consisting of the name of the class of which the 
	 * object is an instance, the at-sign character `<code>@</code>', and 
	 * the unsigned hexadecimal representation of the hash code of the 
	 * object. In other words, this method returns a string equal to the 
	 * value of:
	 * <blockquote>
	 * <pre>
	 * getClass().getName() + '@' + Integer.toHexString(hashCode())
	 * </pre></blockquote>
	 *
	 * @return  a string representation of the object.
	 */
	public String toString() {
		return new String(this.buffer);
	}
}