package com.ford.gcamp.targeting.prelaunchreports;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.Data;

@Data
public class Wers {
	@Size(min = 0, max = 10)
	@Pattern(regexp = "^[\\d]*$")
	@Schema(example = "1397", description = "wers Code")
	private String wersCode;

	@Size(min = 0, max = 100)
	@Pattern(regexp = "^[a-zA-Z\\d\\s\\(\\)\\-\\_\\/]*$")
	@Schema(example = "Bl -B-C -Majestic (2T9)", description = "Wers Value")
	private String wersValue;


	@Size(min = 0, max = 10)
	@Pattern(regexp = "^[a-zA-Z\\d]*$")
	@Schema(example = "2T9", description = "Wers Family Code")
	private String wersFamilyCode;
}
