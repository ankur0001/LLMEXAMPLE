package com.ford.gcamp.targeting.gsar.api;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class GsarFileUploadRequest {
	@NotNull
	@Size(min = 0, max = 10)
	@Pattern(regexp = "^[a-zA-Z\\d\\s]*$")
	@Schema(example = "15S01", description = "FSA number")
	private String fsaNumber;

	@NotNull
	@Schema(example = "G", description = "fsaType")
	@Size(min = 0, max = 1)
	@Pattern(regexp = "^[A-Za-z]$", message = "FSA Type")
	private String fsaType;

	@Schema(example = "F", description = "fileType")
	@Size(min = 0, max = 1)
	@Pattern(regexp = "^[A-Za-z]$", message = "File Type")
	private String fileType;

	@Schema(example = "V", description = "vinSelectionOption")
	@Size(min = 0, max = 1)
	@Pattern(regexp = "^[A-Za-z]$", message = "vinSelectionOption")
	private String vinSelectionOption;
	private String groupCode;
	private String groupDescription;

	@Size(min = 0, max = 8)
	@Pattern(regexp = "^[a-zA-Z\\d\\-]*$")
	@Schema(example = "TDHARTI", description = "CDSID")
	private String cdsId;


	@Schema(example = "GSAR",description = "sourceForReason")
	@Size(min = 0, max = 254)
	@Pattern(regexp ="^[A-Za-z\\d\\s]*$")
	private String sourceForReason;

	@Schema(example = "Include gsar",description = "reasonOfVins")
	@Size(min = 0, max = 254)
	@Pattern(regexp ="^[A-Za-z\\d\\s]*$")
	private String reasonOfVins;

	@Size(min = 0, max = 2)
	@Pattern(regexp ="^[A-Za-z\\d\\s\\*]*$", message = "population Code")
	@Schema(example = "AA", description = "Population")
	private String population;

	@Size(min = 0, max = 10)
	@Pattern(regexp ="^[A-Za-z\\d]*$", message = "event Code")
	@Schema(example = "CFC", description = "event code")
	private String eventCode;

	@Size(min = 0, max = 3)
	@Pattern(regexp = "^[a-zA-Z\\*\\s]*$")
	@Schema(example = "CAN", description = "CountryCode")
	private String countryCode;

	@Size(min = 0, max = 10)
	@Pattern(regexp = "^[\\d]*$")
	@Schema(example = "1036", description = "resultId")
	private String resultId;

	@Size(min = 0, max = 10)
	@Pattern(regexp = "^[\\d]*$")
	@Schema(example = "3", description = "uniqueId")
	private String uniqueId;

	@Schema(description = "filePath")
	@Size(min = 1, max = 100, message = "length 100")
	@Pattern(regexp ="^[A-Za-z\\d\\s,.#_\\-/{}()]*$", message = "File Path invalid")
	private String filePath;

	@Size(min = 0, max = 2)
	@Pattern(regexp = "^[a-zA-Z\\*\\s]*$")
	@Schema(example = "NA", description = "user hub")
	private String userHub;

	@Schema(example= "Y" , description = "Flag")
	@Size(min = 0, max = 1)
	@Pattern(regexp ="^[A-Za-z]*$")
	private String otaIndicator;

	@Schema(example= "B" , description = "Flag")
	@Size(min = 0, max = 1)
	@Pattern(regexp ="^[A-Za-z]*$")
	private String fhmIndicator;

}
