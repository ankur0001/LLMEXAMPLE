package com.ford.gcamp.targeting.prelaunchreports.api;

import com.ford.gcamp.targeting.common.api.CommonResponse;
import java.sql.Blob;
import java.util.Arrays;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.ObjectUtils;

@Setter
@Getter
public class ReportsResponse extends CommonResponse {

    private String reportId;
    private String requestedBy;
    private Blob blobData;
    private String reportFormatCode;

    @Setter(AccessLevel.NONE)
    @Getter(AccessLevel.NONE)
    private byte[] byteArry;

    public byte[] getByteArry() {
        if (ObjectUtils.isNotEmpty(byteArry)) {
            return Arrays.copyOf(this.byteArry, this.byteArry.length);
        }
        return new byte[1];
    }

    public void setByteArry(byte[] byteArry) {
        this.byteArry = Arrays.copyOf(byteArry, byteArry.length);
    }
}
