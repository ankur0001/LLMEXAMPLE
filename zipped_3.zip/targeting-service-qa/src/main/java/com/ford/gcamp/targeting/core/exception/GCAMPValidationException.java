package com.ford.gcamp.targeting.core.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.BAD_REQUEST)
public class GCAMPValidationException extends GCAMPException {
	
	private static final long serialVersionUID = 1L;
	
	public GCAMPValidationException(String errorDescription) {
		super(HttpStatus.BAD_REQUEST.value(), HttpStatus.BAD_REQUEST.getReasonPhrase(), errorDescription);
	}
	
	
	
}

