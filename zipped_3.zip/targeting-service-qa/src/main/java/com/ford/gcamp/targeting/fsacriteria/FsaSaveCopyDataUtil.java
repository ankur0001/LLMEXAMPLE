package com.ford.gcamp.targeting.fsacriteria;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.ford.gcamp.targeting.common.TargetingUtil;
import com.ford.gcamp.targeting.fsacriteria.api.DeleteFsaInfoReq;
import com.ford.gcamp.targeting.fsacriteria.api.FsaCriteriaParamRequest;

@Component
public class FsaSaveCopyDataUtil {
	private static final Logger LOGGER = LoggerFactory.getLogger(FsaSaveCopyDataUtil.class);
	@Autowired
	FsaUtil fscCriteriaUtil;

	public String getfsaGoParam(FsaCriteriaParamRequest fsaCriteriaParam) {
		StringBuilder builder = new StringBuilder();
		builder.append(fsaCriteriaParam.getFsaType());
		if (("G").equals(fsaCriteriaParam.getFsaType())) {
			builder.append(TargetingUtil.fillRemainingString(fsaCriteriaParam.getFsaNumber(), 8, "0"));
		} else if (("L").equals(fsaCriteriaParam.getFsaType())) {
			builder.append(TargetingUtil.fillRemainingString(fsaCriteriaParam.getFsaNumber().toUpperCase(), 10, " "));
		}
		builder.append(TargetingUtil.addSpaceToProc("", 9));
		return builder.toString();
	}

	public String getFsaSaveInputParam(FsaCriteriaParamRequest fsaCriteriaParam) {
		StringBuilder builder = new StringBuilder();
		builder.append("U");
		builder.append(fsaCriteriaParam.getVehiclePopUpCode());
		builder.append(TargetingUtil.fillRemainingString(fsaCriteriaParam.getCdsId(), 8, " "));
		builder.append(TargetingUtil.fillRemainingString(fsaCriteriaParam.getVinGrpSeq(), 4, "0"));
		builder.append(fsaCriteriaParam.getVinGrpCode());
		builder.append(TargetingUtil.fillRemainingString(fsaCriteriaParam.getVinGrpDesc(), 254, " "));
		builder.append(TargetingUtil.addSpaceToProc("", 1));
		builder.append(fsaCriteriaParam.getFhmIndicator());
		builder.append(fsaCriteriaParam.getFlag());
		builder.append(TargetingUtil.addSpaceToProc("", 726));
		return builder.toString();
	}

	public String getFsaCopyInputParam(FsaCriteriaParamRequest fsaCriteriaParam) {

		StringBuilder builder = new StringBuilder();
		builder.append("C");
		builder.append(fsaCriteriaParam.getVehiclePopUpCode());
		builder.append(TargetingUtil.fillRemainingString(fsaCriteriaParam.getCdsId(), 8, " "));
		builder.append(TargetingUtil.fillRemainingString(fsaCriteriaParam.getVinGrpSeq(), 4, "0"));
		builder.append(fsaCriteriaParam.getVinGrpCode());
		builder.append(TargetingUtil.fillRemainingString(fsaCriteriaParam.getVinGrpDesc(), 254, " "));
		builder.append(TargetingUtil.fillRemainingString(fsaCriteriaParam.getOtaIndicator(), 1, " "));
		builder.append(TargetingUtil.addSpaceToProc("", 728));
		return builder.toString();
	}

	public String getFsaDeleteInputParam(FsaCriteriaParamRequest fsaCriteriaParam) {

		StringBuilder builder = new StringBuilder();
		builder.append("279");
		builder.append(TargetingUtil.fillRemainingString(fsaCriteriaParam.getFsaNumber(), 8, "0"));
		builder.append(TargetingUtil.addSpaceToProc(10));
		builder.append(TargetingUtil.addSpaceToProc(2));
		builder.append(TargetingUtil.addSpaceToProc(3));
		builder.append(TargetingUtil.fillRemainingString(fsaCriteriaParam.getCdsId(), 8, " "));
		builder.append("N");
		builder.append(TargetingUtil.addZerosToProc(5));
		// suplement code is 00
		builder.append(fsaCriteriaParam.getVehiclePopUpCode());
		builder.append(" ");
		builder.append("P");
		builder.append("00");
		builder.append(" ");
		builder.append(" ");
		builder.append("999");
		builder.append(TargetingUtil.addSpaceToProc(17));

		builder.append(TargetingUtil.addSpaceToProc(32));
		LOGGER.info("input parm lenth {}:", builder.length());
		return builder.toString();
	}

	public String deleteAllFSAInputParam(DeleteFsaInfoReq fsaCriteriaParam) {

		StringBuilder builder = new StringBuilder();
		builder.append("280");
		builder.append(TargetingUtil.fillRemainingString(fsaCriteriaParam.getFsaNumber(), 8, "0"));
		builder.append(TargetingUtil.addSpaceToProc(10));
		builder.append(TargetingUtil.addSpaceToProc(2));
		builder.append(TargetingUtil.addSpaceToProc(3));
		builder.append(TargetingUtil.fillRemainingString(fsaCriteriaParam.getCdsId(), 8, " "));
		builder.append("N");
		builder.append(TargetingUtil.addZerosToProc(5));
		// suplement code is 00
		builder.append(fsaCriteriaParam.getPopulation());
		builder.append(" ");
		builder.append("P");
		builder.append("00");
		builder.append(" ");
		builder.append(" ");
		builder.append("999");
		builder.append(TargetingUtil.addSpaceToProc(17));

		builder.append(TargetingUtil.addSpaceToProc(32));
		LOGGER.info("Batch code is{}:", builder);
		return builder.toString();
	}

	public String getDeleteVInParam(FsaCriteriaParamRequest fsaCriteriaParam) {
		String vingrpDelSelection = "";
		String vingrpsSeq = fsaCriteriaParam.getVinGrpSeq();
		String vinGrpCode = fsaCriteriaParam.getVinGrpCode();

		String[] vinGrpCodeArray = vinGrpCode.split(",");
		String[] vinGrpSeqArray = vingrpsSeq.split(",");
		vingrpDelSelection = String.valueOf(vinGrpSeqArray.length);
		StringBuilder builder = new StringBuilder();
		builder.append("G");
		builder.append(TargetingUtil.fillRemainingString(fsaCriteriaParam.getFsaNumber(), 8, "0"));
		builder.append(TargetingUtil.fillRemainingString(vingrpDelSelection, 3, "0"));
		builder.append("D");
		// SUPLEMENT CODE
		builder.append(fsaCriteriaParam.getVehiclePopUpCode());
		builder.append(TargetingUtil.fillRemainingString(fsaCriteriaParam.getCdsId(), 8, " "));
		builder.append(fsaCriteriaParam.getDeleteConfirmFlag());
		for (int i = 0; i < vinGrpSeqArray.length; i++) {
			builder.append(TargetingUtil.fillRemainingString(vinGrpSeqArray[i], 4, "0") + vinGrpCodeArray[i]);
		}

		LOGGER.info("Batch Code is {}:", builder);
		return builder.toString();
	}

	public String deleteInputParam(FsaCriteriaParamRequest fsaCriteriaParam) {
		StringBuilder builder = new StringBuilder();
		builder.append("279");
		builder.append(TargetingUtil.fillRemainingString(fsaCriteriaParam.getFsaNumber(), 8, "0"));
		builder.append(TargetingUtil.fillRemainingString("*", 10, " "));
		builder.append(TargetingUtil.fillRemainingString("*", 2, " "));
		builder.append(TargetingUtil.fillRemainingString("*", 3, " "));
		builder.append(TargetingUtil.addZerosToProc(5));
		// suplement code is 00
		builder.append(fsaCriteriaParam.getVehiclePopUpCode());
		builder.append("999");
		builder.append(TargetingUtil.fillRemainingString("*", 17, " "));
		builder.append(TargetingUtil.fillRemainingString(fsaCriteriaParam.getCdsId(), 8, " "));
		builder.append(TargetingUtil.addSpaceToProc(39));
		return builder.toString();
	}

	public String deleteAllInputParam(DeleteFsaInfoReq deleteFsaInfoReq) {
		StringBuilder builder = new StringBuilder();
		builder.append("280");
		builder.append(TargetingUtil.fillRemainingString(deleteFsaInfoReq.getFsaNumber(), 8, "0"));
		builder.append(TargetingUtil.fillRemainingString("*", 10, " "));
		builder.append(TargetingUtil.fillRemainingString("*", 2, " "));
		builder.append(TargetingUtil.fillRemainingString("*", 3, " "));
		builder.append(TargetingUtil.addZerosToProc(5));
		// suplement code is 00
		builder.append(deleteFsaInfoReq.getPopulation());
		builder.append("999");
		builder.append(TargetingUtil.fillRemainingString("*", 17, " "));
		builder.append(TargetingUtil.fillRemainingString(deleteFsaInfoReq.getCdsId(), 8, " "));
		builder.append(TargetingUtil.addSpaceToProc(39));
		return builder.toString();
	}

}
