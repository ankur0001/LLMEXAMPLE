package com.ford.gcamp.targeting.regionalfilters;

import java.util.List;
import java.util.Map;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Service;
import com.ford.gcamp.targeting.common.BatchTrigger;
import com.ford.gcamp.targeting.common.CommonConstants;
import com.ford.gcamp.targeting.common.CommonRepository;
import com.ford.gcamp.targeting.common.api.BatchJobData;
import com.ford.gcamp.targeting.common.api.CommonJobResponse;
import com.ford.gcamp.targeting.core.exception.GCAMPException;
import com.ford.gcamp.targeting.core.exception.GCampBatchTriggerException;
import com.ford.gcamp.targeting.regionalfilters.api.ProcessMigVehRequest;
import com.ford.gcamp.targeting.regionalfilters.api.RegionalAuditReport;
import com.ford.gcamp.targeting.regionalfilters.api.RegionalFilterSaveRequest;
import com.ford.gcamp.targeting.regionalfilters.api.RegionalFilterStateProvinceResponse;
import com.ford.gcamp.targeting.regionalfilters.api.RegionalFilterStateRequest;
import com.ford.gcamp.targeting.regionalfilters.api.RegionalFiltersGoResponse;
import com.ford.gcamp.targeting.common.TargetingUtil;
import com.ford.gcamp.targeting.common.api.CommonResponse;
import com.ford.gcamp.targeting.common.api.FSACommonGoRequest;
import com.ford.gcamp.targeting.common.api.FSAInfoVO;
import com.ford.gcamp.targeting.common.api.GenericLookup;
import com.ford.gcamp.targeting.common.api.GenericLookupResponse;
import com.ford.gcamp.targeting.common.api.RoiCountryResponse;
import com.ford.gcamp.targeting.regionalfilters.api.RegionalFiltersRequest;
import com.ford.gcamp.targeting.regionalfilters.api.RegionalAuditReportResponse;

@Service
public class RegionalFiltersService {
	private BatchTrigger trigger;
	private BatchJobData processMigVehjob;
	private RegionalFiltersMapper regionalFiltersMapper;
	private RegionalFiltersRepository regionalFiltersRepository;
	private CommonRepository commonRepository;

	public RegionalFiltersService(BatchTrigger trigger, BatchJobData processMigVehjob,
			RegionalFiltersMapper regionalFiltersMapper, RegionalFiltersRepository regionalFiltersRepository,
			CommonRepository commonRepository) {
		this.trigger = trigger;
		this.processMigVehjob = processMigVehjob;
		this.regionalFiltersMapper = regionalFiltersMapper;
		this.regionalFiltersRepository = regionalFiltersRepository;
		this.commonRepository = commonRepository;

	}

	public RegionalFiltersGoResponse commonSearch(FSACommonGoRequest fsaGoRequest) throws GCAMPException {
		String param1 = TargetingUtil.commonFsaGoRequest(fsaGoRequest);
		String param2 = regionalFiltersMapper.loadRegionalFilterSearchParam2(fsaGoRequest);
		String param3 = regionalFiltersMapper.loadRegionalFilterSearchParam3(fsaGoRequest);
		List<GenericLookup> supplements;
		Map<String, Object> goResponseMap = regionalFiltersRepository.commonSearch(param1, param2, param3);
		List<GenericLookup> countryData = regionalFiltersRepository.getCountries();
		RegionalFiltersGoResponse regionalFiltersGoResponse = regionalFiltersMapper
				.parseRegionalFilterGoResponse(goResponseMap, countryData, loadHubRoiCountry(fsaGoRequest));
		supplements = regionalFiltersRepository
				.getExistingSupplements(regionalFiltersGoResponse.getFsaDetails().getGlobalFSANumber());
		if (CollectionUtils.isNotEmpty(supplements)) {
			supplements.forEach(supplement -> {
				if (supplement.getCode().contains(CommonConstants.TWO_ZEROS)) {
					supplement.setDescription(CommonConstants.ORIGINAL);
				}

			});

		}

		regionalFiltersGoResponse.setExistingSupplements(supplements);
		return regionalFiltersGoResponse;
	}

	public CommonJobResponse processMigratedVehicle(ProcessMigVehRequest processMigVeh) throws GCAMPException {

		CommonJobResponse jobResponse = new CommonJobResponse();
		try {
			int jobId = jobSubmission(processMigVeh);
			String resultMsg = CommonConstants.JOB_SUBMISSION_MSG + jobId + " for the Batch Code "
					+ CommonConstants.PROCESS_MIG_VEH_BATCH_JOB_CODE;
			jobResponse.setStatus(CommonConstants.SUCCESS);
			jobResponse.setStatusCode(CommonConstants.SUCCESS_CODE);
			jobResponse.setStatusDescription(resultMsg);
		} catch (GCampBatchTriggerException e) {
			throw new GCAMPException(CommonConstants.BATCH_CODE_ERROR, e);

		}

		return jobResponse;
	}

	private int jobSubmission(ProcessMigVehRequest processMigVeh) throws GCAMPException {
		processMigVehjob.setCdsId(processMigVeh.getCdsId());
		processMigVehjob.setGlobalFSANo(Integer.parseInt(processMigVeh.getFsaNumber()));
		processMigVehjob.setHubCode(processMigVeh.getHub());
		processMigVehjob.setCountryCode(processMigVeh.getCountry());
		processMigVehjob.setEmailIndicator(CommonConstants.FLAG_Y);
		processMigVehjob.setBatchCode(CommonConstants.PROCESS_MIG_VEH_BATCH_JOB_CODE);
		return trigger.submitJob(processMigVehjob);
	}

	public RegionalFilterStateProvinceResponse getStatesProvinces(RegionalFilterStateRequest regionalFilterStateRequest)
			throws GCAMPException {
		String param1 = regionalFiltersMapper.getStatesProvincesparam1(regionalFilterStateRequest);
		String param2 = regionalFiltersMapper.getStatesProvincesparam2(regionalFilterStateRequest);
		Map<String, Object> responseMap = regionalFiltersRepository.getStatesProvinces(param1, param2);
		return regionalFiltersMapper.getStateProvincesResponse(responseMap);

	}

	public RoiCountryResponse loadCountry(FSACommonGoRequest regionalFiltersCountryRequest, String hubCode)
			throws GCAMPException {
		Map<String, Object> responseMap = loadHubRoiCountry(regionalFiltersCountryRequest);
		return regionalFiltersMapper.parseCountryResponseMap(responseMap, hubCode);

	}

	private Map<String, Object> loadHubRoiCountry(FSACommonGoRequest regionalFiltersCountryRequest)
			throws GCAMPException {
		String param1 = TargetingUtil.commonFsaGoRequest(regionalFiltersCountryRequest);
		String param2 = regionalFiltersMapper.countryParam2();
		return regionalFiltersRepository.loadCountry(param1, param2);
	}

	public CommonResponse saveRegionalFilters(RegionalFilterSaveRequest regionalFilterSaveRequest)
			throws GCAMPException {

		int regFilterParm = 0;
		if (regionalFilterSaveRequest.isOriginallySoldIn() && regionalFilterSaveRequest.isCurrentlyResidesIn()) {
			regFilterParm = 3;
		} else if (regionalFilterSaveRequest.isOriginallySoldIn()
				&& !regionalFilterSaveRequest.isCurrentlyResidesIn()) {
			regFilterParm = 1;
		} else if (!regionalFilterSaveRequest.isOriginallySoldIn()
				&& regionalFilterSaveRequest.isCurrentlyResidesIn()) {
			regFilterParm = 2;
		}
		regionalFilterSaveRequest.setParm(String.valueOf(regFilterParm));
		regionalFiltersMapper.filterHubCountries(regionalFilterSaveRequest);
		String param1 = regionalFiltersMapper.saveRegionalFiltersparam1(regionalFilterSaveRequest);
		String param2 = regionalFiltersMapper.saveRegionalFiltersparam2(regionalFilterSaveRequest);
		String param3 = regionalFiltersMapper.saveRegionalFiltersparam3(regionalFilterSaveRequest);
		String param4 = regionalFiltersMapper.saveRegionalFiltersparam4(regionalFilterSaveRequest);
		String param5 = regionalFiltersMapper.saveRegionalFiltersparam5(regionalFilterSaveRequest);
		Map<String, Object> responseMap = regionalFiltersRepository.saveRegionalFilters(param1, param2, param3, param4,
				param5);
		return regionalFiltersMapper.saveRegionalFiltersResponse(responseMap);
	}

	public CommonResponse deleteRegionalFilters(RegionalFiltersRequest deleteRequest) throws GCAMPException {

		String inputParam1 = regionalFiltersMapper.deleteInputParam1(deleteRequest);
		String inputParam2 = TargetingUtil.addSpaceToProc(1600);
		String inputParam3 = TargetingUtil.addSpaceToProc(2200);
		String inputParam4 = TargetingUtil.addSpaceToProc(6100);
		String inputParam5 = regionalFiltersMapper.regionalFiltersParam5(deleteRequest);
		Map<String, Object> deletedResponseMap = regionalFiltersRepository.deleteRegionalFilters(inputParam1,
				inputParam2, inputParam3, inputParam4, inputParam5);
		return regionalFiltersMapper.parseDeleteResponseMap(deletedResponseMap);
	}

	public GenericLookupResponse getSupplements(FSACommonGoRequest fsaGoRequest) throws GCAMPException {
		GenericLookupResponse supplementResponse = new GenericLookupResponse();
		Map<String, Object> fsaDeatils = commonRepository.getFsaInfo(fsaGoRequest);
		String errorParm = (String) fsaDeatils.get(CommonConstants.OUTPUT_ERR1);
		TargetingUtil.getResponseStatus(errorParm, supplementResponse);
		if (CommonConstants.SUCCESS.equalsIgnoreCase(supplementResponse.getStatus())) {
			FSAInfoVO fsaInfo = new FSAInfoVO();
			String oParam1 = (String) fsaDeatils.get(CommonConstants.OUTPUT_PARM1);
			String oParam2 = (String) fsaDeatils.get(CommonConstants.OUTPUT_PARM2);
			fsaInfo.setString(oParam1, oParam2);
			List<GenericLookup> supplements = regionalFiltersRepository.getSupplements(fsaInfo.getGlobalFSANumber());
			supplementResponse.setValues(supplements);
		}
		return supplementResponse;
	}

	public RegionalAuditReportResponse getRegionalAuditReport(String fsaNumber, String flag, String supplement) {
		RegionalAuditReportResponse regionalAuditReportResponse = new RegionalAuditReportResponse();
		List<RegionalAuditReport> regionalAuditReport = regionalFiltersRepository.getRegionalAuditReport(fsaNumber,
				flag, supplement);
		regionalAuditReportResponse.setStatus(CommonConstants.SUCCESS);
		regionalAuditReportResponse.setStatusCode(CommonConstants.SUCCESS_CODE);
		regionalAuditReportResponse.setStatusDescription(CommonConstants.SUCCESS);
		regionalAuditReportResponse.setRegionalAuditReport(regionalAuditReport);
		return regionalAuditReportResponse;
	}
}