package com.ford.gcamp.targeting.fsacriteria.entity;

import java.io.Serializable;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class VinGroupLookupId implements Serializable {

	private static final long serialVersionUID = 1L;

	private int globalFSANumber;
	private String vinGroupCode;

}
