
package com.ford.gcamp.targeting.reports.batch.exception.writer;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import com.ford.gcamp.targeting.reports.batch.common.ReportGenerationUtil;
import org.apache.commons.collections4.ListUtils;
import org.apache.poi.xssf.streaming.SXSSFSheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.item.Chunk;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.ford.gcamp.targeting.reports.batch.api.ExcelConfig;
import com.ford.gcamp.targeting.reports.batch.api.ReportMetaData;
import com.ford.gcamp.targeting.reports.batch.common.ReportCodeConstants;
import com.ford.gcamp.targeting.reports.batch.exception.GCAMPReportException;
import com.ford.gcamp.targeting.reports.batch.exception.api.TargetingExceptionReport;
import com.ford.gcamp.targeting.reports.batch.writer.GCAMPXSSFReportWriter;

@Component(ReportCodeConstants.T10 + "itemWriter")
@StepScope
public class ExcelVINNotFoundInVDMReportItemWriter extends GCAMPXSSFReportWriter implements ItemWriter<TargetingExceptionReport> {

	private List<TargetingExceptionReport> vinNotFoundInVDMList;
	
	@Value("#{jobParameters['reportMetaData']}")
	private String reportMetaDataString;

	private ReportMetaData rptData;
	
	@Value("${exception.report.xlsx.maxrecords}")
	private int xlsxMaxRecords;

	@Override
	public void write(Chunk<? extends TargetingExceptionReport> items) throws Exception {
		rptData = ReportGenerationUtil.getReportMetaDataObject(reportMetaDataString);
		vinNotFoundInVDMList = new ArrayList<>(items.getItems());
		this.createReport(rptData);
	}

	@Override
	public void createWorksheet(SXSSFWorkbook hssfWorkbook, ReportMetaData metaData) throws GCAMPReportException {

		initializeWorkbook(hssfWorkbook);
		
		List<List<TargetingExceptionReport>> vinNotFoundInVDMs = ListUtils.partition(vinNotFoundInVDMList,
				xlsxMaxRecords);
		List<ExcelConfig> vinNotFoundInVDMConfigList = loadConfigFile(ReportCodeConstants.T10,
				metaData.getSuppCode());
		int index = 1;
		for (List<TargetingExceptionReport> vinNotFoundInVDM : vinNotFoundInVDMs) {
			
			SXSSFSheet sheet = hssfWorkbook
					.createSheet(vinNotFoundInVDMList.size() > xlsxMaxRecords ? "VIN Not Found in VDM " + index
							: "VIN Not Found in VDM");
			try {

				createProfile(sheet, metaData, "VIN Not Found in VDM Report");

				setColumnWidth(sheet, vinNotFoundInVDMConfigList);

				setColumnHeader(sheet, vinNotFoundInVDMConfigList);

				setRowData(sheet, vinNotFoundInVDMConfigList, vinNotFoundInVDM);

			} catch (Exception e) {
				throw new GCAMPReportException("VIN Not Found In VDM REPORT ERROR", e);
			}
			index++;
		}

	}
	
	public void setXlsxMaxRecords(int xlsxMaxRecords) {
		this.xlsxMaxRecords = xlsxMaxRecords;
	}

	public void setRptData(ReportMetaData rptData) {
		this.rptData = rptData;
	}

}