package com.ford.gcamp.targeting.fsacriteria.api;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class FSACriteriaRegionalFilterDetails {

	@Size(min = 0, max = 2)
	@Pattern(regexp = "^[a-zA-Z\\*\\s\\d]*$")
	@Schema(example = "NA", description = "Hub code")
	private String hubCode;



	@Size(min = 0, max = 5)
	@Pattern(regexp = "^[a-zA-Z\\d\\*]*$")
	@Schema(example = "NR1", description = "Region of interest")
	private String roiCode;


	@Size(min = 0, max = 3)
	@Pattern(regexp = "^[a-zA-Z\\*\\s]*$")
	@Schema(example = "CAN", description = "CountryCode")
	private String countryCode;

	@Size(min = 0, max = 3)
	@Pattern(regexp = "^[\\d\\s]*$")
	@Schema(example = "01", description = "geographic code")
	private String geographicCode;

	@Size(min = 0, max = 2)
	@Pattern(regexp = "^[a-zA-Z]*$")
	@Schema(example = "AL", description = "state code")
	private String stateCode;
	
}
