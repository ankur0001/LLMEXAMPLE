package com.ford.gcamp.targeting.fsacriteria.entity;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@NoArgsConstructor
@Table(name = "SGCPD24_SLCN_ROI_CNTRY")
@Embeddable
public class RegionalFilterId implements Serializable {

	private static final long serialVersionUID = 1L;

	@Column(name = "GCPA15_GLOBL_FSA_R")
	private int globalFSANumber;
	
	@Column(name = "GCPA09_SUPPL_C")
	private String supplementId;

	@Column(name = "GCPD22_VINGP_LBL_C")
	private String vinGroupCode;

	@Column(name = "GCPD24_SA_INDEX")
	private int criteriaSequenceId;

}
