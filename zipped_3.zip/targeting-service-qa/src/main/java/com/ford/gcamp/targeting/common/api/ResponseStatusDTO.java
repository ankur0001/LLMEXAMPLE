package com.ford.gcamp.targeting.common.api;

import com.ford.gcamp.targeting.common.CommonConstants;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ResponseStatusDTO {

	@Size(min = 0, max = 30)
	@Pattern(regexp = "^[A-Za-z\\s\\d]*$")
	@Schema(types={"string","null"},example = "SUCCESS", description = "Status of the response")
	private String status = CommonConstants.SUCCESS;

	@Size(min = 0, max = 30)
	@Pattern(regexp = "^[A-Za-z\\d\\s_.,'()\"]*$")
	@Schema(types={"string","null"},example = "SUCCESS", description = "Status of the response")
	private String statusCode = CommonConstants.SUCCESS_CODE;

	@Size(min = 0, max = 500)
	@Pattern(regexp = "^[\\s\\S]*$")
	@Schema(types={"string","null"},example = "SUCCESS", description = "Status of the response")
	private String statusDescription = CommonConstants.SUCCESS_DESC;
	
}
