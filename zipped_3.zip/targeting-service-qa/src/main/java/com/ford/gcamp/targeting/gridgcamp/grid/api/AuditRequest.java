package com.ford.gcamp.targeting.gridgcamp.grid.api;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.*;

@Setter
@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class AuditRequest {
    @Schema(example = "G", description = "fsaType")
    @Size(min = 0, max = 1)
    @Pattern(regexp = "^[A-Za-z]$", message = "FSA Type")
    private String fsaType;

    @Size(min = 0, max = 10)
    @Pattern(regexp = "^[a-zA-Z\\d\\s]*$")
    @Schema(example = "15S01", description = "FSA number")
    private String fsaNumber;


    @Schema(example = "AA" , description = "supplement Code")
    @Size(min = 0, max = 2)
    @Pattern(regexp ="^[A-Za-z\\d\\*]*$")
    private String supplementCode;

    @Size(min = 0, max = 8)
    @Pattern(regexp = "^[a-zA-Z\\d\\-]*$")
    @Schema(example = "TDHARTI", description = "CDSID")
    private String cdsId;
}
