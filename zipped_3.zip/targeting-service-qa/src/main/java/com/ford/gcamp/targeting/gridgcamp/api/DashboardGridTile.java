package com.ford.gcamp.targeting.gridgcamp.api;

import java.util.List;

import com.ford.gcamp.targeting.gridgcamp.gcamp.api.VinAttachment;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Builder
public class DashboardGridTile {

	@Size(min = 0, max = 40, message = "Max length 40")
	@Pattern(regexp ="^|[A-Za-z\\d\\-\\s]*$")
	@Schema(example = "21-330-5-V1-S0", description = "vernNumber")
	private String vernNumber;

	@Size(min = 0, max = 10)
	@Pattern(regexp = "^|[\\d\\s]*$")
	@Schema(example = "17768", description = "Global FSA Number")
	private String globalFsaNumber;

	@Size(min = 0, max = 10)
	@Pattern(regexp = "^|[a-zA-Z\\d\\s]*$")
	@Schema(example = "15S01", description = "Local FSA number")
	private String localFsaNumber;

	@Size(min = 0, max = 100)
	@Pattern(regexp = "^|[a-zA-Z\\d\\-\\.\\:\\s]*$")
	@Schema(example = "test", description = "Local Fsa Description")
	private String localFsaDescription;


	@Size(min = 0, max = 2, message = "length 1-2")
	@Pattern(regexp ="^|[\\w\\s\\*]*$")
	@Schema(example = "01", description = "Population Code")
	private String population;

	@Size(min = 0, max = 100)
	@Pattern(regexp = "^|[a-zA-Z\\d\\-\\.\\:\\s]*$")
	@Schema(example = "VERN is not associated with any FSA", description = "Remarks")
	private String remarks;

	@Size(min = 1, max = 8)
	@Pattern(regexp = "^[a-zA-Z\\d\\-\\*]*$")
	@Schema(example = "SDUDIWAR", description = "Last Action By")
	private String lastActionBy;

	@Size(min = 0, max = 500, message = "List of Vin Attachment")
	private List<VinAttachment> vinAttachment; 
}
