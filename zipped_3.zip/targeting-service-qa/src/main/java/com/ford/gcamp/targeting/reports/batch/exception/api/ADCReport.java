package com.ford.gcamp.targeting.reports.batch.exception.api;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Builder
public class ADCReport {
	private String reportId;
	private String globalFsa;
	private String supplementCode;
	private String vinGroupCode; 
	private String vin;
	private String hubCode;
	private String countryCode;
	private String remarks;
	private String timestamp;
}

  