package com.ford.gcamp.targeting.fsacriteria.api;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class VinGroupVO {

	@Size(min = 0, max = 2)
	@Pattern(regexp = "^[a-zA-Z\\d\\s]*$")
	@Schema(example = "AA", description = "VingrpLabel")
	private String vinGrpLabel;

	@Size(min=0 ,max = 254)
	@Pattern(regexp = "^[A-Za-z\\d\\s\\*,._\\-()]*$")
	@Schema(example = "OTA Test1", description = "VinGrpDesc")
	private String vinGrpDesc;

	@Size(min = 0, max = 4)
	@Pattern(regexp = "^[A-Za-z\\d\\s\\*]*$")
	@Schema(example = "0001", description = "Vin Grp Seq")
	private String vinGrpSeq;

	@Size(min = 0, max = 1)
	@Pattern(regexp ="^[A-Za-z]$")
	@Schema(example= " " , description = "otaIndicator")
	private String otaIndicator;

	@Size(min = 0, max = 1)
	@Pattern(regexp ="^[A-Za-z]$")
	@Schema(example= " " , description = "FHM Indicator")
	private String fhmIndicator;
	
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("VinGroupVO [vinGrpLabel=");
		builder.append(vinGrpLabel);
		builder.append(", vinGrpDesc=");
		builder.append(vinGrpDesc);
		builder.append(", vinGrpSeq=");
		builder.append(vinGrpSeq);
		builder.append(", otaIndicator=");
		builder.append(otaIndicator);
		builder.append(", fhmIndicator=");
		builder.append(fhmIndicator);
		builder.append("]");
		return builder.toString();
	}
	
}
