package com.ford.gcamp.targeting.reports.batch.api;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class OrigSoldStateProvince extends GenericReportData {

    private String country;

    private String stateProvince;

    private String modelYear;

    private int count;

}
