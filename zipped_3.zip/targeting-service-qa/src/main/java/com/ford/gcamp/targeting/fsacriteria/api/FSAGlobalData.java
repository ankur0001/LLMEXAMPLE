package com.ford.gcamp.targeting.fsacriteria.api;

import org.springframework.stereotype.Component;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Component
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class FSAGlobalData {
private String localFsaCode;
private String localFscType;

}
