package com.ford.gcamp.targeting.reports.batch.exception.api;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Builder
public class AssignResponsibleDealer {

	private String vin;
	
	private String reason;
	
	private String hub;
	
	private String country;
	
	private String shippingDealer;
	
	private String sellingDealer;
	
	private String orderingDealer;
	
	private String stockingDealer;
}
