
package com.ford.gcamp.targeting.reports.batch.exception.writer;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import com.ford.gcamp.targeting.reports.batch.common.ReportGenerationUtil;
import org.apache.poi.xssf.streaming.SXSSFSheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.item.Chunk;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.ford.gcamp.targeting.reports.batch.api.ExcelConfig;
import com.ford.gcamp.targeting.reports.batch.api.ReportMetaData;
import com.ford.gcamp.targeting.reports.batch.common.ReportCodeConstants;
import com.ford.gcamp.targeting.reports.batch.exception.GCAMPReportException;
import com.ford.gcamp.targeting.reports.batch.exception.api.AssignResponsibleDealer;
import com.ford.gcamp.targeting.reports.batch.writer.GCAMPXSSFReportWriter;

@Component(ReportCodeConstants.ADE + "itemWriter")
@StepScope
public class ExcelAssignResponsibleDealerReportItemWriter extends GCAMPXSSFReportWriter
		implements ItemWriter<AssignResponsibleDealer> {

	private List<AssignResponsibleDealer> assignResponsibleDealerList;

	@Value("#{jobParameters['reportMetaData']}")
	private String reportMetaDataString;

	private ReportMetaData rptData;

	@Override
	public void write(Chunk<? extends AssignResponsibleDealer> items) throws Exception {
		rptData = ReportGenerationUtil.getReportMetaDataObject(reportMetaDataString);
		assignResponsibleDealerList = new ArrayList<>(items.getItems());
		this.createReport(rptData);
	}

	@Override
	public void createWorksheet(SXSSFWorkbook hssfWorkbook, ReportMetaData metaData) throws GCAMPReportException {

		initializeWorkbook(hssfWorkbook);

		SXSSFSheet sheet = hssfWorkbook.createSheet("Assign Responsible Dealer Exception");

		try {

			createProfile(sheet, metaData, "Assign Responsible Dealer Exception Report");

			List<ExcelConfig> assignResponsibleDealerConfigList = loadConfigFile(ReportCodeConstants.ADE,
					metaData.getSuppCode());

			setColumnWidth(sheet, assignResponsibleDealerConfigList);

			setColumnHeader(sheet, assignResponsibleDealerConfigList);

			setRowData(sheet, assignResponsibleDealerConfigList, assignResponsibleDealerList);

		} catch (Exception e) {
			throw new GCAMPReportException("Assign Responsible Dealer REPORT ERROR", e);
		}

	}

}