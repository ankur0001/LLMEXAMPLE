
package com.ford.gcamp.targeting.reports.batch.exception.writer;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import com.ford.gcamp.targeting.reports.batch.common.ReportGenerationUtil;
import org.apache.poi.xssf.streaming.SXSSFSheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.item.Chunk;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.ford.gcamp.targeting.reports.batch.api.ExcelConfig;
import com.ford.gcamp.targeting.reports.batch.api.ReportMetaData;
import com.ford.gcamp.targeting.reports.batch.common.ReportCodeConstants;
import com.ford.gcamp.targeting.reports.batch.exception.GCAMPReportException;
import com.ford.gcamp.targeting.reports.batch.exception.api.TargetingExceptionReport;
import com.ford.gcamp.targeting.reports.batch.writer.GCAMPXSSFReportWriter;

@Component(ReportCodeConstants.T12 + "itemWriter")
@StepScope
public class ExcelExcludeFileVINSNotInFSAReportItemWriter extends GCAMPXSSFReportWriter implements ItemWriter<TargetingExceptionReport> {

	private List<TargetingExceptionReport> excludeFileVINSNotInFSAList;

	@Value("#{jobParameters['reportMetaData']}")
	private String reportMetaDataString;

	private ReportMetaData rptData;

	@Override
	public void write(Chunk<? extends TargetingExceptionReport> items) throws Exception {
		rptData = ReportGenerationUtil.getReportMetaDataObject(reportMetaDataString);
		excludeFileVINSNotInFSAList = new ArrayList<>(items.getItems());
		this.createReport(rptData);
	}

	@Override
	public void createWorksheet(SXSSFWorkbook hssfWorkbook, ReportMetaData metaData) throws GCAMPReportException {

		initializeWorkbook(hssfWorkbook);

		SXSSFSheet sheet = hssfWorkbook.createSheet("Exclude File VINs not in FSA");

		try {

			createProfile(sheet, metaData, "Exclude File VINs not in FSA Report");

			List<ExcelConfig> excludeFileVINSNotInFSAConfigList = loadConfigFile(ReportCodeConstants.T12, metaData.getSuppCode());

			setColumnWidth(sheet, excludeFileVINSNotInFSAConfigList);

			setColumnHeader(sheet, excludeFileVINSNotInFSAConfigList);

			setRowData(sheet,excludeFileVINSNotInFSAConfigList, excludeFileVINSNotInFSAList);

		} catch (Exception e) {
			throw new GCAMPReportException("Error in processing Exclude File VINs not in FSA Report ", e);
		}

	}

}