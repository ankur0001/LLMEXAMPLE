package com.ford.gcamp.targeting.common.api;


import java.util.List;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class VinGroup {
	@Size(min = 1, max = 2)
	@Pattern(regexp = "^[A-Za-z\\d\\s\\*]*$")
	@Schema(example = "**", description = "Vin Group Code")
	private String vinGroupCode;

	@Size(min = 1, max = 254)
	@Pattern(regexp = "^[\\w\\s&\\.\\(\\)'\\*]*$")
	@Schema(example = "label", description = "vingrp Description")
	private String label;

	@Size(min = 0, max = 250, message = "Children List")
	private List<@Valid HubVinGroupRoiData> children;
}
