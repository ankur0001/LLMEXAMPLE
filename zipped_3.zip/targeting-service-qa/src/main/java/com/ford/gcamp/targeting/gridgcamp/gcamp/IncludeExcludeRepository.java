package com.ford.gcamp.targeting.gridgcamp.gcamp;
import com.ford.gcamp.targeting.gsar.api.IncludeExcludeEntity;
import com.ford.gcamp.targeting.gsar.api.IncludeExcludeId;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface IncludeExcludeRepository extends JpaRepository<IncludeExcludeEntity, IncludeExcludeId> {
    Optional<IncludeExcludeEntity> findTopByIncludeExcludeIdGlobalFsaNumberAndFolderPath(String globalFsaNumber, String folderPath);

    boolean existsByIncludeExcludeId_GlobalFsaNumberAndSupplementCodeAndFolderActionFlagIn(String globalFsaNumber, String supplementCode, List<String> folderActionFlags);
}