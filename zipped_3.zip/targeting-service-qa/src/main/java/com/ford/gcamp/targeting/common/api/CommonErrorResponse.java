package com.ford.gcamp.targeting.common.api;

import java.io.Serializable;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class CommonErrorResponse implements Serializable {
	
	private static final long serialVersionUID = 1L;
	@Size(min=0, max = 30)
	@Pattern(regexp ="^[A-Za-z\\s]*$")
	@Schema(types={"string","null"})
	private String status;
	
	@Size(min=0, max = 50)
	@Pattern(regexp ="^[A-Za-z\\d\\s_.,'()\"]*$")
	@Schema(types={"string","null"})
	private String statusCode;
	
	@Size(min=0, max = 500)
	@Pattern(regexp ="^[\\s\\S]*$")
	@Schema(types={"string","null"})
	private String statusDescription;
}
