package com.ford.gcamp.targeting.common.api;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@EqualsAndHashCode(callSuper=false)
public class CommonJobResponse extends CommonResponse {
	@Min(0)
	@Max(999999)
	@Schema(example = "1019", description = "jobId code")
	private int jobId;

}
