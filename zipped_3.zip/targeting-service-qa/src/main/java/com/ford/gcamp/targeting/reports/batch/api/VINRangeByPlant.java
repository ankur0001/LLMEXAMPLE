
package com.ford.gcamp.targeting.reports.batch.api;

import lombok.Getter;
import lombok.Setter;
@Setter
@Getter
public class VINRangeByPlant extends GenericReportData {

   
    private String plant;

   
    private String firstVIN;

   
    private String lastVIN;

   
    private String hubDesc;

   
    private String roiDesc;

   
    private String cntryDesc;

    
    private String brand;

   
    private String vehicleLine;

    
    private String modelYear;

    
    private String count;
    
    private String totalCount;
    
    private int countryRecordCount;


}
