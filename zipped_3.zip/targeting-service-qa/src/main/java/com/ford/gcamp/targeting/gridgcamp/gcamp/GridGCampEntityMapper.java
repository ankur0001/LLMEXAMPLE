package com.ford.gcamp.targeting.gridgcamp.gcamp;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.modelmapper.ModelMapper;
import org.springframework.beans.BeanWrapper;
import org.springframework.beans.PropertyAccessorFactory;
import org.springframework.stereotype.Component;

import com.ford.gcamp.targeting.common.CommonConstants;
import com.ford.gcamp.targeting.common.api.GenericLookup;
import com.ford.gcamp.targeting.fsacriteria.api.AttributeGroupingList;
import com.ford.gcamp.targeting.fsacriteria.api.LoadFsaResponseDTO;
import com.ford.gcamp.targeting.gridgcamp.GridGCampConstants;
import com.ford.gcamp.targeting.gridgcamp.gcamp.api.GridVehicleCriteria;
import com.ford.gcamp.targeting.gridgcamp.gcamp.api.GridVernInfo;
import com.ford.gcamp.targeting.gridgcamp.gcamp.api.MarketRegion;
import com.ford.gcamp.targeting.gridgcamp.gcamp.api.MarketRegionCriteria;
import com.ford.gcamp.targeting.gridgcamp.gcamp.api.ProductionDate;
import com.ford.gcamp.targeting.gridgcamp.gcamp.api.SoftwareCriteria;
import com.ford.gcamp.targeting.gridgcamp.gcamp.api.VehicleCode;
import com.ford.gcamp.targeting.gridgcamp.gcamp.api.VehicleCriteria;
import com.ford.gcamp.targeting.gridgcamp.gcamp.api.VinAttachment;
import com.ford.gcamp.targeting.gridgcamp.gcamp.entity.GridCriteriaData;
import com.ford.gcamp.targeting.gridgcamp.gcamp.entity.GridCriteriaId;
import com.ford.gcamp.targeting.gridgcamp.gcamp.entity.SoftwareCriteriaData;
import com.ford.gcamp.targeting.gridgcamp.gcamp.entity.SoftwareCriteriaId;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class GridGCampEntityMapper {

	public void transformGridVehicleCriteria(GridVernInfo gridVernRequest, List<GridCriteriaData> gcampVehicleCriteria,
			List<SoftwareCriteriaData> gcampSoftwareCriteria) {

		ModelMapper modelMapper = new ModelMapper();
		GridCriteriaId criteriaId = modelMapper.map(gridVernRequest, GridCriteriaId.class);
		AtomicInteger criteriaSeqId = new AtomicInteger(1);
		gridVernRequest.getVehicleCritiera().forEach(girdVehicleCriteria -> {

			AtomicInteger sequenceNum = new AtomicInteger(1);
			List<GridCriteriaData> tempGCampCriteria = new ArrayList<>();
			List<SoftwareCriteriaData> tempSoftwareCriteriaData = new ArrayList<>();
			getCommonCriteria(tempGCampCriteria, girdVehicleCriteria);

			getAdditionalCriteria(girdVehicleCriteria, tempGCampCriteria);
			if (CollectionUtils.isNotEmpty(girdVehicleCriteria.getSoftware())) {
				AtomicInteger softwareSeqNum = new AtomicInteger(1);
				girdVehicleCriteria.getSoftware().forEach(sftCriteria -> {
					SoftwareCriteriaData softwareCriteria = modelMapper.map(sftCriteria, SoftwareCriteriaData.class);
					softwareCriteria.setUpdateId(gridVernRequest.getRequester());
					softwareCriteria.setId(
							new SoftwareCriteriaId(criteriaId, criteriaSeqId.get(), softwareSeqNum.getAndIncrement()));
					tempSoftwareCriteriaData.add(softwareCriteria);
				});

			}

			tempGCampCriteria.forEach(tempCriterion -> {
				GridCriteriaId tempCriteriaId = new GridCriteriaId(criteriaId, criteriaSeqId.get(),
						sequenceNum.getAndIncrement());
				tempCriterion.setGridCriteriaId(tempCriteriaId);
				tempCriterion.setUpdateId(gridVernRequest.getRequester());
				if (!gridVernRequest.isOtaIndicator()) {
					tempCriterion.setCriteriaOTAIndicator(
							girdVehicleCriteria.isOtaIndicator() ? CommonConstants.FLAG_Y : CommonConstants.FLAG_N);
				} else {
					tempCriterion.setCriteriaOTAIndicator(CommonConstants.FLAG_Y);
				}
				log.info("OTA indicator at Vehcile line level {}", tempCriterion.getCriteriaOTAIndicator());
			});
			gcampVehicleCriteria.addAll(tempGCampCriteria);
			gcampSoftwareCriteria.addAll(tempSoftwareCriteriaData);
			criteriaSeqId.incrementAndGet();

		});

	}

	private void getAdditionalCriteria(VehicleCriteria girdVehicleCriteria, List<GridCriteriaData> tempGCampCriteria) {
		if (CollectionUtils.isNotEmpty(girdVehicleCriteria.getVehicleCode())) {
			getVehicleCodes(girdVehicleCriteria, tempGCampCriteria);
		}

		if (ObjectUtils.isNotEmpty(girdVehicleCriteria.getMarketRegions())) {
			getMarketRegionsCriteria(girdVehicleCriteria.getMarketRegions(), tempGCampCriteria);
		}

		if (ObjectUtils.isNotEmpty(girdVehicleCriteria.getProduction())) {
			getProductionDateCriteria(girdVehicleCriteria.getProduction(), tempGCampCriteria);
		}
	}

	private void getMarketRegionsCriteria(MarketRegionCriteria marketRegions,
			List<GridCriteriaData> tempGCampCriteria) {

		if (CollectionUtils.isNotEmpty(marketRegions.getValue())) {
			marketRegions.getValue().forEach(marketRegion -> {
				GridCriteriaData gridCriteriaData = getMarketRegionCriteria(marketRegion.getRegion(),
						marketRegion.getRegion().getCode(), marketRegions.getOperator(), CommonConstants.FLAG_R);
				tempGCampCriteria.add(gridCriteriaData);
				if (CollectionUtils.isNotEmpty(marketRegion.getCountries())) {
					marketRegion.getCountries().forEach(country -> {
						GridCriteriaData countryCriteriaData = getMarketRegionCriteria(country,
								marketRegion.getRegion().getCode(), marketRegions.getOperator(),
								CommonConstants.FLAG_C);
						tempGCampCriteria.add(countryCriteriaData);
					});
				}
			});
		}
	}

	private GridCriteriaData getMarketRegionCriteria(GenericLookup marketRegion, String region, String operator,
			String regionCountryFlag) {
		GridCriteriaData gridCriteriaData = new GridCriteriaData();
		gridCriteriaData.setFilterCode(0);
		gridCriteriaData.setFilterDescription(region);
		gridCriteriaData.setOperator(operator);
		gridCriteriaData.setAttributeBegin(regionCountryFlag);
		gridCriteriaData.setAttributeCode(marketRegion.getCode());
		gridCriteriaData.setAttributeDescription(marketRegion.getDescription());
		return gridCriteriaData;
	}

	private void getCommonCriteria(List<GridCriteriaData> criteria, VehicleCriteria girdVehicleCriteria) {

		for (Entry<Integer, String> entry : GridGCampConstants.VEHICLE_CRITERIA_PROPERTIES_MAP.entrySet()) {
			GridVehicleCriteria gridCriteria = getGridVehCriteriaByPropertyName(girdVehicleCriteria, entry.getValue());
			if (gridCriteria!=null &&  ObjectUtils.isNotEmpty(gridCriteria)) {
				transformVehicleCriteria(criteria, gridCriteria);
			}
		}

		if (CollectionUtils.isNotEmpty(girdVehicleCriteria.getWers())) {
			for (GridVehicleCriteria wers : girdVehicleCriteria.getWers()) {
				transformVehicleCriteria(criteria, wers);
			}
		}

	}

	private void transformVehicleCriteria(List<GridCriteriaData> criteria, GridVehicleCriteria gridCriteria) {
		if (ObjectUtils.isNotEmpty(gridCriteria)) {
			for (GenericLookup lookup : gridCriteria.getValue()) {
				GridCriteriaData gridCriteriaData = new GridCriteriaData();
				gridCriteriaData.setFilterCode(StringUtils.isNotBlank(gridCriteria.getFilter().getCode())
						&& NumberUtils.isCreatable(gridCriteria.getFilter().getCode())
								? Integer.parseInt(gridCriteria.getFilter().getCode())
								: 0);
				gridCriteriaData.setFilterDescription(gridCriteria.getFilter().getDescription());
				gridCriteriaData.setOperator(gridCriteria.getOperator());
				gridCriteriaData.setAttributeCode(StringUtils.trimToEmpty(lookup.getCode()).length() > 100
						? StringUtils.trimToEmpty(lookup.getCode()).substring(0, 99)
						: StringUtils.trimToEmpty(lookup.getCode()));
				gridCriteriaData.setAttributeDescription(lookup.getDescription());
				criteria.add(gridCriteriaData);
			}

		}
	}

	private GridVehicleCriteria getGridVehCriteriaByPropertyName(VehicleCriteria vehicleCritiera, String propertyName) {

		try {
			BeanWrapper wrapper = PropertyAccessorFactory.forBeanPropertyAccess(vehicleCritiera);
			Optional<Object> value = Optional.ofNullable(wrapper.getPropertyValue(propertyName));
			if (value.isPresent()) {
				return (GridVehicleCriteria) value.get();
			}
		} catch (Exception ex) {
			log.error("Coundn't find the getter method for a given property {} in Class {} and error {}", propertyName,
					vehicleCritiera, ex);
		}
		return null;
	}

	private List<GridCriteriaData> getProductionDateCriteria(ProductionDate productionDate,
			List<GridCriteriaData> criteria) {

		GridCriteriaData productionDateCriteria = new GridCriteriaData();
		productionDateCriteria.setFilterCode(NumberUtils.isCreatable(productionDate.getFilter().getCode())
				? Integer.parseInt(productionDate.getFilter().getCode())
				: 0);
		productionDateCriteria.setFilterDescription(productionDate.getFilter().getDescription());
		productionDateCriteria.setOperator(productionDate.getOperator());
		productionDateCriteria.setAttributeBegin(productionDate.getStartDate());
		productionDateCriteria.setAttributeEnd(productionDate.getEndDate());
		criteria.add(productionDateCriteria);
		return criteria;
	}

	private List<GridCriteriaData> getVehicleCodes(VehicleCriteria vehicleCriteria, List<GridCriteriaData> criteria) {
		log.info("size befores vechicle attributes {}", criteria.size());
		for (VehicleCode vehicleCode : vehicleCriteria.getVehicleCode()) {

			if (CollectionUtils.isNotEmpty(vehicleCode.getValue())) {
				for (String value : vehicleCode.getValue()) {
					GridCriteriaData criteriaData = new GridCriteriaData();
					criteriaData.setFilterCode(NumberUtils.isCreatable(vehicleCode.getFilter().getCode())
							? Integer.parseInt(vehicleCode.getFilter().getCode())
							: 0);
					criteriaData.setFilterDescription(vehicleCode.getFilter().getDescription());
					criteriaData.setOperator(vehicleCode.getOperator());
					criteriaData.setAttributeCode(vehicleCode.getFilterGroup().getCode());
					criteriaData.setAttributeDescription(value);
					criteriaData.setAttributeBegin(vehicleCode.getValueFrom());
					criteriaData.setAttributeEnd(vehicleCode.getValueTo());
					criteria.add(criteriaData);
				}
			} else {
				GridCriteriaData criteriaData = new GridCriteriaData();
				criteriaData.setFilterCode(NumberUtils.isCreatable(vehicleCode.getFilter().getCode())
						? Integer.parseInt(vehicleCode.getFilter().getCode())
						: 0);
				criteriaData.setFilterDescription(vehicleCode.getFilter().getDescription());
				criteriaData.setOperator(vehicleCode.getOperator());
				criteriaData.setAttributeCode(vehicleCode.getFilterGroup().getCode());
				criteriaData.setAttributeDescription(StringUtils.EMPTY);
				criteriaData.setAttributeBegin(vehicleCode.getValueFrom());
				criteriaData.setAttributeEnd(vehicleCode.getValueTo());
				criteria.add(criteriaData);
			}

		}
		log.info("size after vechicle attributes {}", criteria.size());
		return criteria;

	}

	public String convertVinAttachmentsToString(List<VinAttachment> vinAttachments) {
		StringBuilder vinAttachmentBuilder = new StringBuilder();
		if (CollectionUtils.isNotEmpty(vinAttachments)) {
			for (VinAttachment vinAttachment : vinAttachments) {
				if (StringUtils.isNotBlank(vinAttachment.getType())
						&& StringUtils.isNotBlank(vinAttachment.getFilePath())
						&& StringUtils.isNotBlank(vinAttachment.getFileName())) {
					vinAttachmentBuilder.append(vinAttachment.getType()).append("|").append(vinAttachment.getFilePath())
							.append("|").append(vinAttachment.getFileName()).append("|")
							.append(vinAttachment.getAction()).append("|")
							.append(StringUtils.isNotBlank(vinAttachment.getDeletedVernNumber())
									? vinAttachment.getDeletedVernNumber()
									: StringUtils.SPACE)
							.append("|")
							.append(StringUtils.isNotBlank(vinAttachment.getAddedVernNumber())
									? vinAttachment.getAddedVernNumber()
									: StringUtils.SPACE)
							.append("|").append(vinAttachment.getVinCount()).append(",");
				}

			}
		}
		return vinAttachmentBuilder.toString();
	}

	public List<VinAttachment> convertStringToVinAttachments(String vinListFileDetails) {
		List<VinAttachment> vinAttachments = new ArrayList<>();
		if (StringUtils.isNotBlank(vinListFileDetails)) {
			String[] vinListFileDetailsArr = StringUtils.split(vinListFileDetails, ",");
			for (String vinListFile : vinListFileDetailsArr) {
				if (StringUtils.isNotBlank(vinListFile)) {
					VinAttachment vinAttachment = getVinAttachment(vinListFile);
					vinAttachments.add(vinAttachment);
				}
			}
		}
		return vinAttachments;
	}

	private VinAttachment getVinAttachment(String vinListFile) {
		String[] vinListFileArr = StringUtils.split(vinListFile, "|");
		return new VinAttachment(vinListFileArr[0], vinListFileArr[1],
				vinListFileArr.length > 2 ? vinListFileArr[2] : StringUtils.EMPTY,
				vinListFileArr.length > 3 ? vinListFileArr[3] : StringUtils.EMPTY,
				vinListFileArr.length > 4 ? vinListFileArr[4] : StringUtils.EMPTY,
				vinListFileArr.length > 5 ? vinListFileArr[5] : StringUtils.EMPTY,
				vinListFileArr.length > 6 && NumberUtils.isCreatable(vinListFileArr[6])
						? Integer.parseInt(vinListFileArr[6])
						: 0);
	}

	public List<VehicleCriteria> transformGridCriteria(List<GridCriteriaData> criteria,
			List<SoftwareCriteriaData> softwareCriteria, LoadFsaResponseDTO fsaCriteriaLookupData,
			List<Integer> vehicleAttrFilterCodes) {

		List<VehicleCriteria> vehicleCriteria = new ArrayList<>();
		Map<Integer, List<GridCriteriaData>> criteriaIdentifierGroup = criteria.stream()
				.sorted(Comparator.comparing(gridCriteria -> gridCriteria.getGridCriteriaId().getCriteriaNumber()))
				.collect(Collectors.groupingBy(gridCriteria -> gridCriteria.getGridCriteriaId().getCriteriaNumber(),
						HashMap::new, Collectors.toList()));

		Map<Integer, List<SoftwareCriteriaData>> softwareCriteriaGroup = softwareCriteria.stream()
				.sorted(Comparator.comparing(swCriteria -> swCriteria.getId().getCriteriaNumber()))
				.collect(Collectors.groupingBy(swCriteria -> swCriteria.getId().getCriteriaNumber(), HashMap::new,
						Collectors.toList()));

		for (Entry<Integer, List<GridCriteriaData>> criteriaEntry : criteriaIdentifierGroup.entrySet()) {

			VehicleCriteria vehicleCriterion = new VehicleCriteria();

			Map<Integer, List<GridCriteriaData>> filterGroup = criteriaEntry.getValue().stream()
					.sorted(Comparator.comparing(GridCriteriaData::getFilterCode))
					.collect(Collectors.groupingBy(GridCriteriaData::getFilterCode, HashMap::new, Collectors.toList()));

			for (Entry<Integer, List<GridCriteriaData>> filterEntry : filterGroup.entrySet()) {

				String propertyName = GridGCampConstants.VEHICLE_CRITERIA_PROPERTIES_MAP.get(filterEntry.getKey());
				if (StringUtils.isNotBlank(propertyName)) {
					GridVehicleCriteria gridVehCriteria = new GridVehicleCriteria();
					List<GenericLookup> values = new ArrayList<>();
					GenericLookup filter = null;
					String operator = null;
					for (GridCriteriaData gridFilterCriteria : filterEntry.getValue()) {
						GenericLookup value = GenericLookup.builder().code(gridFilterCriteria.getAttributeCode())
								.description(gridFilterCriteria.getAttributeDescription()).build();
						values.add(value);
						filter = GenericLookup.builder().code(String.valueOf(gridFilterCriteria.getFilterCode()))
								.description(gridFilterCriteria.getFilterDescription()).build();
						operator = StringUtils.trimToEmpty(gridFilterCriteria.getOperator());

						vehicleCriterion.setOtaIndicator(
								CommonConstants.FLAG_Y.equalsIgnoreCase(gridFilterCriteria.getCriteriaOTAIndicator()));

					}
					gridVehCriteria.setFilter(filter);
					gridVehCriteria.setOperator(operator);
					gridVehCriteria.setValue(values);
					setGridVehCriteriaByPropertyName(vehicleCriterion, propertyName, gridVehCriteria);

				} else if (GridGCampConstants.PRODUCTION_DATE_FILTER_CODE == (filterEntry.getKey())) {
					vehicleCriterion.setProduction(getProductionDateData(filterEntry));
				} else if (vehicleAttrFilterCodes.stream()
						.anyMatch(vehicleAttr -> vehicleAttr.equals(filterEntry.getKey()))) {
					getVehicleCodesFromDB(vehicleCriterion, filterEntry.getValue(),
							fsaCriteriaLookupData.getAttributeGroupingLists());
				} else if (fsaCriteriaLookupData.getGcpFilterList().stream()
						.anyMatch(wers -> wers.getGcpFilterC() == filterEntry.getKey())) {
					getWers(vehicleCriterion, filterEntry.getValue());
				} else if (filterEntry.getKey() == 0) {
					vehicleCriterion.setMarketRegions(getMarketRegions(filterEntry.getValue()));
				}

			}
			List<SoftwareCriteria> software = transformSoftwareCriteria(softwareCriteriaGroup, criteriaEntry.getKey());
			vehicleCriterion.setSoftware(software);
			vehicleCriteria.add(vehicleCriterion);

		}
		return vehicleCriteria;

	}

	private MarketRegionCriteria getMarketRegions(List<GridCriteriaData> marketRegionCriteriaData) {

		MarketRegionCriteria marketRegionCriteria = new MarketRegionCriteria();
		Map<String, List<GridCriteriaData>> filterGroup = marketRegionCriteriaData.stream()
				.sorted(Comparator.comparing(GridCriteriaData::getFilterDescription)).collect(Collectors
						.groupingBy(GridCriteriaData::getFilterDescription, HashMap::new, Collectors.toList()));
		List<MarketRegion> marketRegions = new ArrayList<>();
		filterGroup.entrySet().forEach(market -> {
			MarketRegion marketRegion = new MarketRegion();
			List<GenericLookup> countries = new ArrayList<>();
			market.getValue().forEach(regionCountry -> {
				if (CommonConstants.FLAG_R
						.equalsIgnoreCase(StringUtils.trimToEmpty(regionCountry.getAttributeBegin()))) {
					GenericLookup region = GenericLookup.builder().code(regionCountry.getAttributeCode())
							.description(regionCountry.getAttributeDescription()).build();
					marketRegion.setRegion(region);
				} else {
					GenericLookup country = GenericLookup.builder().code(regionCountry.getAttributeCode())
							.description(regionCountry.getAttributeDescription()).build();
					countries.add(country);
				}
			});
			marketRegion.setCountries(countries);
			marketRegions.add(marketRegion);
		});
		marketRegionCriteria.setValue(marketRegions);
		marketRegionCriteria.setOperator(StringUtils.trimToEmpty(marketRegionCriteriaData.get(0).getOperator()));
		return marketRegionCriteria;
	}

	private List<SoftwareCriteria> transformSoftwareCriteria(
			Map<Integer, List<SoftwareCriteriaData>> softwareCriteriaGroup, int criteriaNum) {
		List<SoftwareCriteria> software = new ArrayList<>();
		if (softwareCriteriaGroup.containsKey(criteriaNum)) {
			softwareCriteriaGroup.get(criteriaNum).forEach(softwareEntry -> {
				ModelMapper modelMapper = new ModelMapper();
				SoftwareCriteria tempSwCriteria = modelMapper.map(softwareEntry, SoftwareCriteria.class);
				software.add(tempSwCriteria);
			});
		}
		return software;
	}

	private void getWers(VehicleCriteria vehicleCriterion, List<GridCriteriaData> wersValues) {
		if (CollectionUtils.isEmpty(vehicleCriterion.getWers())) {
			vehicleCriterion.setWers(new ArrayList<>());
		}

		List<GridVehicleCriteria> wers = vehicleCriterion.getWers();

		GridVehicleCriteria gridVehCriteria = new GridVehicleCriteria();
		List<GenericLookup> values = new ArrayList<>();
		GenericLookup filter = null;
		String operator = null;
		for (GridCriteriaData gridFilterCriteria : wersValues) {
			GenericLookup value = GenericLookup.builder().code(gridFilterCriteria.getAttributeCode())
					.description(gridFilterCriteria.getAttributeDescription()).build();
			values.add(value);
			filter = GenericLookup.builder().code(String.valueOf(gridFilterCriteria.getFilterCode()))
					.description(gridFilterCriteria.getFilterDescription()).build();
			operator = StringUtils.trimToEmpty(gridFilterCriteria.getOperator());
		}
		gridVehCriteria.setFilter(filter);
		gridVehCriteria.setOperator(operator);
		gridVehCriteria.setValue(values);
		wers.add(gridVehCriteria);
	}

	private void getVehicleCodesFromDB(VehicleCriteria vehicleCriterion, List<GridCriteriaData> vehicleAttributes,
			List<AttributeGroupingList> attributeGroups) {

		if (CollectionUtils.isEmpty(vehicleCriterion.getVehicleCode())) {
			vehicleCriterion.setVehicleCode(new ArrayList<>());
		}
		List<VehicleCode> vehicleCodes = vehicleCriterion.getVehicleCode();
		VehicleCode gridVehicleCode = new VehicleCode();
		List<String> values = new ArrayList<>();
		GenericLookup filter = null;
		String operator = null;
		if (CollectionUtils.isNotEmpty(vehicleAttributes)) {
			for (GridCriteriaData gridVehicleAttribute : vehicleAttributes) {
				if (StringUtils.isNotEmpty(gridVehicleAttribute.getAttributeDescription())) {
					values.add(gridVehicleAttribute.getAttributeDescription());
				}
				Optional<AttributeGroupingList> attributeGrp = attributeGroups.stream().filter(attrGrp -> attrGrp
						.getGcpFilterGRPC() == Integer.parseInt(gridVehicleAttribute.getAttributeCode())).findFirst();
				gridVehicleCode.setFilterGroup(GenericLookup.builder()
						.code(String.valueOf(gridVehicleAttribute.getAttributeCode()))
						.description(
								attributeGrp.isPresent() ? attributeGrp.get().getGcpFilterGRPX() : StringUtils.EMPTY)
						.build());
				filter = GenericLookup.builder().code(String.valueOf(gridVehicleAttribute.getFilterCode()))
						.description(gridVehicleAttribute.getFilterDescription()).build();
				operator = StringUtils.trimToEmpty(gridVehicleAttribute.getOperator());
				gridVehicleCode.setValueFrom(gridVehicleAttribute.getAttributeBegin());
				gridVehicleCode.setValueTo(gridVehicleAttribute.getAttributeEnd());
			}
		}
		gridVehicleCode.setFilter(filter);
		gridVehicleCode.setOperator(operator);
		gridVehicleCode.setValue(values);
		vehicleCodes.add(gridVehicleCode);
	}

	private ProductionDate getProductionDateData(Entry<Integer, List<GridCriteriaData>> filterEntry) {
		ProductionDate productionDate = new ProductionDate();
		filterEntry.getValue().forEach(gridFilterCriteria -> {
			productionDate.setFilter(GenericLookup.builder().code(String.valueOf(gridFilterCriteria.getFilterCode()))
					.description(gridFilterCriteria.getFilterDescription()).build());
			productionDate.setOperator(StringUtils.trimToEmpty(gridFilterCriteria.getOperator()));
			productionDate.setStartDate(StringUtils.trimToEmpty(gridFilterCriteria.getAttributeBegin()));
			productionDate.setEndDate(StringUtils.trimToEmpty(gridFilterCriteria.getAttributeEnd()));

		});
		return productionDate;
	}

	private void setGridVehCriteriaByPropertyName(VehicleCriteria vehicleCritiera, String propertyName,
			GridVehicleCriteria gridVehCriteria) {

		try {
			BeanWrapper wrapper = PropertyAccessorFactory.forBeanPropertyAccess(vehicleCritiera);
			wrapper.setPropertyValue(propertyName, gridVehCriteria);
		} catch (Exception ex) {
			log.error("Coundn't find the getter method for a given property {} in Class {} and error {}", propertyName,
					vehicleCritiera, ex);
		}
	}

}
