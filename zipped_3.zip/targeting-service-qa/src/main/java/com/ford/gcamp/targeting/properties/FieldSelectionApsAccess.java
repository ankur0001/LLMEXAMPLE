package com.ford.gcamp.targeting.properties;

import java.util.Map;

import org.springframework.boot.context.properties.ConfigurationProperties;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@ConfigurationProperties(prefix = "fsavin.fieldselection.aps")
@Getter
@Setter
@NoArgsConstructor
public class FieldSelectionApsAccess {

	private String pageName;
	private Map<String, String> resources;
}
