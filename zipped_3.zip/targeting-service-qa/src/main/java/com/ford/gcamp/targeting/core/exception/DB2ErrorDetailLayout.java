package com.ford.gcamp.targeting.core.exception;

import java.io.Serializable;

import com.ford.gcamp.targeting.common.api.LayoutBuffer;

public class DB2ErrorDetailLayout extends LayoutBuffer implements Serializable{

	private static final long serialVersionUID = 1L;
	private static final int DB2_ERR_LAYOUT_LENGTH = 246;

	/**
	 * Constructor for DB2ErrorDetailLayout
	 */
	public DB2ErrorDetailLayout(int length) {
		super(length);
	}

	/**
	 * Constructor for DB2ErrorDetailLayout
	 */
	public DB2ErrorDetailLayout() {
		this(DB2_ERR_LAYOUT_LENGTH);
	}
	

}

