package com.ford.gcamp.targeting;

import com.ford.aps.spring.configuration.EnableApsService;
import net.javacrumbs.shedlock.spring.annotation.EnableSchedulerLock;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.ConfigurationPropertiesScan;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.scheduling.annotation.EnableScheduling;
import reactor.core.publisher.Hooks;

@SpringBootApplication
@EnableCaching
@EnableApsService
@EnableScheduling
@EnableSchedulerLock(defaultLockAtMostFor = "PT30S")
@ConfigurationPropertiesScan("com.ford.gcamp.targeting.properties")
public class TargetingApplication {

	public static void main(String[] args) {
		Hooks.enableAutomaticContextPropagation();
		SpringApplication.run(TargetingApplication.class, args);
	}

}
