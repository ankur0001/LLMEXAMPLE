package com.ford.gcamp.targeting.gridgcamp.gcamp.api;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

import com.ford.gcamp.targeting.common.api.GenericLookup;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonIgnoreProperties(ignoreUnknown = true)
public class VehicleCode {

	@Valid
	private GenericLookup filterGroup;

	@Schema(description = "valueFrom", example = " ")
	@Size(min = 0, max = 25, message = "length max 25")
	@Pattern(regexp ="^|[A-Za-z\\s]*$")
	private String valueFrom;

	@Schema(description = "valueFrom", example = " ")
	@Size(min = 0, max = 25, message = "length max 25")
	@Pattern(regexp ="^|[A-Za-z\\s]*$")
	private String valueTo;
	@Size(min=0, max = 500)
	private List< @Size(min = 0, max = 25, message = "length max 25")
	@Pattern(regexp ="^|[A-Za-z\\s]*$") String> value;

	@Schema(description = "valueFrom", example = " ")
	@Size(min = 0, max = 25, message = "length max 25")
	@Pattern(regexp ="^|[A-Za-z\\s]*$")
	private String operator;
	@Valid
	private GenericLookup filter;
}
