package com.ford.gcamp.targeting.fsacriteria.api;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class FsaCriteriaResponse {

	private List<String> outputParam1;
	private List<String> outputParam2;
	private String outputParam3;
	private String errorParam1;
	private String errorParam2;

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("FsaCriteriaResponse [outputParam1=");
		builder.append(outputParam1);
		builder.append(", outputParam2=");
		builder.append(outputParam2);
		builder.append(", outputParam3=");
		builder.append(outputParam3);
		builder.append(", errorParam1=");
		builder.append(errorParam1);
		builder.append(", errorParam2=");
		builder.append(errorParam2);
		builder.append("]");
		return builder.toString();
	}

	
	
}
