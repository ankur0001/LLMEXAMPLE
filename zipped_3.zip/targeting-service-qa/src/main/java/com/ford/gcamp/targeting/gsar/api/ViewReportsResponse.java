package com.ford.gcamp.targeting.gsar.api;

import java.util.List;

import com.ford.gcamp.targeting.common.api.CommonResponse;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ViewReportsResponse extends CommonResponse {
	@Size(min = 0, max = 250, message = "view Reports List")
	private List<@Valid ViewReports> viewReports;
}
