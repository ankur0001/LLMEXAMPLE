package com.ford.gcamp.targeting.common;

import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;
import org.springframework.web.util.HtmlUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import com.ford.gcamp.targeting.common.api.FSACommonGoRequest;
import com.ford.gcamp.targeting.common.api.GenericLookup;
import com.ford.gcamp.targeting.core.exception.GCAMPException;

import lombok.extern.slf4j.Slf4j;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;

@Repository
@Slf4j
public class CommonRepository {

	@Autowired
	private JdbcTemplate jdbcTemplate;
	@Value("${DB_OWNER}")
	private String ownerId;

	@Value("${db2.uncommit.read}")
	private String uncommitRead;
	@Autowired
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

	public Map<String, Object> loadCountry(String inputParam1, String inputParam2, String inputParam3)
			throws GCAMPException {

		try {
			SimpleJdbcCall simpleJdbcCall = creatSimpleJdbcCall(CommonConstants.FSA_SCHEMA_NAME,
					CommonConstants.FSA_SELECT_COUNTRY);
			SqlParameterSource sqlParameterSource = createSqlParameterSource(CommonConstants.INPUT_PARM1, inputParam1,
					CommonConstants.INPUT_PARM2, inputParam2, CommonConstants.INPUT_PARM3, inputParam3);
			log.info("input of ROI Country proc info {}", sqlParameterSource);
			return simpleJdbcCall.execute(sqlParameterSource);
		} catch (Exception e) {
			throw new GCAMPException(CommonConstants.DB_EXCEPTION, e);
		}

	}

	public Map<String, Object> getFsaInfo(FSACommonGoRequest fsaGoRequest) throws GCAMPException {
		try {
			SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate)
					.withSchemaName(CommonConstants.FSA_SCHEMA_NAME).withProcedureName(CommonConstants.J12_STORE_PROC);
			String param1 = TargetingUtil.commonFsaGoRequest(fsaGoRequest);
			return simpleJdbcCall.execute(new MapSqlParameterSource().addValue(CommonConstants.INPUT_PARM1, param1));
		} catch (Exception e) {
			throw new GCAMPException(CommonConstants.DB_EXCEPTION, e);
		}
	}

	MapSqlParameterSource createSqlParameterSource(String inputParamKey1, String inputParamVal1, String inputParamKey2,
			String inputParamVal2, String inputParamKey3, String inputParamVal3) {
		return new MapSqlParameterSource().addValue(inputParamKey1, inputParamVal1)
				.addValue(inputParamKey2, inputParamVal2).addValue(inputParamKey3, inputParamVal3);

	}

	SimpleJdbcCall creatSimpleJdbcCall(String schemaName, String procedureName) {
		return new SimpleJdbcCall(jdbcTemplate).withSchemaName(schemaName).withProcedureName(procedureName);
	}

	public List<GenericLookup> getSupplements(String globalFsaNumber) {
		Map<String, Object> valueByKey = new HashMap<>();
		valueByKey.put("globalFsaNumber", HtmlUtils.htmlEscape(globalFsaNumber));
		SqlParameterSource parameters = new MapSqlParameterSource(valueByKey);
		StringBuilder sqlValue = new StringBuilder();
		sqlValue.append("SELECT DISTINCT GCPA09_SUPPL_C AS code ,GCPA09_SUPP_DESC_X AS description ");
		sqlValue.append(" FROM ");
		sqlValue.append(ownerId);
		sqlValue.append("SGCPA09_FSA_SUPPL ");
		sqlValue.append(" WHERE GCPA15_GLOBL_FSA_R = :globalFsaNumber ");
		sqlValue.append(" ORDER BY GCPA09_SUPP_DESC_X ");
		sqlValue.append(uncommitRead);
		return namedParameterJdbcTemplate.query(sqlValue.toString(), parameters,
				new BeanPropertyRowMapper<GenericLookup>(GenericLookup.class));
	}
	
	public String getFRCDecisionDate(int globalFSANumber) {
		StringBuilder sqlQuery = new StringBuilder();
		String frcDecisionDate = StringUtils.EMPTY;
		sqlQuery.append("SELECT GCPA15_FRC_DECN_Y FROM ").append(ownerId).append("SGCPA15_GLOBAL_FSA")
				.append(" WHERE GCPA15_GLOBL_FSA_R= :globalFSANumber ").append(uncommitRead);
		SqlParameterSource parameters = new MapSqlParameterSource().addValue("globalFSANumber", globalFSANumber);
		try {
			frcDecisionDate =namedParameterJdbcTemplate.queryForObject(sqlQuery.toString(), parameters, String.class);
			return CommonConstants.INVALID_DATE.equals(frcDecisionDate) ? StringUtils.EMPTY : frcDecisionDate;
		} catch (EmptyResultDataAccessException e) {
			log.info("No records found for the Global FSA: {} in A15 Table", globalFSANumber);
		}
		return frcDecisionDate;
	}

	public String getFSAExpirationDate(int globalFSANumber, String hub) {
		StringBuilder sqlQuery = new StringBuilder();
		String fsaExpirationDate = StringUtils.EMPTY;
		sqlQuery.append("SELECT GCPA16_EXPIRE_Y FROM ").append(ownerId).append("SGCPA16_GLBFSAHUB")
				.append(" WHERE GCPA15_GLOBL_FSA_R = :globalFSANumber").append(" AND GCPE10_HUB_C = :hub ").append(uncommitRead);
		SqlParameterSource parameterSource = new MapSqlParameterSource().addValue("globalFSANumber", globalFSANumber).addValue("hub", hub);
		try {
			fsaExpirationDate = namedParameterJdbcTemplate.queryForObject(sqlQuery.toString(), parameterSource, String.class);
			return CommonConstants.INVALID_DATE.equals(fsaExpirationDate) ? StringUtils.EMPTY : fsaExpirationDate;
		} catch (EmptyResultDataAccessException e) {
			log.info("No records found for the Global FSA: {} and Hub: {} in A16 Table", globalFSANumber, hub);
		}
		return fsaExpirationDate;
	}
	
	public List<String> getFSACoordinatorsCdsids(List<String> hubCodes) {
		StringBuilder sqlQuery = new StringBuilder();
		sqlQuery.append("SELECT GCPG12_CDS_ID_C FROM ")
				.append(ownerId)
				.append("SGCPG12_DSTLST_DTL G12, ")
				.append(ownerId)
				.append("SGCPG13_DST_PRC G13, ")
				.append(ownerId)
				.append("SGCPG14_PRCDST_MAP G14 ")
				.append("WHERE G13.GCPG13_PROCESS_X = 'GRID_UPDATE_NOTIFY' ")
				.append("AND G13.GCPG13_PROCESS_D = G14.GCPG13_PROCESS_D ")
				.append("AND G12.GCPG11_DIST_LIST_D = G14.GCPG11_DIST_LIST_D ")
				.append("AND G14.GCPE10_HUB_C IN (:hubCode) ")
				.append(uncommitRead);
		SqlParameterSource parameters = new MapSqlParameterSource().addValue("hubCode", hubCodes);
		log.info("Query for FSA Coordinator CDSIDs: {}", sqlQuery.toString());
		return namedParameterJdbcTemplate.query(sqlQuery.toString(), parameters,  new RowMapper<String>() {
			@Override
			public String mapRow(ResultSet rs, int rowNum) throws SQLException {
				return rs.getString(1);
			}
		});
	}
	
	public List<Integer> getFilterCodesByFilterGroup(List<Integer> filterGroups) {
		StringBuilder sqlQuery = new StringBuilder();
		sqlQuery.append("SELECT GCPD02_FILTER_C FROM ").append(ownerId).append("SGCPD02_FILTER")
				.append(" WHERE GCPD03_FILTR_GRP_C IN (:filterGroups) ").append(uncommitRead);
		SqlParameterSource parameters = new MapSqlParameterSource().addValue("filterGroups", filterGroups);
		return namedParameterJdbcTemplate.query(sqlQuery.toString(), parameters, new RowMapper<Integer>() {
			@Override
			public Integer mapRow(ResultSet rs, int rowNum) throws SQLException {
				return rs.getInt(1);
			}
		});
	}

	public List<GenericLookup> getCountries(String hubCode) {

		Map<String, Object> valueByKey = new HashMap<>();
		valueByKey.put("hubCode", HtmlUtils.htmlEscape(hubCode));
		SqlParameterSource parameters = new MapSqlParameterSource(valueByKey);
		StringBuilder sql = new StringBuilder();
		sql.append("SELECT c.COUNTRY_ISO3_C AS code, ");
		sql.append("c.COUNTRY_NAME_X AS description ");
		sql.append(" FROM ");
		sql.append(ownerId);
		sql.append("SGCPE02_CTRY_HUB h, ");
		sql.append(ownerId);
		sql.append("SDPMA01_COUNTRY c ");
		sql.append("WHERE ");
		sql.append(" h.GCPE10_HUB_C = :hubCode ");
		sql.append(" AND h.COUNTRY_ISO3_C = c.COUNTRY_ISO3_C AND ");
		sql.append(" h.GCPE02_EFF_TO_Y >= (SELECT current date FROM sysibm.sysdummy1) ");
		sql.append(" ORDER BY c.COUNTRY_NAME_X ");
		sql.append(uncommitRead);

		return namedParameterJdbcTemplate.query(sql.toString(), parameters,
				new BeanPropertyRowMapper<GenericLookup>(GenericLookup.class));

	}

}
