package com.ford.gcamp.targeting.manualaddvin;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import com.ford.gcamp.targeting.common.api.CommonResponse;
import com.ford.gcamp.targeting.common.api.FSAInfoVO;
import com.ford.gcamp.targeting.common.api.GenericLookup;
import com.ford.gcamp.targeting.core.exception.GCAMPException;
import com.ford.gcamp.targeting.common.CommonConstants;
import com.ford.gcamp.targeting.common.TargetingUtil;
import com.ford.gcamp.targeting.manualaddvin.api.ManualUploadResponse;
import com.ford.gcamp.targeting.manualaddvin.api.ManualAddVinsVO;
import com.ford.gcamp.targeting.manualaddvin.api.ManualUploadList;
import com.ford.gcamp.targeting.manualaddvin.api.SegmentDataVo;
import com.ford.gcamp.targeting.manualaddvin.api.SegmentMapVo;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class ManualAddVinUtil {

	public static final String SEGMENT_R = "GCPD14_SEGMENT_R";

	public String getInputParam3(ManualAddVinsVO manualVinsVo, String flag) {
		StringBuilder inputParam2 = new StringBuilder();
		if (CommonConstants.INQUIRY.equalsIgnoreCase(flag)) {
			inputParam2.append(flag);
		} else {
			inputParam2.append(flag.equalsIgnoreCase(CommonConstants.ADD) ? CommonConstants.ADD : StringUtils.SPACE);
		}
		inputParam2.append(manualVinsVo.getSupplementCode());
		inputParam2.append(TargetingUtil.fillRemainingString(manualVinsVo.getSegmentNumber(), 5, CommonConstants.ZERO));
		inputParam2.append(TargetingUtil.fillRemainingString(manualVinsVo.getVinGroupCode(), 2, StringUtils.SPACE));
		inputParam2.append(
				TargetingUtil.fillRemainingString(manualVinsVo.getVinGroupDescription(), 254, StringUtils.SPACE));
		inputParam2.append(TargetingUtil.fillRemainingString(manualVinsVo.getCdsId(), 8, StringUtils.SPACE));
		inputParam2.append(TargetingUtil.addSpaceToProc(28));
		log.info("input param3 for manual add vin with new vin grp{}", inputParam2.toString());
		return inputParam2.toString();
	}

	public ManualUploadResponse getManualUploadData(Map<String, Object> manulUpplodMap) {
		ManualUploadResponse manualUploadResp = new ManualUploadResponse();

		String errorParam = (String) manulUpplodMap.get(CommonConstants.ERROR_PARM);
		String statusInd = errorParam.substring(9, 10);
		ManualUploadResponse manualUploadResponse = setStatus(statusInd, errorParam, manualUploadResp);

		if (!manualUploadResponse.getStatus().equals(CommonConstants.FAILURE)) {
			String segmentDetails = (String) manulUpplodMap.get("OUTPUT_PARM3");
			FSAInfoVO fsaInfoVO = new FSAInfoVO();
			fsaInfoVO.setString((String) manulUpplodMap.get("OUTPUT_PARM1"),
					(String) manulUpplodMap.get("OUTPUT_PARM2"));
			manualUploadResponse.setFsaInfoVO(fsaInfoVO);
			manualUploadResponse.setSegmentMapVo(
					mergeResults(setSegmentVOList(segmentDetails.split("\\|")), getSegmentList(manulUpplodMap)));
		}
		return manualUploadResponse;
	}

	private List<SegmentMapVo> mergeResults(List<SegmentDataVo> liststatus, List<SegmentMapVo> mainList) {

		List<SegmentMapVo> segmentResponse = new ArrayList<>();
		for (SegmentMapVo segmentMap : mainList) {
			Optional<SegmentDataVo> mergeModel = liststatus.stream().filter(
					segmentMapVo -> segmentMapVo.getSegmentNumber().equalsIgnoreCase(segmentMap.getSegmentNumber()))
					.findFirst();
			if (mergeModel.isPresent()) {
				segmentMap.setSegmentNumber(mergeModel.get().getSegmentNumber());
				segmentMap.setSegmentDescription(mergeModel.get().getSegmentDescription());
				segmentMap.setLaunchedStatus(mergeModel.get().getLaunchedStatus());
				segmentResponse.add(segmentMap);
			}
		}

		return segmentResponse;
	}

	@SuppressWarnings("unchecked")
	private List<SegmentMapVo> getSegmentList(Map<String, Object> manulUpplodMap) {

		List<ManualUploadList> segments = ((List<ManualUploadList>) manulUpplodMap.get("segmentZero")).stream().sorted(Comparator.comparing(ManualUploadList::getVinGrpSeqNum).reversed()).collect(Collectors.toList());
		segments.addAll((List<ManualUploadList>) manulUpplodMap.get("segments"));
		Map<String, List<ManualUploadList>> segmentGroups = segments.stream()
				.sorted(Comparator.comparing(ManualUploadList::getSegmentNum)).collect(Collectors
						.groupingBy(ManualUploadList::getSegmentNum, LinkedHashMap::new, Collectors.toList()));
		List<SegmentMapVo> segmentList = new ArrayList<>();
		for (Map.Entry<String, List<ManualUploadList>> entry : segmentGroups.entrySet()) {
			SegmentMapVo segmntVo = new SegmentMapVo();
			segmntVo.setSegmentNumber(entry.getKey());
			segmntVo.setManuluploadList(entry.getValue());
			segmentList.add(segmntVo);
		}

		return segmentList;
	}

	private ManualUploadResponse setStatus(String statusInd, String errorParam,
			ManualUploadResponse manualUploadResponse) {
		if (statusInd != null && ("Y").equalsIgnoreCase(statusInd)) {
			String errorCode = errorParam.substring(37, 40);
			String errorDesc = errorParam.substring(40, 150);
			manualUploadResponse.setStatus(CommonConstants.FAILURE);
			manualUploadResponse.setStatusCode(CommonConstants.FAILURE_CODE);
			manualUploadResponse.setStatusDescription(errorCode + errorDesc);
		} else {
			manualUploadResponse.setStatus(CommonConstants.SUCCESS);
			manualUploadResponse.setStatusCode(CommonConstants.SUCCESS_CODE);
			manualUploadResponse.setStatusDescription(CommonConstants.SUCCESS_DESC);
		}
		return manualUploadResponse;
	}

	private List<SegmentDataVo> setSegmentVOList(String[] noOfVinsArray) {
		List<SegmentDataVo> segmentVoList = new ArrayList<>();
		for (int i = 0; i < noOfVinsArray.length; i++) {
			if (!noOfVinsArray[i].trim().isEmpty()) {
				SegmentDataVo segmentVo = new SegmentDataVo();
				segmentVo.setLaunchedStatus(noOfVinsArray[i].substring(0, 1));
				segmentVo.setSegmentDescription(noOfVinsArray[i].substring(1, 41).trim());
				segmentVo.setSegmentNumber((String.valueOf(Integer.parseInt(noOfVinsArray[i].substring(42, 47)))));
				segmentVoList.add(segmentVo);
			}
		}
		return segmentVoList;
	}

	public ManualUploadResponse checkExistenceOfVin(Map<String, Object> vinListListResponse) {
		ManualUploadResponse responseStatus = new ManualUploadResponse();
		responseStatus.setStatusCode("");
		String vinCheckResponse = String.valueOf(vinListListResponse.get("OUTPUT_PARM4"));
		ArrayList<String> statusFlagList = new ArrayList<>();

		String[] str = vinCheckResponse.split("\\|");
		for (int i = 0; i < str.length - 1; i++) {
			if (("Y").equalsIgnoreCase(str[i])) {
				responseStatus.setStatus(CommonConstants.FAILURE);
				responseStatus.setStatusCode(CommonConstants.FAILURE_CODE);
				responseStatus.setStatusDescription(CommonConstants.VIN_DUPLICATE_CHECK);
			}
			statusFlagList.add(str[i]);
		}
		responseStatus.setVinStatus(statusFlagList);

		return responseStatus;
	}

	public GenericLookup addNewVinGroupResponse(Map<String, Object> addNewVinResponse) throws GCAMPException {
		String errorParam = (String) addNewVinResponse.get(CommonConstants.ERROR_PARM);
		log.info("error param for manual add vin {}", errorParam);
		CommonResponse response = TargetingUtil.getCommonResponse(errorParam);
		if (CommonConstants.FAILURE.equalsIgnoreCase(response.getStatus())) {
			throw new GCAMPException(response.getStatusDescription());
		}
		GenericLookup lookup = new GenericLookup();
		String outputParam = String.valueOf(addNewVinResponse.get("OUTPUT_PARM5"));
		log.info("output param5 value {}",outputParam);
		if (outputParam.length() > 3) {
			lookup.setCode(outputParam.substring(0, 3)); 
			lookup.setDescription(outputParam.substring(3, 6));  
		}
		return lookup;
	}
}
