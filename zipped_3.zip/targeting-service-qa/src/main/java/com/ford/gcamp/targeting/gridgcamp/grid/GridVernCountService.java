package com.ford.gcamp.targeting.gridgcamp.grid;

import com.ford.gcamp.targeting.common.CommonConstants;
import com.ford.gcamp.targeting.common.CommonRepository;
import com.ford.gcamp.targeting.common.TargetingUtil;
import com.ford.gcamp.targeting.common.api.CommonResponse;
import com.ford.gcamp.targeting.common.api.GenericLookup;
import com.ford.gcamp.targeting.common.api.ReportBatchStatusResponse;
import com.ford.gcamp.targeting.config.WebClientAdConfiguration;
import com.ford.gcamp.targeting.core.exception.GCAMPException;
import com.ford.gcamp.targeting.core.exception.ResourceNotFoundException;
import com.ford.gcamp.targeting.gridgcamp.GridGCampConstants;
import com.ford.gcamp.targeting.gridgcamp.gcamp.FSARepository;
import com.ford.gcamp.targeting.gridgcamp.gcamp.GridGCampVernInfoService;
import com.ford.gcamp.targeting.gridgcamp.gcamp.api.GridVfdRequest;
import com.ford.gcamp.targeting.gridgcamp.gcamp.api.GridVfdResponse;
import com.ford.gcamp.targeting.gridgcamp.gcamp.entity.FSAData;
import com.ford.gcamp.targeting.gridgcamp.gcamp.entity.GridVernData;
import com.ford.gcamp.targeting.gridgcamp.grid.api.*;
import com.ford.gcamp.targeting.gridgcamp.grid.entity.GridVernCountData;
import com.ford.gcamp.targeting.gridgcamp.grid.entity.HubCountryLookupData;
import com.ford.gcamp.targeting.gridgcamp.grid.entity.LocalFSADetail;
import com.ford.gcamp.targeting.gridgcamp.grid.entity.PDCLookupData;
import com.ford.gcamp.targeting.prelaunchreports.ExtractOptionService;
import com.ford.gcamp.targeting.prelaunchreports.ViewTargetingReportsRepository;
import com.ford.gcamp.targeting.prelaunchreports.api.ExtractOptionRequest;
import com.ford.gcamp.targeting.prelaunchreports.api.ReportResponseHistoric;
import com.ford.gcamp.targeting.prelaunchreports.api.ReportsResponse;
import com.ford.gcamp.targeting.properties.ConfigProperties;
import com.ford.gcamp.targeting.reports.batch.common.ReportCodeConstants;
import com.ford.gcamp.targeting.vin.S3Service;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.jetbrains.annotations.NotNull;
import org.json.JSONObject;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Lazy;
import org.springframework.core.io.ClassPathResource;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;

@Service
@Slf4j
public class GridVernCountService {

	private PushVehicleCountRepo repo;

	private GridVernCountRepository gridVernCountRepository;

	private S3Service s3Service;

	private PDCLookupRepository pdcLookupRepository;

	private LocalFSARepository localFSARepository;

	private CommonRepository commonRepository;

	private WebClient reactiveWebClient;

	private ViewTargetingReportsRepository reportRepository;

	@Autowired
	private FSARepository fsaRepository;

	@Lazy
	@Autowired
	private ExtractOptionService extractService;

	@Autowired
	private GridGCampVernInfoService serviceHelper;

	@Autowired
	private ExtractOptionService extractOptionService;

	@Autowired
	private ConfigProperties configProperties;
	private WebClient webClient;
	private WebClientAdConfiguration webClientAdConfiguration;
	@Value("${spring.security.oauth2.client.registration.client-reportingservice-azure-ad.scope}")
	private String scope;

	public static final String ZERO_AS_STRING = "0";
	public static final int INT_ONE = 1;

	public static final String BEARER = "Bearer ";
	public static final String AUTHORIZATION = "Authorization";

	@Value("${grid.api.url}")
	private String gridApiUrl;

	@Value("${deleteFSA.grid.api.url}")
	private String deleteFSAGridApiUrl;

	@Value("${localFSA.grid.api.url}")
	private String localFSAGridApiUrl;

	@Value("${fsaType.grid.api.url}")
	private String fsaTypeGridApiUrl;

	@Value("${vinFile.grid.api.url}")
	private String vinFileGridApiUrl;

	@Value("${vfdReport.grid.api.url}")
	private String vfdReportGridApiUrl;

	@Value("${s3.bucket}")
	private String gcampBucket;

	private static final String ACTION_1 = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";  // Compliant
	private static final String ACTION_2 = "{} Report uploaded to S3 successfully for GRID";  // Compliant
	private static final String ACTION_3 = "Error in uploading Report to S3";  // Compliant

	public GridVernCountService(GridVernCountRepository gridVernCountRepository, S3Service s3Service,
								PDCLookupRepository pdcLookupRepository, LocalFSARepository localFSARepository,
								CommonRepository commonRepository, @Qualifier("grid-gcamp-client") WebClient reactiveWebClient,
								ViewTargetingReportsRepository reportRepository, PushVehicleCountRepo repo,
								@Qualifier("reportingServiceWebClient") WebClient webClient, WebClientAdConfiguration webClientAdConfiguration) {
		super();
		this.gridVernCountRepository = gridVernCountRepository;
		this.s3Service = s3Service;
		this.pdcLookupRepository = pdcLookupRepository;
		this.localFSARepository = localFSARepository;
		this.commonRepository = commonRepository;
		this.reactiveWebClient = reactiveWebClient;
		this.reportRepository = reportRepository;
		this.repo= repo;
		this.webClient = webClient;
		this.webClientAdConfiguration = webClientAdConfiguration;
	}

	/**
	 * Invoked when send VERN Count button click in View Targeting Reports Screen
	 *
	 * @param gridVernData
	 * @param vernCountRequest
	 * @return
	 */
	public CommonResponse sendVernCountToGrid(GridVernData gridVernData, GridVernCountSendRequest vernCountRequest) {
		if (gridVernData != null) {
			gridVernData.setUpdateId(vernCountRequest.getCdsId());
			gridVernData.setComments(vernCountRequest.getComments());
			return sendAssignedVernInfoToGrid(gridVernData, GridGCampConstants.SEND_VERN_COUNT_ON_EXTRACT);
		} else {
			return new CommonResponse();
		}

	}

	public CommonResponse sendDeletedFSAInfoToGrid(GridVernData gridVernData) {
		GridVernCount gridVernCount = transformGridVernData(gridVernData);
		return invokeGridAPI(gridVernCount, deleteFSAGridApiUrl, HttpMethod.PUT, 0);
	}

	public CommonResponse sendFSATypeToGrid(GridVernData gridVernData) {
		GridVernCount fsaTypeGridVernCount = transformGridVernData(gridVernData);
		return invokeGridAPI(fsaTypeGridVernCount, fsaTypeGridApiUrl, HttpMethod.PUT, 0);
	}

	public CommonResponse sendVinFileProcessedStatus(GridVernData gridVernData, String vinFileName, String action) {
		GridVernCount vinFileGridVernCount = transformGridVernData(gridVernData);
		vinFileGridVernCount.setAction(action);
		vinFileGridVernCount.setVinFileName(vinFileName);
		return invokeGridAPI(vinFileGridVernCount, vinFileGridApiUrl, HttpMethod.PUT, 0);
	}

	public CommonResponse sendLocalFSAChangesToGrid(GridVernData gridVernData, List<String> regions,
													String actionFlag) {
		GridVernCount gridVernCount = transformGridVernData(gridVernData);
		gridVernCount.setRegions(regions);
		gridVernCount.setAction(StringUtils.EMPTY);
		gridVernCount.setComment(StringUtils.EMPTY);
		gridVernCount.setLocalFSANumber(getLocalFSANumber(gridVernCount.getGlobalFSANumber()));
		Optional<FSAData> fsaData = fsaRepository.findById(gridVernCount.getGlobalFSANumber());
		if (fsaData.isPresent()) {
			gridVernCount.setFrcApprovalDate(fsaData.get().getFrcDecisionDate());
			gridVernCount.setFsaTitle(fsaData.get().getGlobalFSADescription());
		}
		HttpMethod httpMethod = CommonConstants.FLAG_C.equalsIgnoreCase(actionFlag) ? HttpMethod.POST
				: HttpMethod.DELETE;
		log.info("Local FSA Status: {}", httpMethod.toString());
		return invokeGridAPI(gridVernCount, localFSAGridApiUrl, httpMethod, 0);
	}

	@Transactional(transactionManager = "jpaDb2TransactionManager", propagation = Propagation.NOT_SUPPORTED)
	public CommonResponse sendAssignedVernInfoToGrid(GridVernData gridVernData, String actionFlag){
		if (gridVernData == null) {
			return CommonResponse.builder().statusCode(CommonConstants.FAILURE_CODE).status(CommonConstants.FAILURE)
					.statusDescription("Grid record not found.").build();
		}else if (configProperties.isSlice5Flag() && !configProperties.isParallelProcessingFlag()){ // FOR SLICE 5

			//Create the request
			GridVernCountSendRequest gridVernCountSendRequest =  new GridVernCountSendRequest();
			gridVernCountSendRequest.setGlobalFSANumber(String.valueOf(gridVernData.getGlobalFSANumber()));
			gridVernCountSendRequest.setComments(gridVernData.getComments());
			gridVernCountSendRequest.setCdsId(gridVernData.getUpdateId().trim());
			gridVernCountSendRequest.setSupplementCode(gridVernData.getGridVernId().getSupplementId());
			gridVernCountSendRequest.setActionFlag(actionFlag); //added the action flag to the request

			//call the reporting service to send the vern count
			return sendVernCountToGridUsingReportingService(gridVernCountSendRequest);
		}else {

			GridVernCount gridVernCount = transformGridVernData(gridVernData);
			gridVernCount.setFrcApprovalDate(commonRepository.getFRCDecisionDate(gridVernCount.getGlobalFSANumber()));
			gridVernCount.setLocalFSAInitHub(serviceHelper.getGridRegion(gridVernData.getInitiatingHub()));
			gridVernCount.setAction(actionFlag);
			gridVernCount.setComment(gridVernData.getComments());
			gridVernCount.setLocalFSANumber(getLocalFSANumber(gridVernCount.getGlobalFSANumber()));
			gridVernCount.setGlobalFsaType(gridVernData.getGlobalFsaType());
			//For Tandem FSA Changes
			gridVernCount.setTandemFlag(CommonConstants.FLAG_Y.equalsIgnoreCase(gridVernData.getIsTandem()));
			gridVernCount.setExpirationDate(commonRepository.getFSAExpirationDate(gridVernCount.getGlobalFSANumber(), gridVernData.getInitiatingHub()));

			if (GridGCampConstants.SEND_VERN_COUNT_ON_EXTRACT.equalsIgnoreCase(actionFlag)
					|| GridGCampConstants.VEHICLE_CONFIRMATION.equalsIgnoreCase(actionFlag)) {
				if (CommonConstants.FLAG_E.equalsIgnoreCase(gridVernData.getExtractCompleteFlag())) {
					getVehicleCount(gridVernData, gridVernCount, actionFlag);
				} else {
					return CommonResponse.builder().statusCode(CommonConstants.FAILURE_CODE)
							.status(CommonConstants.FAILURE)
							.statusDescription("The targeting extract hasn't been completed for a new VERN ("
									+ gridVernData.getVernNumber()
									+ ") assigned to FSA. Please submit vehicle line counts to GRID after the extraction.")
							.build();
				}
			}
			return invokeGridAPIPush(gridVernCount, gridApiUrl, HttpMethod.PUT, 0, gridVernData);
		}
	}

	private CommonResponse sendVernCountToGridUsingReportingService(GridVernCountSendRequest gridVernCountSendRequest) {
		try {
			log.info("Sending Vern Count Request to Reporting Service for Global FSA Number: {} and Reqeust : {}",
					gridVernCountSendRequest.getGlobalFSANumber(), gridVernCountSendRequest);

			CommonResponse response = webClient.post()
					.uri("/api/v1/grid/verncount/send")
					.contentType(MediaType.APPLICATION_JSON)
					.header(AUTHORIZATION, BEARER + webClientAdConfiguration.getAccessToken(scope, "reporting"))
					.body(Mono.just(gridVernCountSendRequest), GridVernCountSendRequest.class)
					.exchangeToMono(clientResponse -> {
						if (clientResponse.statusCode().isError()) {
							return errorHandler(clientResponse);
						}
						return clientResponse.bodyToMono(String.class)
								.map(responseBody -> CommonResponse.builder()
										.status(CommonConstants.SUCCESS)
										.statusCode(CommonConstants.SUCCESS_CODE)
										.statusDescription(responseBody)
										.build());
					})
					.block();
			log.info("Response from Reporting Service for Send Vern Count to Grid : {} : {}", gridVernCountSendRequest.getGlobalFSANumber(),
					response.getStatusDescription());
			return response;
		} catch (Exception e) {
			log.error("Error While Send Vern Count to Grid : {}", gridVernCountSendRequest.getGlobalFSANumber());
			return CommonResponse.builder().status(CommonConstants.FAILURE_CODE).statusCode(CommonConstants.FAILURE_CODE)
					.statusDescription("Failed to send Vehicle Count to GRID. Try later.").build();
		}
	}
	private static Mono<CommonResponse> errorHandler (ClientResponse clientResponse) {
		return clientResponse.bodyToMono(String.class)
				.flatMap(errorMessage -> {
					JSONObject json = new JSONObject(errorMessage);
					String messages = json.getJSONObject("error").getJSONArray("messages").join(", ");
					log.error("Error While Send Vern Count to Grid : {}, error message: {}",
							clientResponse.statusCode(), messages);
					CommonResponse commonResponse = new CommonResponse();
					commonResponse.setStatusCode(CommonConstants.FAILURE_CODE);
					commonResponse.setStatus(CommonConstants.FAILURE_CODE);
					commonResponse.setStatusDescription(messages.replaceAll("\"", ""));
					return Mono.just(commonResponse);
				});

	}


	private GridVernCount transformGridVernData(GridVernData gridVernData) {
		ModelMapper modelMapper = new ModelMapper();
		GridVernCount gridVernCount = modelMapper.map(gridVernData.getGridVernId(), GridVernCount.class);
		modelMapper.map(gridVernData, gridVernCount);
		gridVernCount.setTandemFlag(CommonConstants.FLAG_Y.equalsIgnoreCase(gridVernData.getIsTandem()));
		gridVernCount.setVernStatus(getVernStatusDesc(gridVernCount.getVernStatus()));
		return gridVernCount;
	}

	private void getVehicleCount(GridVernData gridVernData, GridVernCount gridVernCount,String actionFlag) {
		List<VehicleCountRegion> vernCount = getVehicleCountRegions(gridVernCount.getGlobalFSANumber(),
				gridVernCount.getSupplementId(), gridVernData.getReportId());
		gridVernCount.setVernCount(vernCount);
		if (CollectionUtils.isNotEmpty(vernCount)) {
			String fileName = saveHistoryReportToS3(gridVernData, ReportCodeConstants.T20,actionFlag,gridVernCount);
			gridVernCount.setVernExtractFileName(fileName);
			gridVernCount.setVernExtractFilePath(fileName);
		}
		// Upload Exception Report If any
		String fileName = uploadReportToS3(gridVernData, ReportCodeConstants.T09, actionFlag);
		gridVernCount.setVernExceptionFileName(fileName);
		gridVernCount.setVernExceptionFilePath(fileName);
	}

	private String getVernStatusDesc(String vernStatus) {
		switch (vernStatus) {
			case CommonConstants.FLAG_O:
				return GridGCampConstants.OFFICIAL;
			case CommonConstants.FLAG_L:
				return GridGCampConstants.LAUNCHED;
			default:
				return GridGCampConstants.TRANSIENT;
		}
	}

	private CommonResponse invokeGridAPI(GridVernCount gridVernCount, String apiUrl, HttpMethod httpMethod,
										 int retryCount) {
		log.info("VERN Count Response from GCAMP to GRID: {}", TargetingUtil.prettyPrintJSON(gridVernCount));
		try {
			CommonResponse gridResponse = reactiveWebClient.method(httpMethod).uri(apiUrl)
					.body(Mono.just(gridVernCount), GridVernCount.class).retrieve().bodyToMono(CommonResponse.class)
					.block();
			if (gridResponse != null && CommonConstants.SUCCESS_CODE.equals(gridResponse.getStatusCode())) {
				return CommonResponse.builder().status(CommonConstants.SUCCESS).statusCode(CommonConstants.SUCCESS_CODE)
						.statusDescription("Vehicle Count Sent Successfully to GRID").build();
				//new code integration sp-CSGCSC54

			}
			log.info("Vern Response Sent Successfully to GRID");
		} catch (Exception e) {
			retryCount++;
			if (retryCount < 3 && e.getMessage() != null && !e.getMessage().contains("412")) {
				retryGridVernFlow(gridVernCount, apiUrl, httpMethod, retryCount);
			}
			log.error("Failed to send Vehicle Count to GRID", e);
		}
		return CommonResponse.builder().status(CommonConstants.FAILURE).statusCode(CommonConstants.FAILURE_CODE)
				.statusDescription("Failed to send Vehicle Count to GRID. Try later.").build();
	}


	private void retryGridVernFlow(GridVernCount gridVernCount, String apiUrl, HttpMethod httpMethod, int retryCount) {
		try {
			// First retry
			Thread.sleep(5000);
			invokeGridAPI(gridVernCount, apiUrl, httpMethod, retryCount);
		} catch (Exception ex) {
			log.error("InterruptedException occured to send Vehicle Count to GRID in 1st attempt", ex);
			try {
				// Second Retry
				Thread.sleep(3000);
				invokeGridAPI(gridVernCount, apiUrl, httpMethod, retryCount);
			} catch (Exception e) {
				log.error("InterruptedException occured to send Vehicle Count to GRID in 2nd attempt", e);
				Thread.currentThread().interrupt();
			}

		}
	}

	public List<VehicleCountRegion> getVehicleCountRegions(int globalFSANumber, String supplementCode) {
		return getVehicleCountRegions(globalFSANumber, supplementCode, StringUtils.EMPTY);
	}

	public List<VehicleCountRegion> getVehicleCountRegions(int globalFSANumber, String supplementCode,
														   String reportId) {
		List<GridVernCountData> gridVernCountData = gridVernCountRepository
				.findByGlobalFSANumberAndSupplementCode(globalFSANumber, supplementCode);
		List<VehicleCountRegion> vehCountRegions = new ArrayList<>();
		if (CollectionUtils.isNotEmpty(gridVernCountData)) {
			Map<HubCountryLookupData, List<GridVernCountData>> hubCodeMap = gridVernCountData.stream()
					.sorted(Comparator.comparing(gridVernCount -> gridVernCount.getHubCountry().getGridHubCode()))
					.collect(
							Collectors.groupingBy(GridVernCountData::getHubCountry, HashMap::new, Collectors.toList()));
			hubCodeMap.entrySet().forEach(hubEntry -> {
				VehicleCountRegion vehCountRegion = new VehicleCountRegion();
				vehCountRegion.setRegion(StringUtils.trimToEmpty(hubEntry.getKey().getGridHubCode()));
				vehCountRegion.setGcampRegion(StringUtils.trimToEmpty(hubEntry.getKey().getHubCode()));

				Map<String, List<GridVernCountData>> countryCodeMap = hubEntry.getValue().stream()
						.sorted(Comparator.comparing(
								gridVernData -> StringUtils.trim(gridVernData.getCountry().getDescription())))
						.collect(Collectors.groupingBy(
								gridVernData -> StringUtils.trim(gridVernData.getCountry().getDescription()),
								HashMap::new, Collectors.toList()));
				List<VehicleCountCountry> vehicleCountCountries = new ArrayList<>();
				countryCodeMap.entrySet().forEach(countryEntry -> {
					VehicleCountCountry vehCountCountry = new VehicleCountCountry();
					vehCountCountry.setCountry(StringUtils.trimToEmpty(countryEntry.getKey()));
					vehCountCountry.setPdc(getPdcs(reportId, countryEntry.getKey()));

					Map<String, List<GridVernCountData>> vehicleMap = countryEntry.getValue().stream().collect(
							Collectors.groupingBy(GridVernCountData::getVehicleKey, HashMap::new, Collectors.toList()));
					List<VehicleCountDetail> vehCountDetails = new ArrayList<>();
					vehicleMap.entrySet().forEach(vehicleEntry -> {
						VehicleCountDetail vehicleCountDetail = new VehicleCountDetail();
						vehicleEntry.getValue().forEach(vehDetail -> {
							setVehicleDetails(vehicleCountDetail, vehDetail);
							if (ObjectUtils.isNotEmpty(vehDetail.getLocalFSA())
									&& ObjectUtils.isNotEmpty(vehDetail.getLocalFSA().getLocalFSACreateDate())) {
								vehCountRegion.setLocalFSACreationDate(vehDetail.getLocalFSA().getLocalFSACreateDate());
							}
						});
						vehCountDetails.add(vehicleCountDetail);

					});
					vehCountCountry.setVehicles(vehCountDetails);

					vehicleCountCountries.add(vehCountCountry);
				});
				vehCountRegion.setRegionDetails(vehicleCountCountries);
				vehCountRegions.add(vehCountRegion);
			});
		}
		return vehCountRegions;
	}

	private void setVehicleDetails(VehicleCountDetail vehicleCountDetail, GridVernCountData vehDetail) {
		vehicleCountDetail.setModelYear(vehDetail.getModelYear());
		vehicleCountDetail.setBrand(GenericLookup.builder().code(vehDetail.getBrand().getCode())
				.description(StringUtils.trimToEmpty(vehDetail.getBrand().getDescription())).build());
		vehicleCountDetail.setVehicleLine(GenericLookup.builder()
				.code(ObjectUtils.isNotEmpty(vehDetail.getVehicleLine()) ? vehDetail.getVehicleLine().getCode()
						: StringUtils.EMPTY)
				.description(StringUtils.trimToEmpty(
						ObjectUtils.isNotEmpty(vehDetail.getVehicleLine()) ? vehDetail.getVehicleLine().getDescription()
								: StringUtils.EMPTY))
				.build());
		if (CommonConstants.FLAG_Y.equalsIgnoreCase(vehDetail.getSoldFlag())) {
			vehicleCountDetail.setSold(vehDetail.getVehicleCount());
		} else {
			vehicleCountDetail.setUnSold(vehDetail.getVehicleCount());
		}
	}

	private List<String> getPdcs(String reportId, String countryName) {
		if (StringUtils.isNotBlank(reportId)) {
			List<PDCLookupData> pdcData = pdcLookupRepository.findByReportIdAndCountryName(reportId, countryName);
			if (CollectionUtils.isNotEmpty(pdcData)) {
				return pdcData.stream().map(PDCLookupData::getPdcDescription).collect(Collectors.toList());
			}
		}
		return Collections.emptyList();
	}

	private String getLocalFSANumber(int globalFSANumber) {
		Optional<LocalFSADetail> localFSA = localFSARepository.findFirstByGlobalFSANumber(globalFSANumber);
		return localFSA.isPresent() ? StringUtils.trimToEmpty(localFSA.get().getLocalFSANumber()) : StringUtils.EMPTY;
	}

	/**
	 * This method is to download ALL Report file (T20) or VIN File upload Exception
	 * and upload to S3 for GRID interface
	 * <p>
	 * //@param globalFSANumber
	 * //@param supplementCode
	 *
	 * @return
	 * @throws GCAMPException
	 */
	public String uploadReportToS3(GridVernData gridVernData, String reportCode, String actionFlag) {
		ReportsResponse reportResponse = reportRepository.getReportBlob(gridVernData.getGlobalFSANumber(),
				gridVernData.getGridVernId().getSupplementId(), reportCode);
		if (reportResponse != null && reportResponse.getByteArry().length > 1) {
			String reportName = ReportCodeConstants.T20.equalsIgnoreCase(reportCode) ? "Targeting" : "Exception";
			String fileName = gridVernData.getGlobalFSANumber() + "_" + gridVernData.getGridVernId().getSupplementId()
					+ "_" + reportName + "_Report.xlsx";
			try (InputStream inputStream = new ByteArrayInputStream(reportResponse.getByteArry())) {
				//Replace the S3 upload with GCS upload
				uploadToGcs(inputStream, fileName, gridVernData.getGlobalFSANumber(), actionFlag, gridVernData.getRequester());
				log.info(ACTION_2, reportName);
				gridVernData.setReportId(reportResponse.getReportId());
				return fileName;
			} catch (Exception e) {
				log.error(ACTION_3, e);
			}
		}
		return StringUtils.EMPTY;
	}

	public CommonResponse refreshSoldUnsoldCount(GridVfdRequest gridBasicVernInfo) throws ResourceNotFoundException {
		ExtractOptionRequest processExtractRequest = prepareSubmitExtractRequest(gridBasicVernInfo);
		try {
			return extractService.submitExtract(processExtractRequest, gridBasicVernInfo.getRequester());
		} catch (GCAMPException e) {
			log.error("Error in sold unsold count refresh", e);
			throw new ResourceNotFoundException("Error in sold unsold count refresh");
		}
	}

	private ExtractOptionRequest prepareSubmitExtractRequest(GridVfdRequest gridBasicVernInfo)
			throws ResourceNotFoundException {

		Optional<FSAData> fsaData = fsaRepository.findById(gridBasicVernInfo.getGlobalFSANumber());
		if (fsaData.isPresent()) {
			String hubCode = StringUtils.trimToEmpty(fsaData.get().getHubCode());
			String countryCode = StringUtils.trimToEmpty(fsaData.get().getHub().getDefaultCountryCode());
			log.info(" Hub and Default Country for FSA: {},{}", hubCode, countryCode);
			return ExtractOptionRequest.builder().processFlag(CommonConstants.FLAG_R)
					.fsaNumber(String.valueOf(gridBasicVernInfo.getGlobalFSANumber())).fsaType(CommonConstants.FLAG_G)
					.cdsId(GridGCampConstants.SOLD_UNSOLD_GRID_CDSID)
					.population(TargetingUtil.fillWithZeros(gridBasicVernInfo.getSupplementId(), 2)).hubCode(hubCode)
					.countryCode(countryCode).reportCount(15).reportChecked(ReportCodeConstants.ALL_REPORT_CODES)
					.wersCodeCount(0).wersCodeSelected(StringUtils.EMPTY).emailSubmitInd(CommonConstants.FLAG_N)
					.serialNumInd(CommonConstants.FLAG_N).regionalFilter(CommonConstants.FLAG_N)
					.loadTeraDataInd(CommonConstants.FLAG_N).build();
		} else {
			throw new ResourceNotFoundException("Global FSA Number not found in GCamp");
		}

	}

	public CommonResponse sendVfdReportResponseToGrid(GridVfdResponse vfdResponse) {
		log.info("GRID VFD Report Response from GCAMP to GRID: {}", TargetingUtil.prettyPrintJSON(vfdResponse));
		return reactiveWebClient.method(HttpMethod.PUT).uri(vfdReportGridApiUrl)
				.body(Mono.just(vfdResponse), GridVfdResponse.class).retrieve().bodyToMono(CommonResponse.class)
				.block();
	}

	public String addFileToStorage(InputStream inputStream, String fileName, String contentType, long size, GridVernData gridVerData, String actionFlag) {
		log.info("print success upload " + inputStream + fileName + contentType + size);
		String timestamp = s3Service.putFile(fileName, inputStream, contentType, true, size, gridVerData, actionFlag);
		try {
			inputStream.close();
		} catch (IOException e) {
			log.error("Exception while adding file to S3. fileName = {}", fileName, e);
		}
		return timestamp;
	}

	public String saveHistoryReportToS3(GridVernData gridVernData, String reportCode,String actionFlag,GridVernCount gridVernCount) {
		ReportsResponse reportResponse = reportRepository.getReportBlob(gridVernData.getGlobalFSANumber(),
				gridVernData.getGridVernId().getSupplementId(), reportCode);
		if (reportResponse != null && reportResponse.getByteArry().length > 1) {
			String reportName = ReportCodeConstants.T20.equalsIgnoreCase(reportCode) ? "Targeting" : "Exception";
			String fileName = gridVernData.getGlobalFSANumber() + "_" + gridVernData.getGridVernId().getSupplementId()
					+ "_" + reportName + "_Report.xlsx";
			try (InputStream inputStream = new ByteArrayInputStream(reportResponse.getByteArry())) {
				//Replace the S3 upload with GCS upload
				uploadToGcs(inputStream,fileName, gridVernData.getGlobalFSANumber(), actionFlag, gridVernData.getRequester());
				log.info(ACTION_2, reportName);
				gridVernData.setReportId(reportResponse.getReportId());
				//String key = saveReportToS3WithVersioning(gridVernData,fileName,reportResponse,actionFlag,gridVernCount);
				String timeStamp = getTimeStamp(gridVernCount, fileName);
				gridVernCount.setTimestamp(timeStamp);
				gridVernCount.setKey(fileName);
				return fileName;
			} catch (Exception e) {
				log.error(ACTION_3, e);
			}
		}
		return StringUtils.EMPTY;
	}
	//---------------------------------------------------------------
	@Async
	public CompletableFuture<Void> processHistoryRecordsAsync(String fileName) throws InterruptedException {
		int processed = 0;
		int failed = 0;
		List<RecordData> recordsToProcess = new ArrayList<>();

		// Step 1: Read all records first, then close the workbook immediately
		try (InputStream inputStream = new ClassPathResource(fileName).getInputStream();
			 Workbook workbook = WorkbookFactory.create(inputStream)) {
			Sheet sheet = workbook.getSheetAt(0);
			DataFormatter formatter = new DataFormatter();
			boolean isHeader = true;

			for (Row row : sheet) {
				if (isHeader) {
					isHeader = false;
					continue;
				}

				Cell gfsaCell = row.getCell(0);
				Cell suppCell = row.getCell(1);
				if (gfsaCell != null && suppCell != null) {
					recordsToProcess.add(new RecordData(
							(int) gfsaCell.getNumericCellValue(),
							formatter.formatCellValue(suppCell)
					));
				}
			}
		} catch (Exception e) {
			log.error("Error reading DEV_FSA_SUPP.xlsx", e);
			return CompletableFuture.completedFuture(null);
		}

		// Step 2: Process records in batches without keeping workbooks open
		int batchSize = 25;
		for (int i = 0; i < recordsToProcess.size(); i += batchSize) {
			int endIndex = Math.min(i + batchSize, recordsToProcess.size());
			List<RecordData> batch = recordsToProcess.subList(i, endIndex);

			for (RecordData record : batch) {
				try {
					log.info("Generating the History report for GFSA: {}, Supp: {}", record.gfsaNumber, record.suppCode);

					// Each method call will open/close workbooks internally
					saveHistoryReportToGcs(record.gfsaNumber, record.suppCode, List.of("T20"));
					if(!record.suppCode.trim().equals("*")) {
						saveHistoryReportToGcs(record.gfsaNumber, record.suppCode,
								List.of("ADC", "ADE", "CDM", "IAD", "T01", "T02", "T08", "T09", "T10", "T12"));
					}
					processed++;

					// Explicit cleanup
					record = null;

				} catch (Exception e) {
					failed++;
					log.error("Error processing GFSA: {}, Supp: {}", record.gfsaNumber, record.suppCode, e);
				}
			}
			System.gc();
			Thread.sleep(500);
			log.info("Processed batch. Total processed: {}", processed);
		}
		recordsToProcess.clear();
		log.info("History processing completed. Processed: {}, Failed: {}", processed, failed);
		return CompletableFuture.completedFuture(null);
	}

	public String saveHistoryReportToGcs(int gfsaNumber, String suppCode, List<String> reportCodes) throws IOException {
		if (reportCodes.size() == 1) {
			return processSingleReport(gfsaNumber, suppCode, reportCodes.get(0));
		} else {
			return processCombinedReports(gfsaNumber, suppCode, reportCodes);
		}
	}

	private String processSingleReport(int gfsaNumber, String suppCode, String reportCode) throws IOException {
		suppCode = suppCode.trim();
		ReportResponseHistoric reportResponse = reportRepository.getReportBlobHistoric(gfsaNumber, suppCode, reportCode);
		if (reportResponse == null || reportResponse.getReportContentStream() == null) {
			log.error("ReportResponse or its InputStream is null for GFSA: {}, Supp: {}, ReportCode: {}", gfsaNumber, suppCode, reportCode);
			return StringUtils.EMPTY;
		}
		log.info("Report ID " + reportResponse.getReportId() +" for GFSA: {}, Supp: {}, ReportCode: {}", gfsaNumber, suppCode, reportCode);
		Path tempFile = null;
		try (InputStream is = reportResponse.getReportContentStream()) {
			// Create a temporary file to store the LOB content
			tempFile = Files.createTempFile("report_" + gfsaNumber + "_" + suppCode + "_" + reportCode + "_", ".tmp");
			Files.copy(is, tempFile, StandardCopyOption.REPLACE_EXISTING);
			log.info("Successfully streamed report content to temporary file: {}", tempFile.toAbsolutePath());

			// Now, we can create multiple InputStreams from the temporary file
			String fileExtension = "xlsx";
			Workbook workbook = null; // Initialize workbook outside try-with-resources to close it in finally
			try (InputStream workbookStream = new FileInputStream(tempFile.toFile())) {
				// Determine file type based on format code or content if necessary
				if ("XLS".equalsIgnoreCase(reportResponse.getReportFormatCode())) {
					fileExtension = "xls";
					workbook = new HSSFWorkbook(workbookStream);
				} else {
					workbook = new SXSSFWorkbook(new XSSFWorkbook(workbookStream)); // SXSSFWorkbook needs XSSFWorkbook as base
				}
			} catch (Exception e) {
				log.error("Error creating workbook from temporary file for GFSA: {}, Supp: {}, ReportCode: {}", gfsaNumber, suppCode, reportCode, e);
				return StringUtils.EMPTY; // No need to delete tempFile here, finally block handles it
			}
			String fileName;
			// At this point, the workbook has been created. If it was an empty file,
			// WorkbookFactory.create might have thrown an exception or created an empty workbook.
			// Further checks can be added here if needed (e.g., workbook.getNumberOfSheets() > 0).
			if(suppCode.equals("*")){
				 fileName = gfsaNumber + "_" + "All" + "_Targeting_Report." + fileExtension;
			}else {
				 fileName = gfsaNumber + "_" + suppCode + "_Targeting_Report." + fileExtension;
			}
			try (InputStream uploadStream = new FileInputStream(tempFile.toFile())) { // Create a new stream for upload
				uploadToGcsHistoric(
						uploadStream,
						fileName,
						gfsaNumber,
						"E", // Assuming actionFlag for single report upload
						reportResponse.getRequestedBy(),
						getContentType(reportResponse)
				);
			} catch (Exception e) {
				log.error("Error in uploading file to GCS from temporary file for GFSA: {}, Supp: {}, ReportCode: {}", gfsaNumber, suppCode, reportCode, e);
				return StringUtils.EMPTY;
			} finally {
				if (workbook != null) {
					try {
						workbook.close(); // Close the workbook after use
					} catch (IOException e) {
						log.error("Error closing workbook for GFSA: {}, Supp: {}, ReportCode: {}", gfsaNumber, suppCode, reportCode, e);
					}
				}
			}
			return fileName;

		} catch (Exception e) {
			log.error("Error processing single report via temporary file for GFSA: {}, Supp: {}, ReportCode: {}", gfsaNumber, suppCode, reportCode, e);
			return StringUtils.EMPTY;
		} finally {
			if (tempFile != null) {
				try {
					Files.deleteIfExists(tempFile); // Ensure temporary file is deleted
					log.info("Temporary file deleted: {}", tempFile.toAbsolutePath());
				} catch (IOException e) {
					log.error("Error deleting temporary file: {}", tempFile.toAbsolutePath(), e);
				}
			}
		}
	}


	private String processCombinedReports(int gfsaNumber, String suppCode, List<String> reportCodes) {
		if (CollectionUtils.isEmpty(reportCodes)) {
			return StringUtils.EMPTY;
		}

		// Collect ReportResponseHistoric objects first, then process their streams via temp files
		List<ReportResponseHistoric> validResponses = new ArrayList<>();
		for (String reportCode : reportCodes) {
			ReportResponseHistoric rr = reportRepository.getReportBlobHistoric(gfsaNumber, suppCode, reportCode);
			if (isValidReportResponse(rr)) { // Checks if the InputStream itself is not null
				validResponses.add(rr);
			}
		}

		if (CollectionUtils.isEmpty(validResponses)) {
			return StringUtils.EMPTY;
		}

		ReportResponseHistoric firstValidResponse = validResponses.get(0); // Use the first for format code

		String fileExtension;
		Workbook combinedWorkbook = null; // Initialize workbook outside try-catch
		try {
			if ("XLS".equalsIgnoreCase(firstValidResponse.getReportFormatCode())) {
				fileExtension = "xls";
				combinedWorkbook = new HSSFWorkbook();
			} else {
				fileExtension = "xlsx";
				combinedWorkbook = new SXSSFWorkbook();
			}

			ReportResponseHistoric lastReportResponse = null; // To get requester for upload

			// Process each individual report, streaming its content to temp file and then into combinedWorkbook
			for (ReportResponseHistoric reportResponse : validResponses) {
				lastReportResponse = reportResponse; // Keep track of the last one for requester
				processIndividualReport(reportResponse, combinedWorkbook); // Pass only the relevant info
			}

			String fileName = gfsaNumber + "_" + suppCode + "_Exception_Report." + fileExtension;
			String contentType = getXmlContentType(combinedWorkbook, firstValidResponse);
			if (lastReportResponse != null) {
				return uploadCombinedWorkbook(
						combinedWorkbook,
						fileName,
						gfsaNumber,
						lastReportResponse,
						contentType
				);
			}
			return StringUtils.EMPTY; // Should not happen if validResponses was not empty
		} catch (Exception e) {
			log.error("Error creating combined Excel file: {}", e.getMessage(), e);
			return StringUtils.EMPTY;
		} finally {
			try {
				if (combinedWorkbook != null) {
					combinedWorkbook.close();
				}
			} catch (IOException e) {
				log.error("Error closing combined workbook", e);
			}
		}
	}


	private String adjustFileExtensionForContentType(String fileName, String contentType) {
		log.info("Adjusting file extension for file: {}, contentType: {}", fileName, contentType);
		String result;
		if ("text/csv".equalsIgnoreCase(contentType)) {
			int dotIndex = fileName.lastIndexOf('.');
			if (dotIndex > 0) {
				result = fileName.substring(0, dotIndex) + ".csv";
			} else {
				result = fileName;
			}
		} else {
			result = fileName;
		}
		log.info("Resulting file name after extension adjustment: {}", result);
		return result;
	}

	@NotNull
	private static String getXmlContentType(Workbook combinedWorkbook, ReportResponseHistoric firstValidResponse) {
		return getContentType(firstValidResponse);
	}


	private static boolean isOnlyIad(Workbook combinedWorkbook, ReportsResponse firstValidResponse) {
		log.info("Combined workbook sheet count: {}", combinedWorkbook.getNumberOfSheets());
		if (combinedWorkbook.getNumberOfSheets() == 1) {
			String sheetName = combinedWorkbook.getSheetAt(0).getSheetName();
			log.info("Combined workbook has a single sheet with name: {}", sheetName);
			return (sheetName.contains("Invalid Assigned Responsible De") || sheetName.contains("IAD"))
					&& (firstValidResponse.getReportFormatCode().equalsIgnoreCase("XLS") || firstValidResponse.getReportFormatCode().equalsIgnoreCase("XLX"));
		}
		return false;
	}

	private static String getContentType(ReportResponseHistoric reportResponse) {
		if( reportResponse.getReportFormatCode() != null && reportResponse.getReportFormatCode().equalsIgnoreCase("XLS")){
			return "application/vnd.ms-excel";
		}else{
			return "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
		}
	}

	private ReportResponseHistoric processReportCodes(int gfsaNumber, String suppCode, List<String> reportCodes, Workbook combinedWorkbook) throws IOException {
		ReportResponseHistoric lastValidResponse = null;
		Map<CellStyle, CellStyle> globalStyleCache = new HashMap<>();

		for (String reportCode : reportCodes) {
			ReportResponseHistoric reportResponse = reportRepository.getReportBlobHistoric(gfsaNumber, suppCode, reportCode);
			if (isValidReportResponse(reportResponse)) {
				lastValidResponse = reportResponse; // Keep track of last valid response
				processIndividualReport(reportResponse, combinedWorkbook);
			}
		}
		return lastValidResponse; // Return the last valid ReportsResponse
	}

	private void processIndividualReport(ReportResponseHistoric reportResponse, Workbook combinedWorkbook) throws IOException {
		Path tempFile = null;
		try (InputStream is = reportResponse.getReportContentStream()) {
			// Stream the individual report's content to a temporary file
			tempFile = Files.createTempFile("individual_report_" + reportResponse.getReportId() + "_", ".tmp");
			Files.copy(is, tempFile, StandardCopyOption.REPLACE_EXISTING);
			log.info("Successfully streamed individual report content to temporary file: {}", tempFile.toAbsolutePath());

			byte[] data;
			// Read from the temporary file into a byte[] for type detection and processing.
			// This is a controlled buffer within the scope of this single report being merged.
			try (InputStream tempFileInputStream = new FileInputStream(tempFile.toFile())) {
				data = tempFileInputStream.readAllBytes();
			}

			// Check if the file is empty after reading from temp file
			if (data.length == 0) {
				log.warn("Individual report content is empty for report ID: {}", reportResponse.getReportId());
				return; // Skip processing empty reports
			}

			if (isValidExcelFile(data)) {
				try (InputStream reportInputStream = new ByteArrayInputStream(data); // Create stream from byte array
					 Workbook sourceWorkbook = WorkbookFactory.create(reportInputStream)) {
					Sheet sourceSheet = sourceWorkbook.getSheetAt(0);
					String uniqueSheetName = generateUniqueSheetName(sourceSheet.getSheetName(), combinedWorkbook);
					Sheet targetSheet = combinedWorkbook.createSheet(uniqueSheetName);

					// Re-initialize a new style cache for each individual report to avoid cross-workbook style issues
					Map<CellStyle, CellStyle> individualStyleCache = new HashMap<>();
					copySheetData(sourceSheet, targetSheet, combinedWorkbook, individualStyleCache);
					copyColumnWidths(sourceSheet, targetSheet);
				} catch (Exception e) {
					log.error("Error processing individual Excel report from temp file for report ID: {}", reportResponse.getReportId(), e);
				}
			} else if (isCsvFile(data)) {
				try (InputStream csvStream = new ByteArrayInputStream(data); // Create stream from byte array
					 BufferedReader reader = new BufferedReader(new InputStreamReader(csvStream))) {
					String uniqueSheetName = generateUniqueSheetName("Invalid Assigned Responsible De", combinedWorkbook); // Unique name for CSV
					Sheet targetSheet = combinedWorkbook.createSheet(uniqueSheetName);

					String line;
					int rowNum = 0;
					while ((line = reader.readLine()) != null) {
						Row row = targetSheet.createRow(rowNum++);
						String[] values = line.split(",(?=([^\"]*\"[^\"]*\")*[^\"]*$)", -1); // Handles quoted commas
						for (int col = 0; col < values.length; col++) {
							row.createCell(col).setCellValue(values[col].replaceAll("^\"|\"$", "")); // Remove surrounding quotes
						}
					}
				} catch (Exception e) {
					log.error("Error processing individual CSV report from temp file for report ID: {}", reportResponse.getReportId(), e);
				}
			} else {
				log.warn("Skipped unsupported file type for report ID: {}", reportResponse.getReportId());
			}
		} catch (Exception e) {
			log.error("Error processing individual report via temporary file for report ID: {}", reportResponse.getReportId(), e);
		} finally {
			if (tempFile != null) {
				try {
					Files.deleteIfExists(tempFile); // Ensure temporary file is deleted
					log.info("Temporary file deleted for individual report: {}", tempFile.toAbsolutePath());
				} catch (IOException e) {
					log.error("Error deleting temporary file for individual report: {}", tempFile.toAbsolutePath(), e);
				}
			}
		}
	}

	private boolean isValidExcelFile(byte[] data) {
		if (data == null || data.length < 2) return false;
		// XLS header: D0 CF 11 E0
		if (data.length >= 4 &&
				data[0] == (byte)0xD0 && data[1] == (byte)0xCF &&
				data[2] == (byte)0x11 && data[3] == (byte)0xE0) return true;
		// XLSX header: PK (zip)
		if (data[0] == (byte)0x50 && data[1] == (byte)0x4B) return true;
		return false;
	}

	private boolean isCsvFile(byte[] data) {
		if (data == null || data.length == 0) return false;
		String firstLine = new String(data, 0, Math.min(data.length, 256));
		return firstLine.matches("[\\x20-\\x7E\\r\\n,;]+") && (firstLine.contains(",") || firstLine.contains(";"));
	}


	private String generateUniqueSheetName(String originalSheetName, Workbook workbook) {
		String uniqueSheetName = originalSheetName;
		int counter = 1;
		while (workbook.getSheet(uniqueSheetName) != null) {
			uniqueSheetName = originalSheetName + "_" + counter;
			counter++;
		}
		return uniqueSheetName;
	}

	private void copySheetData(Sheet sourceSheet, Sheet targetSheet, Workbook targetWorkbook, Map<CellStyle, CellStyle> styleCache) {
		for (int rowIndex = 0; rowIndex <= sourceSheet.getLastRowNum(); rowIndex++) {
			Row sourceRow = sourceSheet.getRow(rowIndex);
			if (sourceRow != null) {
				Row targetRow = targetSheet.createRow(rowIndex);
				targetRow.setHeight(sourceRow.getHeight());
				copyRowCells(sourceRow, targetRow, targetWorkbook, styleCache);
			}
		}
	}

	private void copyRowCells(Row sourceRow, Row targetRow, Workbook targetWorkbook, Map<CellStyle, CellStyle> styleCache) {
		for (int cellIndex = 0; cellIndex < sourceRow.getLastCellNum(); cellIndex++) {
			Cell sourceCell = sourceRow.getCell(cellIndex);
			if (sourceCell != null) {
				Cell targetCell = targetRow.createCell(cellIndex);
				copyCellValue(sourceCell, targetCell);
				copyCellStyle(sourceCell, targetCell, targetWorkbook, styleCache);
			}
		}
	}

	private void copyCellValue(Cell sourceCell, Cell targetCell) {
		switch (sourceCell.getCellType()) {
			case STRING:
				targetCell.setCellValue(sourceCell.getStringCellValue());
				break;
			case NUMERIC:
				if (DateUtil.isCellDateFormatted(sourceCell)) {
					targetCell.setCellValue(sourceCell.getDateCellValue());
				} else {
					targetCell.setCellValue(sourceCell.getNumericCellValue());
				}
				break;
			case BOOLEAN:
				targetCell.setCellValue(sourceCell.getBooleanCellValue());
				break;
			case FORMULA:
				targetCell.setCellFormula(sourceCell.getCellFormula());
				break;
			default:
				targetCell.setCellValue(sourceCell.toString());
		}
	}

	private void copyCellStyle(Cell sourceCell, Cell targetCell, Workbook targetWorkbook, Map<CellStyle, CellStyle> styleCache) {
		CellStyle sourceStyle = sourceCell.getCellStyle();
		CellStyle targetStyle = styleCache.get(sourceStyle);
		if (targetStyle == null) {
			targetStyle = targetWorkbook.createCellStyle();
			// Only use cloneStyleFrom if both styles are of the same type
			if (sourceStyle.getClass().equals(targetStyle.getClass())) {
				targetStyle.cloneStyleFrom(sourceStyle);
			} else {
				// Manually copy style properties
				targetStyle.setAlignment(sourceStyle.getAlignment());
				targetStyle.setVerticalAlignment(sourceStyle.getVerticalAlignment());
				targetStyle.setWrapText(sourceStyle.getWrapText());
				targetStyle.setBorderTop(sourceStyle.getBorderTop());
				targetStyle.setBorderBottom(sourceStyle.getBorderBottom());
				targetStyle.setBorderLeft(sourceStyle.getBorderLeft());
				targetStyle.setBorderRight(sourceStyle.getBorderRight());
				targetStyle.setTopBorderColor(sourceStyle.getTopBorderColor());
				targetStyle.setBottomBorderColor(sourceStyle.getBottomBorderColor());
				targetStyle.setLeftBorderColor(sourceStyle.getLeftBorderColor());
				targetStyle.setRightBorderColor(sourceStyle.getRightBorderColor());
				targetStyle.setFillPattern(sourceStyle.getFillPattern());
				targetStyle.setFillForegroundColor(sourceStyle.getFillForegroundColor());
				targetStyle.setFillBackgroundColor(sourceStyle.getFillBackgroundColor());
				targetStyle.setDataFormat(sourceStyle.getDataFormat());
				targetStyle.setHidden(sourceStyle.getHidden());
				targetStyle.setLocked(sourceStyle.getLocked());
				targetStyle.setIndention(sourceStyle.getIndention());
				targetStyle.setRotation(sourceStyle.getRotation());
			}
			styleCache.put(sourceStyle, targetStyle);
		}
		targetCell.setCellStyle(targetStyle);
	}


	private void copyColumnWidths(Sheet sourceSheet, Sheet targetSheet) {
		String sheetName = sourceSheet.getSheetName();

		if (sheetName != null && sheetName.toUpperCase().contains("Country Dealer Mismatch Report".toUpperCase())) {
			copyColumnWidthsForCDM(sourceSheet, targetSheet);
		} else {
			copyColumnWidthsDefault(sourceSheet, targetSheet);
		}
	}

	private void copyColumnWidthsDefault(Sheet sourceSheet, Sheet targetSheet) {
		if (sourceSheet.getRow(0) != null) {
			for (int i = 0; i < sourceSheet.getRow(0).getLastCellNum(); i++) {
				targetSheet.setColumnWidth(i, sourceSheet.getColumnWidth(i));
			}
		}
	}

	private void copyColumnWidthsForCDM(Sheet sourceSheet, Sheet targetSheet) {
		// For CDM reports: headers in row 2, data starts from row 4
		int headerRowIndex = 1; // Row 2 (0-based)
		int dataStartRowIndex = 3; // Row 4 (0-based)

		// Find maximum column count from header row and data rows
		int maxColumns = 0;

		// Check header row
		Row headerRow = sourceSheet.getRow(headerRowIndex);
		if (headerRow != null && headerRow.getLastCellNum() > maxColumns) {
			maxColumns = headerRow.getLastCellNum();
		}

		// Check first few data rows to ensure we capture all columns
		for (int rowIndex = dataStartRowIndex; rowIndex <= Math.min(dataStartRowIndex + 5, sourceSheet.getLastRowNum()); rowIndex++) {
			Row dataRow = sourceSheet.getRow(rowIndex);
			if (dataRow != null && dataRow.getLastCellNum() > maxColumns) {
				maxColumns = dataRow.getLastCellNum();
			}
		}

		// Copy column widths and auto-size if needed
		for (int colIndex = 0; colIndex < maxColumns; colIndex++) {
			int sourceWidth = sourceSheet.getColumnWidth(colIndex);
			if (sourceWidth > 0) {
				targetSheet.setColumnWidth(colIndex, sourceWidth);
			} else {
				// Auto-size based on header and data content
				try {
					targetSheet.autoSizeColumn(colIndex);
					// Ensure minimum width for readability
					int autoWidth = targetSheet.getColumnWidth(colIndex);
					if (autoWidth < 2560) { // ~10 characters minimum
						targetSheet.setColumnWidth(colIndex, 2560);
					}
				} catch (Exception e) {
					targetSheet.setColumnWidth(colIndex, 3000); // Default width for CDM
				}
			}
		}

		log.debug("CDM column widths copied for {} columns", maxColumns);
	}

	private String uploadCombinedWorkbook(Workbook workbook, String fileName, int gfsaNumber, ReportResponseHistoric reportResponse, String xmlContentType) throws IOException {
		Path tempFile = null;
		try {
			// Write the combined workbook to a temporary file
			tempFile = Files.createTempFile("combined_report_" + gfsaNumber + "_" + reportResponse.getReportId() + "_", ".xlsx"); // Use .xlsx, SXSSFWorkbook is streaming XLSX
			try (OutputStream fileOutputStream = Files.newOutputStream(tempFile)) {
				workbook.write(fileOutputStream);
			}
			log.info("Combined workbook written to temporary file: {}", tempFile.toAbsolutePath());

			// Upload the temporary file to GCS
			try (InputStream uploadStream = Files.newInputStream(tempFile)) {
				uploadToGcsHistoric(uploadStream, fileName, gfsaNumber, "E", reportResponse.getRequestedBy(), xmlContentType);
			}
			log.info("Combined Excel file uploaded to GCS: {}", fileName);
			return fileName;
		} catch (Exception e) {
			log.error("Error creating or uploading combined Excel file via temp file: {}", e.getMessage(), e);
			return StringUtils.EMPTY;
		} finally {
			try {
				if (workbook != null) {
					workbook.close(); // Close the workbook after use
				}
				if (tempFile != null) {
					Files.deleteIfExists(tempFile); // Ensure temporary file is deleted
					log.info("Temporary file deleted for combined report: {}", tempFile.toAbsolutePath());
				}
			} catch (IOException e) {
				log.error("Error closing workbook or deleting temporary file for combined report", e);
			}
		}
	}

	private boolean isValidReportResponse(ReportResponseHistoric reportResponse) {
		if (reportResponse == null) {
			return false;
		}
		// Only check if the stream object itself is non-null.
		// The actual content check (e.g., if the temp file is empty) should happen
		// when processing the stream (e.g., when trying to create a workbook from it).
		return reportResponse.getReportContentStream() != null;
	}
//---------------------------------------------------------------


	private static String getTimeStamp(GridVernCount gridVernCount, String fileName) {
		gridVernCount.setKey(fileName);
		long timestamp = System.currentTimeMillis();
		Date date = new Date(timestamp);
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd-HH.mm.ss.SSSSSS");
		return dateFormat.format(date);
	}

	private void uploadToGcs(InputStream inputStream, String fileName, int globalFsaNumber, String actionFlag, String requester) {
		try {
			log.info("Converting InputStream to MultipartFile for file: {} - FSA : {} : {} : {} to Upload on GCS. ",
					fileName, globalFsaNumber, actionFlag, requester);
			byte[] bytes = inputStream.readAllBytes();
			MultipartFile multipartFile = new MockMultipartFile(fileName, fileName, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", bytes);
			//extractOptionService.addFileToGcsViaFsaService(fileName, multipartFile, actionFlag, requester);
			extractOptionService.addFileToGcsViaFsaService(fileName, multipartFile, actionFlag, requester, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
		} catch (IOException e) {
			log.error("Error converting InputStream to MultipartFile for file: {} : {} : {}", fileName, actionFlag, requester);
		}
	}

	private void uploadToGcsHistoric(InputStream inputStream, String fileName, int globalFsaNumber, String actionFlag, String requester, String contentType) {
		try {
			log.info("Converting InputStream to MultipartFile for file: {} - FSA : {} : {} : {} to Upload on GCS. ",
					fileName, globalFsaNumber, actionFlag, requester);
			byte[] bytes = inputStream.readAllBytes();
			MultipartFile multipartFile = new MockMultipartFile(fileName, fileName, contentType, bytes);
			extractOptionService.addFileToGcsViaFsaService(fileName, multipartFile, actionFlag, requester, contentType);
		} catch (IOException e) {
			log.error("Error converting InputStream to MultipartFile for file: {} : {} : {}", fileName, actionFlag, requester);
		}
	}
	public String saveReportToS3WithVersioning(GridVernData gridVernData,String fileName,ReportsResponse reportResponse, String actionFlag,GridVernCount gridVernCount) {
		String key = fileName;
		int version = 0;

		while (s3Service.doesObjectExist(key + "-" + version)) {
			version++;
		}
		key = key + "-" + version;
		try (InputStream inputStream = new ByteArrayInputStream(reportResponse.getByteArry())) {
			String timestamp=this.addFileToStorage(inputStream, key,
					ACTION_1, inputStream.available(),gridVernData,actionFlag);
			log.info(ACTION_2, fileName);
			gridVernCount.setTimestamp(timestamp);
		} catch (Exception e) {
			log.error(ACTION_3, e);
		}
		return key;
	}

	public void insertTo(GridVernData gridVernData, GridVernCount gridVernCount) throws GCAMPException {
		StringBuilder param = new StringBuilder();
		param.append(TargetingUtil.fillRemainingString("G",1," "));
		param.append(TargetingUtil.fillWithZeros(String.valueOf(gridVernData.getGlobalFSANumber()),8));
		param.append(TargetingUtil.fillRemainingString("",11," "));
		StringBuilder param2 = new StringBuilder();
		param2.append(TargetingUtil.fillRemainingString(gridVernCount.getSupplementId(),2,"0"));
		param2.append(TargetingUtil.fillRemainingString(gridVernData.getUpdateId(),8," "));
		param2.append(TargetingUtil.fillRemainingString(gridVernCount.getTimestamp(),26," "));
		param2.append(TargetingUtil.fillRemainingString(gridVernCount.getAction(),1," "));
		repo.insertData(param.toString(),param2.toString(),gridVernCount);

	}

	private CommonResponse invokeGridAPIPush(GridVernCount gridVernCount, String apiUrl, HttpMethod httpMethod,
											 int retryCount,GridVernData gridVernData) {
		log.info("VERN Count Response from GCAMP to GRID: {}", TargetingUtil.prettyPrintJSON(gridVernCount));
		try {
			CommonResponse gridResponse = reactiveWebClient
					.method(httpMethod)
					.uri(apiUrl)
					.body(Mono.just(gridVernCount), GridVernCount.class)
					.retrieve()
					.bodyToMono(CommonResponse.class)
					.block();
			if (gridResponse != null && CommonConstants.SUCCESS_CODE.equals(gridResponse.getStatusCode())) {
				if(gridVernCount.getTimestamp()!=null) {
					insertTo(gridVernData, gridVernCount);
				}
				return CommonResponse.builder().status(CommonConstants.SUCCESS).statusCode(CommonConstants.SUCCESS_CODE)
						.statusDescription("Vehicle Count Sent Successfully to GRID").build();
			}
			log.info("Vern Response Sent Successfully to GRID");
		} catch (Exception e) {
			retryCount++;
			if (retryCount < 3 && e.getMessage() != null && !e.getMessage().contains("412")) {
				retryGridVernFlow(gridVernCount, apiUrl, httpMethod, retryCount);
			}
			log.error("Failed to send Vehicle Count to GRID", e);
		}
		if(gridVernCount.getKey()!=null) {
			s3Service.deleteFile(gridVernCount.getKey());
		}
		return CommonResponse.builder().status(CommonConstants.FAILURE).statusCode(CommonConstants.FAILURE_CODE)
				.statusDescription("Failed to send Vehicle Count to GRID. Try later.").build();
	}

	void normalizeSupplementId(GridVfdRequest gridVfdRequest) {
		log.info("Normalizing supplement ID for Refresh Request");
		if (gridVfdRequest.getSupplementId().length() == INT_ONE) {
			gridVfdRequest.setSupplementId(ZERO_AS_STRING + gridVfdRequest.getSupplementId());
		}
	}

	public ReportBatchStatusResponse getReportBatchStatus(int globalFsaNumber, String supplCode) {
		try {
			log.info("Fetching report batch status for Global FSA Number: {} and Supplement Code: {}", globalFsaNumber, supplCode);

			ReportBatchStatusResponse response = webClient.get()
					.uri("/api/v1/batchblocker/bqreportstatus/{globalFsaNumber}/{supplCode}", globalFsaNumber, supplCode)
					.header(AUTHORIZATION, BEARER + webClientAdConfiguration.getAccessToken(scope, "reporting"))
					.exchangeToMono(clientResponse -> {
						if (clientResponse.statusCode().isError()) {
							return errorHandler(clientResponse)
									.map(commonResponse -> new ReportBatchStatusResponse(false, false, false));
						}
						return clientResponse.bodyToMono(ReportBatchStatusResponse.class);
					})
					.block();

			log.info("Report batch status retrieved successfully for FSA: {} and Supplement Code: {}", globalFsaNumber, supplCode);
			return response != null ? response : new ReportBatchStatusResponse(false, false, false);

		} catch (Exception e) {
			log.error("Error fetching report batch status for FSA: {} and Supplement Code: {}", globalFsaNumber, supplCode, e);
			return new ReportBatchStatusResponse(false, false, false);
		}
	}
	public static class RecordData {
		final int gfsaNumber;
		final String suppCode;

		RecordData(int gfsaNumber, String suppCode) {
			this.gfsaNumber = gfsaNumber;
			this.suppCode = suppCode;
		}
	}

}
