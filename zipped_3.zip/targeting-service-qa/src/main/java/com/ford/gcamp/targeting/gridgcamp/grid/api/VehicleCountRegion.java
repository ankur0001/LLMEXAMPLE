package com.ford.gcamp.targeting.gridgcamp.grid.api;

import java.util.List;

import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class VehicleCountRegion {
	@Size(min=0, max = 2)
	@Pattern(regexp ="^[A-Za-z]*$")
	private String region;
	
	@Size(min=0, max = 2)
	@Pattern(regexp ="^[A-Za-z]*$")
	private String gcampRegion;
	
	private String localFSACreationDate; 
	
	@Size(min=0, max = 500)
	private List<VehicleCountCountry> regionDetails;
}
