package com.ford.gcamp.targeting.prelaunchreports;


import com.ford.cloudnative.base.api.StandardErrorResponse;
import com.ford.gcamp.targeting.common.CommonConstants;
import com.ford.gcamp.targeting.common.CommonService;
import com.ford.gcamp.targeting.common.api.CommonErrorResponse;
import com.ford.gcamp.targeting.common.api.ReportBatchStatusResponse;
import com.ford.gcamp.targeting.gridgcamp.grid.GridVernCountService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.ford.gcamp.targeting.common.api.CommonJobResponse;
import com.ford.gcamp.targeting.core.exception.GCAMPException;
import com.ford.gcamp.targeting.prelaunchreports.api.DistributionsRequest;
import com.ford.gcamp.targeting.prelaunchreports.api.DistributionsResponse;
import com.ford.gcamp.targeting.prelaunchreports.api.ExtractOptionRequest;
import com.ford.gcamp.targeting.prelaunchreports.api.ExtractOptionResponse;
import com.ford.gcamp.targeting.prelaunchreports.api.SaveAsDefaultResponse;
import com.ford.gcamp.targeting.prelaunchreports.api.SaveDistributionsResponse;

import java.util.concurrent.CompletableFuture;

@RestController
@RequestMapping("/api/v1/targeting/extract")
@Validated
@Slf4j
public class ExtractOptionController {

    private ExtractOptionService extractService;
    private GridVernCountService gridVernCountService;

    @Autowired
    public ExtractOptionController(ExtractOptionService extractService, GridVernCountService gridVernCountService) {
        this.extractService = extractService;
        this.gridVernCountService = gridVernCountService;
    }

    @PreAuthorize("@authorizeService.isAuthorized('GCAMP:extractOption:go','execute')")
    @Operation(summary = "load Extract Option", security = {
			@SecurityRequirement(name = "ADFS"),
			@SecurityRequirement(name = "AzureAD")
	})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Load Extract Option request processed successfully", content = @Content(mediaType = "application/problem+json", schema = @Schema(implementation = ExtractOptionResponse.class))),
            @ApiResponse(responseCode = "412", description = "Precondition Failed", content = @Content(schema = @Schema(implementation = CommonErrorResponse.class))),
            @ApiResponse(responseCode = "default", description = "All Errors", content = @Content(schema = @Schema(implementation = StandardErrorResponse.class)))
    })
    @PostMapping(value = "/loadExtractOption")
    public ResponseEntity<ExtractOptionResponse> loadReportSelections(@RequestBody @Valid ExtractOptionRequest extractOptionReq) throws GCAMPException {
        ExtractOptionResponse response = extractService.loadDefaultSelection(extractOptionReq);
        return ResponseEntity.ok(response);

    }

    @PreAuthorize("@authorizeService.isAuthorized('GCAMP:extractOption:saveDefaults','execute')")
    @Operation(summary = "Save as Default Option", security = {
			@SecurityRequirement(name = "ADFS"),
			@SecurityRequirement(name = "AzureAD")
	})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Save as Default request processed successfully", content = @Content(mediaType = "application/problem+json", schema = @Schema(implementation = SaveAsDefaultResponse.class))),
            @ApiResponse(responseCode = "412", description = "Precondition Failed", content = @Content(schema = @Schema(implementation = CommonErrorResponse.class))),
            @ApiResponse(responseCode = "default", description = "All Errors", content = @Content(schema = @Schema(implementation = StandardErrorResponse.class)))
    })
    @PostMapping(value = "/saveAsDefault")
    public ResponseEntity<SaveAsDefaultResponse> saveAsDefault(@RequestBody @Valid ExtractOptionRequest extractOptionReq) throws GCAMPException {
        SaveAsDefaultResponse response = extractService.saveAsDefault(extractOptionReq);
        return ResponseEntity.ok(response);

    }

    @PreAuthorize("@authorizeService.isAuthorized('GCAMP:DistributionListAction:selectDistributionList','execute')")
    @Operation(summary = "load Distributions", security = {
			@SecurityRequirement(name = "ADFS"),
			@SecurityRequirement(name = "AzureAD")
	})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Load Distributions request processed successfully", content = @Content(mediaType = "application/problem+json", schema = @Schema(implementation = DistributionsResponse.class))),
            @ApiResponse(responseCode = "412", description = "Precondition Failed"),
            @ApiResponse(responseCode = "default", description = "All Errors", content = @Content(schema = @Schema(implementation = StandardErrorResponse.class)))
    })
    @PostMapping(value = "/loadDistributions")
    public ResponseEntity<DistributionsResponse> distrubutionList(@RequestBody @Valid DistributionsRequest distributionRequest) {
        DistributionsResponse response = extractService.loadDistrubutions(distributionRequest);
        return ResponseEntity.ok(response);

    }

    @PreAuthorize("@authorizeService.isAuthorized('GCAMP:DistributionListAction:saveSelectMember','execute')")
    @Operation(summary = "Save Distributions", security = {
			@SecurityRequirement(name = "ADFS"),
			@SecurityRequirement(name = "AzureAD")
	})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Save Distributions request processed successfully", content = @Content(mediaType = "application/problem+json", schema = @Schema(implementation = SaveDistributionsResponse.class))),
            @ApiResponse(responseCode = "412", description = "Precondition Failed", content = @Content(schema = @Schema(implementation = CommonErrorResponse.class))),
            @ApiResponse(responseCode = "default", description = "All Errors", content = @Content(schema = @Schema(implementation = StandardErrorResponse.class)))
    })
    @PostMapping(value = "/saveDistributions")
    public ResponseEntity<SaveDistributionsResponse> saveDistributionList(@RequestBody @Valid DistributionsRequest distributionRequest) throws GCAMPException {
        SaveDistributionsResponse response = extractService.saveDistributionList(distributionRequest);
        return ResponseEntity.ok(response);

    }

    @PreAuthorize("@authorizeService.isAuthorized('GCAMP:extractOption:submitExtract','execute')")
    @Operation(summary = "Submit extract", security = {
			@SecurityRequirement(name = "ADFS"),
			@SecurityRequirement(name = "AzureAD")
	})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Submit extract request processed successfully", content = @Content(mediaType = "application/problem+json", schema = @Schema(implementation = CommonJobResponse.class))),
            @ApiResponse(responseCode = "412", description = "Precondition Failed", content = @Content(schema = @Schema(implementation = CommonErrorResponse.class))),
            @ApiResponse(responseCode = "default", description = "All Errors", content = @Content(schema = @Schema(implementation = StandardErrorResponse.class)))
    })
    @PostMapping(value = "/submitExtract")
    public ResponseEntity<CommonJobResponse> submitExtract(@RequestBody @Valid ExtractOptionRequest extractProcessRequest) throws GCAMPException {
        ReportBatchStatusResponse reportAndBatchFlagResponse = gridVernCountService.getReportBatchStatus(Integer.parseInt(extractProcessRequest.getFsaNumber()), extractProcessRequest.getPopulation());
        if (reportAndBatchFlagResponse.isBatchBlockFlag()) {
            CommonJobResponse commonJobResponse = new CommonJobResponse();
            commonJobResponse.setJobId(0);
            commonJobResponse.setStatusCode(String.valueOf(HttpStatus.PRECONDITION_FAILED.value()));
            commonJobResponse.setStatus(CommonConstants.FAILURE);
            commonJobResponse.setStatusDescription(String.format(
                    "Extract cannot be submitted due to Batch Blocker. Targeting Extracts is in progress FSA Number: %s Supplement Population: %s",
                    extractProcessRequest.getFsaNumber(),
                    extractProcessRequest.getPopulation()
            ));

            return ResponseEntity.status(HttpStatus.PRECONDITION_FAILED).body(commonJobResponse);
        }
        CommonJobResponse response = extractService.submitExtract(extractProcessRequest, extractProcessRequest.getCdsId());
        return ResponseEntity.ok(response);

    }


    @Operation(summary = "Submit extract", security = {
			@SecurityRequirement(name = "ADFS"),
			@SecurityRequirement(name = "AzureAD")
	})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Submit extract request processed successfully", content = @Content(mediaType = "application/problem+json", schema = @Schema(implementation = CommonJobResponse.class))),
            @ApiResponse(responseCode = "412", description = "Precondition Failed", content = @Content(schema = @Schema(implementation = CommonErrorResponse.class))),
            @ApiResponse(responseCode = "default", description = "All Errors", content = @Content(schema = @Schema(implementation = StandardErrorResponse.class)))
    })
    @PostMapping(value = "/submitExtractFromFsa")
    public ResponseEntity<CommonJobResponse> submitExtractFromFsa(@RequestBody @Valid ExtractOptionRequest extractProcessRequest) throws GCAMPException {
        extractProcessRequest.setFsaRequest(true);
        CommonJobResponse response = extractService.submitExtract(extractProcessRequest, extractProcessRequest.getCdsId());
        return ResponseEntity.ok(response);

    }


    @PreAuthorize("@authorizeService.isAuthorized('GCAMP:extractOption:submitReports','execute')")
    @Operation(summary = "Submit Report", security = {
			@SecurityRequirement(name = "ADFS"),
			@SecurityRequirement(name = "AzureAD")
	})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Submit Report request processed successfully", content = @Content(mediaType = "application/problem+json", schema = @Schema(implementation = CommonJobResponse.class))),
            @ApiResponse(responseCode = "412", description = "Precondition Failed", content = @Content(schema = @Schema(implementation = CommonErrorResponse.class))),
            @ApiResponse(responseCode = "default", description = "All Errors", content = @Content(schema = @Schema(implementation = StandardErrorResponse.class)))
    })
    @PostMapping(value = "/submitReport")
    public ResponseEntity<CommonJobResponse> submitReport(@RequestBody @Valid
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            content = @Content(
                    schema = @Schema(implementation = ExtractOptionRequest.class),
                    examples = @ExampleObject(
                            name = "Submit Report Example",
                            value = """
                                    {
                                        "cdsId": "PDHANAS9",
                                        "countryCode": "CAN",
                                        "emailSubmitInd": "Y",
                                        "fsaNumber": "21911",
                                        "fsaRequest": true,
                                        "fsaType": "G",
                                        "hubCode": "NA",
                                        "loadTeraDataInd": "Y",
                                        "navisIndicator": "Y",
                                        "population": "AA",
                                        "processFlag": "S",
                                        "regionalFilter": "Y",
                                        "reportChecked": "T21T22T23T24T25T26T27T28T29T30T31T33T32T34IAD",
                                        "reportCount": 15,
                                        "serialNumInd": "Y",
                                        "wersCodeCount": 15,
                                        "wersCodeSelected": "23,35,36"
                                      }
                """
                    )
            )
    )ExtractOptionRequest processExtractRequest) throws GCAMPException {
        ReportBatchStatusResponse reportAndBatchFlagResponse = gridVernCountService.getReportBatchStatus(Integer.parseInt(processExtractRequest.getFsaNumber()), processExtractRequest.getPopulation());
        if (reportAndBatchFlagResponse.isBatchBlockFlag()) {
            CommonJobResponse commonJobResponse = new CommonJobResponse();
            commonJobResponse.setJobId(0);
            commonJobResponse.setStatusCode(String.valueOf(HttpStatus.PRECONDITION_FAILED.value()));
            commonJobResponse.setStatus(CommonConstants.FAILURE);
            commonJobResponse.setStatusDescription(String.format(
                    "Report cannot be submitted due to Batch Blocker. Targeting Extracts is in progress FSA Number: %s Supplement Population: %s",
                    processExtractRequest.getFsaNumber(),
                    processExtractRequest.getPopulation()
            ));

            return ResponseEntity.status(HttpStatus.PRECONDITION_FAILED).body(commonJobResponse);
        }

        CommonJobResponse response = extractService.submitReports(processExtractRequest);
        return ResponseEntity.ok(response);
    }

}
