package com.ford.gcamp.targeting.gsar;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ford.gcamp.targeting.gsar.entity.GcampSnapEntity;

@Repository
public interface GsarRepository extends JpaRepository<GcampSnapEntity, Integer>{
	
	List<GcampSnapEntity> findByUserIdOrderByRunDateDesc(String userId);

	List<GcampSnapEntity> findByResultIdOrderByRunDateDesc(int resultId);
	
	List<GcampSnapEntity> findByResIdOrderByRunDateDesc(Long resId);
}
