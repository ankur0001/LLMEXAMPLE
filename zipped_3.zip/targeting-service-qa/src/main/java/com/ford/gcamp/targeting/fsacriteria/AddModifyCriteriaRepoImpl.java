package com.ford.gcamp.targeting.fsacriteria;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;
import org.springframework.web.util.HtmlUtils;

import com.ford.gcamp.targeting.common.CommonConstants;
import com.ford.gcamp.targeting.common.Hubs;
import com.ford.gcamp.targeting.common.TargetingUtil;
import com.ford.gcamp.targeting.common.api.FSATypes;
import com.ford.gcamp.targeting.common.api.FscCriteriaRequest;
import com.ford.gcamp.targeting.common.api.SuppPopulationVo;
import com.ford.gcamp.targeting.core.exception.GCAMPException;
import com.ford.gcamp.targeting.fsacriteria.api.DeleteFsaInfoReq;
import com.ford.gcamp.targeting.fsacriteria.api.FsaCriteriaParamRequest;
import com.ford.gcamp.targeting.fsacriteria.api.FsaGlobalSearchDTO;
import com.ford.gcamp.targeting.fsacriteria.api.FscCriteriaResponseGoDTO;
import com.ford.gcamp.targeting.fsacriteria.api.LoadFsaResponseDTO;
import com.ford.gcamp.targeting.fsacriteria.api.LoadSelectCounValDTO;
import com.ford.gcamp.targeting.fsacriteria.api.LoadStateProvinceDTO;
import com.ford.gcamp.targeting.fsacriteria.api.LoadVehAttValDTO;
import com.ford.gcamp.targeting.fsacriteria.api.TraceablityList;
import com.ford.gcamp.targeting.vin.api.ExistingVinGrpList;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Repository
public class AddModifyCriteriaRepoImpl {

	private static final Logger LOGGER = LoggerFactory.getLogger(AddModifyCriteriaRepoImpl.class);

	@Value("${DB_OWNER}")
	private String ownerId;

	@Value("${db2.uncommit.read}")
	private String uncommitRead;

	@Autowired
	private JdbcTemplate jdbcTemplate;
	@Autowired
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;
	@Autowired
	private LoadFsaResponseDTO fsaLoadData;
	@Autowired
	private FSADBStoreProcUtil fsadbStoreProcUtil;
	@Autowired
	FsaCriteriaSearchStoreProc fsaCriteriaStoreProc;
	@Autowired
	private LoadSelectCounValDTO selectCountryResp;
	@Autowired
	FsaUtil fscCriteriaUtil;
	@Autowired
	private FSADBStoreProcVehAttUtil fsadbStoreProcVehAttUtil;
	@Autowired
	FsaSaveCopyDataUtil fsaSaveCopyDataUtil;
	@Autowired
	FSADBStoreProcStateprovUtil fsaDbStoreProcProvUtil;
	@Autowired
	private LoadStateProvinceDTO loadStateProvResp;
	@Autowired
	private FSADBStoreProcSelectCountryUtil fsadbStoreProcSelectCountryUtil;
	@Autowired
	FsaGlobalSearchDTO fsaSearchDto;
	@Autowired
	FsaGlobalSearchUtil fsaGlobalSearchUtil;

	MapSqlParameterSource createSqlParameterSource(String inputParamKey1, String inputParamVal1) {
		return new MapSqlParameterSource().addValue(inputParamKey1, inputParamVal1);
	}

	MapSqlParameterSource createSqlParameterSource(String inputParamKey1, String inputParamVal1, String inputParamKey2,
			String inputParamVal2) {
		return new MapSqlParameterSource().addValue(inputParamKey1, inputParamVal1).addValue(inputParamKey2,
				inputParamVal2);
	}

	MapSqlParameterSource createSqlParameterSource(String inputParamKey1, String inputParamVal1, String inputParamKey2,
			String inputParamVal2, String inputParamKey3 , String inputParamVal3) {
		return new MapSqlParameterSource().addValue(inputParamKey1, inputParamVal1)
				.addValue(inputParamKey2, inputParamVal2).addValue(inputParamKey3, inputParamVal3);
	}

	SimpleJdbcCall creatSimpleJdbcCall(String schemaName, String procedureName) {
		return new SimpleJdbcCall(jdbcTemplate).withSchemaName(schemaName).withProcedureName(procedureName);
	}

	public LoadFsaResponseDTO loadFscCriteriaDetails() {

		SimpleJdbcCall simpleJdbcCall = null;
		try {
			simpleJdbcCall = creatSimpleJdbcCall(CommonConstants.FSA_SCHEMA_NAME,
					CommonConstants.ADD_MODIFYSTOREDPROC_NAME);
			SqlParameterSource sqlParameterSource = createSqlParameterSource(CommonConstants.INPUT_PARM1, "00",
					CommonConstants.INPUT_PARM2, " ");
			Map<String, Object> map = simpleJdbcCall.execute(sqlParameterSource);
			fsaLoadData = fsadbStoreProcUtil.callStoreProcedure(map);
		} catch (Exception e) {
			LOGGER.error(CommonConstants.EXCEPTION_OCCURED, e);
		}
		return fsaLoadData;

	}

	public FscCriteriaResponseGoDTO getFscSearchList(FscCriteriaRequest fscCriteriaRequest) {

		Map<String, Object> fscCriteriaResponseMap = null;
		SimpleJdbcCall sipleJdbcCall = null;
		FscCriteriaResponseGoDTO fsaCriteriaDTO = new FscCriteriaResponseGoDTO();

		String intputParam1 = fscCriteriaUtil.formInputParam2(fscCriteriaRequest.getPopulation(),
				fscCriteriaRequest.getCdsId());
		String inputFSAG = fscCriteriaUtil.formInputParamFAG(fscCriteriaRequest.getFscNumber(),
				fscCriteriaRequest.getOptRadio());
		try {
			sipleJdbcCall = creatSimpleJdbcCall(CommonConstants.FSA_SCHEMA_NAME,
					CommonConstants.GLOBALFSA_STOREDPROC_NAME);
			SqlParameterSource sqlParameterSource = createSqlParameterSource(CommonConstants.INPUT_PARM1, intputParam1,
					CommonConstants.INPUT_FSAGO1, inputFSAG);
			LOGGER.info("inout of fsa go {}", sqlParameterSource);
			fscCriteriaResponseMap = sipleJdbcCall.execute(sqlParameterSource);
			LOGGER.info("response of fsa go {}", fscCriteriaResponseMap);

			fsaCriteriaDTO = fsaCriteriaStoreProc.callFsaSearch(fscCriteriaResponseMap);
			String globalFsaNumber = null;
			if (fsaCriteriaDTO.getFsaInfoVO().getGlobalFSANumber() != null) {

				globalFsaNumber = fsaCriteriaDTO.getFsaInfoVO().getGlobalFSANumber();

				List<SuppPopulationVo> populationList = getSupplementVo(globalFsaNumber);

				fsaCriteriaDTO.setSuppPopulation(populationList);

				SqlParameterSource parameters = new MapSqlParameterSource().addValue("fsaNumber", globalFsaNumber);

				StringBuilder vinSql = new StringBuilder();
				vinSql.append("SELECT count(*) FROM ");
				vinSql.append(ownerId);
				vinSql.append(" SGCPD08_INCL_EXCL WHERE GCPA15_GLOBL_FSA_R= :fsaNumber");
				vinSql.append(" AND GCPA09_SUPPL_C = '00'");
				Integer vinCount = namedParameterJdbcTemplate.queryForObject(vinSql.toString(), parameters,
						Integer.class);

				StringBuilder serialQuery = new StringBuilder();
				serialQuery.append("SELECT count(*) FROM ");
				serialQuery.append(ownerId);
				serialQuery.append(" SGCPD31_SERNUM_FLS WHERE GCPA15_GLOBL_FSA_R= :fsaNumber");
				serialQuery.append(" AND GCPA09_SUPPL_C = '00'");
				Integer serialCount = namedParameterJdbcTemplate.queryForObject(serialQuery.toString(), parameters,
						Integer.class);

				if (null != vinCount && vinCount > 0) {
					fsaCriteriaDTO.setVinFlag(true);
				}
				if (null != serialCount && serialCount > 0) {
					fsaCriteriaDTO.setSerialFlag(true);
				}
			}
		} catch (Exception e) {
			LOGGER.error(CommonConstants.EXCEPTION_OCCURED, e);
		}
		return fsaCriteriaDTO;
	}

	public LoadVehAttValDTO loadDynamicQueryDetailsForVehAtt(String inputModelValue) {
		SimpleJdbcCall simpleJdbcCall = null;
		String inputParam1 = null;
		String outputParam = null;
		String vehicleAttributeValue = null;
		LoadVehAttValDTO vehicleAttributeResponse = new LoadVehAttValDTO();
		StringBuilder query = new StringBuilder();
		try {
			simpleJdbcCall = creatSimpleJdbcCall(CommonConstants.FSA_SCHEMA_NAME,
					CommonConstants.ADD_MODIFYSTOREDPROC_NAME);
			query.append("SELECT GCPD13_COMP_TYPE_C, GCPD13_COMP_TYPE_X FROM  ").append(ownerId)
					.append(" SGCPD13_TRAC_COMP ORDER BY GCPD13_COMP_TYPE_X  ").append(uncommitRead);
			if ("17".equalsIgnoreCase(inputModelValue)) {
				List<TraceablityList> fsaCriteriaFilters = new ArrayList<>();

				jdbcTemplate
						.query(query.toString(), new Object[] {},
								(rs, rowNum) -> fsaCriteriaFilters
										.add(new TraceablityList(rs.getString("GCPD13_COMP_TYPE_C").trim(),
												rs.getString("GCPD13_COMP_TYPE_X").trim())));
				vehicleAttributeResponse.setTraceablityList(fsaCriteriaFilters);

			} else {
				if (inputModelValue.length() == 1) {
					vehicleAttributeValue = "000" + inputModelValue;
				} else if (inputModelValue.length() >= 1) {
					vehicleAttributeValue = "00" + inputModelValue;
				}

				inputParam1 = "03" + TargetingUtil.addZerosToProc(12) + vehicleAttributeValue;
				outputParam = " ";
				SqlParameterSource sqlParameterSource = createSqlParameterSource(CommonConstants.INPUT_PARM1,
						inputParam1, CommonConstants.INPUT_PARM2, outputParam);
				Map<String, Object> map = simpleJdbcCall.execute(sqlParameterSource);
				vehicleAttributeResponse = fsadbStoreProcVehAttUtil.callStoreProcedure(map);
			}
		} catch (Exception e) {
			LOGGER.error(CommonConstants.EXCEPTION_OCCURED, e);
		}

		return vehicleAttributeResponse;
	}

	public Map<String, Object> saveFscSearchListDesc(FsaCriteriaParamRequest fsaCriteriaParam) throws GCAMPException {
		SimpleJdbcCall simpleJdbcCall = null;
		Map<String, Object> fscCriteriaResponseMap = new HashMap<>();
		try {
			simpleJdbcCall = creatSimpleJdbcCall(CommonConstants.FSA_SCHEMA_NAME,
					CommonConstants.GLOBALFSA_STOREDPROC_NAME);
			SqlParameterSource sqlParameterSource = createSqlParameterSource(CommonConstants.INPUT_FSAGO1,
					fsaSaveCopyDataUtil.getfsaGoParam(fsaCriteriaParam), CommonConstants.INPUT_PARM1,
					fsaSaveCopyDataUtil.getFsaSaveInputParam(fsaCriteriaParam));
			LOGGER.info("inout param of save is {}", sqlParameterSource);

			fscCriteriaResponseMap = simpleJdbcCall.execute(sqlParameterSource);
		} catch (Exception e) {
			LOGGER.error(CommonConstants.EXCEPTION_OCCURED, e);
			throw new GCAMPException(CommonConstants.EXCEPTION_OCCURED);
		}

		return fscCriteriaResponseMap;
	}

	public FscCriteriaResponseGoDTO copyFscSearchListDesc(FsaCriteriaParamRequest fsaCriteriaParam) {
		SimpleJdbcCall simpleJdbcCall = null;
		Map<String, Object> fscCriteriaResponseMap = new HashMap<>();
		FscCriteriaResponseGoDTO response = null;
		FsaListingCopyStoreProc fsaCopyStoreProc = new FsaListingCopyStoreProc();
		try {
			simpleJdbcCall = creatSimpleJdbcCall(CommonConstants.FSA_SCHEMA_NAME,
					CommonConstants.GLOBALFSA_STOREDPROC_NAME);
			SqlParameterSource sqlParameterSource = createSqlParameterSource(CommonConstants.INPUT_FSAGO1,
					fsaSaveCopyDataUtil.getfsaGoParam(fsaCriteriaParam), CommonConstants.INPUT_PARM1,
					fsaSaveCopyDataUtil.getFsaCopyInputParam(fsaCriteriaParam));
			LOGGER.info("inout param values {}", sqlParameterSource);
			fscCriteriaResponseMap = simpleJdbcCall.execute(sqlParameterSource);
			LOGGER.info("response copy {}", fscCriteriaResponseMap);
			response = fsaCopyStoreProc.fsaCopySoreProc(fscCriteriaResponseMap);
		} catch (Exception e) {
			LOGGER.error(CommonConstants.EXCEPTION_OCCURED, e);
		}
		return response;
	}

	public LoadStateProvinceDTO loadDynamicQueryDetailsForStateProv() {
		SimpleJdbcCall simpleJdbcCall = null;
		try {
			simpleJdbcCall = creatSimpleJdbcCall(CommonConstants.FSA_SCHEMA_NAME, "CSGCSB41");

			SqlParameterSource sqlParameterSource = createSqlParameterSource(CommonConstants.INPUT_PARM1, "000",
					CommonConstants.INPUT_PARM2, "");
			Map<String, Object> map = simpleJdbcCall.execute(sqlParameterSource);
			loadStateProvResp = fsaDbStoreProcProvUtil.callStoreProcedure(map);
		} catch (Exception e) {
			LOGGER.error(CommonConstants.EXCEPTION_OCCURED, e);
		}

		return loadStateProvResp;
	}

	public LoadSelectCounValDTO loadDynamicQueryDetailsForSelectCountry(FscCriteriaRequest fscCriteriaRequest) {
		SimpleJdbcCall simpleJdbcCall = null;
		try {
			String inputParam1 = fscCriteriaUtil.formInputParamFAG(fscCriteriaRequest.getFscNumber(),
					fscCriteriaRequest.getOptRadio());
			simpleJdbcCall = creatSimpleJdbcCall(CommonConstants.FSA_SCHEMA_NAME, CommonConstants.FSA_SELECT_COUNTRY);

			SqlParameterSource sqlParameterSource = createSqlParameterSource(CommonConstants.INPUT_PARM1, inputParam1,
					CommonConstants.INPUT_PARM2, "2", CommonConstants.INPUT_PARM3, StringUtils.SPACE);
			Map<String, Object> map = simpleJdbcCall.execute(sqlParameterSource);
			selectCountryResp = fsadbStoreProcSelectCountryUtil.callStoreProcedure(map);
		} catch (Exception e) {
			LOGGER.error(CommonConstants.EXCEPTION_OCCURED, e);
		}

		return selectCountryResp;
	}

	public FsaGlobalSearchDTO globalFsaSearchDetails(String dynamicQueryInutParam, String fsaType) {

		SimpleJdbcCall simpleJdbcCall = null;
		String sysProcName = "";
		try {
			if ("G".equals(fsaType)) {
				sysProcName = CommonConstants.GLOBALFSA_SEARCH_STOREDPROC_NAME;
			} else if ("L".equals(fsaType)) {
				sysProcName = CommonConstants.LOCALFSA_SEARCH_STOREDPROC_NAME;
			}
			simpleJdbcCall = creatSimpleJdbcCall(CommonConstants.FSA_SCHEMA_NAME, sysProcName);

			SqlParameterSource sqlParameterSource = createSqlParameterSource(CommonConstants.INPUT_PARM1,
					dynamicQueryInutParam);
			Map<String, Object> map = simpleJdbcCall.execute(sqlParameterSource);

			fsaSearchDto = fsaGlobalSearchUtil.callGlobalSearchStorProc(map, fsaType);
		} catch (Exception e) {
			LOGGER.error(CommonConstants.EXCEPTION_OCCURED, e);
		}

		return fsaSearchDto;
	}

	public Map<String, Object> deleteFscSearchListDesc(FsaCriteriaParamRequest fsaCriteriaParam) {
		SimpleJdbcCall simpleJdbcCall = null;
		Map<String, Object> fscCriteriaResponseMap = null;
		try {
			simpleJdbcCall = creatSimpleJdbcCall(CommonConstants.FSA_SCHEMA_NAME, CommonConstants.FSA_DELETE_CRITERIA);
			SqlParameterSource sqlParameterSource = createSqlParameterSource(CommonConstants.INPUT_PARM1,
					fsaSaveCopyDataUtil.getFsaDeleteInputParam(fsaCriteriaParam), CommonConstants.INPUT_PARM2,
					fsaSaveCopyDataUtil.getDeleteVInParam(fsaCriteriaParam));
			LOGGER.info("inout param values: {}", sqlParameterSource);
			fscCriteriaResponseMap = simpleJdbcCall.execute(sqlParameterSource);
		} catch (Exception e) {
			LOGGER.error(CommonConstants.EXCEPTION_OCCURED, e);
		}

		return fscCriteriaResponseMap;
	}

	public Map<String, Object> deleteAllFsaInfo( DeleteFsaInfoReq deleteFsaInfoReq) {
		SimpleJdbcCall simpleJdbcCall = null;
		Map<String, Object> deleteAllFsaInfo = null;
		try {
			simpleJdbcCall = creatSimpleJdbcCall(CommonConstants.FSA_SCHEMA_NAME, CommonConstants.FSA_DELETE_CRITERIA);
			SqlParameterSource sqlParameterSource = createSqlParameterSource(CommonConstants.INPUT_PARM1,
					fsaSaveCopyDataUtil.deleteAllFSAInputParam(deleteFsaInfoReq), CommonConstants.INPUT_PARM2, "");
			LOGGER.info(" SQL Parm source for Delete ALL {}", sqlParameterSource);
			deleteAllFsaInfo = simpleJdbcCall.execute(sqlParameterSource);
		} catch (Exception e) {
			LOGGER.error(CommonConstants.EXCEPTION_OCCURED, e);
		}

		return deleteAllFsaInfo;

	}

	public Map<String, Object> checkBlocker(String deleteInputParam) {
		SimpleJdbcCall simpleJdbcCall = null;
		Map<String, Object> addDeletedataResp = null;
		try {
			simpleJdbcCall = creatSimpleJdbcCall(CommonConstants.FSA_SCHEMA_NAME, CommonConstants.FSA_DELETE_DATA);
			SqlParameterSource sqlParameterSource = createSqlParameterSource(CommonConstants.INPUT_PARM1,
					deleteInputParam);
			LOGGER.info(" SQL Parm source for Delete entry {}", sqlParameterSource);
			addDeletedataResp = simpleJdbcCall.execute(sqlParameterSource);
		} catch (Exception e) {
			LOGGER.error(CommonConstants.EXCEPTION_OCCURED, e);
		}
		return addDeletedataResp;
	}

	public List<SuppPopulationVo> getSupplementVo(String globalFsaNumber) {

		SqlParameterSource parameters = new MapSqlParameterSource().addValue("fsaNum", globalFsaNumber);
		StringBuilder sql = new StringBuilder();
		sql.append("SELECT DISTINCT  GCPA09_SUPPL_C, GCPA09_SUPP_DESC_X,GCPA07_FSA_STAT_C  FROM ");
		sql.append(ownerId);
		sql.append(" SGCPA09_FSA_SUPPL WHERE GCPA15_GLOBL_FSA_R = :fsaNum");
		sql.append(" ORDER BY GCPA09_SUPP_DESC_X  ");
		sql.append(uncommitRead);
		List<SuppPopulationVo> populationList = new ArrayList<>();

		namedParameterJdbcTemplate.query(sql.toString(), parameters, new RowMapper<Object>() {

			public Object mapRow(ResultSet resultSet, int i) throws SQLException {
				if (!("U".equalsIgnoreCase(resultSet.getString(3)))) {
					SuppPopulationVo suppPopulationVo = new SuppPopulationVo();
					suppPopulationVo.setSupCode(resultSet.getString(1));
					suppPopulationVo.setSupDesc(resultSet.getString(1) + "-" + resultSet.getString(2).trim());
					suppPopulationVo.setFsaStatus(resultSet.getString(3));
					populationList.add(suppPopulationVo);
				}
				return populationList;

			}
		});
		return populationList;
	}

	public List<Hubs> getHubCodes() {
		StringBuilder query = new StringBuilder();
		query.append("SELECT DISTINCT GCPE10_HUB_C, GCPE10_HUB_DESC_X FROM ").append(ownerId)
				.append(" SGCPE10_HUB ORDER BY GCPE10_HUB_DESC_X  ").append(uncommitRead);
		List<Hubs> hubsList = new ArrayList<>();
		jdbcTemplate.query(query.toString(), new Object[] {}, (rs, rowNum) -> hubsList
				.add(new Hubs(rs.getString("GCPE10_HUB_C").trim(), rs.getString("GCPE10_HUB_DESC_X").trim())));
		return hubsList;

	}

	public List<FSATypes> getFsaTypes() {
		StringBuilder query = new StringBuilder();
		query.append("SELECT GCPA11_FSA_TYPE_C, GCPA11_FSA_TYPE_X FROM ");
		query.append(ownerId);
		query.append(" SGCPA11_FSA_TYPE WHERE GCPA11_LCFSA_GEN_C <> ' ' AND GCPA11_TO_DATE_Y > CURRENT DATE ");
		query.append(uncommitRead);

		List<FSATypes> fsaTypes = new ArrayList<>();

		jdbcTemplate.query(query.toString(), new Object[] {}, (rs, rowNum) -> fsaTypes
				.add(new FSATypes(rs.getString("GCPA11_FSA_TYPE_C").trim(), rs.getString("GCPA11_FSA_TYPE_X").trim())));
		return fsaTypes;

	}

	public List<ExistingVinGrpList> checkVinExistence(String fsaNumber, List<String> vingrpCode) {
		Map<String, Object> valueByKey = new HashMap<>();
		valueByKey.put("fsaNumber", HtmlUtils.htmlEscape(fsaNumber));
		valueByKey.put("vingrpCode", vingrpCode);
		SqlParameterSource parameters = new MapSqlParameterSource(valueByKey);
		StringBuilder sql = new StringBuilder();
		sql.append("SELECT DISTINCT GCPD22_VINGP_LBL_C,GCPB18_VINGRP_X FROM ");
		sql.append(ownerId);
		sql.append("SGCPB18_VINGRPSEQ  WHERE GCPA15_GLOBL_FSA_R = :fsaNumber AND GCPD22_VINGP_LBL_C IN (:vingrpCode)");
		sql.append(" ORDER BY GCPD22_VINGP_LBL_C  ");
		sql.append(uncommitRead);

		log.info("sql query{}", sql.toString());
		return namedParameterJdbcTemplate.query(sql.toString(), parameters,
				(rs, rowNum) -> new ExistingVinGrpList(rs.getString("GCPD22_VINGP_LBL_C").trim(),
						rs.getString("GCPB18_VINGRP_X").trim()));

	}

	public Map<String, Object> getExtractTimeStamp(String parm1, String parm2) throws GCAMPException {
		try {
			SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate)
					.withSchemaName(CommonConstants.FSA_SCHEMA_NAME)
					.withProcedureName(CommonConstants.CONFIRM_DELETE_CHECK);
			return simpleJdbcCall.execute(new MapSqlParameterSource().addValue(CommonConstants.INPUT_PARM1, parm1)
					.addValue(CommonConstants.INPUT_PARM2, parm2));
		} catch (Exception e) {
			throw new GCAMPException(CommonConstants.DB_EXCEPTION, e);
		}
	}

}
