package com.ford.gcamp.targeting.gridgcamp.grid;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ford.gcamp.targeting.gridgcamp.grid.entity.PDCLookupData;
import com.ford.gcamp.targeting.gridgcamp.grid.entity.PDCLookupId;

@Repository
public interface PDCLookupRepository extends JpaRepository<PDCLookupData, PDCLookupId>{
	public List<PDCLookupData> findByReportIdAndCountryName(String reportId, String countryName);
}
