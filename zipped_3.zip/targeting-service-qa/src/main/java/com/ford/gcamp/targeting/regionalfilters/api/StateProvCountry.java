package com.ford.gcamp.targeting.regionalfilters.api;

import java.util.List;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class StateProvCountry {
	@NotNull
	@Size(min = 1, max = 3)
	@Pattern(regexp = "^[a-zA-Z\\*\\s\\d]*$")
	@Schema(example = "CAN", description = "CountryCode")
	private String countryCode;


	@Size(min = 0, max = 100)
	@Pattern(regexp = "^[a-zA-Z\\-\\s\\&\\(\\)\\.]*$")
	@Schema(example = "CANADA", description = "Country Description")
	private String label;

	@Size(min = 0, max = 350, message = "GeoCodes List")
	private List<@Valid GeoCode> children;

}
