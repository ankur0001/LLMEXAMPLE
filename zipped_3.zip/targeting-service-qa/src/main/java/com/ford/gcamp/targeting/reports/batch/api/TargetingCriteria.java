package com.ford.gcamp.targeting.reports.batch.api;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class TargetingCriteria extends GenericReportData {

    private String filterCode;
    private String filterValue;
 
}
