package com.ford.fcsdtech.util;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.NullAndEmptySource;
import org.junit.jupiter.params.provider.ValueSource;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Coverage for new FsaDateUtil (FCSDREC2-2338).
 * Paste to: src/test/java/com/ford/fcsdtech/util/FsaDateUtilTest.java
 */
class FsaDateUtilTest {

    @Test
    @DisplayName("formatDate: valid yyyy-MM-dd → dd-MMM-yyyy")
    void formatDate_valid() {
        assertThat(FsaDateUtil.formatDate("2021-10-25")).isEqualTo("25-Oct-2021");
    }

    @ParameterizedTest
    @NullAndEmptySource
    @ValueSource(strings = {" ", "0001-01-01", "0001-01-01"})
    @DisplayName("formatDate: null/empty/invalid sentinel → empty")
    void formatDate_blankOrSentinel(String input) {
        assertThat(FsaDateUtil.formatDate(input)).isEmpty();
    }

    @ParameterizedTest
    @CsvSource({
            "not-a-date",
            "2021/10/25",
            "25-10-2021",
            "2021-13-01"
    })
    @DisplayName("formatDate: unparseable → empty (catch ParseException)")
    void formatDate_unparseable(String input) {
        assertThat(FsaDateUtil.formatDate(input)).isEmpty();
    }
}
