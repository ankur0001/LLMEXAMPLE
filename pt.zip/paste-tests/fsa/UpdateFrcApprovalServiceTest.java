package com.ford.fcsdtech.service;

import com.ford.fcsdtech.entities.FsaTypeEntity;
import com.ford.fcsdtech.entities.GlobalFsaEntity;
import com.ford.fcsdtech.models.dto.LocalFSARequestDto;
import com.ford.fcsdtech.models.dto.UpdateFrcApprovalDto;
import com.ford.fcsdtech.repo.*;
import com.ford.fcsdtech.util.ProNotificationUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.util.ReflectionTestUtils;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

/**
 * Coverage for FRC approval update path in LocalFsaService (FCSDREC2-2338).
 * Paste to: src/test/java/com/ford/fcsdtech/service/UpdateFrcApprovalServiceTest.java
 *
 * Requires production methods: updateFrcApprovalData, updateFrcApprovalDataIfNeeded,
 * sendEmailOnVernUpdate, getEmailSubject (and createLocalFsas calling IfNeeded).
 */
class UpdateFrcApprovalServiceTest {

    @Mock private LocalFsaRepo localFsaRepo;
    @Mock private GlobalFsaRepo globalFsaRepo;
    @Mock private DependentFsaService dependentFsaService;
    @Mock private GoasisSuppRepository goasisSuppRepository;
    @Mock private TransTextRepository transTextRepository;
    @Mock private LanguageGoasisRepo languageGoasisRepo;
    @Mock private GridVinRptRepo gridVinRptRepo;
    @Mock private RetentionRuleRepo retentionRuleRepo;
    @Mock private AuditRepository auditRepository;
    @Mock private ApprovalQueueRepository approvalQueueRepository;
    @Mock private GlobalFsaCountryRepo globalFsaCountryRepo;
    @Mock private FsaHubStatusRepository fsaHubStatusRepository;
    @Mock private ProNotificationUtil proNotificationUtil;
    @Mock private LdapService ldapService;
    @Mock private LangGoasisRepository langGoasisRepository;
    @Mock private SysSequenceRepository sysSequenceRepository;
    @Mock private FsaSupplementRepo fsaSupplementRepo;
    @Mock private FsaTypeRepo fsaTypeRepo;
    @Mock private ProNotificationSender proNotificationSender;

    @InjectMocks
    private LocalFsaService service;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        ReflectionTestUtils.setField(service, "activeProfile", "dev");
        ReflectionTestUtils.setField(service, "emailSubject", "TEST SUBJECT");
    }

    @Test
    @DisplayName("updateFrcApprovalData: multi-char fsaType uses findFirstByFsaTypeCode and saves")
    void updateFrcApprovalData_byFsaTypeCode_savesAndEmails() {
        GlobalFsaEntity fsa = new GlobalFsaEntity();
        fsa.setGlobalFsaNumber(12345);
        fsa.setFsaCartId("gcamp1");
        fsa.setUpdateId("owner1");

        FsaTypeEntity type = new FsaTypeEntity();
        type.setFsaTypeCode("SI");
        type.setFsaTypeDescription("OPTIONAL PRODUCT IMPRVMNT PGM");

        when(globalFsaRepo.findById(12345)).thenReturn(Optional.of(fsa));
        when(fsaTypeRepo.findFirstByFsaTypeCode("SI")).thenReturn(type);
        when(globalFsaRepo.save(any(GlobalFsaEntity.class))).thenReturn(fsa);

        UpdateFrcApprovalDto dto = UpdateFrcApprovalDto.builder()
                .globalFsaNumber(12345)
                .fsaTitle("Brake Air Bag")
                .fsaType("SI")
                .frcDecisionDate("2021-10-25")
                .updateId("approver")
                .build();

        service.updateFrcApprovalData(dto);

        verify(fsaTypeRepo).findFirstByFsaTypeCode("SI");
        verify(fsaTypeRepo, never()).findFirstByLocalFsaGenerationCode(anyString());
        verify(globalFsaRepo).save(argThat(e ->
                "SI".equals(e.getFsaType())
                        && "Brake Air Bag".equals(e.getGlobalFsa())
                        && LocalDate.of(2021, 10, 25).equals(e.getFrcDecisionDate())));

        ArgumentCaptor<List<String>> toCaptor = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<List<String>> ccCaptor = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<Map<String, String>> valuesCaptor = ArgumentCaptor.forClass(Map.class);
        verify(proNotificationSender).sendProNotificationEmail(
                toCaptor.capture(), ccCaptor.capture(),
                eq(ProNotificationUtil.EMAIL_TEMPLATE_NAME), valuesCaptor.capture());

        assertThat(toCaptor.getValue()).contains("gcamp1@ford.com", "owner1@ford.com");
        assertThat(ccCaptor.getValue()).contains("approver@ford.com");
        assertThat(valuesCaptor.getValue().get("emailSubject")).startsWith("TEST DEV:");
    }

    @Test
    @DisplayName("updateFrcApprovalData: single-char fsaType uses findFirstByLocalFsaGenerationCode")
    void updateFrcApprovalData_byGenerationCode() {
        GlobalFsaEntity fsa = new GlobalFsaEntity();
        fsa.setGlobalFsaNumber(99);
        fsa.setFsaCartId("cart");

        FsaTypeEntity type = new FsaTypeEntity();
        type.setFsaTypeCode("SC");
        type.setFsaTypeDescription("SAFETY COMPLIANCE");

        when(globalFsaRepo.findById(99)).thenReturn(Optional.of(fsa));
        when(fsaTypeRepo.findFirstByLocalFsaGenerationCode("C")).thenReturn(type);

        service.updateFrcApprovalData(UpdateFrcApprovalDto.builder()
                .globalFsaNumber(99)
                .fsaTitle("Title")
                .fsaType("C")
                .frcDecisionDate("2022-01-15")
                .updateId("u1")
                .build());

        verify(fsaTypeRepo).findFirstByLocalFsaGenerationCode("C");
        verify(globalFsaRepo).save(any(GlobalFsaEntity.class));
    }

    @Test
    @DisplayName("updateFrcApprovalData: FSA missing → no save, no email")
    void updateFrcApprovalData_fsaMissing_noOp() {
        when(globalFsaRepo.findById(1)).thenReturn(Optional.empty());
        when(fsaTypeRepo.findFirstByFsaTypeCode(anyString())).thenReturn(new FsaTypeEntity());

        service.updateFrcApprovalData(UpdateFrcApprovalDto.builder()
                .globalFsaNumber(1)
                .fsaTitle("T")
                .fsaType("SI")
                .frcDecisionDate("2021-10-25")
                .updateId("u")
                .build());

        verify(globalFsaRepo, never()).save(any());
        verify(proNotificationSender, never()).sendProNotificationEmail(anyList(), anyList(), anyString(), anyMap());
    }

    @Test
    @DisplayName("updateFrcApprovalData: type null → no save, no email (phase-2 gated)")
    void updateFrcApprovalData_typeNull_noEmail() {
        GlobalFsaEntity fsa = new GlobalFsaEntity();
        fsa.setGlobalFsaNumber(5);
        fsa.setUpdateId("owner");
        when(globalFsaRepo.findById(5)).thenReturn(Optional.of(fsa));
        when(fsaTypeRepo.findFirstByFsaTypeCode("SI")).thenReturn(null);

        service.updateFrcApprovalData(UpdateFrcApprovalDto.builder()
                .globalFsaNumber(5)
                .fsaTitle("T")
                .fsaType("SI")
                .frcDecisionDate("2021-10-25")
                .updateId("owner")
                .build());

        verify(globalFsaRepo, never()).save(any());
        verify(proNotificationSender, never()).sendProNotificationEmail(anyList(), anyList(), anyString(), anyMap());
    }

    @Test
    @DisplayName("sendEmailOnVernUpdate: no TO recipients → skip send")
    void sendEmail_noToRecipients() {
        GlobalFsaEntity fsa = new GlobalFsaEntity();
        fsa.setGlobalFsaNumber(7);
        // no cart / updateId
        when(globalFsaRepo.findById(7)).thenReturn(Optional.of(fsa));
        when(fsaTypeRepo.findFirstByLocalFsaGenerationCode("C")).thenReturn(new FsaTypeEntity());

        service.updateFrcApprovalData(UpdateFrcApprovalDto.builder()
                .globalFsaNumber(7)
                .fsaTitle("T")
                .fsaType("C")
                .frcDecisionDate("2021-10-25")
                .updateId("onlyCc")
                .build());

        verify(proNotificationSender, never()).sendProNotificationEmail(anyList(), anyList(), anyString(), anyMap());
    }

    @Test
    @DisplayName("sendEmailOnVernUpdate: sender throws → swallowed")
    void sendEmail_senderThrows_swallowed() {
        GlobalFsaEntity fsa = new GlobalFsaEntity();
        fsa.setGlobalFsaNumber(8);
        fsa.setFsaCartId("cart");
        FsaTypeEntity type = new FsaTypeEntity();
        type.setFsaTypeCode("SI");
        type.setFsaTypeDescription("desc");
        when(globalFsaRepo.findById(8)).thenReturn(Optional.of(fsa));
        when(fsaTypeRepo.findFirstByFsaTypeCode("SI")).thenReturn(type);
        doThrow(new RuntimeException("mail down"))
                .when(proNotificationSender)
                .sendProNotificationEmail(anyList(), anyList(), anyString(), anyMap());

        service.updateFrcApprovalData(UpdateFrcApprovalDto.builder()
                .globalFsaNumber(8)
                .fsaTitle("T")
                .fsaType("SI")
                .frcDecisionDate("2021-10-25")
                .updateId("u")
                .build());

        verify(proNotificationSender).sendProNotificationEmail(anyList(), anyList(), anyString(), anyMap());
    }

    @ParameterizedTest
    @CsvSource({
            "dev,TEST DEV:",
            "qa,TEST QA:",
            "prod,"
    })
    @DisplayName("getEmailSubject: profile prefixes")
    void getEmailSubject_byProfile(String profile, String prefix) {
        ReflectionTestUtils.setField(service, "activeProfile", profile);
        String result = ReflectionTestUtils.invokeMethod(service, "getEmailSubject", "Hello");
        if (prefix.isEmpty()) {
            assertThat(result).isEqualTo("Hello");
        } else {
            assertThat(result).isEqualTo(prefix + "Hello");
        }
    }

    @Test
    @DisplayName("updateFrcApprovalDataIfNeeded: flag false → no update")
    void ifNeeded_flagFalse() {
        LocalFSARequestDto req = LocalFSARequestDto.builder()
                .globalFsaNumber("123")
                .updateGlobalFrcApproval(false)
                .build();
        ReflectionTestUtils.invokeMethod(service, "updateFrcApprovalDataIfNeeded", req);
        verifyNoInteractions(fsaTypeRepo);
        verify(globalFsaRepo, never()).findById(anyInt());
    }

    @Test
    @DisplayName("updateFrcApprovalDataIfNeeded: flag true → maps fields and updates")
    void ifNeeded_flagTrue() {
        GlobalFsaEntity fsa = new GlobalFsaEntity();
        fsa.setGlobalFsaNumber(123);
        fsa.setFsaCartId("c1");
        FsaTypeEntity type = new FsaTypeEntity();
        type.setFsaTypeCode("SI");
        type.setFsaTypeDescription("d");
        when(globalFsaRepo.findById(123)).thenReturn(Optional.of(fsa));
        when(fsaTypeRepo.findFirstByFsaTypeCode("SI")).thenReturn(type);

        LocalFSARequestDto req = LocalFSARequestDto.builder()
                .globalFsaNumber("123")
                .localFsaDesc("LFSA Title")
                .fsaType("SI")
                .frcDecisionDate("2023-05-01")
                .cdsld("cds1")
                .updateGlobalFrcApproval(true)
                .build();

        ReflectionTestUtils.invokeMethod(service, "updateFrcApprovalDataIfNeeded", req);

        verify(globalFsaRepo).save(argThat(e -> "LFSA Title".equals(e.getGlobalFsa())));
        verify(proNotificationSender).sendProNotificationEmail(anyList(), anyList(), anyString(), anyMap());
    }
}
