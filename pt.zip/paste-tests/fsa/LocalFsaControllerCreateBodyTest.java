package com.ford.fcsdtech.controllers;

import com.ford.fcsdtech.configuration.PropertiesConfig;
import com.ford.fcsdtech.entities.LocalEntity;
import com.ford.fcsdtech.entities.LocalFsaEntityId;
import com.ford.fcsdtech.models.dto.LocalFSARequestDto;
import com.ford.fcsdtech.models.request.LocalFSARequest;
import com.ford.fcsdtech.service.FsaDetailsService;
import com.ford.fcsdtech.service.GovernmentService;
import com.ford.fcsdtech.service.LocalFsaService;
import com.ford.fcsdtech.translator.DtoMapper;
import com.google.gson.Gson;
import com.google.json.JsonSanitizer;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.ResponseEntity;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

/**
 * Extra coverage for createLocalFsa returning LocalEntity body (FCSDREC2-2338).
 * Paste to: src/test/java/com/ford/fcsdtech/controllers/LocalFsaControllerCreateBodyTest.java
 */
@ExtendWith(MockitoExtension.class)
class LocalFsaControllerCreateBodyTest {

    @Mock private LocalFsaService localFsaService;
    @Mock private Gson gson;
    @Mock private DtoMapper mapper;
    @Mock private PropertiesConfig properties;
    @Mock private GovernmentService governmentService;
    @Mock private FsaDetailsService fsaDetailsService;

    @InjectMocks
    private LocalFsaController localFsaController;

    private LocalEntity sampleEntity() {
        LocalEntity entity = new LocalEntity();
        entity.setId(new LocalFsaEntityId(12345, "26S01", "NA"));
        return entity;
    }

    @BeforeEach
    void setUp() {
        // PropertiesConfig field may be named `properties` on controller
    }

    @Test
    @DisplayName("createLocalFsa: flag true → 201 with LocalEntity body")
    void createLocalFsa_returnsBody() {
        LocalFSARequest req = new LocalFSARequest();
        String json = "{}";
        LocalFSARequestDto dto = LocalFSARequestDto.builder().globalFsaNumber("12345").hub("NA").build();
        LocalEntity created = sampleEntity();

        when(properties.isSaveLfsaFlag()).thenReturn(true);
        when(gson.toJson(any(LocalFSARequest.class))).thenReturn(json);
        when(gson.fromJson(anyString(), eq(LocalFSARequest.class))).thenReturn(req);
        when(mapper.convertToLocalFSARequestDto(any(LocalFSARequest.class))).thenReturn(dto);
        when(localFsaService.createLocalFsas(dto)).thenReturn(created);

        try (MockedStatic<JsonSanitizer> mock = mockStatic(JsonSanitizer.class)) {
            mock.when(() -> JsonSanitizer.sanitize(json)).thenReturn(json);

            ResponseEntity<LocalEntity> response = localFsaController.createLocalFsa(req);

            assertThat(response.getStatusCode().value()).isEqualTo(201);
            assertThat(response.getBody()).isNotNull();
            assertThat(response.getBody().getId().getLocalFsaNumber()).isEqualTo("26S01");
            verify(localFsaService).createLocalFsas(dto);
        }
    }

    @Test
    @DisplayName("createLocalFsa: flag false → 404 empty body, service never called")
    void createLocalFsa_flagOff() {
        when(properties.isSaveLfsaFlag()).thenReturn(false);

        ResponseEntity<LocalEntity> response = localFsaController.createLocalFsa(new LocalFSARequest());

        assertThat(response.getStatusCode().value()).isEqualTo(404);
        assertThat(response.getBody()).isNull();
        verify(localFsaService, never()).createLocalFsas(any());
    }
}
