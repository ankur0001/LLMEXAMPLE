# Phase 2 — Sonar / review fixes (included in this zip)

Apply files under `phase2-fixes/` **after** pasting Phase-1 tests. See `phase2-fixes/APPLY.md`.

## Ready-to-replace source files

### FSA
| File | Action |
|------|--------|
| `phase2-fixes/fsa/FsaDateUtil.java` | Replace main `FsaDateUtil.java` (DateTimeFormatter) |
| `phase2-fixes/fsa/LocalFSARequestDto_FRC_FIELDS_SNIPPET.java` | Rename boolean field for Lombok |

### Vern
| File | Action |
|------|--------|
| `phase2-fixes/vern/CreateVernUtil.java` | Replace main util (`isBlank` + `fillWithZeros` + `addSpaceToProc`) |
| `phase2-fixes/vern/GridFrcApprovalData.java` | Replace DTO (`ignoreUnknown = true`) |

## Manual patches (APPLY.md)
- Controller 404 comment
- Gate FRC email on successful save
- Remove `throws` from VernController endpoint
- Optional `subscribeOn(boundedElastic())`
- Keep `commonGolnputParam` JSON key (wire compat)
- Do not merge local `permitAll` security hacks

Phase-1 tests already assume phase-2 boolean naming (`updateGlobalFrcApproval`) and gated email behavior.
