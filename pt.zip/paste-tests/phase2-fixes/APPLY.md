/*
 * PHASE-2 PATCHES — apply manually in IntelliJ (search → replace).
 * File path is relative to each service root.
 */

/* ========== FSA: LocalFsaController.java ==========
 * Find BOTH create endpoints' disabled branch comments:

     return ResponseEntity.status(404).build(); //Service Unavailable

 * Replace with:

     return ResponseEntity.status(404).build(); // Feature flag disabled
 */


/* ========== FSA: LocalFSARequestDto.java (+ LocalFSARequest.java) ==========
 * Rename field for Lombok clarity (JSON stays the same):

     @JsonProperty("isUpdateGlobalFrcApproval")
     private boolean updateGlobalFrcApproval;

     @JsonProperty("frcDecisionDate")
     private String frcDecisionDate;

 * Call sites:
     localFSARequest.isUpdateGlobalFrcApproval()
     .updateGlobalFrcApproval(true)
 */


/* ========== FSA: LocalFsaService.updateFrcApprovalData ==========
 * Gate email on successful update (optional business fix).
 * Replace the try/finally so email only runs when save happened:

    public void updateFrcApprovalData(UpdateFrcApprovalDto updateFrcApprovalDto) {
        Optional<GlobalFsaEntity> fsaData = globalFsaRepo.findById(updateFrcApprovalDto.getGlobalFsaNumber());
        String fsaType = StringUtils.trimToEmpty(updateFrcApprovalDto.getFsaType());
        FsaTypeEntity fsaTypeResponse = fsaType.length() > 1
                ? fsaTypeRepo.findFirstByFsaTypeCode(fsaType)
                : fsaTypeRepo.findFirstByLocalFsaGenerationCode(fsaType);

        boolean updated = false;
        if (fsaData.isPresent() && fsaTypeResponse != null) {
            fsaData.get().setFsaType(fsaTypeResponse.getFsaTypeCode());
            fsaData.get().setGlobalFsa(updateFrcApprovalDto.getFsaTitle());
            fsaData.get().setFrcDecisionDate(LocalDate.parse(updateFrcApprovalDto.getFrcDecisionDate()));
            globalFsaRepo.save(fsaData.get());
            updated = true;
        }
        if (updated) {
            String subject = getEmailSubject("FSA Title, FSA Type and FRC Decision Date received from GRID for FSA "
                    + updateFrcApprovalDto.getGlobalFsaNumber());
            StringBuilder body = new StringBuilder();
            body.append("The following details received from GRID and updated in GCAMP for FSA ")
                    .append(updateFrcApprovalDto.getGlobalFsaNumber()).append(":\n\n").append("FSA Title: ")
                    .append(updateFrcApprovalDto.getFsaTitle()).append("\n").append("FSA Type: ")
                    .append(fsaTypeResponse.getFsaTypeDescription())
                    .append("\n").append("FRC Decision Date: ")
                    .append(FsaDateUtil.formatDate(String.valueOf(updateFrcApprovalDto.getFrcDecisionDate()))).append("\n\n\n")
                    .append(AUTOMATIC_EMAIL_TEXT);
            sendEmailOnVernUpdate(updateFrcApprovalDto, subject, body.toString());
        }
    }

 * NOTE: if you apply this, remove/adjust UpdateFrcApprovalServiceTest
 *       updateFrcApprovalData_typeNull_stillEmails (expect no email).
 */


/* ========== VERN: VernController.saveFrcApprovalData ==========
 * Remove throws from method signature:

     public ResponseEntity<FrcApprovalResponse> saveFrcApprovalData(
             @RequestBody @Valid GridFrcApprovalData gridFrcApprovalData) {
         FrcApprovalResponse response = createVernService.saveGridFrcApprovalData(gridFrcApprovalData);
         return ResponseEntity.ok(response);
     }
 */


/* ========== VERN: CreateVernHelper.invokeCreateLocalFsaForAllHub ==========
 * Optional Sonar/reactive hygiene — after bodyToMono(Void.class) add:

     .subscribeOn(reactor.core.scheduler.Schedulers.boundedElastic())
     .subscribe();
 */


/* ========== VERN: commonGolnputParam ==========
 * KEEP the JSON property name "commonGolnputParam" for FSA wire compatibility.
 * Add a short comment only:

     // JSON key kept as commonGolnputParam for FSA contract compatibility
     @JsonProperty("commonGolnputParam")
     private String commonGolnputParam;
 */


/* ========== VERN: WebSecurityConfiguration ==========
 * Do NOT merge anyRequest().permitAll() / commented oauth2ResourceServer.
 * Keep only the intentional matcher changes from the PR for main.
 */
