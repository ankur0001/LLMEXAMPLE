package com.ford.fcsdtech.util;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Locale;

/**
 * Phase-2 Sonar fix: DateTimeFormatter instead of SimpleDateFormat (thread-safe).
 * Replace: src/main/java/com/ford/fcsdtech/util/FsaDateUtil.java
 */
@Slf4j
public final class FsaDateUtil {

    private static final String INVALID_DATE = "0001-01-01";
    private static final DateTimeFormatter INPUT_FORMAT =
            DateTimeFormatter.ofPattern("yyyy-MM-dd");
    private static final DateTimeFormatter OUTPUT_FORMAT =
            DateTimeFormatter.ofPattern("dd-MMM-yyyy", Locale.ENGLISH);

    private FsaDateUtil() {
        // utility
    }

    public static String formatDate(String date) {
        if (StringUtils.isEmpty(date) || INVALID_DATE.equalsIgnoreCase(date)) {
            return StringUtils.EMPTY;
        }
        try {
            LocalDate parsed = LocalDate.parse(date, INPUT_FORMAT);
            return OUTPUT_FORMAT.format(parsed);
        } catch (DateTimeParseException e) {
            log.error("error while parsing date", e);
            return StringUtils.EMPTY;
        }
    }
}
