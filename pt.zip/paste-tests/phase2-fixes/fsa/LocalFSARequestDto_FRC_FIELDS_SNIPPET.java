/*
 * PHASE-2 SNIPPET — LocalFSARequestDto
 * File: src/main/java/com/ford/fcsdtech/models/dto/LocalFSARequestDto.java
 *
 * ADD these fields after isTranslationModified (do NOT name the field isUpdateGlobalFrcApproval):
 */

/*
    @JsonProperty("isUpdateGlobalFrcApproval")
    private boolean updateGlobalFrcApproval;

    @JsonProperty("frcDecisionDate")
    private String frcDecisionDate;
*/

/*
 * Also on LocalFSARequest (request model), prefer:
 *   private boolean updateGlobalFrcApproval;
 * with @JsonProperty("isUpdateGlobalFrcApproval") / @JsonProperty("updateGlobalFrcApproval")
 * matching the JSON contract.
 *
 * Then in LocalFsaService.updateFrcApprovalDataIfNeeded use:
 *   if (localFSARequest.isUpdateGlobalFrcApproval()) { ... }
 *
 * Builder: .updateGlobalFrcApproval(true)
 */
