package com.ford.fcsdtech.util;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

/**
 * Phase-2 Sonar fix: fillWithZeros uses StringUtils.isBlank.
 * Replace entire file: src/main/java/com/ford/fcsdtech/util/CreateVernUtil.java
 * (includes existing prettyPrintJSON + new PR methods)
 */
@Slf4j
@Component
public class CreateVernUtil {

    private CreateVernUtil() {
        // private constructor to prevent instantiation
    }

    public static <T> String prettyPrintJSON(T object) {
        ObjectMapper objectMapper = new ObjectMapper();
        try {
            return objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(object);
        } catch (Exception e) {
            log.error("Java Object to JSON Parsing Exception: ", e);
        }
        return StringUtils.EMPTY;
    }

    /**
     * Left-pads with zeros up to totalLength.
     */
    public static String fillWithZeros(String fsaInput, int totalLength) {
        StringBuilder builder = new StringBuilder();
        if (StringUtils.isBlank(fsaInput)) {
            fsaInput = "";
        }
        String trimmed = fsaInput.trim();
        int length = trimmed.length();
        if (length <= totalLength) {
            int remainingLength = totalLength - length;
            builder.append("0".repeat(remainingLength));
        }
        builder.append(trimmed);
        return builder.toString();
    }

    public static String addSpaceToProc(int length) {
        if (length <= 0) {
            return StringUtils.EMPTY;
        }
        return " ".repeat(length);
    }
}
