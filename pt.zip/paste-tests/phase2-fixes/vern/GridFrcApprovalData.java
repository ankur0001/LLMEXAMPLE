package com.ford.fcsdtech.models.request;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.*;
import lombok.Getter;
import lombok.Setter;
import org.springframework.validation.annotation.Validated;

/**
 * Phase-2 Sonar fix: @JsonIgnoreProperties(ignoreUnknown = true).
 * Replace: src/main/java/com/ford/fcsdtech/models/request/GridFrcApprovalData.java
 */
@Setter
@Getter
@Validated
@JsonIgnoreProperties(ignoreUnknown = true)
public class GridFrcApprovalData {

    @NotNull
    @NotBlank(message = "FSA Title is mandatory")
    @Schema(example = "FSA Brake Air Bag 2020, Launch")
    @Size(min = 1, max = 254, message = "length 1-254")
    @Pattern(regexp = "^[a-zA-Z\\d .\\-_,]*$", message = "FSA Title")
    private String fsaTitle;

    @NotNull
    @NotBlank(message = "FRC Approval Date is mandatory")
    @Schema(example = "2021-10-25")
    @Size(min = 10, max = 10, message = "length 1-10")
    @Pattern(regexp = "^[0-9]{4}-[0-9]{2}-[0-9]{2}$",
            message = "FRC Approval Date must be in yyyy-MM-dd format")
    private String frcApprovalDate;

    @Schema(description = "supplementId")
    @Size(min = 1, max = 2, message = "length 1-2")
    @Pattern(regexp = "^[A-Za-z\\d]*$", message = "Supplement Code")
    private String supplementId;

    @NotNull
    @NotBlank(message = "FSA Type is mandatory")
    @Schema(example = "C")
    @Size(min = 1, max = 1, message = "length 1")
    @Pattern(regexp = "^[A-Za-z\\d]*$", message = "FSA Type  is mandatory")
    private String fsaType;

    @Schema(description = "updateId")
    @Size(min = 0, max = 8, message = "Max length 8")
    @Pattern(regexp = "^[A-Za-z\\d]*$", message = "Update CDSId")
    private String approvedBy;

    @Schema(description = "globalFSANumber")
    @NotNull(message = "globalFSANumber is mandatory")
    @Min(1)
    @Max(99999999)
    private Integer globalFSANumber;

    @Schema(example = "NA")
    @Size(max = 2, message = "length 2")
    @Pattern(regexp = "^[A-Za-z]*$", message = "Initiating hub code invalid")
    private String initiatingHub;
}
