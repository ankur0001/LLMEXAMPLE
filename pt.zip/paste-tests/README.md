# Paste-ready Sonar coverage tests for FCSDREC2-2338

## FSA service (`fcsd-recall-fsa-service`) — PR #651
Copy files from `fsa/` into matching packages under `src/test/java/...`

| File | Covers |
|------|--------|
| `FsaDateUtilTest.java` | new `FsaDateUtil.formatDate` |
| `UpdateFrcApprovalServiceTest.java` | `updateFrcApprovalData`, `IfNeeded`, email, subject prefixes |
| `LocalFsaControllerCreateBodyTest.java` | controller returns `LocalEntity` body |

## Vern service (`fcsd-recall-vern-service`) — PR #335
Copy files from `vern/` into matching packages under `src/test/java/...`

| File | Covers |
|------|--------|
| `VernControllerFrcApprovalTest.java` | `PUT /gridverninfo/frcapproval` |
| `SaveGridFrcApprovalDataTest.java` | `CreateVernService.saveGridFrcApprovalData` |
| `CreateLocalFsaWebClientHelperTest.java` | sync/async LFSA WebClient helpers |
| `LocalFsaCreateResponseTest.java` | nested id + `getLocalFsaNumber()` |
| `CreateVernUtilFillWithZerosTest.java` | new `fillWithZeros` |

## How to run
```bash
# FSA
./gradlew test --tests com.ford.fcsdtech.util.FsaDateUtilTest
./gradlew test --tests com.ford.fcsdtech.service.UpdateFrcApprovalServiceTest
./gradlew test --tests com.ford.fcsdtech.controllers.LocalFsaControllerCreateBodyTest

# Vern
./gradlew test --tests com.ford.fcsdtech.controller.VernControllerFrcApprovalTest
./gradlew test --tests com.ford.fcsdtech.service.SaveGridFrcApprovalDataTest
./gradlew test --tests com.ford.fcsdtech.service.CreateLocalFsaWebClientHelperTest
./gradlew test --tests com.ford.fcsdtech.models.response.LocalFsaCreateResponseTest
./gradlew test --tests com.ford.fcsdtech.util.CreateVernUtilFillWithZerosTest
```

## Phase 2 Sonar fixes
See `PHASE2_SONAR.md` and folder `phase2-fixes/` (full replace files + `APPLY.md` patches).
Apply Phase 2 source fixes together with the tests above.
