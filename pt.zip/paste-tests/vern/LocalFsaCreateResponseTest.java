package com.ford.fcsdtech.models.response;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Coverage for LocalFsaCreateResponse helpers (FCSDREC2-2338).
 * Paste to: src/test/java/com/ford/fcsdtech/models/response/LocalFsaCreateResponseTest.java
 */
class LocalFsaCreateResponseTest {

    @Test
    @DisplayName("getLocalFsaNumber: from nested id")
    void getLocalFsaNumber_fromId() {
        LocalFsaCreateResponse response = LocalFsaCreateResponse.builder()
                .id(new LocalFsaCreateResponse.LocalFsaIdResponse(123, "26S01", "NA"))
                .fsaType("SI")
                .build();

        assertThat(response.getLocalFsaNumber()).isEqualTo("26S01");
    }

    @Test
    @DisplayName("getLocalFsaNumber: null id → null")
    void getLocalFsaNumber_nullId() {
        LocalFsaCreateResponse response = LocalFsaCreateResponse.builder().id(null).build();
        assertThat(response.getLocalFsaNumber()).isNull();
    }
}
