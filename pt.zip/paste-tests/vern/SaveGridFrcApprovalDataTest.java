package com.ford.fcsdtech.service;

import com.ford.fcsdtech.entities.GridEntityId;
import com.ford.fcsdtech.entities.GridVernEntity;
import com.ford.fcsdtech.exception.GlobalExceptionHandler;
import com.ford.fcsdtech.models.request.GridFrcApprovalData;
import com.ford.fcsdtech.models.response.FrcApprovalResponse;
import com.ford.fcsdtech.models.response.LocalFsaCreateResponse;
import com.ford.fcsdtech.repo.GridVernRepo;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import java.time.LocalDate;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

/**
 * Coverage for CreateVernService.saveGridFrcApprovalData (FCSDREC2-2338).
 * Paste to: src/test/java/com/ford/fcsdtech/service/SaveGridFrcApprovalDataTest.java
 */
@ExtendWith(MockitoExtension.class)
class SaveGridFrcApprovalDataTest {

    @Mock
    private GridVernRepo gridVernRepo;

    @Mock
    private CreateVernHelper createVernHelper;

    @InjectMocks
    private CreateVernService createVernService;

    private GridVernEntity baseVern() {
        GridVernEntity entity = new GridVernEntity();
        entity.setGridVernId(new GridEntityId(2024, 1, 1, 1, "00"));
        entity.setGlobalFSANumber(21345);
        entity.setInitiatingHub("NA");
        entity.setInitiatingHubDesc("North America");
        entity.setFsaTitle("Old Title");
        return entity;
    }

    private GridFrcApprovalData baseRequest() {
        GridFrcApprovalData data = new GridFrcApprovalData();
        data.setGlobalFSANumber(21345);
        data.setSupplementId("0"); // fillWithZeros → "00"
        data.setFsaTitle("Brake Air Bag");
        data.setFrcApprovalDate("2021-10-25");
        data.setFsaType("C");
        data.setApprovedBy("approver");
        data.setInitiatingHub("NA");
        return data;
    }

    @BeforeEach
    void setUp() {
        // no-op; MockitoExtension handles mocks
    }

    @Test
    @DisplayName("happy path: saves vern, creates LFSA, returns localFsaNumber")
    void saveGridFrcApprovalData_happyPath() {
        GridVernEntity vern = baseVern();
        when(gridVernRepo.getAssignedGridVernInfoBySupplement(21345, "00")).thenReturn(vern);
        when(gridVernRepo.save(any(GridVernEntity.class))).thenAnswer(inv -> inv.getArgument(0));

        LocalFsaCreateResponse lfsa = LocalFsaCreateResponse.builder()
                .id(new LocalFsaCreateResponse.LocalFsaIdResponse(21345, "26S01", "NA"))
                .build();
        when(createVernHelper.createLocalFsaForAllHub(any(), eq("NA"), anyString(), eq("approver")))
                .thenReturn(lfsa);

        FrcApprovalResponse response = createVernService.saveGridFrcApprovalData(baseRequest());

        assertThat(response.getGlobalFsaNumber()).isEqualTo(21345);
        assertThat(response.getSupplementId()).isEqualTo("00");
        assertThat(response.getLocalFsaNumber()).isEqualTo("26S01");
        assertThat(response.getInitiatingHub()).isEqualTo("NA");
        assertThat(response.getFrcApprovalDate()).isEqualTo("2021-10-25");
        assertThat(response.getMessage()).contains("FRC approval");

        verify(gridVernRepo).save(argThat(e ->
                "Brake Air Bag".equals(e.getFsaTitle())
                        && LocalDate.of(2021, 10, 25).equals(e.getFrcApprovalDate())
                        && "Y".equals(e.getFrcApprovedFlag())
                        && "approver".equals(e.getUpdateId())));
        verify(createVernHelper).createLocalFsaForAllHub(any(GridVernEntity.class), eq("NA"), anyString(), eq("approver"));
    }

    @Test
    @DisplayName("vern missing → VernNotFoundException")
    void saveGridFrcApprovalData_notFound() {
        when(gridVernRepo.getAssignedGridVernInfoBySupplement(anyInt(), anyString())).thenReturn(null);

        assertThrows(GlobalExceptionHandler.VernNotFoundException.class,
                () -> createVernService.saveGridFrcApprovalData(baseRequest()));

        verify(createVernHelper, never()).createLocalFsaForAllHub(any(), anyString(), anyString(), anyString());
    }

    @Test
    @DisplayName("invalid frcApprovalDate → ClientInputException")
    void saveGridFrcApprovalData_badDate() {
        when(gridVernRepo.getAssignedGridVernInfoBySupplement(21345, "00")).thenReturn(baseVern());
        GridFrcApprovalData req = baseRequest();
        req.setFrcApprovalDate("25-10-2021");

        assertThrows(GlobalExceptionHandler.ClientInputException.class,
                () -> createVernService.saveGridFrcApprovalData(req));
    }

    @Test
    @DisplayName("blank initiatingHub on request → uses entity hub")
    void saveGridFrcApprovalData_hubFromEntity() {
        GridVernEntity vern = baseVern();
        vern.setInitiatingHub("EU");
        when(gridVernRepo.getAssignedGridVernInfoBySupplement(21345, "00")).thenReturn(vern);
        when(gridVernRepo.save(any())).thenAnswer(inv -> inv.getArgument(0));

        LocalFsaCreateResponse lfsa = LocalFsaCreateResponse.builder()
                .id(new LocalFsaCreateResponse.LocalFsaIdResponse(21345, "26E01", "EU"))
                .build();
        when(createVernHelper.createLocalFsaForAllHub(any(), eq("EU"), anyString(), anyString()))
                .thenReturn(lfsa);

        GridFrcApprovalData req = baseRequest();
        req.setInitiatingHub(null);

        FrcApprovalResponse response = createVernService.saveGridFrcApprovalData(req);

        assertThat(response.getInitiatingHub()).isEqualTo("EU");
        verify(createVernHelper).createLocalFsaForAllHub(any(), eq("EU"), anyString(), eq("approver"));
    }

    @Test
    @DisplayName("lfsaResponse null → localFsaNumber null in response")
    void saveGridFrcApprovalData_nullLfsaResponse() {
        when(gridVernRepo.getAssignedGridVernInfoBySupplement(21345, "00")).thenReturn(baseVern());
        when(gridVernRepo.save(any())).thenAnswer(inv -> inv.getArgument(0));
        when(createVernHelper.createLocalFsaForAllHub(any(), anyString(), anyString(), anyString()))
                .thenReturn(null);

        FrcApprovalResponse response = createVernService.saveGridFrcApprovalData(baseRequest());

        assertThat(response.getLocalFsaNumber()).isNull();
    }
}
