package com.ford.fcsdtech.util;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.NullAndEmptySource;
import org.junit.jupiter.params.provider.ValueSource;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Coverage for CreateVernUtil.fillWithZeros (FCSDREC2-2338).
 * Paste to: src/test/java/com/ford/fcsdtech/util/CreateVernUtilFillWithZerosTest.java
 */
class CreateVernUtilFillWithZerosTest {

    @Test
    @DisplayName("fillWithZeros: pads short value")
    void fillWithZeros_pads() {
        assertThat(CreateVernUtil.fillWithZeros("0", 2)).isEqualTo("00");
        assertThat(CreateVernUtil.fillWithZeros("1", 2)).isEqualTo("01");
        assertThat(CreateVernUtil.fillWithZeros("12", 2)).isEqualTo("12");
    }

    @ParameterizedTest
    @NullAndEmptySource
    @ValueSource(strings = {" ", "  "})
    @DisplayName("fillWithZeros: null/blank → all zeros")
    void fillWithZeros_blank(String input) {
        assertThat(CreateVernUtil.fillWithZeros(input, 2)).isEqualTo("00");
    }

    @ParameterizedTest
    @CsvSource({
            "ABC,8,00000ABC",
            "12345678,8,12345678"
    })
    @DisplayName("fillWithZeros: various lengths")
    void fillWithZeros_lengths(String input, int len, String expected) {
        assertThat(CreateVernUtil.fillWithZeros(input, len)).isEqualTo(expected);
    }
}
