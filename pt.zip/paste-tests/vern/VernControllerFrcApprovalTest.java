package com.ford.fcsdtech.controller;

import com.ford.fcsdtech.exception.GlobalExceptionHandler;
import com.ford.fcsdtech.models.request.GridFrcApprovalData;
import com.ford.fcsdtech.models.response.FrcApprovalResponse;
import com.ford.fcsdtech.service.CreateVernService;
import com.ford.fcsdtech.translator.DtoMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

/**
 * Coverage for VernController.saveFrcApprovalData (FCSDREC2-2338).
 * Paste to: src/test/java/com/ford/fcsdtech/controller/VernControllerFrcApprovalTest.java
 */
class VernControllerFrcApprovalTest {

    @InjectMocks
    VernController vernController;

    @Mock
    CreateVernService createVernService;

    @Mock
    DtoMapper mapper;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    @DisplayName("saveFrcApprovalData: returns 200 with service response")
    void saveFrcApprovalData_ok() {
        GridFrcApprovalData request = new GridFrcApprovalData();
        request.setGlobalFSANumber(21345);
        request.setFsaTitle("Brake Air Bag");
        request.setFrcApprovalDate("2021-10-25");
        request.setFsaType("C");
        request.setSupplementId("00");
        request.setApprovedBy("approver");

        FrcApprovalResponse body = FrcApprovalResponse.builder()
                .globalFsaNumber(21345)
                .supplementId("00")
                .frcApprovalDate("2021-10-25")
                .initiatingHub("NA")
                .localFsaNumber("26S01")
                .message("FRC approval recorded successfully for FSA")
                .build();

        when(createVernService.saveGridFrcApprovalData(any(GridFrcApprovalData.class))).thenReturn(body);

        ResponseEntity<FrcApprovalResponse> response = vernController.saveFrcApprovalData(request);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals("26S01", response.getBody().getLocalFsaNumber());
        assertEquals(21345, response.getBody().getGlobalFsaNumber());
        verify(createVernService, times(1)).saveGridFrcApprovalData(request);
    }

    @Test
    @DisplayName("saveFrcApprovalData: VernNotFoundException propagates")
    void saveFrcApprovalData_notFound() {
        when(createVernService.saveGridFrcApprovalData(any()))
                .thenThrow(new GlobalExceptionHandler.VernNotFoundException("not found"));

        assertThrows(GlobalExceptionHandler.VernNotFoundException.class,
                () -> vernController.saveFrcApprovalData(new GridFrcApprovalData()));
    }
}
