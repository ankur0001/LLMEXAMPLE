package com.ford.fcsdtech.service;

import com.ford.fcsdtech.configuration.WebClientAdConfiguration;
import com.ford.fcsdtech.entities.GridEntityId;
import com.ford.fcsdtech.entities.GridVernEntity;
import com.ford.fcsdtech.exception.GlobalExceptionHandler;
import com.ford.fcsdtech.models.request.LocalFSARequest;
import com.ford.fcsdtech.models.response.LocalFsaCreateResponse;
import com.ford.fcsdtech.repo.GridVernRepo;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.http.MediaType;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.time.LocalDate;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

/**
 * Coverage for CreateVernHelper LFSA WebClient methods (FCSDREC2-2338).
 * Paste to: src/test/java/com/ford/fcsdtech/service/CreateLocalFsaWebClientHelperTest.java
 *
 * Matches existing CreateVernHelperTest WebClient mock style.
 */
class CreateLocalFsaWebClientHelperTest {

    @Mock private GridVernRepo gridVernRepo;
    @Mock private CreateVernSoftwareCriteria createVernSoftwareCriteria;
    @Mock private CreateVernVehicleCriteria createVernVehicleCriteria;
    @Mock private WebClient webClient;
    @Mock private LdapService ldapService;
    @Mock private WebClientAdConfiguration webClientAdConfiguration;

    @InjectMocks
    private CreateVernHelper createVernHelper;

    @Mock private WebClient.RequestBodyUriSpec requestBodyUriSpec;
    @Mock private WebClient.RequestBodySpec requestBodySpec;
    @Mock private WebClient.RequestHeadersSpec requestHeadersSpec;
    @Mock private WebClient.ResponseSpec responseSpec;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        ReflectionTestUtils.setField(createVernHelper, "scope", "api://fsa/.default");
        when(webClientAdConfiguration.getAccessToken(anyString())).thenReturn("token");
    }

    private GridVernEntity vern() {
        GridVernEntity entity = new GridVernEntity();
        entity.setGridVernId(new GridEntityId(2024, 1, 1, 1, "00"));
        entity.setGlobalFSANumber(21345);
        entity.setInitiatingHubDesc("NA Hub");
        entity.setFsaTitle("Brake Title");
        entity.setFrcApprovalDate(LocalDate.of(2021, 10, 25));
        return entity;
    }

    private void stubPostChainForLocalCreate(LocalFsaCreateResponse body) {
        when(webClient.post()).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.uri("/api/v1/local/create")).thenReturn(requestBodySpec);
        when(requestBodySpec.contentType(MediaType.APPLICATION_JSON)).thenReturn(requestBodySpec);
        when(requestBodySpec.header(anyString(), anyString())).thenReturn(requestBodySpec);
        when(requestBodySpec.body(any(), eq(LocalFSARequest.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.onStatus(any(), any())).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(LocalFsaCreateResponse.class)).thenReturn(Mono.just(body));
    }

    private void stubPostChainForAllHub() {
        when(webClient.post()).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.uri("/api/v1/local/create/allhub")).thenReturn(requestBodySpec);
        when(requestBodySpec.contentType(MediaType.APPLICATION_JSON)).thenReturn(requestBodySpec);
        when(requestBodySpec.header(anyString(), anyString())).thenReturn(requestBodySpec);
        when(requestBodySpec.body(any(), eq(LocalFSARequest.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.onStatus(any(), any())).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(Void.class)).thenReturn(Mono.empty());
    }

    @Test
    @DisplayName("createLocalFsa: sync POST /create returns LocalFsaCreateResponse")
    void createLocalFsa_success() {
        LocalFsaCreateResponse body = LocalFsaCreateResponse.builder()
                .id(new LocalFsaCreateResponse.LocalFsaIdResponse(21345, "26S01", "NA"))
                .build();
        stubPostChainForLocalCreate(body);

        LocalFSARequest request = LocalFSARequest.builder()
                .globalFsaNumber("21345")
                .flag("I")
                .hub("NA")
                .build();

        LocalFsaCreateResponse result = createVernHelper.createLocalFsa(request);

        assertThat(result.getLocalFsaNumber()).isEqualTo("26S01");
        verify(requestBodyUriSpec).uri("/api/v1/local/create");
    }

    @Test
    @DisplayName("createLocalFsa: error → RecallRunTimeException")
    void createLocalFsa_error() {
        when(webClient.post()).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.uri(anyString())).thenReturn(requestBodySpec);
        when(requestBodySpec.contentType(any())).thenReturn(requestBodySpec);
        when(requestBodySpec.header(anyString(), anyString())).thenReturn(requestBodySpec);
        when(requestBodySpec.body(any(), eq(LocalFSARequest.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.onStatus(any(), any())).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(LocalFsaCreateResponse.class))
                .thenReturn(Mono.error(new RuntimeException("boom")));

        assertThrows(GlobalExceptionHandler.RecallRunTimeException.class,
                () -> createVernHelper.createLocalFsa(LocalFSARequest.builder().globalFsaNumber("1").build()));
    }

    @Test
    @DisplayName("createLocalFsaForAllHub: sync create then async allhub")
    void createLocalFsaForAllHub_callsSyncThenAsync() {
        LocalFsaCreateResponse body = LocalFsaCreateResponse.builder()
                .id(new LocalFsaCreateResponse.LocalFsaIdResponse(21345, "26S01", "NA"))
                .build();

        // First call = /create, second = /allhub — use Answer on uri
        when(webClient.post()).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.uri(anyString())).thenReturn(requestBodySpec);
        when(requestBodySpec.contentType(any())).thenReturn(requestBodySpec);
        when(requestBodySpec.header(anyString(), anyString())).thenReturn(requestBodySpec);
        when(requestBodySpec.body(any(), eq(LocalFSARequest.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.onStatus(any(), any())).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(LocalFsaCreateResponse.class)).thenReturn(Mono.just(body));
        when(responseSpec.bodyToMono(Void.class)).thenReturn(Mono.empty());

        LocalFsaCreateResponse result = createVernHelper.createLocalFsaForAllHub(
                vern(), "NA", "SC", "approver");

        assertThat(result.getLocalFsaNumber()).isEqualTo("26S01");
        verify(requestBodyUriSpec, atLeastOnce()).uri("/api/v1/local/create");
        verify(requestBodyUriSpec, atLeastOnce()).uri("/api/v1/local/create/allhub");
    }

    @Test
    @DisplayName("invokeCreateLocalFsaForAllHub: exception during setup is swallowed")
    void invokeCreateLocalFsaForAllHub_swallowsSetupError() {
        when(webClient.post()).thenThrow(new RuntimeException("no client"));

        // should not throw
        ReflectionTestUtils.invokeMethod(
                createVernHelper,
                "invokeCreateLocalFsaForAllHub",
                LocalFSARequest.builder().globalFsaNumber("21345").build());
    }

    @Test
    @DisplayName("getLocalFSARequest: sets updateGlobalFrcApproval + frcDecisionDate")
    void getLocalFSARequest_setsFrcFlags() throws Exception {
        var method = CreateVernHelper.class.getDeclaredMethod(
                "getLocalFSARequest", GridVernEntity.class, String.class, String.class, String.class);
        method.setAccessible(true);
        LocalFSARequest request = (LocalFSARequest) method.invoke(null, vern(), "NA", "SC", "cds1");

        assertThat(request).isNotNull();
        assertThat(request.getGlobalFsaNumber()).isEqualTo("21345");
        assertThat(request.getHub()).isEqualTo("NA");
        assertThat(request.getFsaType()).isEqualTo("SC");
        assertThat(request.getCdsld()).isEqualTo("cds1");
        assertThat(request.getLocalFsaDesc()).isEqualTo("Brake Title");
        assertThat(request.isUpdateGlobalFrcApproval()).isTrue();
        assertThat(request.getFrcDecisionDate()).isEqualTo("2021-10-25");
        assertThat(request.getAddTandemFlag()).isEqualTo("N");
    }
}
